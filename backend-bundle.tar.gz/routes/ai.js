const express = require('express');
const crypto = require('crypto');
const EmailNotifier = require('../services/emailNotifier');
const { executeContentOperation, executeResumeParsing, extractJson, loadProviderConfiguration, generateWithProviders, parseAiResponse } = require('../services/aiRuntime');
const router = express.Router();

async function generateConfiguredText(req, res, prompt, operation, overrides = {}) {
    const configuration = await loadProviderConfiguration(req.app.get('db'));
    if (overrides.temperature !== undefined) configuration.temperature = overrides.temperature;
    if (overrides.maxTokens !== undefined) configuration.maxTokens = overrides.maxTokens;
    const generated = await generateWithProviders({ prompt, configuration, operation, signal: overrides.signal || req.aiAbortSignal, timeoutMs: overrides.timeoutMs });
    if (res?.setHeader && !res.headersSent) {
        res.setHeader('X-AI-Provider', generated.provider);
        res.setHeader('X-AI-Model', generated.model);
    }
    return generated.raw;
}

function notifyAiResumeReady(req, userName) {
    if (!req.user?.email) return;
    EmailNotifier.notifyAIResumeReady(req.app.get('db'), {
        userEmail: req.user.email,
        userName: String(userName || 'Candidate').slice(0, 120),
        atsScore: 'Not measured',
    }).catch(error => console.warn('[AI notifier]', error.message));
}

// Provider credentials are server-owned. Scope validation strictly to AI routes because this
// router is mounted at /api for legacy endpoint compatibility.
const AI_ROUTE_PATHS = new Set([
    '/generate-resume', '/generate-summary', '/generate-interview', '/generate-work-description',
    '/generate-education-description', '/generate-skills', '/check-grammar', '/generate-content',
    '/parse-resume',
]);
router.use((req, res, next) => {
    if (!AI_ROUTE_PATHS.has(req.path)) return next();
    const requestController = new AbortController();
    req.aiAbortSignal = requestController.signal;
    req.once('aborted', () => requestController.abort());
    if (req.method === 'GET') return next();
    if (Object.prototype.hasOwnProperty.call(req.body || {}, 'apiKey') || req.get('x-gemini-api-key')) {
        return res.status(400).json({ error: { code: 'CLIENT_AI_KEY_REJECTED', message: 'Client-supplied AI credentials are not accepted', requestId: res.locals.requestId } });
    }
    const identityFields = ['uid', 'userId', 'ownerUid', 'resumeId', 'profileId'];
    if (identityFields.some(field => Object.hasOwn(req.body || {}, field) || Object.hasOwn(req.body?.payload || {}, field))) {
        return res.status(400).json({ error: { code: 'CLIENT_AI_IDENTITY_REJECTED', message: 'AI identity and ownership context is server-controlled', requestId: res.locals.requestId } });
    }
    const serialized = JSON.stringify(req.body || {});
    if (serialized.length > 50_000) {
        return res.status(413).json({ error: { code: 'AI_INPUT_TOO_LARGE', message: 'AI input exceeds the allowed size', requestId: res.locals.requestId } });
    }
    return next();
});

// Resume generation endpoint
router.post('/generate-resume', async (req, res) => {
    try {
        const { occupation, experienceLevel, skills = [], education = [], language = 'en', userName } = req.body;
        if (typeof occupation !== 'string' || !occupation.trim() || occupation.length > 160
            || !Array.isArray(skills) || !Array.isArray(education) || skills.length > 50 || education.length > 30) {
            return res.status(400).json({ error: { code: 'INVALID_AI_INPUT', message: 'Valid occupation, skills, and education are required', requestId: res.locals.requestId } });
        }

        // Language mapping for proper language names in prompt
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };

        const targetLanguage = languageNames[language] || 'English';

        // Get years of experience range based on experience level
        let yearsOfExperience;
        let positionLevel;
        let currentYear = new Date().getFullYear();
        let cleanOccupation = occupation.trim();
        let positionTitle;

        // Setup basic variables based on experience level first
        switch (experienceLevel) {
            case 'entry-level':
                yearsOfExperience = { min: 0, max: 2 };
                positionLevel = 'Junior';
                break;
            case 'mid-level':
                yearsOfExperience = { min: 3, max: 5 };
                positionLevel = '';
                break;
            case 'senior-level':
                yearsOfExperience = { min: 6, max: 12 };
                positionLevel = 'Senior';
                break;
            default:
                yearsOfExperience = { min: 3, max: 5 };
                positionLevel = '';
        }

        // Format position title with level
        positionTitle = positionLevel ? `${positionLevel} ${cleanOccupation}` : cleanOccupation;

        // Build the established complete-resume prompt, then execute it through the
        // configured secure server-side provider chain.
        const prompt = `
        Generate a professional resume content for a ${positionTitle} with ${yearsOfExperience.max} years of experience.
        
        IMPORTANT: Generate ALL content in ${targetLanguage}. This includes all text, descriptions, and field values.
        
        Specific info:
        - Occupation: ${cleanOccupation}
        - Experience level: ${experienceLevel} (${yearsOfExperience.min}-${yearsOfExperience.max} years)
        - Skills: ${skills.length > 0 ? skills.join(', ') : 'Generate appropriate skills for this role'}
        - Education: ${education.length > 0 ? education.join(', ') : 'Generate appropriate education background'}
        - Target Language: ${targetLanguage}
        
        Generate a realistic professional summary, work experiences with achievements, education history, and relevant skills. 
        Please provide a COMPREHENSIVE profile with AT LEAST 3 employment entries and AT LEAST 3 education entries.
        
        Return the results in a structured JSON format with the following fields:
        1. firstname: A common first name in ${targetLanguage}
        2. lastname: A common last name in ${targetLanguage}
        3. email: A professional email based on the name
        4. phone: A realistic phone number in (555) 123-4567 format
        5. occupation: The exact job title provided
        6. country: A country where ${targetLanguage} is spoken
        7. city: A city in that country
        8. address: A generic address in ${targetLanguage}
        9. summary: A well-written professional summary paragraph in ${targetLanguage}
        10. employments: An array of AT LEAST 3 employment objects each containing:
            - id: A numeric ID (1, 2, etc.)
            - jobTitle: Job title in ${targetLanguage}, showing progression if multiple jobs
            - employer: Company name
            - begin: Start year (based on experience range)
            - end: End year or "Present" for current job
            - description: 3-4 bullet points of achievements in ${targetLanguage}
            - date: A timestamp
        11. educations: An array of AT LEAST 3 education objects each containing:
            - id: A numeric ID
            - school: School name (use provided education if available)
            - degree: Relevant degree name in ${targetLanguage}
            - started: Start year
            - finished: End year
            - description: Brief description in ${targetLanguage}
            - date: A timestamp
        12. languages: An array of language objects, EXACTLY in this format:
            [
              {
                "id": 1,
                "name": "${targetLanguage}",
                "level": "Native",
                "date": 1718348693123
              },
              {
                "id": 2,
                "name": "English",
                "level": "Intermediate",
                "date": 1718348693000
              }
            ]
        13. skills: An array of AT LEAST 8 skill objects, EXACTLY in this format:
            [
              {
                "id": 1,
                "name": "JavaScript",
                "rating": 4,
                "date": 1718348693123
              },
              {
                "id": 2,
                "name": "React",
                "rating": 5,
                "date": 1718348693000
              }
            ]
        
        Important: Ensure that skills and languages are properly formatted with "name" fields for each item. Do not change the field names in the output.
        ALL TEXT CONTENT must be in ${targetLanguage}.
        Only return the JSON without any explanation or additional text.
        `;

        const configuration = await loadProviderConfiguration(req.app.get('db'));
        configuration.maxTokens = Math.max(configuration.maxTokens, 4096);
        const generated = await generateWithProviders({ prompt, configuration, operation: 'generate-resume', signal: req.aiAbortSignal, timeoutMs: 45_000 });
        const text = generated.raw;
        res.setHeader('X-AI-Provider', generated.provider);
        res.setHeader('X-AI-Model', generated.model);

        // Parse provider JSON with the same tolerant fenced/prose extraction used by section AI.
        try {
            const resumeData = extractJson(text);
            if (!resumeData || typeof resumeData !== 'object' || Array.isArray(resumeData)) throw new Error('Invalid resume response');
            let recovery;
            const getRecovery = () => recovery || (recovery = generateDefaultResumeData(cleanOccupation, experienceLevel, yearsOfExperience, positionTitle, currentYear, skills, education, targetLanguage));
            for (const section of ['employments', 'educations', 'skills', 'languages']) {
                if (!Array.isArray(resumeData[section]) || resumeData[section].length === 0) resumeData[section] = getRecovery()[section];
            }
            resumeData.occupation = resumeData.occupation || positionTitle;
            resumeData.summary = resumeData.summary || getRecovery().summary;
            resumeData._source = 'ai';

            // Validate and fix skills format if needed
            if (resumeData.skills && Array.isArray(resumeData.skills)) {
                resumeData.skills = resumeData.skills.map((skill, index) => {
                    // Ensure skills have the required format
                    return {
                        id: skill.id || index + 1,
                        name: skill.name || skill.skill || skill.title || `Skill ${index + 1}`,
                        rating: skill.rating || skill.level || 4,
                        date: Date.now() - index * 1000,
                    };
                });
            }

            // Validate and fix languages format if needed
            if (resumeData.languages && Array.isArray(resumeData.languages)) {
                resumeData.languages = resumeData.languages.map((language, index) => {
                    // Ensure languages have the required format
                    return {
                        id: language.id || index + 1,
                        name: language.name || language.language || `Language ${index + 1}`,
                        level: language.level || 'Intermediate',
                        date: Date.now() - index * 1000,
                    };
                });
            }

            const safeText = (value, max = 10000) => {
                const withoutMarkup = String(value || '')
                    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                    .replace(/<[^>]*>/g, '');
                return Array.from(withoutMarkup, character => {
                    const code = character.charCodeAt(0);
                    if (code === 10) return '\n';
                    return code <= 31 || code === 127 ? '' : character;
                }).join('').trim().slice(0, max);
            };
            const safeResume = {
                firstname: safeText(resumeData.firstname, 100), lastname: safeText(resumeData.lastname, 100),
                email: safeText(resumeData.email, 254), phone: safeText(resumeData.phone, 50),
                occupation: safeText(resumeData.occupation, 160), country: safeText(resumeData.country, 100),
                city: safeText(resumeData.city, 100), address: safeText(resumeData.address, 300),
                postalcode: safeText(resumeData.postalcode, 30), summary: safeText(resumeData.summary),
                employments: resumeData.employments.slice(0, 20).map((item, index) => ({
                    id: Number(item?.id) || index + 1, jobTitle: safeText(item?.jobTitle || item?.title, 160),
                    employer: safeText(item?.employer || item?.company, 160), begin: safeText(item?.begin || item?.startDate, 30),
                    end: safeText(item?.end || item?.endDate, 30), description: safeText(item?.description), date: Date.now() - index * 1000,
                })),
                educations: resumeData.educations.slice(0, 20).map((item, index) => ({
                    id: Number(item?.id) || index + 1, school: safeText(item?.school, 200), degree: safeText(item?.degree, 200),
                    started: safeText(item?.started || item?.startDate, 30), finished: safeText(item?.finished || item?.endDate, 30),
                    description: safeText(item?.description), date: Date.now() - index * 1000,
                })),
                skills: resumeData.skills.slice(0, 50).map((item, index) => ({
                    id: Number(item?.id) || index + 1, name: safeText(item?.name, 100),
                    rating: Math.min(100, Math.max(0, Number(item?.rating) || 4)), date: Date.now() - index * 1000,
                })).filter(item => item.name),
                languages: resumeData.languages.slice(0, 20).map((item, index) => ({
                    id: Number(item?.id) || index + 1, name: safeText(item?.name, 100),
                    level: safeText(item?.level, 50), date: Date.now() - index * 1000,
                })).filter(item => item.name),
                _source: 'ai',
            };
            notifyAiResumeReady(req, userName);
            res.json(safeResume);
        } catch (error) {
            console.error('Failed to parse JSON from AI response:', error);
            const fallbackData = generateDefaultResumeData(cleanOccupation, experienceLevel, yearsOfExperience, positionTitle, currentYear, skills, education, targetLanguage);
            notifyAiResumeReady(req, userName);
            res.json(fallbackData);
        }
    } catch (error) {
        console.error('Error generating AI content:', error);
        // Use fallback method if AI generation fails
        const { occupation, experienceLevel, skills = [], education = [], language = 'en' } = req.body;
        const currentYear = new Date().getFullYear();

        let yearsOfExperience;
        let positionLevel;

        switch (experienceLevel) {
            case 'entry-level':
                yearsOfExperience = { min: 0, max: 2 };
                positionLevel = 'Junior';
                break;
            case 'mid-level':
                yearsOfExperience = { min: 3, max: 5 };
                positionLevel = '';
                break;
            case 'senior-level':
                yearsOfExperience = { min: 6, max: 12 };
                positionLevel = 'Senior';
                break;
            default:
                yearsOfExperience = { min: 3, max: 5 };
                positionLevel = '';
        }

        const cleanOccupation = occupation.trim();
        const positionTitle = positionLevel ? `${positionLevel} ${cleanOccupation}` : cleanOccupation;

        const fallbackData = generateDefaultResumeData(cleanOccupation, experienceLevel, yearsOfExperience, positionTitle, currentYear, skills, education, language);
        notifyAiResumeReady(req, req.body.userName);
        res.json(fallbackData);
    }
});

// Summary generation endpoint
router.post('/generate-summary', async (req, res) => {
    try {
        const { name, jobTitle, experience, workHistory, education, projects, skills, certifications, achievement, summaryType, language = 'en' } = req.body;


        // Language mapping for proper language names in prompt
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };

        const targetLanguage = languageNames[language] || 'English';
        console.log('Summary target language mapped to:', targetLanguage);

        // Prepare prompt based on summaryType
        let styleGuidance = '';
        switch (summaryType) {
            case 'professional':
                styleGuidance = 'Create a formal, concise professional summary focusing on expertise and achievements.';
                break;
            case 'creative':
                styleGuidance = 'Create a creative, engaging summary that highlights unique qualities while remaining professional.';
                break;
            case 'achievement':
                styleGuidance = 'Create an achievement-focused summary that emphasizes measurable results and impact.';
                break;
            default:
                styleGuidance = 'Create a formal, concise professional executive summary synthesizing complete candidate history.';
        }

        // Clean experience string for prompt
        let expSpan = experience || '3+ years';
        if (typeof expSpan === 'string' && (expSpan.length > 25 || expSpan.includes(' at ') || expSpan.includes(';'))) {
            expSpan = 'several years';
        }

        // Prepare the prompt for Gemini
        const prompt = `
        You are a Fortune 500 Senior Recruiter and Executive Resume Editor. ${styleGuidance}

        CRITICAL REQUIREMENT: You MUST write everything in ${targetLanguage}. Do NOT use English if the target language is not English.
        ${targetLanguage === 'Spanish' ? 'ESCRIBIR EN ESPAÑOL SOLAMENTE. NO USAR INGLÉS.' : ''}
        ${targetLanguage === 'French' ? "ÉCRIRE EN FRANÇAIS SEULEMENT. NE PAS UTILISER L'ANGLAIS." : ''}
        
        LANGUAGE: ${targetLanguage}
        TARGET LANGUAGE: ${targetLanguage}
        WRITE IN: ${targetLanguage}
        RESPONSE LANGUAGE: ${targetLanguage}

        Synthesize this candidate's complete professional profile into a 10/10 human-written, ATS-optimized Executive Resume Summary (2-3 sentences, 50-70 words maximum):
        - Candidate Name: ${name || 'Professional'}
        - Target Role/Occupation: "${jobTitle || 'Professional'}"
        - Calculated Experience Span: ${expSpan}
        - Work History & Roles: ${workHistory || experience || 'Solid industry track record'}
        - Academic Education: ${education || 'Higher education background'}
        - Core Technical Skills: ${skills || 'Key industry skills'}
        - Professional Certifications & Accreditations: ${certifications || 'None specified'}
        - Major Projects & Accomplishments: ${projects || achievement || 'Delivered key organizational outcomes'}
        
        STRICT 10/10 NATURAL HUMAN VOICE RULES:
        1. PUNCHY 2-3 SENTENCE RESUME STRUCTURE:
           - Sentence 1: Start directly with role identity and primary tech domain (e.g., "${jobTitle || 'Full-Stack Engineer'} with ${expSpan} of experience in Full-Stack Engineering, Cloud Architecture, and DevOps.").
           - Sentence 2: Summarize actual accomplishments from work history (e.g., "Proven track record modernizing API architectures, optimizing backend database performance, and building automated CI/CD pipelines.").
           - Sentence 3: Highlight technical stack and industry focus (e.g., "Proficient in Node.js, React, and AWS cloud solutions focused on high-availability system scalability.").
        2. BAN COVER LETTER FLUFF: NEVER write cover letter phrases like "I would bring immediate strategic value to your organization", "make a tangible impact from day one", or "leveraging my expertise to drive business growth". This is a RESUME SUMMARY!
        3. BAN ROBOTIC AI CLICHÉS: Eliminate "seasoned professional", "proven track record of", "resulting in significant performance gains", "spearheaded", "leveraged", "utilize", "fostered", "tapestry", "beacon", "testament".
        4. NO PLACEHOLDERS: Write 100% complete, ready-to-use sentences.
        
        ONLY return the summary text without any surrounding quotes, tags, or markdown wrapper.
        `;

        const summary = await generateConfiguredText(req, res, prompt, 'generate-summary');
        return res.json({ summary });
    } catch (error) {
        console.error('Error generating AI summary:', error);
        // Use fallback method if AI generation fails
        const { name, jobTitle, experience, skills, achievement, summaryType, language = 'en' } = req.body;
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };
        const targetLanguage = languageNames[language] || 'English';
        console.log('Using fallback summary for language:', targetLanguage);
        const fallbackSummary = generateFallbackSummary(name, jobTitle, experience, skills, achievement, summaryType, targetLanguage);
        return res.json({ summary: fallbackSummary });
    }
});

// ── Interview question generation helpers (Contextual Blueprint + Anti-Leakage) ─────
const INTERVIEW_PROMPT_CONTEXT = {
    technical: 'technical architecture, core frameworks, systems design, debugging edge cases, and engineering trade-offs',
    behavioral: 'STAR-format scenarios, cross-functional leadership, conflict resolution, ownership, and stakeholder negotiation',
    hr: 'organizational culture fit, career progression, collaboration dynamics, communication style, and workplace ethics',
    managerial: 'strategic resource allocation, team performance management, hiring standards, prioritization, and executive communication',
    case: 'structured business case reasoning, market estimation, root cause diagnosis, unit economics, and data-backed decision making',
    mixed: 'a comprehensive balance of technical depth, real-world troubleshooting, system trade-offs, and behavioral leadership scenarios',
};

const INTERVIEW_DIFFICULTY_GUIDANCE = {
    easy: 'Focus the set on foundational execution and established best practices with clear criteria.',
    medium: 'Balance practical application, debugging multi-step failures, and nuanced trade-offs.',
    hard: 'Focus on complex systems design, incident triage, edge-case failure modes, and senior-level decision making.',
    expert: 'Focus on enterprise-scale architecture, high-stakes ambiguity, crisis recovery, and strategic organizational trade-offs.',
};

function interviewDifficultyWeights(difficulty) {
    const d = String(difficulty || 'medium').toLowerCase();
    if (d === 'easy') return { easy: 0.6, intermediate: 0.3, advanced: 0.1 };
    if (d === 'hard') return { easy: 0.15, intermediate: 0.4, advanced: 0.45 };
    if (d === 'expert') return { easy: 0.05, intermediate: 0.3, advanced: 0.65 };
    return { easy: 0.35, intermediate: 0.45, advanced: 0.2 };
}

// Compute an exact Easy/Intermediate/Advanced split (sums to questionCount) from the
// requested difficulty and seniority so the difficulty control actually shapes the set.
function interviewDifficultyDistribution(questionCount, difficulty, experienceLevel) {
    const count = Math.min(Math.max(parseInt(questionCount) || 10, 5), 20);
    const weights = interviewDifficultyWeights(difficulty);
    let easy = Math.round(count * weights.easy);
    let intermediate = Math.round(count * weights.intermediate);
    let advanced = count - easy - intermediate;
    const senior = ['senior', 'lead', 'executive', 'staff', 'principal', 'expert'].some(term =>
        String(experienceLevel || '').toLowerCase().includes(term));
    if (senior && advanced < count && easy > 0) { advanced += 1; easy -= 1; }
    if (advanced < 0) { intermediate += advanced; advanced = 0; }
    if (easy < 0) { intermediate += easy; easy = 0; }
    if (intermediate < 0) { easy += intermediate; intermediate = 0; }
    return { easy, intermediate, advanced };
}

function sanitizePromptFragment(value, max = 500) {
    return Array.from(String(value ?? ''), ch => {
        const code = ch.charCodeAt(0);
        if (code === 9 || code === 10 || code === 13) return ' ';
        return code <= 31 || code === 127 ? '' : ch;
    }).join('').replace(/<[^>]*>/g, '').trim().slice(0, max);
}

// Deterministic multi-pass cleaner to strip any leaked UI labels, form headers, or robotic preambles.
function cleanInterviewMetadataArtifacts(text) {
    if (typeof text !== 'string') return '';
    let cleaned = text.trim();

    let prev = '';
    let passes = 0;
    while (cleaned !== prev && passes < 4) {
        prev = cleaned;
        passes++;

        // 1. Strip raw field labels with their immediate values (e.g. "Target Role & Discipline: Senior Software Engineer.")
        cleaned = cleaned.replace(/^(?:(?:(?:For (?:the )?)?(?:Target )?Role & Discipline|(?:For (?:the )?)?(?:Target )?Job Description|(?:For (?:the )?)?(?:Target )?Role|(?:For (?:the )?)?Discipline)\s*:\s*[^.?!:;\n]{1,80}[.?!:;\n]\s*)+/gi, '');

        // 2. Strip bracketed tags and UI headers at start
        cleaned = cleaned.replace(/^\[\s*(?:AI Tailoring|Target Job Description|Target Role & Discipline|Target Role|Job Description)\s*\]\s*[:.\-—]?\s*/gi, '');
        cleaned = cleaned.replace(/^(?:Target Role & Discipline|Target Job Description \(Optional\s*[-—]\s*AI Tailoring\)|Target Job Description|Optional\s*[-—]\s*AI Tailoring|AI Tailoring|Target Role|Target Discipline|Candidate Profile|Setup Parameters|Job Requirements Specification)\s*[:.\-—]?\s*/gi, '');

        // 3. Strip robotic contextual preambles and introductory framing clauses at start of question
        cleaned = cleaned.replace(/^(?:(?:Based on|According to|Considering|In light of|In the context of|With respect to|As mentioned in|As stated in|Referencing)\s+(?:the\s+)?(?:target\s+)?(?:job description|role|discipline|resume|candidate profile|candidate background|provided context|setup|requirements|overview)[^:?,.]{0,150}[:?,.]\s*)+/gi, '');
        cleaned = cleaned.replace(/^(?:For the (?:target )?role(?: and discipline)?[^:?,.]{0,150}[:?,.]\s*)+/gi, '');
        cleaned = cleaned.replace(/^(?:Given (?:the |your )?(?:candidate(?:'s)? )?(?:background|profile|job description|role|experience|context)[^:?,.]{0,150}[:?,.]\s*)+/gi, '');
        cleaned = cleaned.replace(/^(?:As an? (?:candidate for (?:the )?)?[^:?,.]{0,80}(?:engineer|developer|manager|specialist|analyst|architect|consultant|lead|director|professional|role|position|job)[^:?,.]{0,40}[:?,.]\s*)+/gi, '');

        // 4. Strip raw UI headers and field tags anywhere remaining
        cleaned = cleaned.replace(/\b(?:Target Role & Discipline|Target Job Description \(Optional\s*[-—]\s*AI Tailoring\)|Target Job Description|Optional\s*[-—]\s*AI Tailoring|AI Tailoring)\b\s*[:.\-—]?\s*/gi, '');
        cleaned = cleaned.replace(/\b(?:Target Role|Target Discipline|Candidate Profile|Setup Parameters|Job Requirements Specification)\s*:/gi, '');
        cleaned = cleaned.replace(/[^\S\r\n]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
    }

    if (cleaned.length > 0) {
        cleaned = cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
    }
    return cleaned;
}

// Banned generic question patterns
const GENERIC_QUESTION_PATTERNS = [
    /^(?:tell me about yourself|what are your (?:greatest )?(?:strengths|weaknesses)|why should we hire you|why do you want to work here)\b/i,
    /^(?:what is your experience with|what tools (?:or technologies )?do you use|what is your background in)\b/i,
    /^(?:what is [a-z0-9+#.\s]{2,30}\?|explain what [a-z0-9+#.\s]{2,30} is\b)/i,
    /^(?:how do you handle challenges|what are your career goals|where do you see yourself in 5 years)\b/i,
];

function isGenericQuestion(text) {
    if (typeof text !== 'string' || text.trim().length < 15) return true;
    const clean = text.trim();
    return GENERIC_QUESTION_PATTERNS.some(p => p.test(clean));
}

// Extract confirmed candidate evidence (Level 1)
function extractCandidateProfile(resumeFacts) {
    if (!resumeFacts || typeof resumeFacts !== 'string') {
        return { name: '', occupation: '', summary: '', work: [], skills: [], projects: [], certs: [], education: [], confirmedExperience: '' };
    }
    const cleanFacts = cleanInterviewMetadataArtifacts(resumeFacts);
    const lines = cleanFacts.split('\n').map(l => l.trim()).filter(Boolean);
    let name = '';
    let occupation = '';
    let summary = '';
    const work = [];
    const skills = [];
    const projects = [];
    const certs = [];
    const education = [];

    for (const line of lines) {
        if (/^Name:\s*/i.test(line)) name = line.replace(/^Name:\s*/i, '').trim();
        else if (/^Occupation:\s*/i.test(line)) occupation = line.replace(/^Occupation:\s*/i, '').trim();
        else if (/^Summary:\s*/i.test(line)) summary = line.replace(/^Summary:\s*/i, '').trim();
        else if (/^Work:\s*/i.test(line)) {
            const raw = line.replace(/^Work:\s*/i, '');
            raw.split(';').map(w => w.trim()).filter(Boolean).forEach(w => work.push(w));
        }
        else if (/^Skills:\s*/i.test(line)) {
            const raw = line.replace(/^Skills:\s*/i, '');
            raw.split(',').map(s => s.trim()).filter(Boolean).forEach(s => skills.push(s));
        }
        else if (/^Projects:\s*/i.test(line)) {
            const raw = line.replace(/^Projects:\s*/i, '');
            raw.split(',').map(p => p.trim()).filter(Boolean).forEach(p => projects.push(p));
        }
        else if (/^Certifications:\s*/i.test(line)) {
            const raw = line.replace(/^Certifications:\s*/i, '');
            raw.split(',').map(c => c.trim()).filter(Boolean).forEach(c => certs.push(c));
        }
        else if (/^Education:\s*/i.test(line)) {
            const raw = line.replace(/^Education:\s*/i, '');
            raw.split(';').map(e => e.trim()).filter(Boolean).forEach(e => education.push(e));
        }
    }

    const confirmedParts = [];
    if (name) confirmedParts.push(`Name: ${name}`);
    if (occupation) confirmedParts.push(`Current/Stated Role: ${occupation}`);
    if (work.length) confirmedParts.push(`Confirmed Work History: ${work.slice(0, 6).join('; ')}`);
    if (skills.length) confirmedParts.push(`Confirmed Skills/Tech: ${skills.slice(0, 16).join(', ')}`);
    if (projects.length) confirmedParts.push(`Confirmed Projects: ${projects.slice(0, 5).join(', ')}`);
    if (certs.length) confirmedParts.push(`Confirmed Certifications: ${certs.slice(0, 6).join(', ')}`);
    if (summary) confirmedParts.push(`Summary: ${summary.slice(0, 300)}`);

    return {
        name,
        occupation,
        summary,
        work,
        skills,
        projects,
        certs,
        education,
        confirmedExperience: confirmedParts.join('\n'),
    };
}

// Extract normalized JD requirements specification (Level 4)
function extractJobRequirements(jobDescription, occupation = '') {
    if (!jobDescription || typeof jobDescription !== 'string') {
        return { raw: '', role: occupation, cleanRequirements: '' };
    }
    const cleanJd = cleanInterviewMetadataArtifacts(jobDescription).slice(0, 3500);
    return {
        raw: jobDescription,
        role: occupation,
        cleanRequirements: cleanJd,
    };
}

// Build internal contextual interview blueprint
function buildContextualBlueprint({ occupation, interviewType, experienceLevel, difficulty, candidateProfile, jdRequirements, questionCount }) {
    const jdText = (jdRequirements?.cleanRequirements || '').toLowerCase();
    const intersectingSkills = (candidateProfile?.skills || []).filter(skill => 
        jdText.includes(skill.toLowerCase())
    );

    const distribution = interviewDifficultyDistribution(questionCount, difficulty, experienceLevel);

    return {
        intersectingSkills,
        distribution,
        seniority: experienceLevel || 'professional',
    };
}

// Lowercased, punctuation-stripped, whitespace-collapsed fingerprint for comparing
// question text so we can drop exact and near-identical repeats within/across sets.
function questionKey(text) {
    const cleaned = cleanInterviewMetadataArtifacts(String(text || ''));
    return cleaned.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, '').replace(/\s+/g, ' ').trim();
}

// Deterministic, bounded de-duplication with metadata artifact cleaning.
function dedupeQuestions(rawQuestions, previousQuestions = []) {
    if (!Array.isArray(rawQuestions)) return [];
    const previousKeys = new Set((Array.isArray(previousQuestions) ? previousQuestions : [])
        .filter(q => typeof q === 'string').map(q => questionKey(q)));
    const seen = new Set();
    const out = [];
    for (const question of rawQuestions) {
        if (!question || typeof question !== 'object') continue;
        const rawText = typeof question.question === 'string' ? question.question.trim() : '';
        const text = cleanInterviewMetadataArtifacts(rawText);
        if (!text) continue;
        const key = questionKey(text);
        if (!key || seen.has(key)) continue;
        seen.add(key);

        const cleanOptions = (Array.isArray(question.options) ? question.options : [])
            .map(opt => cleanInterviewMetadataArtifacts(typeof opt === 'string' ? opt : String(opt || '')))
            .filter(opt => opt.length > 0);

        out.push({
            ...question,
            question: text,
            options: cleanOptions.length >= 2 ? cleanOptions : question.options,
        });
    }
    // Keep ordering but drop exact matches against recent history.
    return out.filter(question => !previousKeys.has(questionKey(question.question)));
}

function buildInterviewPrompt(input) {
    const languageNames = {
        en: 'English', es: 'Spanish', fr: 'French', de: 'German', it: 'Italian',
        pt: 'Portuguese', ru: 'Russian', nl: 'Dutch', pl: 'Polish', se: 'Swedish',
        no: 'Norwegian', dk: 'Danish', is: 'Icelandic', gk: 'Greek', ro: 'Romanian',
    };
    const rawOccupation = String(input.occupation || '').trim();
    const occupation = cleanInterviewMetadataArtifacts(rawOccupation) || 'Professional';
    const interviewType = String(input.interviewType || 'technical');
    const targetLanguage = languageNames[input.language] || 'English';
    const validQuestionCount = Math.min(Math.max(parseInt(input.questionCount) || 10, 5), 20);
    const promptContext = INTERVIEW_PROMPT_CONTEXT[interviewType] || INTERVIEW_PROMPT_CONTEXT.mixed;
    
    const safeFacts = typeof input.resumeFacts === 'string' ? input.resumeFacts.slice(0, 2500) : '';
    const safeJd = typeof input.jobDescription === 'string' ? input.jobDescription.slice(0, 4000) : '';
    const candidateProfile = extractCandidateProfile(safeFacts);
    const jdRequirements = extractJobRequirements(safeJd, occupation);
    const blueprint = buildContextualBlueprint({
        occupation,
        interviewType,
        experienceLevel: input.experienceLevel,
        difficulty: input.difficulty,
        candidateProfile,
        jdRequirements,
        questionCount: validQuestionCount,
    });

    const nonce = String(input.sessionNonce || crypto.randomBytes(8).toString('hex')).slice(0, 24);
    const difficultyLabel = String(input.difficulty || 'medium').toLowerCase();
    const difficultyGuidance = INTERVIEW_DIFFICULTY_GUIDANCE[difficultyLabel] || '';
    const exclusions = (Array.isArray(input.previousQuestions) ? input.previousQuestions : [])
        .filter(q => typeof q === 'string')
        .map(q => cleanInterviewMetadataArtifacts(sanitizePromptFragment(q, 240)))
        .filter(q => q.length > 0)
        .slice(0, 12);

    const candidateSection = candidateProfile.confirmedExperience
        ? `[LEVEL 1: CANDIDATE VERIFIED EVIDENCE]\nUse ONLY these candidate facts (do not invent experience):\n${candidateProfile.confirmedExperience}\n(MANDATORY: Use ONLY these verified facts for candidate background. NEVER invent claims or past projects.)`
        : `[LEVEL 1: CANDIDATE VERIFIED EVIDENCE]\nUse ONLY these candidate facts (do not invent experience):\nStandard industry professional profile for ${occupation}. (Do not invent fictional employer names.)`;

    const jdSection = jdRequirements.cleanRequirements
        ? `[LEVEL 4: TARGET JOB REQUIREMENTS SPECIFICATION]\nAlign some questions to this job description without fabricating requirements:\n${jdRequirements.cleanRequirements}`
        : `[LEVEL 4: TARGET JOB REQUIREMENTS SPECIFICATION]\nAlign some questions to this job description without fabricating requirements:\nStandard core competencies and production expectations for a ${occupation} position.`;

    const intersectionSection = blueprint.intersectingSkills.length
        ? `[LEVEL 2 & 3 INTERSECTION BLUEPRINT]\nConfirmed high-value intersections: ${blueprint.intersectingSkills.join(', ')}. Target these skills for deep applied scenario & trade-off questions.`
        : `[LEVEL 2 & 3 DISCIPLINE BLUEPRINT]\nAssess applied competency across the ${interviewType} domain for ${occupation}.`;

    const exclusionsSection = exclusions.length
        ? `[PRIOR ATTEMPT EXCLUSIONS]\nThe candidate already answered these questions/competencies in a recent attempt. Generate a FRESH set and DO NOT repeat or closely mirror them:\n- ${exclusions.join('\n- ')}`
        : '';

    const prompt = `
You are an Elite Principal Interviewer and Hiring Bar Raiser conducting an authentic, high-caliber professional interview for a ${occupation} position (${interviewType} track) in ${targetLanguage}.

=== CONTEXT HIERARCHY (USE SILENTLY TO SHAPE QUESTIONS — NEVER REPEAT OR MENTION METADATA) ===
${candidateSection}

[LEVEL 2 & 3: TARGET ROLE & DISCIPLINE FRAMEWORK]
- Target Role: ${occupation}
- Target Seniority: ${input.experienceLevel || 'Professional'}
- Focus Track: ${interviewType} (${promptContext})
- Difficulty Profile: ${difficultyLabel} (${difficultyGuidance})
- Difficulty distribution for this run: ${blueprint.distribution.easy} Easy, ${blueprint.distribution.intermediate} Intermediate, ${blueprint.distribution.advanced} Advanced.
${intersectionSection}

${jdSection}
${exclusionsSection ? '\n' + exclusionsSection : ''}

=== CRITICAL INTERVIEW DESIGN DIRECTIVES (NON-NEGOTIABLE) ===
1. 100% CONTEXTUAL ANCHORS:
   - Connect the candidate's actual background and target requirements into authentic, practical scenarios.
   - Questions should test applied decision-making, debugging unexpected edge cases, architecture trade-offs, performance optimization, incident triage, or behavioral STAR situations.
2. ABSOLUTE BAN ON METADATA LEAKAGE:
   - NEVER include or repeat setup labels such as "Target Role & Discipline", "Target Job Description", "AI Tailoring", "Candidate Profile", or form labels anywhere in the question, options, or explanation.
   - NEVER start questions with robotic preamble phrases such as "Based on the job description...", "As a [role]...", "According to the target role...", "Given your resume...", "In the context of the job description...".
   - Ask the question directly and naturally, exactly as an experienced human hiring manager would in a real interview room.
3. ZERO HALLUCINATION:
   - Never assert that the candidate worked with a specific platform, tool, or employer unless it is explicitly listed in [LEVEL 1: CANDIDATE VERIFIED EVIDENCE].
   - If assessing a requirement from Level 4 not present in Level 1, frame the question as an applied scenario, transition strategy, or architecture evaluation (e.g. "How would you approach optimizing X when Y occurs?").
4. ZERO GENERIC FLUFF:
   - STRICTLY BAN weak, shallow questions: "Tell me about yourself", "What are your strengths?", "What is [tool]?", "What is your experience with [tool]?".
   - Every question must test critical thinking, reasoning, metrics, or problem-solving.
5. DIVERSE ASSESSMENT ANGLES:
   - Distribute the ${validQuestionCount} questions across distinct categories (e.g. Applied Implementation, Deep Troubleshooting, Architecture & Systems Design, Incident Response & Reliability, Metric Optimization, Stakeholder Leadership).
6. CALIBRATED DIFFICULTY DISTRIBUTION:
   - Generate exactly: ${blueprint.distribution.easy} Easy, ${blueprint.distribution.intermediate} Intermediate, ${blueprint.distribution.advanced} Advanced questions.
   - Easy: Foundational execution following established industry best practices.
   - Intermediate: Nuanced trade-offs, debugging multi-step failures, multi-metric optimization.
   - Advanced: Complex systems design, high-stakes ambiguity, scale bottlenecks, crisis recovery, strategic trade-offs.

IMPORTANT: All text including questions, answer options, and explanations must be written in ${targetLanguage}.

Format the response as a JSON object with this exact structure:
{
    "title": "${occupation} - ${interviewType.charAt(0).toUpperCase() + interviewType.slice(1)} Assessment",
    "company": "Professional Evaluation Services",
    "department": "${interviewType === 'technical' ? 'Technical Department' : interviewType === 'case' ? 'Case Analysis' : 'Human Resources'}",
    "duration": "${Math.round(validQuestionCount * 3)} minutes",
    "totalQuestions": ${validQuestionCount},
    "passingScore": 70,
    "categories": ["list", "of", "categories"],
    "questions": [
        {
            "id": 1,
            "question": "Clear, contextual scenario question text without any leaked metadata or robotic preambles?",
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "correctAnswer": 0,
            "category": "Category name",
            "difficulty": "Easy/Intermediate/Advanced",
            "weight": 1,
            "explanation": "Detailed explanation of why the correct answer is optimal and why alternatives are flawed.",
            "estimatedTime": 120
        }
    ]
}

Fresh-run directive: produce a distinct set of questions from any prior attempt (unique run token: ${nonce}). Only return valid JSON without any markdown wrapper or surrounding commentary.
`;

    return { prompt, validQuestionCount, targetLanguage, distribution: blueprint.distribution, sessionNonce: nonce, blueprint };
}

// Generate interview questions based on occupation and interview type
router.post('/generate-interview', async (req, res) => {
    const markSource = (source) => {
        if (res?.setHeader && !res.headersSent) res.setHeader('X-AI-Source', source);
    };
    try {
        const { occupation, interviewType, questionCount = 10, language = 'en', experienceLevel, difficulty, jobDescription, resumeFacts, previousQuestions } = req.body;
        const allowedInterviewTypes = ['technical', 'behavioral', 'mixed', 'hr', 'managerial', 'case'];

        if (typeof occupation !== 'string' || !occupation.trim() || occupation.length > 160
            || !allowedInterviewTypes.includes(interviewType)) {
            return res.status(400).json({ error: { code: 'INVALID_AI_INPUT', message: 'Valid occupation and interview type are required', requestId: res.locals.requestId } });
        }

        // Bounded, privacy-preserving history: only the last few question texts are accepted so
        // prior-attempt repetition can be avoided without shipping unlimited history.
        const priorQuestions = (Array.isArray(previousQuestions) ? previousQuestions : [])
            .filter(q => typeof q === 'string')
            .map(q => cleanInterviewMetadataArtifacts(sanitizePromptFragment(q, 240)))
            .filter(q => q.length > 0)
            .slice(0, 12);

        const built = buildInterviewPrompt({
            occupation,
            interviewType,
            questionCount,
            language,
            experienceLevel,
            difficulty,
            jobDescription,
            resumeFacts,
            previousQuestions: priorQuestions,
            sessionNonce: crypto.randomBytes(8).toString('hex'),
        });
        const prompt = built.prompt;

        const responseText = await generateConfiguredText(req, res, prompt, 'generate-interview', { maxTokens: 4096 });

        try {
            // Extract the JSON from the response
            const jsonMatch = responseText.match(/\{[\s\S]*\}/);
            const jsonStr = jsonMatch ? jsonMatch[0] : responseText;
            const jsonData = extractJson(jsonStr) || extractJson(responseText);

            if (!jsonData || typeof jsonData !== 'object') throw new Error('Invalid interview response');

            // De-duplicate and strip any leaked metadata artifacts from questions and options
            const questions = dedupeQuestions(jsonData.questions, priorQuestions).slice(0, built.validQuestionCount);
            if (!questions.length) throw new Error('No usable questions after de-duplication');

            jsonData.questions = questions;
            jsonData.totalQuestions = questions.length;
            markSource('ai');
            res.json(jsonData);
        } catch (parseError) {
            console.error('Error parsing AI response:', parseError);
            // Fall back to generating default interview questions (role/difficulty/count-aware).
            const fallbackData = generateDefaultInterview({
                occupation,
                interviewType,
                questionCount: built.validQuestionCount,
                language,
                difficulty,
                experienceLevel,
                previousQuestions: priorQuestions,
            });
            markSource('fallback');
            res.json(fallbackData);
        }
    } catch (error) {
        console.error('Error generating interview questions:', error);
        // Use fallback if AI generation fails
        const { occupation, interviewType, questionCount = 10, language = 'en', difficulty, experienceLevel, previousQuestions } = req.body;
        const priorQuestions = (Array.isArray(previousQuestions) ? previousQuestions : [])
            .filter(q => typeof q === 'string')
            .map(q => cleanInterviewMetadataArtifacts(sanitizePromptFragment(q, 240)))
            .filter(q => q.length > 0)
            .slice(0, 12);
        const fallbackData = generateDefaultInterview({
            occupation,
            interviewType,
            questionCount,
            language,
            difficulty,
            experienceLevel,
            previousQuestions: priorQuestions,
        });
        markSource('fallback');
        res.json(fallbackData);
    }
});

// Generate work experience descriptions endpoint
router.post('/generate-work-description', async (req, res) => {
    try {
        const { jobTitle, employer, startDate, endDate, current, language = 'en' } = req.body;


        if (typeof jobTitle !== 'string' || !jobTitle.trim() || jobTitle.length > 160
            || typeof employer !== 'string' || !employer.trim() || employer.length > 160) {
            return res.status(400).json({ error: { code: 'INVALID_AI_INPUT', message: 'Job title and employer are required', requestId: res.locals.requestId } });
        }

        // Language mapping for proper language names in prompt
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };

        const targetLanguage = languageNames[language] || 'English';
        console.log('Target language mapped to:', targetLanguage);

        // Create a comprehensive prompt for work experience descriptions
        const duration = startDate && (endDate || current) ? `from ${startDate} to ${current ? 'present' : endDate}` : 'for the specified period';

        const prompt = `
        You are a Fortune 500 Senior Recruiter and Executive Resume Editor. Generate 3 different professional work experience descriptions for a ${jobTitle} position at ${employer} ${duration}.
        
        CRITICAL REQUIREMENT: You MUST write everything in ${targetLanguage}. Do NOT use English if the target language is not English.
        ${targetLanguage === 'Spanish' ? 'ESCRIBIR EN ESPAÑOL SOLAMENTE. NO USAR INGLÉS.' : ''}
        ${targetLanguage === 'French' ? "ÉCRIRE EN FRANÇAIS SEULEMENT. NE PAS UTILISER L'ANGLAIS." : ''}
        
        LANGUAGE: ${targetLanguage}
        TARGET LANGUAGE: ${targetLanguage}
        WRITE IN: ${targetLanguage}
        RESPONSE LANGUAGE: ${targetLanguage}
        
        CRITICAL 10/10 NATURAL HUMAN VOICE GUIDELINES:
        1. SOUND LIKE A REAL HUMAN ENGINEER / PROFESSIONAL: Write direct, concise, down-to-earth bullet points. BAN inflated AI linking clauses like "thereby increasing...", "achieving a significant reduction in...", "fostering seamless collaboration...". State the work done and the direct outcome cleanly.
        2. ACTION-FIRST STRUCTURE: Start directly with strong action verbs (Built, Designed, Wrote, Cut, Shipped, Automated, Managed, Developed, Migrated, Integrated).
        3. STRICT ANTI-AI BUZZWORD BAN: NEVER use robotic AI cliché words ("spearheaded", "leveraged", "utilize", "fostered", "synergy", "tapestry", "beacon", "testament", "thereby", "spearhead", "leverage").
        4. NO PLACEHOLDERS: NEVER output bracketed placeholders like "[insert percentage]" or "[X]". Write complete, ready-to-use bullet points.
        5. STRICT NO-HALLUCINATED-LOCATIONS DIRECTIVE: NEVER invent or add fictitious city names or branch offices (such as "San Francisco branch", "New York office", "Silicon Valley team") unless explicitly provided by the candidate! If no location/city was specified, refer strictly to "${employer}" directly without adding any branch or city name.
        6. EVERY SINGLE WORD must be written in ${targetLanguage}.
        
        Format the response as a JSON array with exactly 3 descriptions, each as a single string with bullet points separated by newlines.
        
        Example format (in ${targetLanguage}):
        [
            "• [First direct achievement in ${targetLanguage}]\n• [Second direct achievement in ${targetLanguage}]\n• [Third direct achievement in ${targetLanguage}]",
            "• [Different first achievement in ${targetLanguage}]\n• [Different second achievement in ${targetLanguage}]\n• [Different third achievement in ${targetLanguage}]",
            "• [Another achievement in ${targetLanguage}]\n• [Another achievement in ${targetLanguage}]\n• [Another achievement in ${targetLanguage}]"
        ]
        
        Only return the JSON array without any explanation or additional text.
        `;

        const text = await generateConfiguredText(req, res, prompt, 'generate-work-description');

        // Parse the JSON response
        let jsonText = text;
        if (text.includes('```json')) {
            jsonText = text.split('```json')[1].split('```')[0].trim();
        } else if (text.includes('```')) {
            jsonText = text.split('```')[1].split('```')[0].trim();
        }

        try {
            const descriptions = extractJson(jsonText) || extractJson(text);

            if (Array.isArray(descriptions) && descriptions.length > 0) {
                console.log('Successfully generated AI work descriptions for language:', targetLanguage);
                console.log('First description preview:', descriptions[0].substring(0, 100) + '...');
                res.json({ suggestions: descriptions });
            } else {
                console.log('Invalid AI response format, using fallback');
                const fallbackDescriptions = generateFallbackWorkDescriptions(jobTitle, employer, targetLanguage);
                res.json({ suggestions: fallbackDescriptions });
            }
        } catch (parseError) {
            console.error('Failed to parse JSON from AI response:', parseError);
            const fallbackDescriptions = generateFallbackWorkDescriptions(jobTitle, employer, targetLanguage);
            res.json({ suggestions: fallbackDescriptions });
        }
    } catch (error) {
        console.error('Error generating AI work descriptions:', error);
        // Use fallback method if AI generation fails
        const { jobTitle, employer, language = 'en' } = req.body;
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };
        const targetLanguage = languageNames[language] || 'English';
        const fallbackDescriptions = generateFallbackWorkDescriptions(jobTitle, employer, targetLanguage);
        res.json({ suggestions: fallbackDescriptions });
    }
});

// Generate education descriptions endpoint
router.post('/generate-education-description', async (req, res) => {
    try {
        const { school, degree, startDate, endDate, current, language = 'en' } = req.body;


        if (typeof school !== 'string' || !school.trim() || school.length > 200
            || typeof degree !== 'string' || !degree.trim() || degree.length > 200) {
            return res.status(400).json({ error: { code: 'INVALID_AI_INPUT', message: 'School and degree are required', requestId: res.locals.requestId } });
        }

        // Language mapping for proper language names in prompt
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };

        const targetLanguage = languageNames[language] || 'English';
        console.log('Target language mapped to:', targetLanguage);

        // Create a comprehensive prompt for education descriptions
        const duration = startDate && (endDate || current) ? `from ${startDate} to ${current ? 'present' : endDate}` : 'during the study period';

        const prompt = `
        You are a professional resume writer. Generate 3 different professional education descriptions for a ${degree} degree at ${school} ${duration}.
        
        CRITICAL REQUIREMENT: You MUST write everything in ${targetLanguage}. Do NOT use English if the target language is not English.
        ${targetLanguage === 'Spanish' ? 'ESCRIBIR EN ESPAÑOL SOLAMENTE. NO USAR INGLÉS.' : ''}
        ${targetLanguage === 'French' ? "ÉCRIRE EN FRANÇAIS SEULEMENT. NE PAS UTILISER L'ANGLAIS." : ''}
        
        LANGUAGE: ${targetLanguage}
        TARGET LANGUAGE: ${targetLanguage}
        WRITE IN: ${targetLanguage}
        RESPONSE LANGUAGE: ${targetLanguage}
        
        Each description should:
        - Be 3-4 bullet points long
        - Include relevant coursework, academic achievements, honors, projects, or extracurricular activities in ${targetLanguage}
        - Mention GPA, Dean's List, honors, or academic recognition where appropriate
        - Include relevant projects, internships, or practical experience gained during studies
        - Be tailored specifically to the ${degree} field of study
        - Sound professional and highlight academic accomplishments in ${targetLanguage}
        - Focus on achievements and learning outcomes rather than just coursework lists
        - Be unique and distinct from the other descriptions
        - EVERY SINGLE WORD must be written in ${targetLanguage}
        
        If the target language is Spanish (${targetLanguage}), use Spanish words, grammar, and structure.
        If the target language is French (${targetLanguage}), use French words, grammar, and structure.
        
        Format the response as a JSON array with exactly 3 descriptions, each as a single string with bullet points separated by newlines.
        
        Example format (but write in ${targetLanguage}):
        [
            "• [First achievement in ${targetLanguage}]\n• [Second achievement in ${targetLanguage}]\n• [Third achievement in ${targetLanguage}]",
            "• [Different first achievement in ${targetLanguage}]\n• [Different second achievement in ${targetLanguage}]\n• [Different third achievement in ${targetLanguage}]",
            "• [Another different achievement in ${targetLanguage}]\n• [Another achievement in ${targetLanguage}]\n• [Another achievement in ${targetLanguage}]"
        ]
        
        Remember: Write EVERYTHING in ${targetLanguage}. Do not mix languages.
        Only return the JSON array without any explanation or additional text.
        `;

        const text = await generateConfiguredText(req, res, prompt, 'generate-education-description');

        // Parse the JSON response
        let jsonText = text;
        if (text.includes('```json')) {
            jsonText = text.split('```json')[1].split('```')[0].trim();
        } else if (text.includes('```')) {
            jsonText = text.split('```')[1].split('```')[0].trim();
        }

        try {
            const descriptions = extractJson(jsonText) || extractJson(text);

            if (Array.isArray(descriptions) && descriptions.length > 0) {
                console.log('Successfully generated AI education descriptions for language:', targetLanguage);
                console.log('First education description preview:', descriptions[0].substring(0, 100) + '...');
                res.json({ suggestions: descriptions });
            } else {
                console.log('Invalid AI response format, using fallback');
                const fallbackDescriptions = generateFallbackEducationDescriptions(school, degree, targetLanguage);
                res.json({ suggestions: fallbackDescriptions });
            }
        } catch (parseError) {
            console.error('Failed to parse JSON from AI response:', parseError);
            const fallbackDescriptions = generateFallbackEducationDescriptions(school, degree, targetLanguage);
            res.json({ suggestions: fallbackDescriptions });
        }
    } catch (error) {
        console.error('Error generating AI education descriptions:', error);
        // Use fallback method if AI generation fails
        const { school, degree, language = 'en' } = req.body;
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };
        const targetLanguage = languageNames[language] || 'English';
        const fallbackDescriptions = generateFallbackEducationDescriptions(school, degree, targetLanguage);
        res.json({ suggestions: fallbackDescriptions });
    }
});

// Fallback summary generator in case the AI call fails
function generateFallbackSummary(name, jobTitle, experience, skills, achievement, summaryType, targetLanguage = 'English') {
    // Clean experience text for natural phrase insertion
    let cleanExp = experience || '3+ years';
    if (typeof cleanExp === 'string' && (cleanExp.length > 25 || cleanExp.includes(' at ') || cleanExp.includes(';'))) {
        cleanExp = 'several years';
    }

    // Create a simplified version of skills for template
    const skillsList =
        typeof skills === 'string'
            ? skills
                  .split(',')
                  .slice(0, 3)
                  .map((s) => s.trim())
                  .join(', ')
            : 'various industry-relevant skills';

    // Extract first name for more natural templates
    const _firstName = name ? name.split(' ')[0] : 'professional';

    // Templates for different languages
    const templates = {
        English: {
            professional: [
                `Dedicated ${jobTitle} with ${cleanExp} of experience in the field. Skilled in ${skillsList}, with a track record demonstrating core competencies across key production projects. Known for technical precision, analytical rigor, and delivering high-value outcomes.`,
                `Experienced ${jobTitle} with ${cleanExp} of professional expertise. Specializing in ${skillsList} with a demonstrated background modernizing architectures, driving impactful delivery, and optimizing strategic workflows.`,
                `Strategic ${jobTitle} bringing ${cleanExp} of industry experience. With deep expertise in ${skillsList}, demonstrated technical leadership, cross-functional execution, and continuous professional excellence.`,
            ],
            creative: [
                `Blending creativity with technical prowess, I have spent ${experience} crafting success as a ${jobTitle}. A master of ${skillsList}, I transform challenges into opportunities, notably when I ${achievement}. Every project becomes my canvas for innovation and excellence.`,
                `Reimagining what's possible as a ${jobTitle}, I bring ${experience} of boundary-pushing expertise to the table. Wielding skills in ${skillsList} like artistic tools, I create solutions that inspire, evidenced by my ${achievement}. I am ready to bring fresh perspectives to your next big challenge.`,
                `In the evolving landscape of ${jobTitle}s, I stand out with ${experience} of visionary work. Artfully combining ${skillsList}, I craft experiences that resonate and deliver results, particularly when I ${achievement}. Innovation meets practicality in everything I touch.`,
            ],
            achievement: [
                `I am a results-focused ${jobTitle} with ${experience} of measurable success. I notably ${achievement}, utilizing my expertise in ${skillsList}. I consistently exceed targets and transform challenges into quantifiable victories, bringing my proven track record of success to every initiative.`,
                `I am an achievement-driven ${jobTitle} with ${experience} of documented success. I have demonstrably improved outcomes when ${achievement}, leveraging my specialized skills in ${skillsList}. I am known for data-backed results and significant contributions to organizational goals.`,
                `I deliver exceptional ROI as a ${jobTitle} with ${experience} in the field. My quantifiable achievements include ${achievement}, made possible through my mastery of ${skillsList}. I have a track record of measurable impact, consistently turning strategies into tangible business outcomes.`,
            ],
        },
        French: {
            professional: [
                `Je suis un ${jobTitle} dévoué avec ${experience} d'expérience dans le domaine. Compétent en ${skillsList}, j'ai réussi à ${achievement}. Connu pour mon expertise et mon engagement envers l'excellence, j'apporte des idées précieuses et des résultats éprouvés à toute organisation.`,
                `Je suis un ${jobTitle} expérimenté avec ${experience} d'expertise professionnelle. Je me spécialise en ${skillsList} et j'ai un historique de ${achievement}. Je suis passionné par la livraison de résultats de haute qualité et le succès organisationnel grâce à des solutions innovantes.`,
                `Je suis un ${jobTitle} axé sur les résultats apportant ${experience} d'expérience industrielle. Avec une expertise en ${skillsList}, j'ai démontré une capacité exceptionnelle en ${achievement}. Je suis engagé dans l'apprentissage continu et la croissance professionnelle.`,
            ],
            creative: [
                `Alliant créativité et expertise technique, j'ai passé ${experience} à façonner le succès en tant que ${jobTitle}. Maître de ${skillsList}, je transforme les défis en opportunités, notamment quand j'ai ${achievement}. Chaque projet devient ma toile pour l'innovation et l'excellence.`,
                `Réinventant ce qui est possible en tant que ${jobTitle}, j'apporte ${experience} d'expertise révolutionnaire. Maniant les compétences en ${skillsList} comme des outils artistiques, je crée des solutions qui inspirent, comme en témoigne mon ${achievement}.`,
                `Dans le paysage évolutif des ${jobTitle}s, je me démarque avec ${experience} de travail visionnaire. Combinant artísticement ${skillsList}, je crée des expériences qui résonnent et livrent des résultats, particularly when I ${achievement}.`,
            ],
            achievement: [
                `Je suis un ${jobTitle} axé sur les résultats avec ${experience} de succès mesurable. J'ai notamment ${achievement}, utilisant mon expertise en ${skillsList}. Je dépasse constamment les objectifs et transforme les défis en victoires quantifiables.`,
                `Je suis un ${jobTitle} orienté réalisations avec ${experience} de succès documenté. J'ai considérablement amélioré les résultats quand j'ai ${achievement}, tirant parti de mes compétences spécialisées en ${skillsList}.`,
                `Je livre un ROI exceptionnel en tant que ${jobTitle} avec ${experience} dans le domaine. Mes réalisations quantifiables incluent ${achievement}, rendues possibles grâce à ma maîtrise de ${skillsList}.`,
            ],
        },
        Spanish: {
            professional: [
                `Soy un ${jobTitle} dedicado con ${experience} de experiencia en el campo. Hábil en ${skillsList}, he logrado con éxito ${achievement}. Conocido por mi experiencia y compromiso con la excelencia, aporto ideas valiosas y resultados probados a cualquier organización.`,
                `Soy un ${jobTitle} experimentado con ${experience} de experiencia profesional. Me especializo en ${skillsList} y tengo un historial de ${achievement}. Soy apasionado por entregar resultados de alta calidad e impulsar el éxito organizacional a través de soluciones innovadoras.`,
                `Soy un ${jobTitle} orientado a resultados que aporta ${experience} de experiencia en la industria. Con experiencia en ${skillsList}, he demostrado capacidad excepcional en ${achievement}. Estoy comprometido con el aprendizaje continuo y el crecimiento profesional.`,
            ],
            creative: [
                `Combinando creatividad con destreza técnica, he pasado ${experience} forjando el éxito como ${jobTitle}. Maestro de ${skillsList}, transformo desafíos en oportunidades, especialmente cuando logré ${achievement}. Cada proyecto se convierte en mi lienzo para la innovación y la excelencia.`,
                `Reimaginando lo que es posible como ${jobTitle}, aporto ${experience} de experiencia revolucionaria. Manejando habilidades en ${skillsList} como herramientas artísticas, creo soluciones que inspiran, evidenciado por mi ${achievement}.`,
                `En el panorama evolutivo de ${jobTitle}s, me destaco con ${experience} de trabajo visionario. Combinando artísticamente ${skillsList}, creo experiencias que resuenan y entregan resultados, particularmente cuando logré ${achievement}.`,
            ],
            achievement: [
                `Soy un ${jobTitle} enfocado en resultados con ${experience} de éxito medible. Notablemente logré ${achievement}, utilizando mi experiencia en ${skillsList}. Consistentemente supero objetivos y transformo desafíos en victorias cuantificables.`,
                `Soy un ${jobTitle} impulsado por logros con ${experience} de éxito documentado. He mejorado demostrablemente los resultados cuando logré ${achievement}, aprovechando mis habilidades especializadas en ${skillsList}.`,
                `Entrego ROI excepcional como ${jobTitle} con ${experience} en el campo. Mis logros cuantificables incluyen ${achievement}, hechos posibles a través de mi dominio de ${skillsList}.`,
            ],
        },
    };

    // Get templates for the target language or default to English
    const languageTemplates = templates[targetLanguage] || templates['English'];

    // Default to professional if type not specified or invalid
    const type = languageTemplates[summaryType] ? summaryType : 'professional';

    // Select a random template from the appropriate category
    const randomIndex = Math.floor(Math.random() * languageTemplates[type].length);
    return languageTemplates[type][randomIndex];
}

// Fallback function to generate interview questions when API fails. Deterministic per input
// (seeded by role/type/difficulty/count), role- and difficulty-aware, honors the requested
// question count, never fabricates candidate experience, and never repeats a question that was
// already asked recently. This is a reliability net — it is never the diversity source.
function seededRand(seedStr) {
    let h = 2166136261;
    for (let i = 0; i < seedStr.length; i++) { h ^= seedStr.charCodeAt(i); h = Math.imul(h, 16777619); }
    return () => {
        h += 0x6D2B79F5;
        let t = h;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}
function seededShuffle(arr, rand) {
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(rand() * (i + 1));
        const tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
    }
    return arr;
}
// diff tiers: 0=Easy, 1=Intermediate, 2=Advanced
const FBQ = (question, options, correctAnswer, category, diff, explanation, estimatedTime) => ({
    question, options, correctAnswer, category, diff,
    explanation: explanation || 'The selected option reflects the best-practice approach for a professional in this role.',
    estimatedTime: estimatedTime || 90,
});

const FALLBACK_TECHNICAL = (occ) => [
    FBQ(`When evaluating whether to adopt a specialized framework versus standard built-in capabilities for a ${occ} project, which trade-off is most critical?`,
        ['Long-term maintainability and team capability versus upfront convenience', 'Whether the tool is trending on developer forums', 'Choosing the tool that has zero learning curve regardless of performance', 'Avoiding all third-party dependencies unconditionally'], 0, 'Technical Architecture', 1,
        'Evaluating long-term maintainability, ecosystem health, and team ergonomics ensures sustainable architecture.'),
    FBQ(`You are tasked with introducing a modern architectural pattern to your ${occ} workflow. How do you mitigate migration risks for active production systems?`,
        ['Implement an end-to-end rewrite in a single deployment', 'Use an incremental rollout with feature flags, baseline benchmarks, and automated rollback triggers', 'Deploy directly to production during off-peak hours without testing', 'Delay the migration indefinitely to avoid risk'], 1, 'Systems Migration', 2,
        'Phased rollouts with automated verification and fallback boundaries prevent production outages during migrations.'),
    FBQ(`How do you approach diagnosing an intermittent production failure as a ${occ}?`,
        ['Restart the service repeatedly until the issue disappears', 'Immediately apply the last fix used on an unrelated bug', 'Isolate telemetry, reproduce failure conditions with synthetic loads, and verify root causes before deploying fixes', 'Assume external network instability without investigation'], 2, 'Problem Solving', 1,
        'Evidence-driven diagnosis using telemetry correlation and reproducible synthetic loads prevents recurring defects.'),
    FBQ(`Which performance telemetry metric is most actionable when optimizing throughput in a ${occ} pipeline?`,
        ['Total lines of configuration written', 'P95/P99 latency distribution and resource saturation bottlenecks', 'Personal estimates of system velocity', 'Gross number of tasks processed without tracking error rates'], 1, 'Performance Engineering', 2,
        'P95/P99 latency profiles and resource saturation metrics identify true user-impacting bottlenecks.'),
    FBQ(`How do you decide when to refactor legacy components in your ${occ} codebase or infrastructure?`,
        ['Refactor only when completely blocked, without documentation', 'Assess defect frequency, maintenance overhead, and test coverage before planning bounded incremental refactors', 'Rewrite everything immediately whenever a new tool is released', 'Never refactor working systems regardless of maintenance costs'], 1, 'Code Quality', 1,
        'Data-backed refactoring targeting high-churn, defect-prone modules maximizes ROI while protecting stability.'),
    FBQ(`During a major production incident in your ${occ} domain, what is your immediate priority?`,
        ['Assign blame and investigate historical commits', 'Triage blast radius, mitigate customer impact via failover, and communicate transparent status updates', 'Silence monitoring alerts to reduce noise', 'Attempt unreviewed speculative patches in production'], 1, 'Incident Response', 2,
        'Rapid blast-radius containment, failover mitigation, and clear stakeholder updates are the gold standard of incident response.'),
    FBQ(`How would you estimate the technical effort and risk for a complex ${occ} initiative with significant ambiguity?`,
        ['Provide a single optimistic deadline based on best-case assumptions', 'Decompose into verifiable milestones, identify integration unknowns, and provide confidence ranges with explicit assumptions', 'Refuse to estimate until all external dependencies are 100% complete', 'Double the first estimate arbitrarily without breakdown'], 1, 'Technical Planning', 1,
        'Decomposition into measurable milestones with confidence intervals and explicit risk assumptions creates defensible plans.'),
    FBQ(`When conducting a peer review for a critical ${occ} deliverable, what should you prioritize?`,
        ['Enforcing personal stylistic preferences over team conventions', 'Approving quickly without deep analysis to unblock velocity', 'Validating system correctness, edge-case failure handling, security posture, and maintainability', 'Rejecting any implementation that differs from your initial mental model'], 2, 'Peer Review', 1,
        'Rigorous review focuses on correctness, security boundaries, failure recovery, and adherence to shared standards.'),
    FBQ(`What is the most effective approach to maintain system reliability when upstream APIs or dependencies experience latency spikes?`,
        ['Retry failed requests infinitely in a tight loop', 'Implement bounded timeouts, exponential backoff with jitter, and circuit breaker fallbacks', 'Fail silently and return empty responses without logging', 'Block incoming requests until upstream services recover completely'], 1, 'Reliability Engineering', 2,
        'Circuit breakers combined with jittered exponential backoff protect upstream dependencies from cascading failure storms.'),
    FBQ(`How do you prioritize competing technical debt versus feature delivery as a ${occ}?`,
        ['Ignore technical debt entirely to maximize immediate feature output', 'Quantify reliability/velocity impact of debt, present business trade-offs, and allocate dedicated capacity alongside roadmap items', 'Halt all product feature development until the system has zero technical debt', 'Fix technical debt secretly without stakeholder visibility'], 1, 'Technical Strategy', 2,
        'Quantifying the operational cost of technical debt aligns engineering health with sustainable business velocity.'),
];

const FALLBACK_BEHAVIORAL = (occ) => [
    FBQ(`How do you handle a conflict within your team as a ${occ}?`,
        ['Avoid the person', 'Listen to all sides, facilitate discussion, and find common ground', 'Always side with seniority', 'Escalate immediately'], 1, 'Conflict Resolution', 1,
        'Active listening and collaborative problem-solving resolve conflicts constructively.'),
    FBQ(`Describe how you prioritize when you face multiple deadlines as a ${occ}.`,
        ['Work on whatever feels urgent', 'Rank by urgency and importance and communicate a plan', 'Work longer hours on everything', 'Do the easiest first'], 2, 'Time Management', 1,
        'Urgency/importance ranking with stakeholder communication is effective prioritization.'),
    FBQ(`How do you respond to constructive feedback on your ${occ} work?`,
        ['Take it personally', 'Listen, reflect, and act on the feedback', 'Ignore it', 'Agree to everything'], 1, 'Adaptability', 0,
        'A growth mindset treats feedback as an input for improvement.'),
    FBQ(`Tell me how you adapt when a major requirement changes mid-project as a ${occ}.`,
        ['Resist the change', 'Understand the reason, replan, and communicate the impact', 'Quietly keep the old plan', 'Blame the requester'], 2, 'Change Management', 1,
        'Understanding the why, replanning, and communicating impact is how professionals adapt.'),
    FBQ(`How do you collaborate with people from other functions as a ${occ}?`,
        ['Avoid cross-functional work', 'Insist others follow your process', 'Learn their context, align goals, and agree on communication', 'Let management coordinate'], 2, 'Collaboration', 1,
        'Empathy plus shared goals and clear channels make cross-functional work succeed.'),
    FBQ(`How do you handle missing information when you need to proceed as a ${occ}?`,
        ['Block until everything is known', 'State assumptions, proceed, and validate them early', 'Make things up', 'Wait passively'], 1, 'Judgment', 1,
        'Explicit assumptions validated early keep momentum without guessing.'),
    FBQ(`How do you deliver good news and bad news to stakeholders as a ${occ}?`,
        ['Only share good news', 'Be transparent, focus on impact and next steps', 'Let them find out', 'Delay all updates'], 1, 'Communication', 0,
        'Transparency about impact with clear next steps builds trust.'),
    FBQ(`What do you do when you realize you were wrong about a technical decision as a ${occ}?`,
        ['Defend the original choice', 'Acknowledge it, assess impact, and propose a correction', 'Hide the mistake', 'Wait for someone else to notice'], 2, 'Ownership', 1,
        'Owning mistakes and proposing corrections is a core professional behavior.'),
];

const FALLBACK_MANAGERIAL = (occ) => [
    FBQ(`How do you delegate work effectively when leading a ${occ} team?`,
        ['Do everything yourself', 'Assign by skill and growth goals, set clear outcomes, and stay available', 'Delegate everything without guidance', 'Assign by who asks first'], 1, 'Delegation', 1,
        'Skill-matched delegation with clear outcomes and support maximizes team output and growth.'),
    FBQ(`How do you handle an underperforming team member as a ${occ} manager?`,
        ['Avoid the conversation', 'Understand root cause, set expectations, and create a support plan', 'Put them on a plan immediately', 'Ignore it'], 2, 'Performance Management', 2,
        'Diagnose, set expectations, and support before escalating is the fair, effective approach.'),
    FBQ(`How do you decide what your ${occ} team should work on next?`,
        ['Follow the loudest voice', 'Align priorities with business goals and capacity, then communicate', 'Do the easiest work', 'Always chase the newest idea'], 1, 'Prioritization', 1,
        'Priorities should map to business impact and be weighed against team capacity.'),
    FBQ(`How do you build trust with the people you manage as a ${occ}?`,
        ['Be distant and formal', 'Be consistent, transparent, and follow through on commitments', 'Be a friend first', 'Only meet at annual reviews'], 1, 'Leadership', 1,
        'Consistency, transparency, and follow-through are the foundations of trust.'),
    FBQ(`How do you handle a situation where two senior stakeholders disagree on scope as a ${occ}?`,
        ['Pick a side', 'Facilitate a discussion around goals, data, and trade-offs', 'Escalate and disengage', 'Make the call secretly'], 2, 'Stakeholder Management', 2,
        'Facilitating around shared goals and trade-offs aligns stakeholders without taking sides.'),
    FBQ(`How do you grow the skills of your ${occ} team?`,
        ['Assume people self-improve', 'Create stretch opportunities, coaching, and regular feedback', 'Send everyone to training once', 'Only fix what breaks'], 1, 'Development', 1,
        'Structured growth through stretch work and coaching is how teams develop.'),
];

const FALLBACK_CASE = (occ) => [
    FBQ(`How would you structure an analysis to size a new ${occ} initiative?`,
        ['Pick a number quickly', 'Clarify scope, identify drivers, build a model, and sanity-check the result', 'Use the last project size', 'Ask for the answer'], 2, 'Case Reasoning', 2,
        'Structured frameworks (scope, drivers, model, sanity check) produce defensible estimates.'),
    FBQ(`How do you evaluate two competing approaches for a ${occ} decision?`,
        ['Go with your favorite', 'Define criteria, weight them, and compare trade-offs against data', 'Ask a friend', 'Do both completely'], 1, 'Decision Making', 1,
        'Criteria-weighted comparison keeps decisions objective and explainable.'),
    FBQ(`What do you do when the data you need for a ${occ} decision is incomplete?`,
        ['Refuse to decide', 'State assumptions, use best estimates, and flag the risk', 'Make up data', 'Decide randomly'], 1, 'Judgment', 1,
        'Explicit assumptions plus risk flagging lets decisions proceed without fabrication.'),
    FBQ(`How would you break down a large, ambiguous ${occ} problem?`,
        ['Tackle it as one big step', 'Decompose into sub-problems, prioritize, and solve iteratively', 'Wait for clarity', 'Do the easiest part only'], 2, 'Problem Structuring', 2,
        'Decomposition and iterative solving make ambiguous problems tractable.'),
    FBQ(`How do you present the trade-offs of a ${occ} recommendation to leadership?`,
        ['Only show the upside', 'Present options, costs, benefits, and risks with a clear recommendation', 'Overwhelm with detail', 'Let them decide blindly'], 1, 'Communication', 1,
        'Clear options-with-trade-offs and a recommendation let leaders decide well.'),
    FBQ(`How would you measure whether a new ${occ} change actually worked?`,
        ['By how it feels', 'Define a baseline and a success metric, then compare before/after', 'Ignore measurement', 'By one anecdote'], 1, 'Measurement', 1,
        'Baseline-and-metric comparison is how outcomes are objectively evaluated.'),
];

const FALLBACK_GENERIC = (occ) => [
    FBQ(`When managing multiple high-priority deliverables under tight deadlines as a ${occ}, what is the most effective approach to maintain delivery quality?`,
        ['Attempt to complete all tasks simultaneously without triaging', 'Prioritize tasks by business impact and operational risk, establish clear stakeholder expectations, and maintain strict verification standards', 'Bypass all quality checks to meet deadlines faster', 'Work in isolation without providing progress visibility'], 1, 'Delivery Management', 1,
        'Risk-based prioritization with transparent stakeholder alignment protects product quality under schedule pressure.'),
    FBQ(`How do you structure an ongoing technical review process to prevent knowledge silos in your ${occ} team?`,
        ['Keep all architecture context in private notes', 'Establish regular collaborative design reviews, standardized documentation, and pair-programming on complex modules', 'Rely on a single senior contributor to approve everything without explanation', 'Discourage questions during code and design reviews'], 1, 'Knowledge Sharing', 1,
        'Shared design reviews and transparent documentation distribute domain knowledge and elevate collective team capability.'),
    FBQ(`How do you ensure requirements and acceptance criteria are testable and unambiguous for a ${occ} initiative?`,
        ['Begin implementation immediately based on high-level verbal requests', 'Define concrete input/output contracts, measurable success thresholds, edge-case failure expectations, and automated verification tests', 'Assume downstream consumers will clarify requirements post-release', 'Avoid writing acceptance criteria to maintain flexibility'], 1, 'Quality Assurance', 1,
        'Measurable success thresholds, contract definitions, and automated verification tests eliminate ambiguity before implementation.'),
    FBQ(`When receiving ambiguous or conflicting feedback from multiple stakeholders on a ${occ} deliverable, how do you proceed?`,
        ['Implement whichever request was submitted most recently', 'Schedule a focused alignment discussion, present data-backed trade-offs against business objectives, and agree on unified success criteria', 'Ignore the feedback and ship the original draft', 'Escalate immediately to executive leadership without synthesizing the issues'], 1, 'Stakeholder Alignment', 2,
        'Synthesizing trade-offs against core business goals facilitates productive consensus among conflicting stakeholders.'),
    FBQ(`How do you measure and demonstrate the business impact of an operational optimization you delivered as a ${occ}?`,
        ['Rely entirely on subjective team feedback', 'Establish pre-change baseline metrics, track post-release performance/cost/latency deltas, and publish an evidence-backed impact summary', 'Assume any positive business trend was caused by the optimization without validation', 'Avoid measuring performance to prevent scrutiny'], 1, 'Impact Measurement', 2,
        'Rigorous before-and-after baseline comparisons provide verifiable evidence of business and engineering impact.'),
    FBQ(`How do you take end-to-end ownership when an unexpected edge case causes a customer-facing degradation in your ${occ} scope?`,
        ['Attribute the failure to third-party infrastructure without remediation', 'Acknowledge the gap, drive immediate mitigation, conduct a blameless root-cause analysis, and implement preventative regression tests', 'Wait for customer support to report additional incidents before acting', 'Quietly deploy an unmonitored fix without documentation'], 1, 'Ownership & Accountability', 2,
        'True ownership combines rapid mitigation with transparent root-cause analysis and automated regression prevention.'),
    FBQ(`How do you balance thoroughness with execution speed when shipping high-velocity ${occ} deliverables?`,
        ['Always maximize speed by eliminating all testing and code review', 'Calibrate verification depth and review rigor to the blast radius, reversibility, and criticality of the change', 'Treat all changes with identical exhaustive bureaucracy regardless of scope', 'Never ship until theoretical perfection is reached'], 1, 'Engineering Judgment', 1,
        'Calibrating review and testing depth to change reversibility and blast radius balances speed with safety.'),
];

const generateDefaultInterview = ({ occupation = 'Professional', interviewType = 'technical', questionCount = 10, language = 'en', difficulty = 'medium', experienceLevel = '', previousQuestions = [] } = {}) => {
    const requestedCount = Math.min(Math.max(parseInt(questionCount) || 10, 5), 20);
    const type = ['technical', 'behavioral', 'hr', 'managerial', 'case', 'mixed'].includes(interviewType) ? interviewType : 'technical';
    const formattedOccupation = String(occupation || 'Professional').trim() || 'Professional';
    const occ = formattedOccupation;

    const pools = {
        technical: FALLBACK_TECHNICAL(occ),
        behavioral: FALLBACK_BEHAVIORAL(occ),
        hr: FALLBACK_MANAGERIAL(occ),
        managerial: FALLBACK_MANAGERIAL(occ),
        case: FALLBACK_CASE(occ),
        generic: FALLBACK_GENERIC(occ),
    };

    let basePool;
    if (type === 'mixed') basePool = [...pools.technical, ...pools.behavioral, ...pools.managerial];
    else if (type === 'hr') basePool = [...pools.behavioral, ...pools.managerial];
    else if (type === 'technical' || type === 'behavioral' || type === 'managerial' || type === 'case') basePool = pools[type];
    else basePool = pools.technical;

    const distribution = interviewDifficultyDistribution(requestedCount, difficulty, experienceLevel);
    const previousKeys = new Set((Array.isArray(previousQuestions) ? previousQuestions : [])
        .filter(q => typeof q === 'string').map(q => questionKey(q)));
    const rand = seededRand(`${occ}|${type}|${difficulty}|${requestedCount}|${language}`);

    // Bucket by base difficulty tier, seeded-shuffled within each tier.
    const tierBuckets = { 0: [], 1: [], 2: [] };
    for (const q of [...basePool, ...pools.generic]) {
        if (tierBuckets[q.diff]) tierBuckets[q.diff].push(q);
    }
    for (const tier of [0, 1, 2]) seededShuffle(tierBuckets[tier], rand);

    const usedKeys = new Set();
    const pickFrom = (tier) => {
        const bucket = tierBuckets[tier] || [];
        for (let i = 0; i < bucket.length; i++) {
            const q = bucket[i];
            const key = questionKey(q.question);
            if (usedKeys.has(key) || previousKeys.has(key)) continue;
            usedKeys.add(key);
            return q;
        }
        return null;
    };

    const selected = [];
    // Fulfill difficulty quotas (Advanced, Intermediate, Easy), borrowing from other tiers if needed.
    const want = [
        { tier: 2, count: distribution.advanced },
        { tier: 1, count: distribution.intermediate },
        { tier: 0, count: distribution.easy },
    ];
    for (const { tier, count } of want) {
        for (let i = 0; i < count; i++) {
            const q = pickFrom(tier) || pickFrom(2) || pickFrom(1) || pickFrom(0);
            if (q) selected.push(q);
            else break;
        }
    }
    // Fill any remaining shortfall from the whole pool (dedup + recent-history exclusion).
    if (selected.length < requestedCount) {
        const remaining = seededShuffle([...basePool, ...pools.generic]
            .filter(q => !usedKeys.has(questionKey(q.question))), rand);
        for (const q of remaining) {
            if (selected.length >= requestedCount) break;
            const key = questionKey(q.question);
            if (usedKeys.has(key) || previousKeys.has(key)) continue;
            usedKeys.add(key);
            selected.push(q);
        }
    }

    const labelFor = (baseDiff) => {
        const d = String(difficulty || 'medium').toLowerCase();
        const senior = ['senior', 'lead', 'executive', 'staff', 'principal', 'expert'].some(t =>
            String(experienceLevel || '').toLowerCase().includes(t));
        const eff = senior ? 'hard' : d;
        if (eff === 'easy') return baseDiff === 2 ? 'Intermediate' : 'Easy';
        if (eff === 'hard') return baseDiff === 0 ? 'Intermediate' : 'Advanced';
        if (eff === 'expert') return 'Advanced';
        return baseDiff === 0 ? 'Easy' : baseDiff === 1 ? 'Intermediate' : 'Advanced';
    };

    const questions = selected.slice(0, requestedCount).map((q, i) => ({
        id: i + 1,
        question: q.question,
        options: q.options,
        correctAnswer: q.correctAnswer,
        category: q.category,
        difficulty: labelFor(q.diff),
        weight: 1,
        explanation: q.explanation,
        estimatedTime: q.estimatedTime,
    }));

    const categories = [...new Set(questions.map(q => q.category))];
    const dept = type === 'technical' ? 'Technical Department' : type === 'case' ? 'Case Analysis' : 'Human Resources';
    const title = `${formattedOccupation} Position - ${type.charAt(0).toUpperCase() + type.slice(1)} Assessment`;

    return {
        title,
        company: 'Professional Evaluation Services',
        department: dept,
        duration: `${Math.max(5, Math.round((questions.length * 3) / 5) * 5)} minutes`,
        totalQuestions: questions.length,
        passingScore: 70,
        categories,
        questions,
        _source: 'fallback',
    };
};

// Fallback function to generate work descriptions when AI is not available
const generateFallbackWorkDescriptions = (jobTitle, employer, targetLanguage = 'English') => {
    // Create base templates for different types of achievements in different languages
    const achievementTemplates = {
        English: [
            {
                category: 'leadership',
                templates: [
                    `• Led cross-functional teams of 5-12 professionals to deliver high-impact projects, resulting in 25-40% improvement in efficiency\n• Implemented strategic initiatives and process improvements that enhanced team productivity and collaboration\n• Mentored junior team members and conducted performance evaluations, contributing to professional development and retention`,

                    `• Managed and coordinated multiple project streams simultaneously, ensuring on-time delivery within budget constraints\n• Established clear communication channels and reporting structures that improved stakeholder satisfaction by 30%\n• Developed training programs and onboarding processes that reduced new employee ramp-up time by 50%`,
                ],
            },
            {
                category: 'technical',
                templates: [
                    `• Developed and implemented innovative solutions using cutting-edge technologies, serving over 10,000+ users\n• Optimized system performance and reduced processing time by 35% through strategic code refactoring and database optimization\n• Collaborated with product teams to translate business requirements into scalable technical architectures`,

                    `• Designed and built robust applications and systems that improved operational efficiency by 40%\n• Established coding standards and best practices that were adopted across the engineering organization\n• Conducted code reviews and technical documentation, ensuring high-quality deliverables and knowledge transfer`,
                ],
            },
            {
                category: 'business',
                templates: [
                    `• Drove business growth initiatives that resulted in 20-30% increase in revenue and market expansion\n• Analyzed market trends and customer data to identify opportunities and optimize business strategies\n• Built strategic partnerships and client relationships that generated $500K+ in new business opportunities`,

                    `• Streamlined business processes and implemented efficiency improvements that reduced costs by 25%\n• Developed comprehensive reports and presentations for executive leadership and key stakeholders\n• Managed client relationships and resolved complex issues, maintaining 95%+ customer satisfaction rates`,
                ],
            },
        ],
        Spanish: [
            {
                category: 'leadership',
                templates: [
                    `• Lideré equipos multifuncionales de 5-12 profesionales para entregar proyectos de alto impacto, resultando en 25-40% de mejora en eficiencia\n• Implementé iniciativas estratégicas y mejoras de procesos que aumentaron la productividad del equipo y la colaboración\n• Mentoreé a miembros júnior del equipo y realicé evaluaciones de desempeño, contribuyendo al desarrollo profesional y retención`,

                    `• Gestioné y coordiné múltiples flujos de proyectos simultáneamente, asegurando entrega a tiempo dentro de restricciones presupuestarias\n• Establecí canales de comunicación claros y estructuras de reporte que mejoraron la satisfacción de stakeholders en 30%\n• Desarrollé programas de entrenamiento y procesos de incorporación que redujeron el tiempo de adaptación de nuevos empleados en 50%`,
                ],
            },
            {
                category: 'technical',
                templates: [
                    `• Desarrollé e implementé soluciones innovadoras usando tecnologías de vanguardia, sirviendo a más de 10,000+ usuarios\n• Optimicé el rendimiento del sistema y reduje el tiempo de procesamiento en 35% mediante refactorización estratégica de código y optimización de base de datos\n• Colaboré con equipos de producto para traducir requisitos de negocio en arquitecturas técnicas escalables`,

                    `• Diseñé y construí aplicaciones y sistemas robustos que mejoraron la eficiencia operativa en 40%\n• Establecí estándares de codificación y mejores prácticas que fueron adoptadas en toda la organización de ingeniería\n• Realicé revisiones de código y documentación técnica, asegurando entregas de alta calidad y transferencia de conocimiento`,
                ],
            },
            {
                category: 'business',
                templates: [
                    `• Impulsé iniciativas de crecimiento empresarial que resultaron en 20-30% de aumento en ingresos y expansión de mercado\n• Analicé tendencias de mercado y datos de clientes para identificar oportunidades y optimizar estrategias empresariales\n• Construí asociaciones estratégicas y relaciones con clientes que generaron $500K+ en nuevas oportunidades de negocio`,

                    `• Optimicé procesos empresariales e implementé mejoras de eficiencia que redujeron costos en 25%\n• Desarrollé informes y presentaciones integrales para liderazgo ejecutivo y stakeholders clave\n• Gestioné relaciones con clientes y resolví problemas complejos, manteniendo tasas de satisfacción del cliente del 95%+`,
                ],
            },
        ],
        French: [
            {
                category: 'leadership',
                templates: [
                    `• Dirigé des équipes transfonctionnelles de 5-12 professionnels pour livrer des projets à fort impact, résultant en 25-40% d'amélioration de l'efficacité\n• Mis en œuvre des initiatives stratégiques et des améliorations de processus qui ont renforcé la productivité et la collaboration de l'équipe\n• Mentoré les membres juniors de l'équipe et mené des évaluations de performance, contribuant au développement professionnel et à la rétention`,

                    `• Géré et coordonné plusieurs flux de projets simultanément, assurant une livraison dans les délais et dans les contraintes budgétaires\n• Établi des canaux de communication clairs et des structures de rapport qui ont amélioré la satisfaction des parties prenantes de 30%\n• Développé des programmes de formation et des processus d'intégration qui ont réduit le temps d'adaptation des nouveaux employés de 50%`,
                ],
            },
            {
                category: 'technical',
                templates: [
                    `• Développé et mis en œuvre des solutions innovantes utilisant des technologies de pointe, servant plus de 10,000+ utilisateurs\n• Optimisé les performances du système et réduit le temps de traitement de 35% grâce à la refactorisation stratégique du code et l'optimisation de base de données\n• Collaboré avec les équipes produit pour traduire les exigences métier en architectures techniques évolutives`,

                    `• Conçu et construit des applications et systèmes robustes qui ont amélioré l'efficacité opérationnelle de 40%\n• Établi des standards de codage et des meilleures pratiques qui ont été adoptés dans toute l'organisation d'ingénierie\n• Effectué des revues de code et de la documentation technique, assurant des livrables de haute qualité et le transfert de connaissances`,
                ],
            },
            {
                category: 'business',
                templates: [
                    `• Mené des initiatives de croissance d'entreprise qui ont résulté en 20-30% d'augmentation des revenus et d'expansion du marché\n• Analysé les tendances du marché et les données clients pour identifier les opportunités et optimiser les stratégies d'entreprise\n• Construit des partenariats stratégiques et des relations clients qui ont généré $500K+ en nouvelles opportunités d'affaires`,

                    `• Rationalisé les processus d'entreprise et mis en œuvre des améliorations d'efficacité qui ont réduit les coûts de 25%\n• Développé des rapports et présentations complets pour la direction exécutive et les parties prenantes clés\n• Géré les relations clients et résolu des problèmes complexes, maintenant des taux de satisfaction client de 95%+`,
                ],
            },
        ],
    };

    // Get templates for the target language or default to English
    const languageTemplates = achievementTemplates[targetLanguage] || achievementTemplates['English'];

    // Determine which category fits best based on job title
    let selectedCategory = 'business'; // default

    const jobLower = jobTitle.toLowerCase();
    if (
        jobLower.includes('developer') ||
        jobLower.includes('engineer') ||
        jobLower.includes('programmer') ||
        jobLower.includes('architect') ||
        jobLower.includes('technical') ||
        jobLower.includes('software')
    ) {
        selectedCategory = 'technical';
    } else if (jobLower.includes('manager') || jobLower.includes('director') || jobLower.includes('lead') || jobLower.includes('supervisor') || jobLower.includes('head')) {
        selectedCategory = 'leadership';
    }

    // Get templates for the selected category
    const categoryTemplates = languageTemplates.find((cat) => cat.category === selectedCategory);
    const templates = categoryTemplates ? categoryTemplates.templates : languageTemplates[2].templates; // fallback to business

    // Create third description with customizable text for different languages
    let thirdDescription;
    if (targetLanguage === 'Spanish') {
        thirdDescription = `• Entregué exitosamente las responsabilidades de ${jobTitle} en ${employer}, logrando mejoras medibles en áreas clave de desempeño\n• Colaboré con stakeholders para implementar soluciones que mejoraron la efectividad organizacional y satisfacción del cliente\n• Contribuí al éxito del equipo mediante enfoques innovadores y compromiso con la excelencia en todos los entregables del proyecto`;
    } else if (targetLanguage === 'French') {
        thirdDescription = `• Livré avec succès les responsabilités de ${jobTitle} chez ${employer}, réalisant des améliorations mesurables dans les domaines de performance clés\n• Collaboré avec les parties prenantes pour implémenter des solutions qui ont amélioré l'efficacité organisationnelle et la satisfaction client\n• Contribué au succès de l'équipe grâce à des approches innovantes et un engagement envers l'excellence dans tous les livrables de projet`;
    } else {
        thirdDescription = `• Successfully delivered ${jobTitle} responsibilities at ${employer}, achieving measurable improvements in key performance areas\n• Collaborated with stakeholders to implement solutions that enhanced organizational effectiveness and client satisfaction\n• Contributed to team success through innovative approaches and commitment to excellence in all project deliverables`;
    }

    // Create variations by mixing and matching different achievement types
    const descriptions = [
        templates[0], // First template as-is
        templates[1], // Second template as-is
        thirdDescription, // Customized third description
    ];

    return descriptions;
};

// Fallback function to generate education descriptions when AI is not available
const generateFallbackEducationDescriptions = (school, degree, targetLanguage = 'English') => {
    // Create base templates for different types of educational achievements in different languages
    const educationTemplates = {
        English: [
            {
                category: 'technical',
                templates: [
                    `• Completed comprehensive coursework in ${degree} fundamentals including advanced programming, software engineering, and system design\n• Achieved Dean's List recognition for maintaining GPA above 3.7 throughout academic career\n• Led senior capstone project developing innovative solutions using modern technologies, serving 500+ users`,

                    `• Graduated Magna Cum Laude with specialization in cutting-edge technologies and methodologies\n• Completed advanced coursework in database systems, web development, and mobile application development\n• Participated in hackathons and coding competitions, placing top 10 in regional programming contests`,

                    `• Earned degree with focus on emerging technologies and industry best practices\n• Completed internship at leading tech company, contributing to development of critical systems and protocols\n• Active member of technical societies, organizing workshops and guest speaker events for fellow students`,
                ],
            },
            {
                category: 'business',
                templates: [
                    `• Completed rigorous ${degree} curriculum with focus on strategic management, finance, and organizational behavior\n• Achieved academic excellence with cumulative GPA of 3.8+ and recognition on Dean's List multiple semesters\n• Led student consulting projects for local businesses, delivering actionable recommendations that improved operations by 20%`,

                    `• Graduated Summa Cum Laude with concentration in business analytics and market research methodologies\n• Completed advanced coursework in international business, digital marketing, and entrepreneurship\n• Founded student entrepreneurship club, organizing networking events and pitch competitions for 200+ participants`,

                    `• Earned degree with emphasis on leadership development and cross-functional team management\n• Completed competitive internship program at Fortune 500 company, contributing to strategic planning initiatives\n• Served as student body representative, advocating for academic policy improvements and student services enhancement`,
                ],
            },
            {
                category: 'liberal_arts',
                templates: [
                    `• Completed diverse ${degree} curriculum emphasizing critical thinking, communication, and analytical reasoning skills\n• Achieved academic honors with GPA above 3.6 and active participation in honor society programs\n• Conducted independent research project on contemporary issues, presenting findings at undergraduate research symposium`,

                    `• Graduated with distinction in ${degree} studies, developing strong writing and presentation capabilities\n• Completed interdisciplinary coursework spanning humanities, social sciences, and communication studies\n• Served as editor for student publication, managing editorial team and increasing readership by 40%`,

                    `• Earned degree with focus on cultural studies and global perspectives through study abroad programs\n• Maintained academic excellence while participating in multiple extracurricular leadership roles\n• Organized community service initiatives, coordinating volunteer efforts for local non-profit organizations`,
                ],
            },
        ],
        Spanish: [
            {
                category: 'technical',
                templates: [
                    `• Completé cursos integrales en fundamentos de ${degree} incluyendo programación avanzada, ingeniería de software y diseño de sistemas\n• Logré reconocimiento en Lista de Decano por mantener GPA superior a 3.7 durante toda mi carrera académica\n• Lideré proyecto final de carrera desarrollando soluciones innovadoras usando tecnologías modernas, sirviendo a 500+ usuarios`,

                    `• Me gradué Magna Cum Laude con especialización en tecnologías de vanguardia y metodologías\n• Completé cursos avanzados en sistemas de bases de datos, desarrollo web y desarrollo de aplicaciones móviles\n• Participé en hackathons y competencias de programación, ubicándome en el top 10 en concursos regionales de programación`,

                    `• Obtuve título con enfoque en tecnologías emergentes y mejores prácticas de la industria\n• Completé prácticas profesionales en empresa tecnológica líder, contribuyendo al desarrollo de sistemas y protocolos críticos\n• Miembro activo de sociedades técnicas, organizando talleres y eventos con oradores invitados para compañeros estudiantes`,
                ],
            },
            {
                category: 'business',
                templates: [
                    `• Completé riguroso programa de ${degree} con enfoque en gestión estratégica, finanzas y comportamiento organizacional\n• Logré excelencia académica con GPA acumulativo de 3.8+ y reconocimiento en Lista de Decano múltiples semestres\n• Lideré proyectos de consultoría estudiantil para empresas locales, entregando recomendaciones accionables que mejoraron operaciones en 20%`,

                    `• Me gradué Summa Cum Laude con concentración en analítica empresarial y metodologías de investigación de mercado\n• Completé cursos avanzados en negocios internacionales, marketing digital y emprendimiento\n• Fundé club de emprendimiento estudiantil, organizando eventos de networking y competencias de pitches para 200+ participantes`,

                    `• Obtuve título con énfasis en desarrollo de liderazgo y gestión de equipos multifuncionales\n• Completé programa competitivo de prácticas en empresa Fortune 500, contribuyendo a iniciativas de planificación estratégica\n• Serví como representante estudiantil, abogando por mejoras en políticas académicas y servicios estudiantiles`,
                ],
            },
            {
                category: 'liberal_arts',
                templates: [
                    `• Completé diverso currículo de ${degree} enfatizando pensamiento crítico, comunicación y habilidades de razonamiento analítico\n• Logré honores académicos con GPA superior a 3.6 y participación activa en programas de sociedad de honor\n• Realicé proyecto de investigación independiente sobre temas contemporáneos, presentando hallazgos en simposio de investigación de pregrado`,

                    `• Me gradué con distinción en estudios de ${degree}, desarrollando fuertes capacidades de escritura y presentación\n• Completé cursos interdisciplinarios abarcando humanidades, ciencias sociales y estudios de comunicación\n• Serví como editor de publicación estudiantil, gestionando equipo editorial y aumentando número de lectores en 40%`,

                    `• Obtuve título con enfoque en estudios culturales y perspectivas globales a través de programas de estudio en el extranjero\n• Mantuve excelencia académica mientras participaba en múltiples roles de liderazgo extracurricular\n• Organicé iniciativas de servicio comunitario, coordinando esfuerzos voluntarios para organizaciones locales sin fines de lucro`,
                ],
            },
        ],
        French: [
            {
                category: 'technical',
                templates: [
                    `• Complété des cours complets sur les fondamentaux de ${degree} incluant programmation avancée, génie logiciel et conception de systèmes\n• Obtenu reconnaissance sur la Liste du Doyen pour maintenir un GPA supérieur à 3.7 tout au long de ma carrière académique\n• Dirigé projet de fin d'études développant des solutions innovantes utilisant des technologies modernes, servant 500+ utilisateurs`,

                    `• Diplômé Magna Cum Laude avec spécialisation en technologies de pointe et méthodologies\n• Complété des cours avancés en systèmes de bases de données, développement web et développement d'applications mobiles\n• Participé à des hackathons et concours de programmation, classé top 10 dans les concours régionaux de programmation`,

                    `• Obtenu diplôme avec accent sur les technologies émergentes et les meilleures pratiques de l'industrie\n• Complété stage dans une entreprise technologique leader, contribuant au développement de systèmes et protocoles critiques\n• Membre actif de sociétés techniques, organisant ateliers et événements avec conférenciers invités pour étudiants`,
                ],
            },
            {
                category: 'business',
                templates: [
                    `• Complété programme rigoureux de ${degree} avec accent sur gestion stratégique, finance et comportement organisationnel\n• Atteint excellence académique avec GPA cumulatif de 3.8+ et reconnaissance sur Liste du Doyen plusieurs semestres\n• Dirigé projets de consultation étudiante pour entreprises locales, livrant recommandations actionnables qui ont amélioré opérations de 20%`,

                    `• Diplômé Summa Cum Laude avec concentration en analytique d'entreprise et méthodologies de recherche de marché\n• Complété cours avancés en affaires internationales, marketing numérique et entrepreneuriat\n• Fondé club d'entrepreneuriat étudiant, organisant événements de réseautage et compétitions de pitchs pour 200+ participants`,

                    `• Obtenu diplôme avec emphasis sur développement du leadership et gestion d'équipes interfonctionnelles\n• Complété programme compétitif de stage chez entreprise Fortune 500, contribuant aux initiatives de planification stratégique\n• Servi comme représentant étudiant, plaidant pour améliorations de politiques académiques et services étudiants`,
                ],
            },
            {
                category: 'liberal_arts',
                templates: [
                    `• Complété curriculum diversifié de ${degree} mettant l'accent sur pensée critique, communication et compétences de raisonnement analytique\n• Atteint honneurs académiques avec GPA supérieur à 3.6 et participation active dans programmes de société d'honneur\n• Mené projet de recherche indépendant sur enjeux contemporains, présentant résultats au symposium de recherche de premier cycle`,

                    `• Diplômé avec distinction en études de ${degree}, développant fortes capacités d'écriture et présentation\n• Complété cours interdisciplinaires couvrant humanités, sciences sociales et études de communication\n• Servi comme éditeur de publication étudiante, gérant équipe éditoriale et augmentant lectorat de 40%`,

                    `• Obtenu diplôme avec accent sur études culturelles et perspectives globales à travers programmes d'études à l'étranger\n• Maintenu excellence académique tout en participant à multiples rôles de leadership parascolaires\n• Organisé initiatives de service communautaire, coordonnant efforts bénévoles pour organisations locales à but non lucratif`,
                ],
            },
        ],
    };

    // Get templates for the target language or default to English
    const languageTemplates = educationTemplates[targetLanguage] || educationTemplates['English'];

    // Determine which category fits best based on degree
    let selectedCategory = 'liberal_arts'; // default

    const degreeLower = degree.toLowerCase();
    if (
        degreeLower.includes('computer') ||
        degreeLower.includes('engineering') ||
        degreeLower.includes('technology') ||
        degreeLower.includes('science') ||
        degreeLower.includes('mathematics') ||
        degreeLower.includes('software') ||
        degreeLower.includes('information')
    ) {
        selectedCategory = 'technical';
    } else if (
        degreeLower.includes('business') ||
        degreeLower.includes('management') ||
        degreeLower.includes('economics') ||
        degreeLower.includes('finance') ||
        degreeLower.includes('marketing') ||
        degreeLower.includes('administration')
    ) {
        selectedCategory = 'business';
    }

    // Get templates for the selected category
    const categoryTemplates = languageTemplates.find((cat) => cat.category === selectedCategory);
    const templates = categoryTemplates ? categoryTemplates.templates : languageTemplates[2].templates; // fallback to liberal_arts

    // Return all three templates with school name integrated based on language
    let descriptions;
    if (targetLanguage === 'Spanish') {
        descriptions = templates.map((template) => template.replace(/en empresa tecnológica líder|en empresa Fortune 500|a través de programas de estudio en el extranjero/, `en ${school}`));
    } else if (targetLanguage === 'French') {
        descriptions = templates.map((template) => template.replace(/dans une entreprise technologique leader|chez entreprise Fortune 500|à travers programmes d'études à l'étranger/, `à ${school}`));
    } else {
        descriptions = templates.map((template) => template.replace(/at leading tech company|at Fortune 500 company|through study abroad programs/, `at ${school}`));
    }

    return descriptions;
};

// Fallback generator in case the AI call fails
const generateDefaultResumeData = (occupation, experienceLevel, yearsOfExperience, positionTitle, currentYear, skills = [], education = [], targetLanguage) => {
    // First name options
    const firstNames = ['James', 'Emma', 'Alex', 'Sarah', 'Michael', 'Jessica', 'David', 'Sophia', 'Robert', 'Olivia'];

    // Last name options
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];

    // Create a deterministic but random-seeming selection based on the occupation
    const occupationSeed = occupation.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);

    // Select names based on the occupation to ensure consistency for the same job title
    const firstName = firstNames[occupationSeed % firstNames.length];
    const lastName = lastNames[(occupationSeed + 3) % lastNames.length];

    // Email formats
    const emailDomains = ['gmail.com', 'outlook.com', 'yahoo.com', 'protonmail.com', 'mail.com'];
    const emailDomain = emailDomains[occupationSeed % emailDomains.length];
    const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}@${emailDomain}`;

    // Locations
    const locations = [
        { country: 'United States', city: 'New York', address: '123 Broadway Avenue' },
        { country: 'United States', city: 'Los Angeles', address: '456 Sunset Boulevard' },
        { country: 'United Kingdom', city: 'London', address: '10 Downing Street' },
        { country: 'Canada', city: 'Toronto', address: '567 Maple Road' },
    ];

    const location = locations[occupationSeed % locations.length];

    // Phone number generation (looks realistic but is fake)
    const areaCode = 100 + (occupationSeed % 900);
    const phoneMiddle = 100 + ((occupationSeed * 3) % 900);
    const phoneLast = 1000 + ((occupationSeed * 7) % 9000);
    const phone = `(${areaCode}) ${phoneMiddle}-${phoneLast.toString().substring(1)}`;

    // Generate keywords based on occupation
    const occupationKeywords = {
        developer: ['software architecture', 'code optimization', 'agile methodologies', 'full-stack development', 'technical leadership'],
        manager: ['team leadership', 'strategic planning', 'performance evaluation', 'process improvement', 'stakeholder communication'],
        designer: ['visual communication', 'creative direction', 'brand identity', 'user experience', 'digital media'],
        analyst: ['data analysis', 'research', 'reporting', 'problem-solving', 'critical thinking'],
        default: ['professional expertise', 'strategic thinking', 'collaborative approach', 'innovative solutions', 'continuous improvement'],
    };

    // Find matching keywords
    const relevantKeywords = Object.keys(occupationKeywords).filter((key) => occupation.toLowerCase().includes(key));
    const keywords = relevantKeywords.length > 0 ? relevantKeywords.flatMap((key) => occupationKeywords[key]) : occupationKeywords.default;
    const uniqueKeywords = [...new Set(keywords)];
    const selectedKeywords = uniqueKeywords.slice(0, 3);

    // Generate summaries
    const summaries = {
        'entry-level':
            targetLanguage === 'English'
                ? `Enthusiastic ${positionTitle} with ${yearsOfExperience.max} years of experience, specializing in ${selectedKeywords.join(
                      ', '
                  )}. Passionate about delivering high-quality results and continuously developing expertise in ${occupation}.`
                : `Enthousiaste ${positionTitle} avec ${yearsOfExperience.max} années d'expérience, spécialisé en ${selectedKeywords.join(
                      ', '
                  )}. Passionné par la livraison de résultats de haute qualité et le développement continu de l'expertise en ${occupation}.`,

        'mid-level':
            targetLanguage === 'English'
                ? `Accomplished ${positionTitle} with ${yearsOfExperience.max} years of experience delivering high-impact solutions through ${selectedKeywords.join(
                      ', '
                  )}. Proven track record combining deep technical competencies with cross-functional execution.`
                : `${positionTitle} expérimenté avec ${yearsOfExperience.max} années d'expérience offrant des résultats réussis grâce à ${selectedKeywords.join(
                      ', '
                  )}. Capacité prouvée à combiner l'expertise technique avec de solides compétences de collaboration.`,

        'senior-level':
            targetLanguage === 'English'
                ? `Accomplished ${positionTitle} with over ${yearsOfExperience.min} years of progressive experience in ${selectedKeywords.join(
                      ', '
                  )}. Demonstrated success in implementing innovative solutions to complex challenges.`
                : `${positionTitle} accompli avec plus de ${yearsOfExperience.min} années d'expérience progressive en ${selectedKeywords.join(
                      ', '
                  )}. Succès démontré dans la mise en œuvre de solutions innovantes aux défis complexes.`,
    };

    // Generate employment history
    const generateEmployments = () => {
        const employments = [];
        let totalYears = yearsOfExperience.max;

        // Company name parts
        const companyPrefixes = ['Global', 'Prime', 'Elite', 'Advanced', 'Innovative', 'Strategic', 'Premier', 'Essential'];
        const companySuffixes = ['Solutions', 'Technologies', 'Systems', 'Industries', 'Enterprises', 'Group', 'International', 'Consulting'];

        // Generate achievements
        const generateAchievements = () => {
            const achievements = [
                `Led key initiatives that improved efficiency by ${Math.floor((occupationSeed * 7) % 30) + 15}%`,
                `Collaborated with cross-functional teams to deliver successful projects on time and within budget`,
                `Implemented innovative solutions to address complex business challenges`,
            ];

            return achievements.join('\n• ');
        };

        // Current job
        const currentEmployer = `${companyPrefixes[occupationSeed % companyPrefixes.length]} ${companySuffixes[(occupationSeed * 3) % companySuffixes.length]}`;
        const currentEmployment = {
            id: 1,
            jobTitle: positionTitle,
            employer: currentEmployer,
            begin: `${currentYear - Math.min(3, totalYears)}`,
            end: 'Present',
            description: `• ${generateAchievements()}`,
            date: Date.now(),
        };
        employments.push(currentEmployment);
        totalYears -= 3;

        // Add previous positions
        for (let i = 0; i < 2; i++) {
            const previousPrefix = companyPrefixes[(occupationSeed * (7 + i * 3)) % companyPrefixes.length];
            const previousSuffix = companySuffixes[(occupationSeed * (11 + i * 5)) % companySuffixes.length];
            const previousEmployer = `${previousPrefix} ${previousSuffix}`;

            let previousJobTitle;
            if (i === 0) {
                previousJobTitle = experienceLevel === 'senior-level' ? occupation : `Junior ${occupation}`;
            } else {
                previousJobTitle = `Junior ${occupation}`;
            }

            const yearsInPosition = Math.min(2, totalYears > 0 ? totalYears : 2);
            const endYear = currentYear - Math.min(3, totalYears) - i * 2;
            const beginYear = endYear - yearsInPosition;

            const previousEmployment = {
                id: i + 2,
                jobTitle: previousJobTitle,
                employer: previousEmployer,
                begin: `${Math.max(beginYear, currentYear - 15)}`, // Avoid unrealistic dates
                end: `${endYear}`,
                description: `• ${generateAchievements()}`,
                date: Date.now() - 1000 * (i + 1),
            };
            employments.push(previousEmployment);
            totalYears -= yearsInPosition;
        }

        return employments;
    };

    // Generate education history
    const generateEducations = () => {
        const universityPrefixes = ['National', 'Central', 'Metropolitan', 'State', 'Pacific', 'Atlantic', 'Northern', 'Southern'];
        const universitySuffixes = ['University', 'College', 'Institute of Technology', 'State University', 'College of Arts & Sciences'];

        // Education-related degree mapping based on occupation
        const degreesByField = {
            software: ['Computer Science', 'Software Engineering', 'Information Technology'],
            market: ['Marketing', 'Business Administration', 'Digital Marketing'],
            sales: ['Business Administration', 'Marketing', 'Communications'],
            manager: ['Business Administration', 'Management', 'Organizational Leadership'],
            design: ['Graphic Design', 'Design', 'Fine Arts'],
            default: ['Business Administration', 'Liberal Arts', 'Communications'],
        };

        const educations = [];

        // Find appropriate degree for the occupation
        let degreeField = 'default';
        for (const field in degreesByField) {
            if (occupation.toLowerCase().includes(field)) {
                degreeField = field;
                break;
            }
        }
        const degrees = degreesByField[degreeField];

        // Use provided education or generate default ones
        if (education.length > 0) {
            education.forEach((edu, index) => {
                const degree = `Bachelor's in ${degrees[(occupationSeed + index) % degrees.length]}`;
                educations.push({
                    id: index + 1,
                    school: edu,
                    degree: degree,
                    started: `${currentYear - yearsOfExperience.max - 4}`,
                    finished: `${currentYear - yearsOfExperience.max}`,
                    description: 'Graduated with honors. Participated in relevant coursework and projects.',
                    date: Date.now() - index * 1000,
                });
            });
        }

        // Generate additional education entries to ensure we have at least 3
        const totalNeeded = Math.max(0, 3 - educations.length);
        for (let i = 0; i < totalNeeded; i++) {
            const index = educations.length;
            const uniPrefix = universityPrefixes[(occupationSeed * (1 + i)) % universityPrefixes.length];
            const uniSuffix = universitySuffixes[(occupationSeed * (3 + i)) % universitySuffixes.length];
            const school = `${uniPrefix} ${uniSuffix}`;

            let degree, started, finished, description;
            if (i === 0 && educations.length === 0) {
                // Main undergraduate education
                degree = `Bachelor's in ${degrees[occupationSeed % degrees.length]}`;
                started = `${currentYear - yearsOfExperience.max - 4}`;
                finished = `${currentYear - yearsOfExperience.max}`;
                description = 'Graduated with honors. Participated in relevant coursework and projects.';
            } else if (i === 1 || (i === 0 && educations.length > 0)) {
                // Master's degree
                degree = `Master's in ${degrees[(occupationSeed * 3) % degrees.length]}`;
                started = `${currentYear - yearsOfExperience.max + 1}`;
                finished = `${currentYear - yearsOfExperience.max + 3}`;
                description = 'Specialized in advanced topics with thesis research. Achieved academic excellence.';
            } else {
                // Earlier education or certification
                degree = `Associate's in ${degrees[(occupationSeed * 5) % degrees.length]}`;
                started = `${currentYear - yearsOfExperience.max - 7 + i}`;
                finished = `${currentYear - yearsOfExperience.max - 5 + i}`;
                description = 'Completed foundational coursework with practical training components.';
            }

            educations.push({
                id: index + 1,
                school: school,
                degree: degree,
                started: started,
                finished: finished,
                description: description,
                date: Date.now() - (index + 1) * 1000,
            });
        }

        return educations;
    };

    // Generate skills
    const generateSkills = () => {
        const skillsList = [];

        // Use provided skills or generate based on occupation
        if (skills.length > 0) {
            skills.forEach((skill, index) => {
                skillsList.push({
                    id: index + 1,
                    name: skill,
                    rating: Math.floor(Math.random() * 2) + 3, // Ratings between 3-5
                    date: Date.now() - index * 1000,
                });
            });
        }

        // Default skills based on occupation
        const defaultSkills = {
            'Software Engineer': ['JavaScript', 'React', 'Node.js', 'Python', 'SQL', 'Git', 'Docker', 'AWS'],
            'Frontend Developer': ['HTML5', 'CSS3', 'JavaScript', 'React', 'Redux', 'Responsive Design', 'Webpack', 'TypeScript'],
            'Backend Developer': ['Node.js', 'Express', 'Python', 'Django', 'SQL', 'MongoDB', 'API Design', 'Docker'],
            'Full Stack Developer': ['JavaScript', 'React', 'Node.js', 'Express', 'SQL', 'Git', 'MongoDB', 'REST APIs'],
            'Data Analyst': ['Excel', 'SQL', 'Tableau', 'Python', 'R', 'Statistical Analysis', 'Data Visualization', 'Power BI'],
            'UX Designer': ['User Research', 'Wireframing', 'Prototyping', 'Figma', 'Adobe XD', 'Usability Testing', 'Information Architecture', 'User Personas'],
            'Product Manager': ['Product Strategy', 'Roadmapping', 'User Stories', 'Agile', 'Market Research', 'Product Analytics', 'Stakeholder Management', 'A/B Testing'],
            'Marketing Manager': ['Digital Marketing', 'Content Strategy', 'SEO', 'Social Media', 'Analytics', 'Campaign Management', 'Market Research', 'Brand Development'],
            default: ['Communication', 'Problem Solving', 'Team Collaboration', 'Project Management', 'Time Management', 'Adaptability', 'Critical Thinking', 'Organization'],
        };

        // Find best match from default skills
        let bestMatch = 'default';
        Object.keys(defaultSkills).forEach((key) => {
            if (occupation.toLowerCase().includes(key.toLowerCase())) {
                bestMatch = key;
            }
        });

        // Ensure we have at least 8 skills total
        const totalSkillsNeeded = Math.max(0, 8 - skillsList.length);
        const matchSkills = defaultSkills[bestMatch].slice(0, totalSkillsNeeded);

        // Add the skills
        matchSkills.forEach((skill, index) => {
            const skillId = skillsList.length + index + 1;
            skillsList.push({
                id: skillId,
                name: skill,
                rating: Math.min(5, Math.floor(((occupationSeed * skillId) % 3) + 3)), // Ratings between 3-5
                date: Date.now() - (skillsList.length + index) * 1000,
            });
        });

        return skillsList;
    };

    // Generate languages
    const generateLanguages = () => {
        const _primaryLanguages = ['English', 'Spanish', 'French', 'German', 'Mandarin', 'Japanese', 'Portuguese', 'Italian'];
        const secondaryLanguages = ['Spanish', 'French', 'German', 'Italian', 'Portuguese', 'Mandarin', 'Japanese', 'Arabic'];
        const levels = ['Native', 'Fluent', 'Advanced', 'Intermediate', 'Basic'];

        // Use target language as primary, English as secondary (if target is not English)
        const primaryLanguage = targetLanguage;
        const secondaryLanguage = targetLanguage === 'English' ? secondaryLanguages[(occupationSeed * 3) % secondaryLanguages.length] : 'English';

        return [
            {
                id: 1,
                name: primaryLanguage,
                level: 'Native',
                date: Date.now(),
            },
            {
                id: 2,
                name: secondaryLanguage,
                level:
                    targetLanguage === 'English'
                        ? levels[((occupationSeed * 7) % (levels.length - 1)) + 1] // Any except Native
                        : 'Intermediate', // English as intermediate if target language is not English
                date: Date.now() - 1000,
            },
        ];
    };

    // Return the complete resume data
    return {
        firstname: firstName,
        lastname: lastName,
        email: email,
        phone: phone,
        occupation: positionTitle,
        country: location.country,
        city: location.city,
        address: location.address,
        summary: summaries[experienceLevel],
        employments: generateEmployments(),
        educations: generateEducations(),
        languages: generateLanguages(),
        skills: generateSkills(),
        _source: 'fallback',
    };
};

// Generate skills based on occupation endpoint
router.post('/generate-skills', async (req, res) => {
    try {
        const { occupation, experienceLevel = 'mid-level', language = 'en' } = req.body;

        if (typeof occupation !== 'string' || !occupation.trim() || occupation.length > 160) {
            return res.status(400).json({ error: { code: 'INVALID_AI_INPUT', message: 'Occupation is required', requestId: res.locals.requestId } });
        }

        // Language mapping for proper language names in prompt
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };

        const targetLanguage = languageNames[language] || 'English';
        console.log('Target language mapped to:', targetLanguage);

        // Create a comprehensive prompt for skills generation
        const prompt = `
        You are a professional career advisor. Generate 12 relevant skills for a ${occupation} position at ${experienceLevel} level.
        
        CRITICAL REQUIREMENT: You MUST write everything in ${targetLanguage}. Do NOT use English if the target language is not English.
        ${targetLanguage === 'Spanish' ? 'ESCRIBIR EN ESPAÑOL SOLAMENTE. NO USAR INGLÉS.' : ''}
        ${targetLanguage === 'French' ? "ÉCRIRE EN FRANÇAIS SEULEMENT. NE PAS UTILISER L'ANGLAIS." : ''}
        
        LANGUAGE: ${targetLanguage}
        TARGET LANGUAGE: ${targetLanguage}
        WRITE IN: ${targetLanguage}
        RESPONSE LANGUAGE: ${targetLanguage}
        
        Generate skills that are:
        - Highly relevant to ${occupation} role
        - Appropriate for ${experienceLevel} experience level
        - ABSOLUTELY NO parenthetical examples like "(e.g. Google Ad Manager)" or "(e.g. Excel)" in skill names
        - Concise 1-3 word specific industry skill or tool names only (e.g. "Google Ad Manager", "Display Advertising", "PostgreSQL", "Excel")
        - Mix of technical skills and soft skills
        - Industry-standard and in-demand skills in ${targetLanguage}
        - Current and modern skills for this field
        - EVERY SINGLE WORD must be written in ${targetLanguage}
        
        Include a mix of:
        - Core technical skills for ${occupation}
        - Programming languages/tools (if applicable)
        - Methodologies and frameworks
        - Soft skills relevant to the role
        - Industry-specific knowledge
        
        If the target language is Spanish (${targetLanguage}), use Spanish words and terminology.
        If the target language is French (${targetLanguage}), use French words and terminology.
        
        Format the response as a JSON array of skill names only, like this:
        ["Skill 1", "Skill 2", "Skill 3", ...]
        
        Example format (but write in ${targetLanguage}):
        ["JavaScript", "Problem Solving", "Team Leadership", "Agile Methodology"]
        
        Remember: Write EVERYTHING in ${targetLanguage}. Do not mix languages.
        Only return the JSON array without any explanation or additional text.
        `;

        const text = await generateConfiguredText(req, res, prompt, 'generate-skills');

        // Parse the JSON response
        let jsonText = text;
        if (text.includes('```json')) {
            jsonText = text.split('```json')[1].split('```')[0].trim();
        } else if (text.includes('```')) {
            jsonText = text.split('```')[1].split('```')[0].trim();
        }

        try {
            const skills = extractJson(jsonText) || extractJson(text);

            if (Array.isArray(skills) && skills.length > 0) {
                console.log('✅ Successfully generated AI skills for language:', targetLanguage);
                console.log('===== SKILLS GENERATION SUCCESS =====');
                res.json({ skills: skills.slice(0, 12) }); // Limit to 12 skills
            } else {
                console.log('❌ Invalid AI response format, using fallback');
                const fallbackSkills = generateFallbackSkills(occupation, experienceLevel, targetLanguage);
                res.json({ skills: fallbackSkills });
            }
        } catch (parseError) {
            console.error('❌ Failed to parse JSON from AI response:', parseError);
            const fallbackSkills = generateFallbackSkills(occupation, experienceLevel, targetLanguage);
            res.json({ skills: fallbackSkills });
        }
    } catch (error) {
        console.error('❌ Error generating AI skills:', error);
        // Use fallback method if AI generation fails
        const { occupation, experienceLevel = 'mid-level', language = 'en' } = req.body;
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };
        const targetLanguage = languageNames[language] || 'English';
        const fallbackSkills = generateFallbackSkills(occupation, experienceLevel, targetLanguage);
        console.log('===== SKILLS GENERATION FAILED =====');
        res.json({ skills: fallbackSkills });
    }
});

// Fallback function to generate skills when AI is not available
const generateFallbackSkills = (occupation, experienceLevel = 'mid-level', targetLanguage = 'English') => {
    // Skills database organized by occupation and language
    const skillsDatabase = {
        English: {
            'software developer': {
                technical: ['JavaScript', 'Python', 'React', 'Node.js', 'SQL', 'Git', 'Docker', 'AWS', 'TypeScript', 'MongoDB'],
                soft: ['Problem Solving', 'Team Collaboration', 'Code Review', 'Agile Methodology'],
            },
            'frontend developer': {
                technical: ['HTML5', 'CSS3', 'JavaScript', 'React', 'Vue.js', 'Webpack', 'Sass', 'TypeScript', 'Responsive Design', 'Jest'],
                soft: ['User Experience Focus', 'Cross-browser Compatibility', 'Design Collaboration', 'Performance Optimization'],
            },
            'backend developer': {
                technical: ['Node.js', 'Python', 'Express.js', 'PostgreSQL', 'MongoDB', 'REST APIs', 'GraphQL', 'Docker', 'Microservices', 'Redis'],
                soft: ['System Architecture', 'Database Design', 'API Development', 'Security Best Practices'],
            },
            'data analyst': {
                technical: ['Python', 'SQL', 'Tableau', 'Excel', 'Power BI', 'R', 'Pandas', 'NumPy', 'Statistics', 'Data Visualization'],
                soft: ['Critical Thinking', 'Business Intelligence', 'Statistical Analysis', 'Report Writing'],
            },
            'product manager': {
                technical: ['Product Analytics', 'A/B Testing', 'User Research', 'Wireframing', 'JIRA', 'Confluence', 'SQL', 'Data Analysis'],
                soft: ['Strategic Planning', 'Stakeholder Management', 'Cross-functional Leadership', 'Market Research'],
            },
            'marketing manager': {
                technical: ['Google Analytics', 'SEO', 'SEM', 'Social Media Marketing', 'Content Management', 'Email Marketing', 'Adobe Creative Suite', 'HubSpot'],
                soft: ['Brand Management', 'Campaign Strategy', 'Market Analysis', 'Customer Segmentation'],
            },
            designer: {
                technical: ['Figma', 'Adobe Creative Suite', 'Sketch', 'Prototyping', 'User Interface Design', 'Adobe XD', 'InVision', 'Zeppelin'],
                soft: ['Creative Thinking', 'User Experience Design', 'Visual Communication', 'Design Systems'],
            },
            default: {
                technical: ['Microsoft Office', 'Project Management', 'Data Analysis', 'Communication Tools', 'Time Management', 'Digital Literacy'],
                soft: ['Leadership', 'Communication', 'Problem Solving', 'Teamwork', 'Adaptability', 'Critical Thinking'],
            },
        },
        Spanish: {
            'software developer': {
                technical: ['JavaScript', 'Python', 'React', 'Node.js', 'SQL', 'Git', 'Docker', 'AWS', 'TypeScript', 'MongoDB'],
                soft: ['Resolución de Problemas', 'Colaboración en Equipo', 'Revisión de Código', 'Metodología Ágil'],
            },
            'frontend developer': {
                technical: ['HTML5', 'CSS3', 'JavaScript', 'React', 'Vue.js', 'Webpack', 'Sass', 'TypeScript', 'Diseño Responsivo', 'Jest'],
                soft: ['Enfoque en Experiencia de Usuario', 'Compatibilidad Cross-browser', 'Colaboración de Diseño', 'Optimización de Rendimiento'],
            },
            'backend developer': {
                technical: ['Node.js', 'Python', 'Express.js', 'PostgreSQL', 'MongoDB', 'APIs REST', 'GraphQL', 'Docker', 'Microservicios', 'Redis'],
                soft: ['Arquitectura de Sistemas', 'Diseño de Base de Datos', 'Desarrollo de APIs', 'Mejores Prácticas de Seguridad'],
            },
            'data analyst': {
                technical: ['Python', 'SQL', 'Tableau', 'Excel', 'Power BI', 'R', 'Pandas', 'NumPy', 'Estadísticas', 'Visualización de Datos'],
                soft: ['Pensamiento Crítico', 'Inteligencia de Negocios', 'Análisis Estadístico', 'Redacción de Informes'],
            },
            default: {
                technical: ['Microsoft Office', 'Gestión de Proyectos', 'Análisis de Datos', 'Herramientas de Comunicación', 'Gestión del Tiempo', 'Alfabetización Digital'],
                soft: ['Liderazgo', 'Comunicación', 'Resolución de Problemas', 'Trabajo en Equipo', 'Adaptabilidad', 'Pensamiento Crítico'],
            },
        },
        French: {
            'software developer': {
                technical: ['JavaScript', 'Python', 'React', 'Node.js', 'SQL', 'Git', 'Docker', 'AWS', 'TypeScript', 'MongoDB'],
                soft: ['Résolution de Problèmes', "Collaboration d'Équipe", 'Révision de Code', 'Méthodologie Agile'],
            },
            'frontend developer': {
                technical: ['HTML5', 'CSS3', 'JavaScript', 'React', 'Vue.js', 'Webpack', 'Sass', 'TypeScript', 'Design Responsive', 'Jest'],
                soft: ['Focus Expérience Utilisateur', 'Compatibilité Cross-browser', 'Collaboration Design', 'Optimisation Performance'],
            },
            'backend developer': {
                technical: ['Node.js', 'Python', 'Express.js', 'PostgreSQL', 'MongoDB', 'APIs REST', 'GraphQL', 'Docker', 'Microservices', 'Redis'],
                soft: ['Architecture Système', 'Design Base de Données', 'Développement APIs', 'Meilleures Pratiques Sécurité'],
            },
            default: {
                technical: ['Microsoft Office', 'Gestion de Projet', 'Analyse de Données', 'Outils de Communication', 'Gestion du Temps', 'Littératie Numérique'],
                soft: ['Leadership', 'Communication', 'Résolution de Problèmes', "Travail d'Équipe", 'Adaptabilité', 'Pensée Critique'],
            },
        },
    };

    // Get skills for the target language or default to English
    const languageSkills = skillsDatabase[targetLanguage] || skillsDatabase['English'];

    // Find the best matching occupation
    let occupationKey = 'default';
    const occupationLower = occupation.toLowerCase();

    // Check for exact matches first
    if (languageSkills[occupationLower]) {
        occupationKey = occupationLower;
    } else {
        // Check for partial matches
        for (const key in languageSkills) {
            if (occupationLower.includes(key.replace(/ /g, '')) || key.replace(/ /g, '').includes(occupationLower.replace(/ /g, ''))) {
                occupationKey = key;
                break;
            }
        }
    }

    const selectedSkills = languageSkills[occupationKey];

    // Combine technical and soft skills
    const technicalSkills = selectedSkills.technical || [];
    const softSkills = selectedSkills.soft || [];

    // Adjust skill selection based on experience level
    let techCount, softCount;
    switch (experienceLevel) {
        case 'entry-level':
            techCount = Math.min(6, technicalSkills.length);
            softCount = Math.min(6, softSkills.length);
            break;
        case 'senior-level':
            techCount = Math.min(8, technicalSkills.length);
            softCount = Math.min(4, softSkills.length);
            break;
        default: // mid-level
            techCount = Math.min(7, technicalSkills.length);
            softCount = Math.min(5, softSkills.length);
    }

    // Select skills
    const selectedTechSkills = technicalSkills.slice(0, techCount);
    const selectedSoftSkills = softSkills.slice(0, softCount);

    // Combine and return
    return [...selectedTechSkills, ...selectedSoftSkills].slice(0, 12);
};

// Fallback function to check grammar when AI is not available
function generateFallbackGrammarCheck(text, _targetLanguage = 'English') {
    // Simple fallback grammar check - looks for common issues
    const corrections = [];
    
    // Basic checks for common grammar issues
    const commonErrors = [
        { pattern: /\bi\b/g, suggestion: 'I', type: 'grammar', explanation: 'Personal pronoun should be capitalized' },
        { pattern: /\b(there|their|they're)\b/g, suggestion: 'check usage', type: 'grammar', explanation: 'Check if correct form of there/their/they\'re is used' },
        { pattern: /\b(your|you're)\b/g, suggestion: 'check usage', type: 'grammar', explanation: 'Check if correct form of your/you\'re is used' },
        { pattern: /\b(its|it's)\b/g, suggestion: 'check usage', type: 'grammar', explanation: 'Check if correct form of its/it\'s is used' },
        { pattern: /\s{2,}/g, suggestion: ' ', type: 'formatting', explanation: 'Multiple spaces should be single space' },
        { pattern: /\s+\./g, suggestion: '.', type: 'punctuation', explanation: 'No space before period' },
        { pattern: /\s+,/g, suggestion: ',', type: 'punctuation', explanation: 'No space before comma' }
    ];
    
    commonErrors.forEach(error => {
        let match;
        while ((match = error.pattern.exec(text)) !== null) {
            if (error.type === 'grammar' && error.pattern.source.includes('(there|their|they\'re)')) {
                // Skip this complex check in fallback
                continue;
            }
            corrections.push({
                original: match[0],
                suggestion: error.suggestion,
                type: error.type,
                explanation: error.explanation,
                startIndex: match.index,
                endIndex: match.index + match[0].length
            });
        }
    });
    
    return {
        hasErrors: corrections.length > 0,
        corrections: corrections.slice(0, 5), // Limit to 5 corrections
        overallSuggestion: corrections.length > 0 ? 
            `Found ${corrections.length} potential issues. Consider reviewing for grammar and formatting.` : 
            `Text appears to be well-written with no obvious grammar errors.`
    };
}

// Grammar checker endpoint
router.post('/check-grammar', async (req, res) => {
    try {
        const { text, language = 'en' } = req.body;

        if (typeof text !== 'string' || !text.trim() || text.length > 40_000) {
            return res.status(400).json({ error: { code: 'INVALID_AI_INPUT', message: 'Text is required for grammar checking', requestId: res.locals.requestId } });
        }
        if (typeof language !== 'string' || !/^[a-z]{2}$/.test(language)) {
            return res.status(400).json({ error: { code: 'INVALID_AI_INPUT', message: 'Unsupported grammar language', requestId: res.locals.requestId } });
        }

        // Language mapping for proper language names in prompt
        const languageNames = {
            en: 'English',
            es: 'Spanish',
            fr: 'French',
            de: 'German',
            it: 'Italian',
            pt: 'Portuguese',
            ru: 'Russian',
            nl: 'Dutch',
            pl: 'Polish',
            se: 'Swedish',
            no: 'Norwegian',
            dk: 'Danish',
            is: 'Icelandic',
            gk: 'Greek',
            ro: 'Romanian',
        };

        const targetLanguage = languageNames[language] || 'English';

        // Prepare the comprehensive prompt for Gemini
        const prompt = `
        You are an expert grammar checker and writing assistant with extensive knowledge of ${targetLanguage} language rules. Your task is to perform a COMPREHENSIVE and EXHAUSTIVE analysis of the provided text in a SINGLE PASS to identify ALL errors and issues.
        
        ANALYSIS APPROACH - Follow this systematic process:
        1. **Read the entire text first** to understand context and intent
        2. **Sentence-by-sentence analysis** for grammar and structure
        3. **Word-by-word review** for spelling and usage
        4. **Punctuation and formatting check** throughout
        5. **Style and clarity assessment** for improvements
        6. **Final comprehensive review** to ensure nothing is missed
        
        Text to analyze:
        "${text}"
        
        COMPREHENSIVE ERROR DETECTION - Check for ALL of the following:
        
        **GRAMMAR ERRORS:**
        - Subject-verb agreement issues
        - Incorrect verb tenses and forms
        - Wrong pronoun usage (he/she/it, they/them, possessive pronouns)
        - Article errors (a/an/the)
        - Preposition mistakes
        - Sentence fragments and run-on sentences
        - Incorrect word order
        - Dangling modifiers
        - Parallel structure issues
        - Conditional sentence errors
        
        **SPELLING & WORD USAGE:**
        - Misspelled words
        - Homophone confusions (there/their/they're, your/you're, its/it's)
        - Wrong word choices (affect/effect, accept/except)
        - Repeated words or phrases
        - Missing or extra words
        - Capitalization errors
        
        **PUNCTUATION & FORMATTING:**
        - Missing or incorrect punctuation marks
        - Comma splices and comma errors
        - Apostrophe misuse
        - Quotation mark errors
        - Hyphen and dash usage
        - Spacing issues (extra spaces, missing spaces)
        
        **STYLE & CLARITY:**
        - Awkward phrasing that can be improved
        - Redundant expressions
        - Unclear or ambiguous sentences
        - Word repetition that should be varied
        - Passive voice that should be active (when appropriate)
        
        CRITICAL INSTRUCTIONS:
        - **BE THOROUGH**: This is a ONE-TIME analysis. Find EVERY error, don't leave anything for a second pass
        - **BE ACCURATE**: Calculate exact startIndex and endIndex positions for each error
        - **BE PRECISE**: Only flag actual errors, not stylistic preferences
        - **BE COMPREHENSIVE**: Look at the text from multiple angles (grammar, spelling, style, clarity)
        - **BE SYSTEMATIC**: Go through the text methodically, don't skip sections
        
        RESPONSE FORMAT - Return ONLY this JSON structure:
        {
            "hasErrors": boolean,
            "corrections": [
                {
                    "original": "exact text with error",
                    "suggestion": "corrected version",
                    "type": "grammar|spelling|punctuation|style",
                    "explanation": "clear, brief explanation of the issue",
                    "startIndex": exact_character_position,
                    "endIndex": exact_end_position
                }
            ],
            "overallSuggestion": "comprehensive assessment of text quality and main areas for improvement"
        }
        
        Remember: This is your ONLY chance to catch all errors. Be thorough, methodical, and comprehensive in your analysis.`;

        const text_response = await generateConfiguredText(req, res, prompt, 'check-grammar', { temperature: 0.1, maxTokens: 4096 });
        const result = parseAiResponse('check-grammar', text_response, { sourceText: text });
        return res.json(result);
    } catch (error) {
        if (error.code === 'INVALID_AI_INPUT') throw error;
        console.error('Error in grammar checking:', error.code || error.message);
        const fallbackData = generateFallbackGrammarCheck(req.body.text, 'English');
        return res.json(fallbackData);
    }
});

router.post('/generate-content', async (req, res) => {
    const operation = String(req.body.operation || '');
    try {
        const result = await executeContentOperation({
            operation,
            payload: req.body.payload || {},
            db: req.app.get('db'),
            signal: req.aiAbortSignal,
            requestId: res.locals.requestId,
        });
        res.setHeader('X-AI-Provider', result.provider);
        res.setHeader('X-AI-Model', result.model);
        return res.json(result.data);
    } catch (error) {
        const status = Number(error.status) || (error.code === 'AI_PROVIDER_UNAVAILABLE' ? 503 : 502);
        const code = error.code || (status < 500 ? 'INVALID_AI_REQUEST' : 'AI_PROVIDER_ERROR');
        if (status >= 500) console.error('[AI generation]', { operation, code, requestId: res.locals.requestId });
        return res.status(status).json({ error: {
            code,
            message: status < 500 ? error.message : 'AI generation is temporarily unavailable',
            requestId: res.locals.requestId,
        } });
    }
});

router.post('/parse-resume', async (req, res) => {
    const rawText = String(req.body.rawText || '');
    if (!rawText || rawText.length > 40_000) return res.status(400).json({ error: { code: 'INVALID_RESUME_TEXT', message: 'Resume text must be between 1 and 40000 characters', requestId: res.locals.requestId } });
    try {
        const result = await executeResumeParsing({ rawText, db: req.app.get('db'), signal: req.aiAbortSignal });
        res.setHeader('X-AI-Provider', result.provider);
        res.setHeader('X-AI-Model', result.model);
        return res.json({ data: result.data });
    } catch (error) {
        const status = Number(error.status) || 502;
        const code = error.code || 'AI_PROVIDER_ERROR';
        console.error('[Resume parser]', { code, requestId: res.locals.requestId });
        return res.status(status).json({ error: { code, message: status < 500 ? error.message : 'Resume parsing is temporarily unavailable', requestId: res.locals.requestId } });
    }
});

// Test endpoint to check AI configuration
module.exports = router;
// Exported for unit testing of the interview generation pipeline (prompt builder,
// de-duplication, difficulty distribution, grounded fallback, metadata cleaners, and blueprinting).
module.exports.buildInterviewPrompt = buildInterviewPrompt;
module.exports.generateDefaultInterview = generateDefaultInterview;
module.exports.dedupeQuestions = dedupeQuestions;
module.exports.questionKey = questionKey;
module.exports.interviewDifficultyDistribution = interviewDifficultyDistribution;
module.exports.cleanInterviewMetadataArtifacts = cleanInterviewMetadataArtifacts;
module.exports.isGenericQuestion = isGenericQuestion;
module.exports.extractCandidateProfile = extractCandidateProfile;
module.exports.extractJobRequirements = extractJobRequirements;
module.exports.buildContextualBlueprint = buildContextualBlueprint;

