'use strict';

const crypto = require('crypto');
const { getRepository } = require('../repositories');

const SENSITIVE_KEY_PATTERN = /(password|secret|apikey|accesskey|token|privatekey|credential|keysecret|card|cvv|authorization|cookie|session)/i;
const SECRET_VALUE_PATTERNS = [
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/i,
  /\b(?:sk_(?:live|test)_|nvapi-|rzp_(?:live|test)_|AIza[A-Za-z0-9_-]{20,}|gh[pousr]_|xox[baprs]-|cfut_|AKIA)[A-Za-z0-9_.-]{8,}/i,
  /\bey[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/,
];

function sanitizeAuditValue(key, value, depth = 0) {
  if (depth > 5) return '[TRUNCATED]';
  if (value === null || value === undefined) return value;
  if (SENSITIVE_KEY_PATTERN.test(String(key))) {
    return '[REDACTED]';
  }
  if (typeof value === 'string') {
    if (SECRET_VALUE_PATTERNS.some(pattern => pattern.test(value))) return '[REDACTED]';
    if (value.length > 1000) return value.slice(0, 1000) + '…[TRUNCATED]';
    return value;
  }
  if (typeof value === 'number' || typeof value === 'boolean') {
    return value;
  }
  if (Array.isArray(value)) {
    return value.slice(0, 50).map((item, idx) => sanitizeAuditValue(String(idx), item, depth + 1));
  }
  if (typeof value === 'object') {
    const cleaned = {};
    for (const [k, v] of Object.entries(value)) {
      if (Object.prototype.hasOwnProperty.call(value, k)) {
        cleaned[k] = sanitizeAuditValue(k, v, depth + 1);
      }
    }
    return cleaned;
  }
  return String(value);
}

function deriveAction(method, pathname, body = {}) {
  const normMethod = String(method || 'GET').toUpperCase();
  const path = String(pathname || '').toLowerCase();

  if (body?.action && typeof body.action === 'string' && /^[A-Z0-9_]{3,80}$/.test(body.action)) {
    return body.action;
  }

  if (path.includes('/ai-settings') || path.includes('/ai/quota')) return `${normMethod}_AI_SETTINGS`;
  if (path.includes('/ai/test-provider')) return 'TEST_AI_PROVIDER';
  if (path.includes('/ai/fetch-models')) return 'FETCH_AI_MODELS';
  if (path.includes('/ai/reset-quota')) return 'RESET_AI_QUOTA';
  if (path.includes('/system-health-settings')) return 'UPDATE_SYSTEM_HEALTH_SETTINGS';
  if (path.includes('/health-summary')) return 'READ_HEALTH_SUMMARY';
  if (path.includes('/payment-settings') || path.includes('/payment/test-provider')) return `${normMethod}_PAYMENT_SETTINGS`;
  if (path.includes('/payments/refund')) return 'PROCESS_PAYMENT_REFUND';
  if (path.includes('/coupons')) return `${normMethod}_COUPON`;
  if (path.includes('/firebase-service-account')) return `${normMethod}_FIREBASE_CREDENTIALS`;
  if (path.includes('/settings/')) return `UPDATE_SETTINGS_${path.split('/settings/')[1]?.toUpperCase().replace(/[^A-Z0-9_]/g, '_') || 'GENERAL'}`;
  if (path.includes('/gdpr-settings')) return 'UPDATE_GDPR_SETTINGS';
  if (path.includes('/twilio-settings')) return `${normMethod}_TWILIO_SETTINGS`;
  if (path.includes('/employer-applications/')) return `${normMethod}_EMPLOYER_APPLICATION`;
  if (path.includes('/users/')) return `${normMethod}_USER_PROFILE`;
  if (path.includes('/delete-user') || path.includes('/purge-orphaned-auth')) return 'DELETE_USER_ACCOUNT';
  if (path.includes('/companies/')) return `${normMethod}_COMPANY`;
  if (path.includes('/jobs/')) return `${normMethod}_JOB_POSTING`;
  if (path.includes('/blog/')) return `${normMethod}_BLOG_CONTENT`;
  if (path.includes('/pages/')) return `${normMethod}_CUSTOM_PAGE`;
  if (path.includes('/trusted-by')) return `${normMethod}_TRUSTED_BY_LOGO`;
  if (path.includes('/reviews')) return `${normMethod}_CUSTOMER_REVIEW`;
  if (path.includes('/ads')) return `${normMethod}_AD_BANNER`;
  if (path.includes('/website-meta')) return 'UPDATE_WEBSITE_META';
  if (path.includes('/landing-content')) return 'UPDATE_LANDING_CONTENT';
  if (path.includes('/platform/tenants') && path.includes('decommission')) return 'DECOMMISSION_PLATFORM_TENANT';
  if (path.includes('/platform/tenants')) return `${normMethod}_PLATFORM_TENANT`;
  if (path.includes('/platform/announcements')) return `${normMethod}_PLATFORM_ANNOUNCEMENT`;
  if (path.includes('/platform/operators')) return `${normMethod}_PLATFORM_OPERATOR`;
  if (path.includes('/platform/maintenance')) return `${normMethod}_PLATFORM_MAINTENANCE`;
  if (path.includes('/platform/queues')) return `${normMethod}_PLATFORM_QUEUE`;
  if (path.includes('/audit-logs')) return 'READ_AUDIT_LOGS';
  
  return `${normMethod}_${path.replace(/^\/api\//, '').replace(/[^a-zA-Z0-9]/g, '_').toUpperCase().slice(0, 60)}`;
}

function deriveCategory(pathname) {
  const path = String(pathname || '').toLowerCase();
  if (path.includes('/ai')) return 'ai.governance';
  if (path.includes('/payment') || path.includes('/coupon')) return 'billing.payments';
  if (path.includes('/user') || path.includes('/auth') || path.includes('/employer-application')) return 'iam.users';
  if (path.includes('/system-health') || path.includes('/health')) return 'platform.health';
  if (path.includes('/firebase') || path.includes('/security') || path.includes('/audit')) return 'platform.security';
  if (path.includes('/blog') || path.includes('/page') || path.includes('/review') || path.includes('/trusted-by') || path.includes('/ad')) return 'content.media';
  if (path.includes('/platform/tenant') || path.includes('/enterprise')) return 'enterprise.tenancy';
  return 'system.configuration';
}

function deriveSeverity(method, pathname, statusCode) {
  const status = Number(statusCode) || 200;
  if (status >= 500) return 'HIGH';
  if (status === 401 || status === 403) return 'MEDIUM';
  const normMethod = String(method || '').toUpperCase();
  const path = String(pathname || '').toLowerCase();
  if (normMethod === 'DELETE' || path.includes('delete') || path.includes('purge') || path.includes('refund')) {
    return 'HIGH';
  }
  if (path.includes('firebase-service-account') || path.includes('security') || path.includes('suspend') || path.includes('decommission') || path.includes('/platform/operators') || path.includes('/platform/maintenance')) {
    return 'HIGH';
  }
  if (normMethod === 'POST' || normMethod === 'PUT' || normMethod === 'PATCH') {
    return 'MEDIUM';
  }
  return 'INFO';
}

async function recordAdminAuditLog(requestOrEvent, explicitEvent) {
  const isRequest = Boolean(requestOrEvent && typeof requestOrEvent === 'object'
    && (requestOrEvent.app || requestOrEvent.originalUrl || requestOrEvent.headers));
  let event = isRequest ? (explicitEvent || {}) : (requestOrEvent || {});
  const repository = isRequest ? (requestOrEvent.repository || null) : null;
  if (!event || typeof event !== 'object') event = {};
  const docData = {
    id: event.id || crypto.randomUUID(),
    actorUid: event.actorUid || 'anonymous',
    actorEmail: event.actorEmail || null,
    actorRole: event.actorRole || 'ADMIN',
    action: event.action || 'UNKNOWN_ACTION',
    category: event.category || 'system.general',
    severity: event.severity || 'INFO',
    outcome: event.outcome || ((Number(event.statusCode) || 200) < 400 ? 'SUCCESS' : 'FAILURE'),
    method: event.method || 'GET',
    pathname: event.pathname || '',
    statusCode: Number(event.statusCode) || 200,
    durationMs: Number(event.durationMs) || 0,
    requestId: event.requestId || null,
    ipAddress: event.ipAddress || null,
    userAgent: event.userAgent ? String(event.userAgent).slice(0, 200) : null,
    resourceType: event.resourceType || null,
    resourceId: event.resourceId || null,
    metadata: sanitizeAuditValue('metadata', event.metadata || {}),
    occurredAt: event.occurredAt || new Date().toISOString(),
    createdAt: new Date().toISOString(),
  };
  const activeRepository = repository || getRepository();
  if (!activeRepository?.recordAdminAuditLog) {
    throw Object.assign(new Error('Administrative audit repository is unavailable'), { code: 'AUDIT_WRITE_FAILED', status: 503 });
  }
  await activeRepository.recordAdminAuditLog(docData);
  return docData;
}

function createAdminAuditMiddleware() {
  return (req, res, next) => {
    const startTime = Date.now();
    const originalEnd = res.end;

    res.end = function (...args) {
      originalEnd.apply(res, args);

      const isMutation = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method);
      const isSensitiveRead = req.path.includes('/audit-logs') || req.path.includes('/firebase-service-account');

      if (isMutation || isSensitiveRead) {
        const durationMs = Date.now() - startTime;
        const statusCode = res.statusCode;

        const action = deriveAction(req.method, req.path, req.body);
        const category = deriveCategory(req.path);
        const severity = deriveSeverity(req.method, req.path, statusCode);
        const outcome = statusCode < 400 ? 'SUCCESS' : statusCode === 403 ? 'DENIED' : 'FAILURE';

        const rawIp = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || req.ip || null;
        const ipAddress = typeof rawIp === 'string' ? rawIp.split(',')[0].trim() : null;

        recordAdminAuditLog(req, {
          actorUid: req.user?.uid || 'unauthenticated',
          actorEmail: req.user?.email || null,
          actorRole: String(req.user?.claims?.role || 'ADMIN').toUpperCase(),
          action,
          category,
          severity,
          outcome,
          method: req.method,
          pathname: req.originalUrl || req.path,
          statusCode,
          durationMs,
          requestId: res.locals?.requestId || null,
          ipAddress,
          userAgent: req.get('user-agent'),
          metadata: {
            params: req.params,
            query: req.query,
            body: sanitizeAuditValue('body', req.body || {}),
          },
        }).catch(error => console.error('[AdminAudit] Post-response audit persistence failed:', error?.message || error));
      }
    };

    next();
  };
}

async function queryAdminAuditLogs(repository, options = {}) {
  const limitCount = Math.min(Math.max(Number(options.limit) || 50, 1), 200);
  const activeRepository = repository?.getAdminAuditLogs ? repository : getRepository();
  if (!activeRepository?.getAdminAuditLogs) {
    throw Object.assign(new Error('Administrative audit repository is unavailable'), { code: 'AUDIT_READ_FAILED', status: 503 });
  }
  const page = await activeRepository.getAdminAuditLogs({
    ...options,
    search: String(options.search || '').trim() || undefined,
    limit: limitCount + 1,
  });
  const hasMore = page.length > limitCount;
  // Read-time redaction protects against legacy/imported rows that predate the
  // write-side sanitizer. Administrative audit APIs must never become a
  // credential exfiltration path merely because historical metadata is dirty.
  const logs = page.slice(0, limitCount).map(log => ({
    ...log,
    metadata: sanitizeAuditValue('metadata', log?.metadata || {}),
  }));
  return {
    logs,
    count: logs.length,
    hasMore,
    nextCursor: hasMore ? logs[logs.length - 1]?.id || null : null,
    source: 'mariadb',
  };
}

module.exports = {
  recordAdminAuditLog,
  createAdminAuditMiddleware,
  queryAdminAuditLogs,
  deriveAction,
  deriveCategory,
  deriveSeverity,
  sanitizeAuditValue,
};
