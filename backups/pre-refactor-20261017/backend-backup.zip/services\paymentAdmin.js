'use strict';

const MASKED_SECRET = /[•*]/;
const PAYMENT_PROVIDERS = Object.freeze(['razorpay', 'stripe', 'paypal', 'paytm', 'phonepe']);

function paymentError(code, message, status = 400) {
  return Object.assign(new Error(message), { code, status });
}

/**
 * Normalize one write-only payment credential. A blank or masked form value is
 * an instruction to preserve the stored value, not to overwrite it. Deletion
 * is intentionally a separate boolean and deployment-managed credentials
 * cannot be cleared from the Admin UI.
 */
function resolveWriteOnlySecret({ value = '', existing = '', environment = '', clear = false, label = 'payment credential' } = {}) {
  const raw = String(value || '').trim();
  if (clear && String(environment || '').trim()) {
    throw paymentError('INFRASTRUCTURE_SECRET_CANNOT_CLEAR', `${label} is deployment-managed and cannot be cleared from the Admin UI.`, 409);
  }
  if (clear) return { value: '', action: 'CLEAR' };
  if (!raw || MASKED_SECRET.test(raw)) return { value: String(existing || ''), action: 'PRESERVE' };
  if (raw.length < 8 || raw.length > 1000 || /\p{Cc}/u.test(raw)) {
    throw paymentError('PAYMENT_SETTINGS_VALIDATION_ERROR', `Invalid ${label} length or format.`, 400);
  }
  return { value: raw, action: 'REPLACE' };
}

function maskWriteOnlySecret(value) {
  const raw = String(value || '').trim();
  return raw ? `••••${raw.slice(-4)}` : '';
}

function paymentCredentialStatus({ keyId = '', secret = '', envKeyId = '', envSecret = '' } = {}) {
  const effectiveId = String(envKeyId || keyId || '').trim();
  const effectiveSecret = String(envSecret || secret || '').trim();
  return {
    configured: Boolean(effectiveId && effectiveSecret),
    source: envSecret || envKeyId ? 'environment' : effectiveSecret || effectiveId ? 'mysql' : 'none',
    masked: maskWriteOnlySecret(effectiveSecret),
  };
}

function selectPaymentPair({ envId = '', envSecret = '', storedId = '', storedSecret = '', requiresId = true } = {}) {
  const environmentId = String(envId || '').trim();
  const environmentSecret = String(envSecret || '').trim();
  const persistedId = String(storedId || '').trim();
  const persistedSecret = String(storedSecret || '').trim();
  if ((!requiresId || environmentId) && environmentSecret) return { id: environmentId, secret: environmentSecret, source: 'environment' };
  if ((!requiresId || persistedId) && persistedSecret) return { id: persistedId, secret: persistedSecret, source: 'mysql' };
  if (environmentId || environmentSecret) return { id: environmentId, secret: environmentSecret, source: 'environment-partial' };
  if (persistedId || persistedSecret) return { id: persistedId, secret: persistedSecret, source: 'mysql-partial' };
  return { id: '', secret: '', source: 'none' };
}

function publicPaymentSettings(value) {
  const sensitive = /(?:secret|password|privatekey|authtoken|clientsecret|merchantkey|saltkey|keysecret|token|api[_-]?key|accesskey)/i;
  if (Array.isArray(value)) return value.map(publicPaymentSettings);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !sensitive.test(key))
    .map(([key, item]) => [key, publicPaymentSettings(item)]));
}

const { getRepository } = require('../repositories');

/**
 * Canonical, secret-free payment settings projection shared by the Admin UI and
 * the backwards-compatible `/api/admin/payment-settings` read alias.
 */
async function getPaymentSettingsProjection(environment = process.env) {
  const repo = getRepository();
  const [publicRootValue, secretsValue] = await Promise.all([
    repo.getSetting('public_config'),
    repo.getSetting('payment_providers'),
  ]);
  if (!publicRootValue || typeof publicRootValue !== 'object'
      || !publicRootValue.subscriptions || typeof publicRootValue.subscriptions !== 'object') {
    throw paymentError(
      'PAYMENT_SETTINGS_UNINITIALIZED',
      'The authoritative payment settings projection has not been initialized.',
      503
    );
  }
  const publicRoot = publicRootValue;
  const secrets = secretsValue && typeof secretsValue === 'object' ? secretsValue : {};

  const publicConfig = publicPaymentSettings(publicRoot.subscriptions);
  const providers = {
    razorpay: selectPaymentPair({ envId: environment.RAZORPAY_KEY_ID, envSecret: environment.RAZORPAY_KEY_SECRET, storedId: secrets.razorpay?.keyId || publicConfig.razorpayKeyId, storedSecret: secrets.razorpay?.keySecret }),
    stripe: selectPaymentPair({ envSecret: environment.STRIPE_SECRET, storedSecret: secrets.stripe?.secretKey, requiresId: false }),
    paypal: selectPaymentPair({ envId: environment.PAYPAL_CLIENT_ID, envSecret: environment.PAYPAL_CLIENT_SECRET, storedId: secrets.paypal?.clientId || publicConfig.paypalClientId, storedSecret: secrets.paypal?.clientSecret }),
    paytm: selectPaymentPair({ envId: environment.PAYTM_MID, envSecret: environment.PAYTM_MERCHANT_KEY, storedId: secrets.paytm?.mid || publicConfig.paytmMid, storedSecret: secrets.paytm?.merchantKey }),
    phonepe: selectPaymentPair({ envId: environment.PHONEPE_MERCHANT_ID, envSecret: environment.PHONEPE_SALT_KEY, storedId: secrets.phonepe?.merchantId || publicConfig.phonepeId, storedSecret: secrets.phonepe?.saltKey }),
  };
  const configuredProviders = Object.fromEntries(Object.entries(providers).map(([provider, pair]) => [provider, Boolean(pair.secret && (provider === 'stripe' || pair.id))]));
  const maskedKeys = Object.fromEntries(Object.entries(providers).map(([provider, pair]) => [provider, maskWriteOnlySecret(pair.secret)]));
  const credentialSources = Object.fromEntries(Object.entries(providers).map(([provider, pair]) => [provider, pair.source === 'environment' ? 'env' : pair.source === 'mysql' ? 'mysql' : pair.source]));
  return {
    settings: publicConfig,
    publicKeys: {
      razorpayKeyId: providers.razorpay.id || '',
      stripePublishableKey: publicConfig.stripePublishableKey || '',
      paypalClientId: providers.paypal.id || '',
      paytmMid: providers.paytm.id || '',
      phonepeId: providers.phonepe.id || '',
      phonepeSaltIndex: publicConfig.phonepeSaltIndex || secrets.phonepe?.saltIndex || environment.PHONEPE_SALT_INDEX || '',
      paytmWebsite: publicConfig.paytmWebsite || secrets.paytm?.website || environment.PAYTM_WEBSITE || '',
    },
    configuredProviders,
    maskedKeys,
    credentialSources,
    revision: Number(secrets._revision || publicRoot._settingsRevisions?.payments || 0),
    secretPolicy: {
      emptyField: 'PRESERVE',
      clear: 'EXPLICIT_ONLY',
      environmentManagedSecrets: Object.entries(credentialSources).filter(([, source]) => source.startsWith('env')).map(([provider]) => provider),
    },
  };
}

module.exports = {
  MASKED_SECRET,
  PAYMENT_PROVIDERS,
  paymentError,
  resolveWriteOnlySecret,
  maskWriteOnlySecret,
  paymentCredentialStatus,
  selectPaymentPair,
  getPaymentSettingsProjection,
};
