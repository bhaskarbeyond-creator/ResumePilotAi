import React, { useCallback, useEffect, useState, useRef } from 'react';
import TemplateRenderer from '../TemplateRenderer';
import { useTranslation } from 'react-i18next';

const PreviewModal = ({ showPreview, setShowPreview, resumeData, onDownload, isDownloading, onDownloadDocx, isDownloadingDocx, onShare, isSharing, currentTemplate = 'Cv1', getTemplateName }) => {
    const { t, i18n } = useTranslation('common');
    const [isVisible, setIsVisible] = useState(false);
    const dialogRef = useRef(null);
    const returnFocusRef = useRef(null);

    useEffect(() => {
        if (showPreview) {
            document.body.style.overflow = 'hidden';
            setTimeout(() => setIsVisible(true), 10);
        } else {
            document.body.style.overflow = 'unset';
            setIsVisible(false);
        }

        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [showPreview]);

    const handleClose = useCallback(() => {
        setIsVisible(false);
        setTimeout(() => {
            setShowPreview(false);
            returnFocusRef.current?.focus?.();
        }, 300);
    }, [setShowPreview]);

    const handleBackdropClick = (e) => {
        if (e.target === e.currentTarget) {
            handleClose();
        }
    };

    useEffect(() => {
        if (!showPreview) return undefined;
        returnFocusRef.current = document.activeElement;
        requestAnimationFrame(() => dialogRef.current?.querySelector('button')?.focus());
        const handleKeyDown = (event) => {
            if (event.key === 'Escape') handleClose();
            if (event.key !== 'Tab' || !dialogRef.current) return;
            const focusable = [...dialogRef.current.querySelectorAll('button:not([disabled]), a[href], input:not([disabled]), [tabindex]:not([tabindex="-1"])')];
            if (!focusable.length) return;
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        };
        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [showPreview, handleClose]);

    if (!showPreview) return null;

    return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-2 sm:p-4">
            {/* Enhanced Backdrop with glassmorphism effect */}
            <div
                className={`absolute inset-0 transition-all duration-500 ease-out ${isVisible ? 'bg-[var(--cuba-ink)]/20 backdrop-blur-md' : 'bg-transparent backdrop-blur-none'}`}
                onClick={handleBackdropClick}
                style={{
                    background: isVisible ? 'linear-gradient(135deg, rgba(15, 23, 42, 0.1) 0%, rgba(30, 41, 59, 0.2) 100%)' : 'transparent',
                }}
            />

            {/* Modal Container with enhanced animations and mobile responsiveness */}
            <div
                ref={dialogRef}
                role="dialog"
                aria-modal="true"
                aria-labelledby="resume-preview-title"
                tabIndex={-1}
                className={`relative w-full max-w-7xl max-h-[95vh] sm:max-h-[90vh] bg-white/95 backdrop-blur-xl rounded-lg sm:rounded-2xl shadow-2xl border border-white/20 transform transition-all duration-500 ease-out ${
                    isVisible ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-8 opacity-0 scale-95'
                }`}
                style={{
                    boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.1)',
                }}>
                {/* Enhanced Header with gradient background - Mobile responsive */}
                <div className="relative bg-gradient-to-r from-[var(--cuba-canvas)] to-blue-50/50 border-b border-[var(--cuba-line)]/50 px-3 sm:px-6 lg:px-8 py-3 sm:py-4 lg:py-6 rounded-t-lg sm:rounded-t-2xl">
                    <button
                        type="button"
                        onClick={handleClose}
                        className="absolute right-2 top-2 inline-flex h-11 w-11 items-center justify-center rounded-lg text-[var(--cuba-ink-subtle)] hover:bg-[var(--cuba-canvas)] hover:text-[var(--cuba-ink-muted)] sm:hidden"
                        aria-label={t('PreviewModal.actions.close')}
                    >
                        <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                    <div className="flex flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <div className="flex items-center space-x-2 sm:space-x-4 min-w-0 flex-1">
                            <div className="hidden sm:block p-2 lg:p-3 bg-blue-100 rounded-lg lg:rounded-xl">
                                <svg className="w-4 h-4 lg:w-6 lg:h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                    />
                                </svg>
                            </div>
                            <div className="min-w-0 flex-1 pr-10 sm:pr-0">
                                <h2 id="resume-preview-title" className="text-lg sm:text-xl lg:text-2xl font-bold text-[var(--cuba-ink)] tracking-tight truncate">{t('PreviewModal.title')}</h2>
                                <p className="text-xs sm:text-sm text-[var(--cuba-ink-muted)] mt-0.5 sm:mt-1 font-medium truncate">
                                    {t('PreviewModal.subtitle', { templateName: getTemplateName ? getTemplateName(currentTemplate) : currentTemplate })}
                                </p>
                            </div>
                        </div>

                        <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto sm:flex-nowrap sm:justify-end sm:gap-3 sm:flex-shrink-0">
                            {/* Enhanced Share Resume Button */}
                            {onShare && (
                                <button
                                    onClick={onShare}
                                    disabled={isSharing}
                                    className={`relative px-3 sm:px-4 lg:px-5 py-2 sm:py-2.5 lg:py-3 rounded-lg sm:rounded-xl font-semibold transition-all duration-300 flex items-center space-x-1 sm:space-x-2 text-xs sm:text-sm shadow-sm ${
                                        isSharing
                                            ? 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-subtle)] cursor-not-allowed shadow-none'
                                            : 'bg-white hover:bg-[var(--cuba-canvas)] border border-[var(--cuba-line-strong)] text-[var(--cuba-ink-muted)] hover:text-indigo-600 shadow-slate-200 hover:shadow-md transform hover:-translate-y-0.5'
                                    }`}>
                                    {isSharing ? (
                                        <>
                                            <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-[var(--cuba-line-strong)] border-t-transparent rounded-full animate-spin"></div>
                                            <span className="hidden sm:inline">{t('PreviewModal.actions.sharing', 'Sharing...')}</span>
                                            <span className="sm:hidden">{t('PreviewModal.actions.sharingShort', 'Share...')}</span>
                                        </>
                                    ) : (
                                        <>
                                            <svg className="w-3 h-3 sm:w-4 sm:h-4 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                                            </svg>
                                            <span className="hidden sm:inline">{t('PreviewModal.actions.shareResume', 'Share Resume')}</span>
                                            <span className="sm:hidden">{t('PreviewModal.actions.shareResumeShort', 'Share')}</span>
                                        </>
                                    )}
                                </button>
                            )}

                            {/* Enhanced Download Word (DOCX) Button */}
                            {onDownloadDocx && (
                                <button
                                    onClick={onDownloadDocx}
                                    disabled={isDownloadingDocx}
                                    className={`relative px-3 sm:px-4 lg:px-5 py-2 sm:py-2.5 lg:py-3 rounded-lg sm:rounded-xl font-semibold transition-all duration-300 flex items-center space-x-1 sm:space-x-2 text-xs sm:text-sm shadow-lg ${
                                        isDownloadingDocx
                                            ? 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-subtle)] cursor-not-allowed shadow-none'
                                            : 'bg-gradient-to-r from-emerald-600 to-green-700 hover:from-emerald-700 hover:to-green-800 text-white shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:shadow-xl transform hover:-translate-y-0.5'
                                    }`}>
                                    {isDownloadingDocx ? (
                                        <>
                                            <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-[var(--cuba-line-strong)] border-t-transparent rounded-full animate-spin"></div>
                                            <span className="hidden sm:inline">{t('PreviewModal.actions.generatingDocx', 'Generating DOCX...')}</span>
                                            <span className="sm:hidden">{t('PreviewModal.actions.generatingDocxShort', 'DOCX...')}</span>
                                        </>
                                    ) : (
                                        <>
                                            <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                                />
                                            </svg>
                                            <span className="hidden sm:inline">{t('PreviewModal.actions.downloadDocx', 'Download Word (DOCX)')}</span>
                                            <span className="sm:hidden">{t('PreviewModal.actions.downloadDocxShort', 'Word')}</span>
                                        </>
                                    )}
                                </button>
                            )}

                            {/* Enhanced Download Button - Mobile responsive */}
                            <button
                                onClick={onDownload}
                                disabled={isDownloading}
                                className={`relative px-3 sm:px-4 lg:px-6 py-2 sm:py-2.5 lg:py-3 rounded-lg sm:rounded-xl font-semibold transition-all duration-300 flex items-center space-x-1 sm:space-x-2 text-xs sm:text-sm shadow-lg ${
                                    isDownloading
                                        ? 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-subtle)] cursor-not-allowed shadow-none'
                                        : 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-blue-500/25 hover:shadow-blue-500/40 hover:shadow-xl transform hover:-translate-y-0.5'
                                }`}>
                                {isDownloading ? (
                                    <>
                                        <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-[var(--cuba-line-strong)] border-t-transparent rounded-full animate-spin"></div>
                                        <span className="hidden sm:inline">{t('PreviewModal.actions.generatingPdf')}</span>
                                        <span className="sm:hidden">PDF...</span>
                                    </>
                                ) : (
                                    <>
                                        <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                                strokeWidth={2}
                                                d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                            />
                                        </svg>
                                        <span className="hidden sm:inline">{t('PreviewModal.actions.downloadPdf')}</span>
                                        <span className="sm:hidden">PDF</span>
                                    </>
                                )}
                            </button>

                            {/* Enhanced Close Button - Mobile responsive */}
                            <button
                                onClick={handleClose}
                                className="hidden h-11 min-w-11 items-center justify-center rounded-lg text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-canvas)] sm:inline-flex sm:rounded-xl transition-all duration-200 group"
                                aria-label={t('PreviewModal.actions.close')}>
                                <svg className="w-4 h-4 sm:w-5 sm:h-5 group-hover:rotate-90 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                {/* Enhanced Modal Body with improved styling and mobile responsiveness */}
                <div className="relative flex-1 overflow-hidden rounded-b-lg sm:rounded-b-2xl">
                    {/* Gradient overlay for better visual depth */}
                    <div className="absolute inset-0 bg-gradient-to-br from-[var(--cuba-canvas)]/50 via-white/30 to-blue-50/50 pointer-events-none"></div>

                    <div className="relative h-[calc(95vh-100px)] sm:h-[calc(90vh-140px)] overflow-auto p-2 sm:p-4 custom-scrollbar">
                        <div className="flex justify-center items-start min-h-full">
                            {/* Enhanced CV Container with multi-page support */}
                            <div
                                className="bg-transparent transition-all duration-300 pb-16"
                                style={{
                                    // Mobile: smaller scale for better fit
                                    transform: window.innerWidth < 640 ? 'scale(0.45)' : window.innerWidth < 1024 ? 'scale(0.55)' : 'scale(0.65)',
                                    transformOrigin: 'top center',
                                    width: '794px',
                                }}>
                                <TemplateRenderer
                                    templateId={currentTemplate}
                                    values={resumeData}
                                    language={i18n.language}
                                    onError={(error) => console.error('Template modal render failed:', error)}
                                />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Keyboard shortcut hint - Mobile responsive */}
                <div className="absolute bottom-2 sm:bottom-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-[var(--cuba-ink)]/90 backdrop-blur-sm text-white px-2 sm:px-3 py-1.5 sm:py-2 rounded-full text-xs font-medium flex items-center space-x-1 sm:space-x-2 shadow-lg">
                        <kbd className="bg-[var(--cuba-ink)] px-1.5 sm:px-2 py-0.5 sm:py-1 rounded text-xs">ESC</kbd>
                        <span className="hidden sm:inline">{t('PreviewModal.keyboard.escToClose')}</span>
                        <span className="sm:hidden">Close</span>
                    </div>
                </div>
            </div>

            {/* Custom scrollbar styles */}
            <style>{`
                .custom-scrollbar::-webkit-scrollbar {
                    width: 6px;
                }
                .custom-scrollbar::-webkit-scrollbar-track {
                    background: rgba(241, 245, 249, 0.5);
                    border-radius: 3px;
                }
                .custom-scrollbar::-webkit-scrollbar-thumb {
                    background: rgba(148, 163, 184, 0.5);
                    border-radius: 3px;
                }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                    background: rgba(148, 163, 184, 0.8);
                }

                /* Mobile specific styles */
                @media (max-width: 640px) {
                    .custom-scrollbar::-webkit-scrollbar {
                        width: 4px;
                    }
                }
            `}</style>
        </div>
    );
};

export default PreviewModal;
