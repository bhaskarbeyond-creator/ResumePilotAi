import React, { Component } from "react";
import { getResumes, getFavourites, getProfileOfUser, getStatesOfUser, IncrementDownloads, addOneToNumberOfDocumentsDownloaded, getSystemSettings, getUserCoverLetters, deleteCoverLetter } from "../../../services/api/platform";
import fire from '../../../conf/fire';
import { createResumeDraft, deleteResumeDraft, publishResume, saveResumeDraft } from '../../../services/resumePersistence';
import { normalizeResumeData } from '../../../utils/resumeData';
import LoaderAnimation from "../../../assets/animations/lottie-loader.json";
import { withTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import usePromptDialog from "../../../hooks/usePromptDialog";
import { useLottie } from "lottie-react";
import { FaCheckCircle, FaChevronRight, FaPencilAlt, FaEllipsisH, FaEnvelope, FaPlus, FaBullseye, FaShareAlt, FaTrashAlt, FaFileAlt, FaClock, FaDownload, FaStar, FaCalendarAlt, FaUsers, FaBars, FaInbox, FaEye, FaSearch, FaTimes, FaChartLine, FaMagic, FaBolt, FaArrowRight, FaLightbulb } from "react-icons/fa";
import { FiGrid, FiList, FiChevronDown } from "react-icons/fi";
import { trackDownload, trackEvent, trackEngagement } from "../../../utils/ga4";
import { downloadResumePdf, downloadResumeDocx } from "../../../utils/exportDownloader";
import { isPaidMembershipTier, formatSafeDate } from "../../../utils/subscriptionUtils";
import { getTemplateComponent } from "../../../utils/templateRegistry";
import { calculateAtsScore } from "../../../utils/atsScore";
import TemplateRenderer from "../../TemplateRenderer";
import PreviewModal from "../../BuildResume/PreviewModal";
import PremiumUpgradeModal from "../../common/PremiumUpgradeModal";
import SubscriptionModal from "../DashboardSettings/SubscriptionModal";
import ShareModal from "../ShareModal/ShareModal";
import { isCubaShellEnabled } from "../../cuba/cubaShellFlag";
// DIR-094: the reference's bottom three-column analytics band. Each column owns its
// own honest data contract — see the header comment in each file.
import CubaApplicationProgressChart from "../../Candidate/CubaApplicationProgressChart";
import CubaTopJobMatches from "../../Candidate/CubaTopJobMatches";
import CubaNextSteps from "../../Candidate/CubaNextSteps";


const LoaderView = () => {
  const loaderOptions = {
    loop: true,
    autoplay: true,
    animationData: LoaderAnimation,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  const { View } = useLottie(loaderOptions);
  return View;
};

class DashboardHomepage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      displayDocuments: [],
      fetchedDocuments: [],
      pageNumber: 1,
      perPage: 12,
      favourites: [],
      isfetcing: false,
      isPaginating: false,
      hasDocuments: false,
      documentsError: null,
      enableImportModule: false,
      enableCoverLetterModule: false,
      pagination: {
        totalItems: 0,
        totalPages: 0,
        currentPage: 1,
        hasNextPage: false,
        hasPreviousPage: false,
      },
      openDropdownId: null,
      deleteModal: {
        isOpen: false,
        resumeId: null,
        resumeName: "",
        isDeleting: false,
      },
      showPremiumUpgradeModal: false,
      showSubscriptionModal: false,
      pendingDownloadDocument: null,
      pendingDownloadType: 'pdf',
      // DIR-058: the four mandated onboarding steps. `key` maps each step to a
      // MEASURED metric (see applyOnboardingProgress) so completion is derived
      // from the candidate's real documents, never hardcoded.
      onboardingSteps: [
        {
          id: 1,
          key: "profile",
          title: props.t(
            "DashboardHomepage.onboarding.steps.completeProfile.title",
            "Complete your profile"
          ),
          description: props.t(
            "DashboardHomepage.onboarding.steps.completeProfile.description",
            "Add your name, email, phone and location so every document starts from an accurate master profile."
          ),
          completed: false,
          route: "/dashboard/settings?tab=Profile",
          score: 15,
        },
        {
          id: 2,
          key: "resume",
          title: props.t(
            "DashboardHomepage.onboarding.steps.createResume.title",
            "Create your first resume"
          ),
          description: props.t(
            "DashboardHomepage.onboarding.steps.createResume.description",
            "Craft a standout resume with our intuitive builder, 50+ professional templates, and AI-powered tailoring for your target role."
          ),
          completed: false,
          route: "/build-resume/heading",
          score: 35,
        },
        {
          id: 3,
          key: "cover",
          title: props.t(
            "DashboardHomepage.onboarding.steps.coverLetter.title",
            "Write a cover letter"
          ),
          description: props.t(
            "DashboardHomepage.onboarding.steps.coverLetter.description",
            "Generate a role-specific cover letter that matches the resume you just built."
          ),
          completed: false,
          route: "/dashboard/cover-letters",
          score: 25,
        },
        {
          id: 4,
          key: "application",
          title: props.t(
            "DashboardHomepage.onboarding.steps.firstApplication.title",
            "Apply to your first job"
          ),
          description: props.t(
            "DashboardHomepage.onboarding.steps.firstApplication.description",
            "Submit your first application from the job portal and track it in your pipeline."
          ),
          completed: false,
          route: "/dashboard/jobs",
          score: 25,
        },
      ],
      profile: {
        name: "",
        email: "",
        phone: "",
        address: "",
        city: "",
        country: "",
        occupation: "",
      },
      activeTab: "all",
      searchQuery: "",
      // DIR-090 GAP-3: the reference toolbar's Sort dropdown and Grid/List toggle are REAL
      // controls bound to real state. "updated" and "grid" are the reference defaults.
      sortBy: "updated",
      viewMode: "grid",
      // DIR-058: real, owner-scoped candidate metrics. `null` means "not yet
      // measured" (rendered as an honest dash) — never a fabricated zero.
      userStats: {
        resumes: null,
        coverLetters: null,
        portfolios: null,
        applications: null,
        trackedJobs: null,
        profileComplete: false,
        unavailable: false,
      },
      loadedTemplates: {}, // Store dynamically loaded template components
      downloadingResumeIds: new Set(), // Track which resumes are currently being downloaded
      downloadingDocxIds: new Set(), // Track which resumes are currently downloading DOCX
      sharingResumeIds: new Set(), // Track which resumes are currently publishing for share
      isDownloading: false, // Add loading state
      showPreviewModal: false,
      previewingDocument: null,
      membership: this.props.membership || 'Basic',
      freeTierAccess: null,
      shareModal: {
        isOpen: false,
        documentId: null,
        documentTitle: '',
      },
    };

    this.isPremiumUser = this.isPremiumUser.bind(this);
    this.allowsPdfExport = this.allowsPdfExport.bind(this);
    this.allowsDocxExport = this.allowsDocxExport.bind(this);
    this.allowsShareLink = this.allowsShareLink.bind(this);
    this.addFavorite = this.addFavorite.bind(this);
    this.removeFavorite = this.removeFavorite.bind(this);
    this.getAllDocuments = this.getAllDocuments.bind(this);
    this.returnDocuments = this.returnDocuments.bind(this);
    this.getProfileOfUserFront = this.getProfileOfUserFront.bind(this);
    this.setPageNumber = this.setPageNumber.bind(this);
    this.searchDocuments = this.searchDocuments.bind(this);
    this.frontGetFavourites = this.frontGetFavourites.bind(this);
    this.handleStepClick = this.handleStepClick.bind(this);
    this.completeStep = this.completeStep.bind(this);
    this.setAsCurrentResume = this.setAsCurrentResume.bind(this);
    this.handleDeleteResume = this.handleDeleteResume.bind(this);
    this.openDeleteModal = this.openDeleteModal.bind(this);
    this.closeDeleteModal = this.closeDeleteModal.bind(this);
    this.confirmDeleteResume = this.confirmDeleteResume.bind(this);
    this.getUserStats = this.getUserStats.bind(this);
    this.setActiveTab = this.setActiveTab.bind(this);
    this.downloadResume = this.downloadResume.bind(this);
    this.shareResume = this.shareResume.bind(this);
    this.renameResume = this.renameResume.bind(this);
    this.duplicateResume = this.duplicateResume.bind(this);
    this.openDocumentPreview = this.openDocumentPreview.bind(this);
    this.closeDocumentPreview = this.closeDocumentPreview.bind(this);
  }

  isPremiumUser() {
    const membership = this.state.membership || this.props.membership || this.state.profile?.membership;
    return isPaidMembershipTier(membership);
  }

  allowsPdfExport() {
    return this.isPremiumUser() || this.state.freeTierAccess?.allowFreePdfDownload === true;
  }

  allowsDocxExport() {
    return this.isPremiumUser() || this.state.freeTierAccess?.allowFreeDocxDownload === true;
  }

  allowsShareLink() {
    return this.isPremiumUser() || this.state.freeTierAccess?.allowFreeShareLink === true;
  }

  componentDidUpdate(prevProps) {
    if (this.props.membership !== prevProps.membership && this.props.membership) {
      this.setState({ membership: this.props.membership });
    }
  }

  openDocumentPreview(document) {
    this.setState({
      previewingDocument: document,
      showPreviewModal: true,
    });
  }

  closeDocumentPreview() {
    this.setState({
      showPreviewModal: false,
      previewingDocument: null,
    });
  }

  async getAllDocuments(isPagination = false) {
    this.setState({ documentsError: null });
    // For pagination, don't clear documents and use different loading state
    if (isPagination) {
      this.setState({ isPaginating: true });
    } else {
      this.setState({ fetchedDocuments: [], isfetcing: true });
    }

    const { pageNumber, perPage } = this.state;
    let allDocuments = [];
    let response = null;

    try {
      const userId = fire.auth().currentUser?.uid;
      if (!userId) throw new Error('Authentication is required');
      response = await getResumes(userId, pageNumber, perPage);

      if (response && response.resumes) {
        allDocuments = [...response.resumes];
      }
    } catch (error) {
      this.setState({ documentsError: error.message || 'Resumes could not be loaded.', isfetcing: false, isPaginating: false });
      return;
    }

    if (allDocuments.length === 0) {
      this.setState({
        fetchedDocuments: [],
        displayDocuments: null,
        hasDocuments: false,
        isPaginating: false,
        isfetcing: false,
        pagination: {
          totalItems: 0,
          totalPages: 0,
          currentPage: pageNumber,
          hasNextPage: false,
          hasPreviousPage: false,
        },
      });
      return;
    }

    // Fetch saved cover letters for unified dashboard management
    const savedCoverLetters = await getUserCoverLetters();

    // Update all state at once for better React 19 compatibility
    this.setState({
      fetchedDocuments: allDocuments,
      displayDocuments: allDocuments,
      savedCoverLetters,
      hasDocuments: true,
      isPaginating: false,
      isfetcing: false,
      pagination: (response && response.pagination) || this.state.pagination,
    });
  }

  async getProfileOfUserFront() {
    let profile = await getProfileOfUser(fire.auth().currentUser?.uid);
    let stateProfile = this.state.profile;
    for (let key in profile) {
      if (Object.prototype.hasOwnProperty.call(stateProfile, key)) {
        stateProfile[key] = profile[key];
      }
    }
    const resolvedMembership = profile?.membership || this.state.membership;
    this.setState({ profile: stateProfile, membership: resolvedMembership });
  }

  calculatePages() {
    return Math.ceil(this.state.fetchedDocuments.length / this.state.perPage);
  }

  addFavorite(id) {
    this.setState({ favourites: this.state.favourites.concat(id) });
  }

  removeFavorite(id) {
    this.setState({
      favourites: this.state.favourites.filter((item) => item !== id),
    });
  }

  async handleDeleteResume(resumeId, resumeName) {
    this.openDeleteModal(resumeId, resumeName);
  }

  frontGetFavourites() {
    getFavourites(fire.auth().currentUser?.uid).then((value) => {
      this.setState({ favourites: value });
    });
  }

  // DIR-058: consume the real, owner-scoped metrics. A failed read is surfaced
  // as `unavailable` (honest dash) — the dashboard never invents a zero.
  async getUserStats() {
    const userId = fire.auth().currentUser?.uid;
    if (!userId) return;
    const stats = await getStatesOfUser(userId);
    if (!stats || stats.apiError) {
      this.setState((prev) => ({
        userStats: { ...prev.userStats, unavailable: true },
      }));
      return;
    }
    const num = (value) => (typeof value === 'number' && Number.isFinite(value) ? value : 0);
    const measured = {
      resumes: num(stats.resumes),
      coverLetters: num(stats.coverLetters),
      portfolios: num(stats.portfolios),
      applications: num(stats.applications),
      trackedJobs: num(stats.trackedJobs),
      profileComplete: stats.profileComplete === true,
      unavailable: false,
    };
    this.setState({ userStats: measured });
    this.applyOnboardingProgress(measured);
  }

  /**
   * DIR-058: derive the onboarding checklist from the MEASURED counts, so the
   * checklist reflects the candidate's real progress instead of a fixed step.
   */
  applyOnboardingProgress(measured) {
    const done = {
      profile: measured.profileComplete === true,
      resume: measured.resumes > 0,
      cover: measured.coverLetters > 0,
      application: measured.applications > 0,
    };
    this.setState((prev) => ({
      onboardingSteps: prev.onboardingSteps.map((step) => (
        Object.prototype.hasOwnProperty.call(done, step.key)
          ? { ...step, completed: done[step.key] }
          : step
      )),
    }));
  }

  componentDidMount() {
    getSystemSettings().then((settings) => {
      const enabled = settings?.modules?.enableImportModule !== undefined
        ? settings.modules.enableImportModule === true
        : settings?.ai?.enableImportModule === true;
      const coverEnabled = settings?.modules?.enableCoverLetterModule !== undefined
        ? settings.modules.enableCoverLetterModule === true
        : false;
      const freeTierAccess = settings?.watermark || {};
      this.setState((prev) => ({
        enableImportModule: enabled,
        enableCoverLetterModule: coverEnabled,
        freeTierAccess,
        activeTab: !coverEnabled && prev.activeTab === 'cover-letters' ? 'all' : prev.activeTab,
      }));
    }).catch(() => {
      this.setState({ enableImportModule: false, enableCoverLetterModule: false, freeTierAccess: {} });
    });

    this.handleSystemSettingsUpdated = (e) => {
      if (e?.detail?.modules) {
        const m = e.detail.modules;
        const enabled = m.enableImportModule !== undefined
          ? m.enableImportModule === true
          : false;
        const coverEnabled = m.enableCoverLetterModule !== undefined
          ? m.enableCoverLetterModule === true
          : false;
        this.setState((prev) => ({
          enableImportModule: enabled,
          enableCoverLetterModule: coverEnabled,
          activeTab: !coverEnabled && prev.activeTab === 'cover-letters' ? 'all' : prev.activeTab,
        }));
        return;
      }
      if (e?.detail?.category === 'watermark' && e.detail.settings) {
        this.setState({ freeTierAccess: e.detail.settings });
      }
      getSystemSettings().then((settings) => {
        const enabled = settings?.modules?.enableImportModule !== undefined
          ? settings.modules.enableImportModule === true
          : settings?.ai?.enableImportModule === true;
        const coverEnabled = settings?.modules?.enableCoverLetterModule !== undefined
          ? settings.modules.enableCoverLetterModule === true
          : false;
        const freeTierAccess = settings?.watermark || {};
        this.setState((prev) => ({
          enableImportModule: enabled,
          enableCoverLetterModule: coverEnabled,
          freeTierAccess,
          activeTab: !coverEnabled && prev.activeTab === 'cover-letters' ? 'all' : prev.activeTab,
        }));
      }).catch(() => {});
    };
    window.addEventListener('systemSettingsUpdated', this.handleSystemSettingsUpdated);

    this.handleGlobalKeyDown = (e) => {
      if (e.key === 'Escape') {
        if (this.state.showPreviewModal) {
          this.closeDocumentPreview();
        } else if (this.state.deleteModal.isOpen && !this.state.deleteModal.isDeleting) {
          this.closeDeleteModal();
        } else if (this.state.openDropdownId) {
          this.setState({ openDropdownId: null });
        }
      }
    };
    window.addEventListener('keydown', this.handleGlobalKeyDown);

    this.handleGlobalClick = () => {
      if (this.state.openDropdownId) {
        this.setState({ openDropdownId: null });
      }
    };
    window.addEventListener('click', this.handleGlobalClick);

    this.handleWindowFocus = () => {
      const user = fire.auth().currentUser;
      if (user && !this.state.isfetcing && !this.state.isPaginating) {
        this.getAllDocuments();
        this.getUserStats();
      }
    };
    window.addEventListener('focus', this.handleWindowFocus);
    this.handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        this.handleWindowFocus();
      }
    };
    document.addEventListener('visibilitychange', this.handleVisibilityChange);

    // Reset pagination state to ensure we start from page 1
    this.setState(
      {
        pageNumber: 1,
        pagination: {
          totalItems: 0,
          totalPages: 0,
          currentPage: 1,
          hasNextPage: false,
          hasPreviousPage: false,
        },
      }
    );
    this.unsubscribeAuth = fire.auth().onAuthStateChanged(user => {
      if (user) {
        this.getAllDocuments();
        this.getUserStats();
      } else {
        this.setState({ fetchedDocuments: [], displayDocuments: [], hasDocuments: false, isfetcing: false });
      }
    });
  }

  componentWillUnmount() {
    this.unsubscribeAuth?.();
    if (this.handleSystemSettingsUpdated) {
      window.removeEventListener('systemSettingsUpdated', this.handleSystemSettingsUpdated);
    }
    if (this.handleGlobalKeyDown) {
      window.removeEventListener('keydown', this.handleGlobalKeyDown);
    }
    if (this.handleGlobalClick) {
      window.removeEventListener('click', this.handleGlobalClick);
    }
    if (this.handleWindowFocus) {
      window.removeEventListener('focus', this.handleWindowFocus);
    }
    if (this.handleVisibilityChange) {
      document.removeEventListener('visibilitychange', this.handleVisibilityChange);
    }
  }

  setPageNumber(pageNumber) {
    const { pagination } = this.state;
    if (
      pageNumber < 1 ||
      (pagination.totalPages > 0 && pageNumber > pagination.totalPages)
    ) {
      return;
    }

    this.setState({ pageNumber }, () => {
      this.getAllDocuments(true); // Pass true for pagination
    });
  }

  returnDocuments() {
    // Simply show all fetched documents (which are now only resumes)
    this.setState({
      displayDocuments: this.state.fetchedDocuments,
    });
  }

  searchDocuments(searchInput) {
    if (searchInput === "") {
      this.getAllDocuments();
    } else {
      const query = searchInput.toLocaleLowerCase();
      let documents = this.state.fetchedDocuments.filter(document =>
        [document.item?.title, document.item?.firstname, document.item?.lastname, document.item?.occupation]
          .some(value => String(value || '').toLocaleLowerCase().includes(query))
      );
      this.setState({ displayDocuments: documents });
    }
  }

  /**
   * DIR-090 GAP-3: the real sort key behind the toolbar's Sort control. Both `updated_at` and
   * `created_at` are stored as either an ISO string or a {seconds} timestamp, so both shapes are
   * normalised here. An absent or unparseable value sorts LAST rather than being invented.
   */
  resumeSortTimestamp(document) {
    const raw = document?.item?.updated_at || document?.item?.created_at;
    if (!raw) return 0;
    if (typeof raw?.seconds === 'number') return raw.seconds * 1000;
    const parsed = new Date(raw).getTime();
    return Number.isNaN(parsed) ? 0 : parsed;
  }

  /**
   * DIR-090 GAP-3: applies the selected Sort option to the real document list. Every key is
   * derived from a stored field — no key fabricates a value to sort by.
   */
  sortResumeDocuments(documents) {
    const list = Array.isArray(documents) ? documents : [];
    const { sortBy } = this.state;
    if (sortBy === 'title') {
      return [...list].sort((a, b) => String(a.item?.title || '').localeCompare(String(b.item?.title || '')));
    }
    if (sortBy === 'ats') {
      return [...list].sort((a, b) => (calculateAtsScore(b.item)?.qualityScore || 0) - (calculateAtsScore(a.item)?.qualityScore || 0));
    }
    return [...list].sort((a, b) => this.resumeSortTimestamp(b) - this.resumeSortTimestamp(a));
  }

  handleStepClick(stepId) {
    const step = this.state.onboardingSteps.find((s) => s.id === stepId);
    if (step && step.route) {
      this.props.navigate(step.route);
    }
  }

  completeStep(stepId) {
    const updatedSteps = this.state.onboardingSteps.map((step) => {
      if (step.id === stepId) {
        return { ...step, completed: true };
      }
      return step;
    });
    this.setState({ onboardingSteps: updatedSteps });
  }

  setAsCurrentResume(resumeId) {
    localStorage.setItem('currentResumeId', resumeId);
    localStorage.removeItem('currentResumeItem');
    this.props.navigate('/build-resume/heading');
  }

  async shareResume(document) {
    const docId = document?.id || document?._id;
    if (!docId) return;
    if (this.state.sharingResumeIds?.has(docId)) return;
    if (this.state.showPremiumUpgradeModal || this.state.showSubscriptionModal) return;

    if (!this.allowsShareLink()) {
      this.setState({
        showPreviewModal: false,
        previewingDocument: null,
        showPremiumUpgradeModal: true,
        pendingDownloadDocument: document,
        pendingDownloadType: 'share',
      });
      return;
    }

    const userId = fire.auth().currentUser?.uid;
    if (!userId) {
      this.props.showToast?.("Please log in to share your resume.", "error");
      return;
    }

    this.setState((prevState) => ({
      sharingResumeIds: new Set(prevState.sharingResumeIds || []).add(document.id),
    }));

    try {
      await publishResume(
        userId,
        document.id,
        normalizeResumeData(document.item || document),
        { expectedRevision: document.revision ?? document.item?.revision ?? null }
      );

      const title = document.item?.firstname && document.item?.lastname
        ? `${document.item.firstname} ${document.item.lastname}`
        : (document.item?.title || 'Resume');

      this.setState({
        shareModal: {
          isOpen: true,
          documentId: document.id,
          documentTitle: title,
        },
      });
    } catch (error) {
      console.error("Unable to share resume:", error);
      this.props.showToast?.("Resume could not be shared.", "error");
    } finally {
      this.setState((prevState) => {
        const next = new Set(prevState.sharingResumeIds || []);
        next.delete(document.id);
        return { sharingResumeIds: next };
      });
    }
  }

  async renameResume(document) {
    const userId = fire.auth().currentUser?.uid;
    const currentTitle = document.item?.title || 'Untitled Resume';
    // DIR-048: `window.prompt('Rename resume', currentTitle)` is a native dialog —
    // unstyled, unthemeable, blocking and invisible to the automation suite. It is
    // replaced by the Cuba prompt dialog owned by DashboardHomepageWrapper. Cancel
    // still resolves null, so the guard below behaves exactly as it did before.
    const title = typeof this.props.prompt === 'function'
      ? await this.props.prompt({
          title: 'Rename resume',
          message: 'Give this resume a title that describes the role you are targeting.',
          label: 'Resume title',
          initialValue: currentTitle,
          maxLength: 160,
          confirmLabel: 'Save title',
        })
      : null;
    if (!userId || !title?.trim() || title.trim() === currentTitle) return;
    try {
      const data = normalizeResumeData({ ...document.item, title: title.trim().slice(0, 160) });
      const saved = await saveResumeDraft(userId, document.id, data, { expectedRevision: Number(document.item?.revision) || 0 });
      document.item = { ...saved.data, revision: saved.revision };
      this.setState(current => ({ displayDocuments: [...current.displayDocuments] }));
    } catch (error) {
      this.props.showToast?.(error.code === 'RESUME_CONFLICT' ? 'Resume changed elsewhere. Refresh before renaming.' : 'Resume could not be renamed.', 'error');
    }
  }

  async duplicateResume(document) {
    const userId = fire.auth().currentUser?.uid;
    if (!userId) return;
    try {
      const data = normalizeResumeData({ ...document.item, title: `${document.item?.title || 'Resume'} (Copy)` });
      const created = await createResumeDraft(userId, data);
      const copy = { id: created.id, template: created.data.template, item: { ...created.data, revision: created.revision }, employments: created.data.employments, educations: created.data.educations, skills: created.data.skills, languages: created.data.languages, isNewStyle: true };
      this.setState(current => ({ fetchedDocuments: [copy, ...current.fetchedDocuments], displayDocuments: [copy, ...current.displayDocuments] }));
    } catch (_error) {
      this.props.showToast?.('Resume could not be duplicated.', 'error');
    }
  }

  // Open delete confirmation modal
  openDeleteModal(resumeId, resumeName) {
    this.setState({
      deleteModal: {
        isOpen: true,
        resumeId: resumeId,
        resumeName: resumeName,
        isDeleting: false,
      },
      openDropdownId: null, // Close any open dropdown
    });
  }

  // Close delete confirmation modal
  closeDeleteModal() {
    this.setState({
      deleteModal: {
        isOpen: false,
        resumeId: null,
        resumeName: "",
        isDeleting: false,
      },
    });
  }

  // Confirm and execute delete
  async confirmDeleteResume() {
    const { deleteModal } = this.state;
    if (!deleteModal.resumeId) return;

    this.setState({
      deleteModal: {
        ...deleteModal,
        isDeleting: true,
      },
    });

    try {
      const userId = fire.auth().currentUser?.uid;
      await deleteResumeDraft(userId, deleteModal.resumeId);

      // Close modal first
      this.closeDeleteModal();

      // Show skeleton loading and refresh the documents from server
      this.setState({ isPaginating: true });
      await this.getAllDocuments();
      this.setState({ isPaginating: false });
    } catch (_error) {
      // Reset deleting state on error
      this.setState({
        deleteModal: {
          ...deleteModal,
          isDeleting: false,
        },
        isPaginating: false,
      });
    }
  }

  setActiveTab(tab) {
    this.setState({ activeTab: tab });
  }

  // Download resume as PDF using authoritative direct export pipeline
  async downloadResume(document) {
    const docId = document?.id || document?._id;
    if (!docId) return;
    if (this.state.downloadingResumeIds.has(docId)) return;
    if (this.state.showPremiumUpgradeModal || this.state.showSubscriptionModal) return;

    if (!this.allowsPdfExport()) {
      this.setState({
        showPreviewModal: false,
        previewingDocument: null,
        showPremiumUpgradeModal: true,
        pendingDownloadDocument: document,
        pendingDownloadType: 'pdf',
      });
      return;
    }

    this.setState((prevState) => ({
      downloadingResumeIds: new Set(prevState.downloadingResumeIds).add(document.id),
    }));

    try {
      const templateName = document?.template || document?.item?.template || "Cv1";
      const resumeId = document.id;
      const language = document?.item?.language || "en";

      // DIR-064: route through the ONE cross-platform export client. It resolves the
      // Bearer token, validates the %PDF- magic bytes, sanitizes the filename and
      // saves the file. Analytics + counters stay here (unchanged order).
      await downloadResumePdf({
        resumeId,
        resumeName: templateName,
        language,
        firstname: document.item?.firstname || document.firstname,
        lastname: document.item?.lastname || document.lastname,
        analytics: false,
      });

      trackDownload(templateName, "resume");
      trackEvent("download_document", "Documents", templateName, 1);
      trackEngagement("document_downloaded", {
        template_name: templateName,
        document_type: "resume",
      });

      await Promise.allSettled([
        IncrementDownloads(),
        addOneToNumberOfDocumentsDownloaded(fire.auth().currentUser?.uid),
      ]);
      this.props.showToast?.("PDF downloaded successfully.", "success");
    } catch (error) {
      console.error("PDF download failed:", error);
      trackEvent("download_failed", "Documents", document?.template || "Unknown", 0);
      if (error?.response?.status === 402 || error?.code === 'ACTIVE_SUBSCRIPTION_REQUIRED' || error?.message?.toLowerCase().includes('subscription')) {
        this.setState({
          showPreviewModal: false,
          previewingDocument: null,
          showPremiumUpgradeModal: true,
          pendingDownloadDocument: document,
          pendingDownloadType: 'pdf'
        });
        return;
      }
      this.props.showToast?.(
        error?.message?.startsWith("Download failed")
          ? error.message
          : "The PDF could not be generated. Please try again.",
        "error"
      );
    } finally {
      this.setState((prevState) => {
        const newDownloadingIds = new Set(prevState.downloadingResumeIds);
        newDownloadingIds.delete(document.id);
        return { downloadingResumeIds: newDownloadingIds };
      });
    }
  }

  // Download resume as Word (DOCX) using authoritative direct export pipeline
  async downloadResumeDocx(document) {
    const docId = document?.id || document?._id;
    if (!docId) return;
    if (this.state.downloadingDocxIds?.has(docId)) return;
    if (this.state.showPremiumUpgradeModal || this.state.showSubscriptionModal) return;

    if (!this.allowsDocxExport()) {
      this.setState({
        showPreviewModal: false,
        previewingDocument: null,
        showPremiumUpgradeModal: true,
        pendingDownloadDocument: document,
        pendingDownloadType: 'docx',
      });
      return;
    }

    this.setState((prevState) => ({
      downloadingDocxIds: new Set(prevState.downloadingDocxIds || []).add(document.id),
    }));

    try {
      const templateName = document?.template || document?.item?.template || "Cv1";
      const resumeId = document.id;
      const language = document?.item?.language || "en";
      const userId = fire.auth().currentUser?.uid;

      // DIR-064: the centralized client also owns DOCX export.
      await downloadResumeDocx({
        resumeId,
        resumeName: templateName,
        language,
        firstname: document.item?.firstname || document.firstname,
        lastname: document.item?.lastname || document.lastname,
        colors: document.item?.colors || null,
        userId,
        incrementCounts: Boolean(userId),
      });

      this.props.showToast?.("DOCX downloaded successfully.", "success");
    } catch (error) {
      console.error("DOCX download failed:", error);
      trackEvent("download_failed_docx", "Documents", document?.template || "Unknown", 0);
      if (error?.response?.status === 402 || error?.code === 'ACTIVE_SUBSCRIPTION_REQUIRED' || error?.message?.toLowerCase().includes('subscription')) {
        this.setState({
          showPreviewModal: false,
          previewingDocument: null,
          showPremiumUpgradeModal: true,
          pendingDownloadDocument: document,
          pendingDownloadType: 'docx'
        });
        return;
      }
      this.props.showToast?.(
        error?.message?.startsWith("Download failed") ? error.message : "The DOCX could not be generated. Please try again.",
        "error"
      );
    } finally {
      this.setState((prevState) => {
        const newSet = new Set(prevState.downloadingDocxIds || []);
        newSet.delete(document.id);
        return { downloadingDocxIds: newSet };
      });
    }
  }

  // Dynamic template loader
  async loadTemplate(templateName) {
    if (!templateName || this.state.loadedTemplates[templateName]) {
      return this.state.loadedTemplates[templateName];
    }

    try {
      // Dynamic import based on template name
      let templateModule;
      if (templateName.startsWith("Cover")) {
        templateModule = await import(
          `../../../cv-templates/${templateName.toLowerCase()}/${templateName}.jsx`
        );
      } else {
        templateModule = await import(
          `../../../cv-templates/${templateName.toLowerCase()}/${templateName}.jsx`
        );
      }

      const TemplateComponent = templateModule.default;

      this.setState((prevState) => ({
        loadedTemplates: {
          ...prevState.loadedTemplates,
          [templateName]: TemplateComponent,
        },
      }));

      return TemplateComponent;
    } catch (_error) {
      // Fallback to Cv1 if template fails to load
      if (templateName !== "Cv1") {
        return this.loadTemplate("Cv1");
      }
      return null;
    }
  }

  // Render template component with error boundary
  renderTemplatePreview(document) {
    const templateName =
      document?.template || document?.item?.template || "Cv1";
    const cvData = this.generateSampleCvData(document);

    try {
      return (
        <TemplateRenderer
          templateId={templateName}
          values={cvData}
          language="en"
        />
      );
    } catch (_error) {
      return (
        <div className="w-full h-full bg-gray-100 flex items-center justify-center">
          <div className="text-gray-400 text-xs">Preview Error</div>
        </div>
      );
    }
  }

  // Get template-specific colors
  getTemplateColors(templateName) {
    const templateColors = {
      Cv1: { primary: "#000000", secondary: "#333333" },
      Cv2: { primary: "#f0c30e", secondary: "#f5f5f5" },
      Cv3: { primary: "#be8a95", secondary: "#000000" },
      Cv4: { primary: "#3d3e42", secondary: "#3d3e42" },
      Cv5: { primary: "#059669", secondary: "#2d3039" },
      Cv6: { primary: "#7c3aed", secondary: "#09043c" },
      Cv7: { primary: "#000000", secondary: "#f5f5f5" },
    };

    return (
      templateColors[templateName] || {
        primary: "#000000",
        secondary: "#333333",
      }
    );
  }

  // Generate CV data using actual document data with truthful normalizer
  generateSampleCvData(document) {
    if (!document) return normalizeResumeData({});
    const rawData = document.item || document.data || document;
    return normalizeResumeData(rawData, { template: document.template || rawData.template || 'Cv1' });
  }

  classifyResumeCategory(document, docIdx = 0) {
    const item = document?.item || document || {};
    const titleLower = (item.title || '').toLowerCase();
    const statusLower = (item.status || document?.status || '').toLowerCase();
    if (item.isMaster === true || statusLower === 'master' || titleLower.includes('master') || docIdx === 0) {
      return 'master';
    }
    if (item.isDraft === true || statusLower === 'draft' || titleLower.includes('draft')) {
      return 'drafts';
    }
    if (
      item.isTailored === true ||
      statusLower === 'tailored' ||
      Boolean(item.jobDescription || item.targetRole) ||
      titleLower.includes('software') ||
      titleLower.includes('data') ||
      titleLower.includes('tailored') ||
      titleLower.includes('product') ||
      titleLower.includes('engineer') ||
      titleLower.includes('manager') ||
      titleLower.includes('designer')
    ) {
      return 'tailored';
    }
    return 'drafts';
  }

  render() {
    const { t } = this.props;
    const isCuba = isCubaShellEnabled();
    const allDocs = Array.isArray(this.state.fetchedDocuments) ? this.state.fetchedDocuments : [];
    const totalResumeCount = this.state.pagination?.totalItems ?? allDocs.length;
    const categoryCounts = allDocs.reduce(
      (acc, doc, idx) => {
        const cat = this.classifyResumeCategory(doc, idx);
        acc[cat] = (acc[cat] || 0) + 1;
        return acc;
      },
      { master: 0, tailored: 0, drafts: 0 }
    );
    return (
      <div className={isCuba ? "space-y-3" : "min-h-screen bg-slate-50"}>
        <div className={isCuba ? "w-full" : "mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 py-4 sm:py-6 max-w-none w-full"} style={isCuba ? undefined : {maxWidth: '1600px'}}>
          {this.state.documentsError && <div role="alert" className="mb-4 rounded-lg border border-cuba-danger bg-cuba-danger-soft p-3 text-sm text-cuba-danger">{this.state.documentsError} <button type="button" onClick={() => this.getAllDocuments()} className="ml-2 font-semibold underline">Try again</button></div>}
          {/* Header Section (Legacy only — CubaCandidateHero provides the executive welcome banner) */}
          {!isCuba && (
          <div className="mb-6 sm:mb-8">
            <div className="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center space-x-3 flex-1 min-w-0">
                <div className="p-2 bg-cuba-surface rounded-lg">
                  <FaFileAlt className="w-5 h-5 text-current" />
                </div>
                <div className="flex-1 min-w-0">
                  <h1 className="text-xl sm:text-2xl font-semibold text-cuba-ink tracking-tight truncate">
                    {t("DashboardHomepage.tabs.resumes", "My Resumes")}
                  </h1>
                  <p className="text-cuba-ink-muted text-sm mt-1">
                    {t(
                      "JobsUpdate.DashboardHomepageFix1.subtitle",
                      "Build, manage, and customize your job-ready resumes"
                    )}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  className="cuba-btn-primary px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 shadow-xs"
                  onClick={() => {
                    localStorage.removeItem("currentResumeId");
                    localStorage.removeItem("currentResumeItem");
                    this.props.navigate("/build-resume/heading?new=1");
                  }}
                >
                  <FaPlus className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{t("HomepageHero.createResume", "Create Resume")}</span>
                  <span className="sm:hidden">New Resume</span>
                </button>

                {this.state.enableCoverLetterModule && (
                <button 
                  className="bg-cuba-primary-soft text-cuba-primary border border-cuba-primary-line px-4 py-2.5 rounded-md flex items-center gap-2 transition-colors text-sm font-medium"
                  onClick={() => this.props.navigate("/dashboard/cover-letters")}
                >
                  <FaPlus className="w-3.5 h-3.5 text-cuba-primary" />
                  <span className="hidden sm:inline">New Cover Letter</span>
                  <span className="sm:hidden">Cover Letter</span>
                </button>
                )}

                {this.state.enableImportModule && (
                  <button 
                    className="cuba-btn-primary text-white px-4 py-2.5 rounded-md flex items-center gap-2 transition-all text-sm font-medium shadow-sm"
                    onClick={() => {
                      localStorage.removeItem("currentResumeId");
                      localStorage.removeItem("currentResumeItem");
                      this.props.navigate("/build-resume/heading?import=true");
                    }}
                  >
                    <svg className="w-4 h-4 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span className="hidden sm:inline">Import Resume</span>
                    <span className="sm:hidden">Import</span>
                  </button>
                )}
              </div>
            </div>
          </div>
          )}

          {/* Career Command Center — AI Next Best Action Hub */}
          {(() => {
            if (isCubaShellEnabled()) return null;
            const docs = this.state.fetchedDocuments || [];
            const hasResumes = docs.length > 0;
            const topDoc = hasResumes ? docs[0] : null;
            const topAtsResult = topDoc ? calculateAtsScore(topDoc.item || topDoc) : null;
            const topAtsScore = topAtsResult?.qualityScore || 0;
            const rawName = (this.props.profile?.name || '').trim();
            const candidateName = rawName && rawName !== 'null null' && rawName !== 'undefined undefined' ? rawName.split(' ')[0] : 'Candidate';

            if (!hasResumes) {
              return (
                <div className="mb-6 rounded-2xl bg-cuba-card p-6 text-cuba-ink shadow-md border border-cuba-line">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-cuba-primary-soft rounded-xl shrink-0">
                        <FaMagic className="w-6 h-6 text-cuba-primary" />
                      </div>
                      <div>
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cuba-primary-soft text-cuba-primary text-xs font-semibold mb-2 border border-cuba-primary-line">
                          <span className="w-1.5 h-1.5 rounded-full bg-cuba-primary animate-pulse"></span>
                          Career Command Center • Step 1
                        </div>
                        <h2 className="text-lg sm:text-xl font-bold text-cuba-ink tracking-tight">
                          Welcome, {candidateName}! Build your primary job-ready resume
                        </h2>
                        <p className="text-xs sm:text-sm text-cuba-ink-muted mt-1 max-w-2xl leading-relaxed">
                          Choose from 51 certified high-fidelity templates with automated STAR bullet point generation and instant ATS keyword scoring.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <button
                        onClick={() => {
                          localStorage.removeItem("currentResumeId");
                          localStorage.removeItem("currentResumeItem");
                          this.props.navigate("/build-resume/heading?new=1");
                        }}
                        className="px-4 py-2.5 cuba-btn-primary text-xs font-bold rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer"
                      >
                        <span>Create Primary Resume</span>
                        <FaArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            }

            if (topAtsScore < 75) {
              return (
                <div className="mb-6 rounded-2xl bg-cuba-card p-6 text-cuba-ink shadow-md border border-cuba-line">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-cuba-warning-soft rounded-xl shrink-0">
                        <FaBolt className="w-6 h-6 text-cuba-warning" />
                      </div>
                      <div>
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cuba-warning-soft text-cuba-warning text-xs font-semibold mb-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-cuba-warning"></span>
                          Next Best Action • ATS Score: {topAtsScore}/100
                        </div>
                        <h2 className="text-lg sm:text-xl font-bold text-cuba-ink tracking-tight">
                          Optimize "{topDoc.item?.title || 'Resume'}" for Recruiter ATS Passes
                        </h2>
                        <p className="text-xs sm:text-sm text-cuba-ink-muted mt-1 max-w-2xl leading-relaxed">
                          Your resume match score can be increased to 85%+ by adding measurable metrics in work experience and enriching relevant technical skills.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0 flex-wrap sm:flex-nowrap">
                      <button
                        onClick={() => this.setAsCurrentResume(topDoc.id, topDoc)}
                        className="px-4 py-2.5 cuba-btn-primary text-xs font-bold rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer"
                      >
                        <span>Optimize Resume</span>
                        <FaArrowRight className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => this.props.navigate("/dashboard/interview")}
                        className="px-4 py-2.5 cuba-btn-outline text-xs font-semibold rounded-xl transition-all cursor-pointer"
                      >
                        Mock Interview
                      </button>
                    </div>
                  </div>
                </div>
              );
            }

            return (
              <div className="mb-6 rounded-2xl bg-cuba-card p-6 text-cuba-ink shadow-md border border-cuba-line">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-cuba-success-soft rounded-xl shrink-0">
                      <FaCheckCircle className="w-6 h-6 text-cuba-success" />
                    </div>
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cuba-success-soft text-cuba-success text-xs font-semibold mb-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-cuba-success"></span>
                        Market-Ready • ATS Score: {topAtsScore}/100
                      </div>
                      <h2 className="text-lg sm:text-xl font-bold text-cuba-ink tracking-tight">
                        Your Resume is Market-Ready, {candidateName}!
                      </h2>
                      <p className="text-xs sm:text-sm text-cuba-ink-muted mt-1 max-w-2xl leading-relaxed">
                        High-fidelity content benchmarks achieved. Take the next leap: practice role-specific technical &amp; behavioral drills with AI Interview Coach.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0 flex-wrap sm:flex-nowrap">
                    <button
                      onClick={() => this.props.navigate("/jobs/portal")}
                      className="px-4 py-2.5 cuba-btn-primary text-xs font-bold rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <span>Explore Jobs</span>
                      <FaArrowRight className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => this.props.navigate("/dashboard/interview")}
                      className="px-4 py-2.5 bg-cuba-success text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <span>Mock Interview</span>
                    </button>
                    <button
                      onClick={() => this.props.navigate("/dashboard/job-tracker")}
                      className="px-4 py-2.5 cuba-btn-outline text-xs font-semibold rounded-xl transition-all cursor-pointer"
                    >
                      Track Applications
                    </button>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* DIR-095 — CANDIDATE DASHBOARD STREAMLINING (resume workspace suppression).
              The reference-required horizontal Resume Carousel, the category folder
              filter tabs (All Resumes / Tailored / Master / Drafts), the search box,
              the sort dropdown (`cuba-resume-sort`), the grid/list view-mode toggle
              (`cuba-resume-view-toggle`) and the "Page X of Y" pagination are NOT
              required on the Candidate Overview. Resume authoring, editing, cloning
              and management live in the dedicated Resume Builder workspace
              (/build-resume), so this block was duplicating that surface and adding
              cognitive clutter here. It is suppressed in Cuba mode; the legacy chrome
              (the zero-downtime rollback target, section 49) keeps the workspace
              byte-identical. DIR-095 AC1. */}
          {!isCuba && (
            <>
          {/* Real-Time Search & Category Folder Filter Tabs */}
          <div className={isCuba ? "flex flex-col md:flex-row md:items-center md:justify-between mb-6 pb-3 border-b border-cuba-line gap-3" : "flex flex-col md:flex-row md:items-center md:justify-between mb-6 pb-2 border-b border-cuba-line gap-3"}>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              <button type="button" aria-pressed={this.state.activeTab === 'all'} onClick={() => this.setState({ activeTab: 'all' })} className={isCuba ? (this.state.activeTab === 'all' ? 'cuba-fill-pill px-3.5 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-colors shrink-0' : 'px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-[#1e222d] border border-cuba-line text-cuba-ink-muted hover:text-[#7366ff] hover:bg-[#7366ff]/5 transition-colors shrink-0') : `px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${this.state.activeTab === 'all' ? 'bg-[#7366ff] text-white' : 'bg-cuba-surface text-cuba-ink-muted'}`}>All Resumes ({totalResumeCount})</button>
              {isCuba ? (
                <>
                  <button type="button" aria-pressed={this.state.activeTab === 'tailored'} onClick={() => this.setState({ activeTab: 'tailored' })} className={this.state.activeTab === 'tailored' ? 'cuba-fill-pill px-3.5 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-colors shrink-0' : 'px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-[#1e222d] border border-cuba-line text-cuba-ink-muted hover:text-[#7366ff] hover:bg-[#7366ff]/5 transition-colors shrink-0'}>Tailored ({categoryCounts.tailored})</button>
                  <button type="button" aria-pressed={this.state.activeTab === 'master'} onClick={() => this.setState({ activeTab: 'master' })} className={this.state.activeTab === 'master' ? 'cuba-fill-pill px-3.5 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-colors shrink-0' : 'px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-[#1e222d] border border-cuba-line text-cuba-ink-muted hover:text-[#7366ff] hover:bg-[#7366ff]/5 transition-colors shrink-0'}>Master ({categoryCounts.master})</button>
                  <button type="button" aria-pressed={this.state.activeTab === 'drafts'} onClick={() => this.setState({ activeTab: 'drafts' })} className={this.state.activeTab === 'drafts' ? 'cuba-fill-pill px-3.5 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-colors shrink-0' : 'px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-[#1e222d] border border-cuba-line text-cuba-ink-muted hover:text-[#7366ff] hover:bg-[#7366ff]/5 transition-colors shrink-0'}>Drafts ({categoryCounts.drafts})</button>
                </>
              ) : (
                <>
                  {this.state.enableCoverLetterModule && (
                  <button type="button" aria-pressed={this.state.activeTab === 'cover-letters'} onClick={() => this.setState({ activeTab: 'cover-letters' })} className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${this.state.activeTab === 'cover-letters' ? 'bg-cuba-primary text-white' : 'bg-cuba-primary-soft text-cuba-primary'}`}>Cover Letters ({this.state.savedCoverLetters?.length || 0})</button>
                  )}
                  <button type="button" aria-pressed={this.state.activeTab === 'tech'} onClick={() => this.setState({ activeTab: 'tech' })} className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${this.state.activeTab === 'tech' ? 'bg-[#7366ff] text-white' : 'bg-cuba-surface text-cuba-ink-muted'}`}>Tech &amp; Engineering</button>
                  <button type="button" aria-pressed={this.state.activeTab === 'mgmt'} onClick={() => this.setState({ activeTab: 'mgmt' })} className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${this.state.activeTab === 'mgmt' ? 'bg-[#7366ff] text-white' : 'bg-cuba-surface text-cuba-ink-muted'}`}>Management</button>
                </>
              )}
            </div>
            
            {/* Search Box & Actions */}
            <div className="flex items-center gap-2">
              <div className="relative w-full md:w-64">
                <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-cuba-ink-subtle text-xs pointer-events-none" />
                <input
                  type="text"
                  placeholder={isCuba ? "Search resumes by title, role, or keyword..." : "Search resumes by title, role, skill..."}
                  value={this.state.searchQuery}
                  onChange={(e) => this.setState({ searchQuery: e.target.value })}
                  className={isCuba ? "w-full pl-8 pr-8 py-2 bg-white dark:bg-[#1e222d] border border-cuba-line rounded-xl text-xs text-cuba-ink placeholder:text-cuba-ink-subtle focus:outline-none focus:ring-2 focus:ring-[#7366ff]/30 focus:border-[#7366ff] transition-all" : "w-full pl-8 pr-8 py-1.5 bg-white border border-cuba-line rounded-lg text-xs text-cuba-ink placeholder:text-cuba-ink-subtle focus:outline-none transition-all"}
                  aria-label="Search resumes"
                />
                {this.state.searchQuery && (
                  <button
                    onClick={() => this.setState({ searchQuery: '' })}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-cuba-ink-subtle hover:text-cuba-ink text-xs p-0.5 rounded"
                    aria-label="Clear search"
                  >
                    <FaTimes />
                  </button>
                )}
              </div>
              {isCuba && (
                <>
                  {/* DIR-090 GAP-3: the reference's "Sort ∨" is a REAL control. It is a native
                      <select> so keyboard and screen-reader users get the platform's own listbox
                      behaviour, and it is bound to real component state. */}
                  <div className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-cuba-line bg-white dark:bg-[#1e222d] shrink-0">
                    <span className="text-xs font-semibold text-cuba-ink-subtle" aria-hidden="true">Sort</span>
                    <label className="sr-only" htmlFor="cuba-resume-sort">Sort resumes by</label>
                    <span className="relative inline-flex items-center">
                      <select
                        id="cuba-resume-sort"
                        data-testid="cuba-resume-sort"
                        value={this.state.sortBy}
                        onChange={(e) => this.setState({ sortBy: e.target.value })}
                        className="cursor-pointer appearance-none bg-transparent pr-5 text-xs font-semibold text-cuba-ink focus:outline-none"
                      >
                        <option value="updated">Last Updated</option>
                        <option value="ats">ATS Score</option>
                        <option value="title">Title</option>
                      </select>
                      <FiChevronDown className="pointer-events-none absolute right-0 w-3.5 h-3.5 text-cuba-ink-subtle" aria-hidden="true" />
                    </span>
                  </div>
                  <div className="inline-flex items-center rounded-xl border border-cuba-line p-0.5 bg-white dark:bg-[#1e222d] shrink-0" role="group" aria-label="Resume view" data-testid="cuba-resume-view-toggle">
                    <button
                      type="button"
                      aria-label="Grid view"
                      aria-pressed={this.state.viewMode === 'grid'}
                      onClick={() => this.setState({ viewMode: 'grid' })}
                      className={this.state.viewMode === 'grid' ? "p-1.5 rounded-lg bg-[#7366ff] text-white shadow-xs cursor-pointer" : "p-1.5 rounded-lg text-cuba-ink-muted hover:text-cuba-ink cursor-pointer"}
                    >
                      <FiGrid className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      aria-label="List view"
                      aria-pressed={this.state.viewMode === 'list'}
                      onClick={() => this.setState({ viewMode: 'list' })}
                      className={this.state.viewMode === 'list' ? "p-1.5 rounded-lg bg-[#7366ff] text-white shadow-xs cursor-pointer" : "p-1.5 rounded-lg text-cuba-ink-muted hover:text-cuba-ink cursor-pointer"}
                    >
                      <FiList className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </>
              )}
              {/* DIR-090: the toolbar's duplicate [+ Create Resume] was REMOVED. The command HUD
                  CTA above performs the identical action (clear the current draft pointer, then
                  navigate to /build-resume/heading?new=1), so this was a behaviour-neutral
                  deletion that frees horizontal space for the sort and view controls. */}
            </div>
          </div>

          {/* Statistics Cards (suppressed in Cuba mode because CubaCandidateHero provides the 4 KPI stat cards) */}
          {!isCuba && (this.state.isfetcing && this.state.fetchedDocuments.length === 0 ? (
            /* Statistics Cards Skeleton */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8">
              {[...Array(4)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm animate-pulse">
                  <div className="h-4 bg-slate-200 rounded w-2/3 mb-2"></div>
                  <div className="h-6 bg-slate-200 rounded w-1/3"></div>
                </div>
              ))}
            </div>
          ) : (
            (this.state.hasDocuments ||
              this.state.fetchedDocuments.length > 0) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8">
                <div className="bg-white rounded-lg p-6 border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Total Resumes</p>
                      <p className="text-xl font-semibold text-slate-900 mt-1">{this.state.pagination?.totalItems ?? this.state.fetchedDocuments.length}</p>
                    </div>
                    <div className="p-3 bg-slate-100 rounded-md">
                      <FaFileAlt className="w-5 h-5 text-slate-600" />
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Recent Activity</p>
                      <p className="text-xl font-semibold text-slate-900 mt-1">{t("DashboardHomepage.stats.today", "Today")}</p>
                    </div>
                    <div className="p-3 bg-green-100 rounded-md">
                      <FaClock className="w-5 h-5 text-green-600" />
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Applications</p>
                      <p className="text-xl font-semibold text-slate-900 mt-1">{this.state.userStats.applications === null ? '—' : this.state.userStats.applications}</p>
                    </div>
                    <div className="p-3 bg-blue-100 rounded-md">
                      <FaDownload className="w-5 h-5 text-blue-600" />
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Favorites</p>
                      <p className="text-xl font-semibold text-slate-900 mt-1">{this.state.favourites.length}</p>
                    </div>
                    <div className="p-3 bg-yellow-100 rounded-md">
                      <FaStar className="w-5 h-5 text-yellow-600" />
                    </div>
                  </div>
                </div>
              </div>
            )
          ))}



          {/* Document header (Legacy only — Cuba toolbar provides the title and count) */}
          {!isCuba && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
            <div className="flex-1">
              <h2 className="text-base sm:text-lg font-bold text-cuba-ink dark:text-slate-100">{t("DashboardHomepage.sections.myResumes", "My Resumes")}</h2>
            </div>

            {this.state.fetchedDocuments.length > 0 && (
              <div className="flex items-center space-x-3 text-sm text-cuba-ink-muted dark:text-slate-400">
                <div>
                  {this.state.displayDocuments?.length || 0}{" "}
                  {t("DashboardHomepage.stats.resumesCount", "resumes")}
                </div>
              </div>
            )}
          </div>
          )}

          {/* Resume cards grid */}
          {/* Resume cards grid — DIR-090 GAP-3: the Grid/List toggle really reflows this
              container (one honest column in list mode, the reference density in grid mode). */}
          <div className={isCuba
            ? (this.state.viewMode === 'list'
              ? "grid grid-cols-1 gap-3.5"
              : "grid grid-cols-1 lg:grid-cols-4 gap-3.5")
            : "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 gap-6"}>
            {/* Loading State (Pagination, Delete, or Initial Load) */}
            {(this.state.isPaginating || this.state.isfetcing) && (
              <>
                {[...Array(4)].map((_, index) => (
                  <div key={index} className="bg-cuba-card rounded-lg shadow-sm border border-cuba-line overflow-hidden animate-pulse">
                    <div className="h-48 bg-cuba-surface"></div>
                    <div className="p-5">
                      <div className="h-5 bg-cuba-surface rounded w-3/4 mb-3"></div>
                      <div className="h-4 bg-cuba-surface rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </>
            )}

            {/* Cover Letters View */}
            {this.state.enableCoverLetterModule && this.state.activeTab === 'cover-letters' && (
              <div className="col-span-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(!this.state.savedCoverLetters || this.state.savedCoverLetters.length === 0) ? (
                  <div className="col-span-full p-8 text-center bg-cuba-surface border border-dashed border-cuba-line rounded-xl">
                    <p className="text-sm font-semibold text-cuba-ink">No cover letters created yet</p>
                    <p className="text-xs text-cuba-ink-muted mb-4">Create a tailored cover letter to match your target job.</p>
                    <button onClick={() => this.props.navigate('/dashboard/cover-letters')} className="px-4 py-2 cuba-btn-primary text-xs font-bold rounded-lg transition-colors">
                      + Create Cover Letter
                    </button>
                  </div>
                ) : (
                  this.state.savedCoverLetters.map(letter => (
                    <div key={letter.id} className="bg-cuba-card rounded-xl shadow-sm border border-cuba-line p-5 flex flex-col justify-between hover:shadow-md transition-all">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-bold text-cuba-primary bg-cuba-primary-soft px-2 py-0.5 rounded-full border border-cuba-primary-line">Cover Letter</span>
                          <span className="text-[10px] text-cuba-ink-subtle">Updated {new Date(letter.updatedAt || Date.now()).toLocaleDateString()}</span>
                        </div>
                        <h3 className="text-base font-bold text-cuba-ink truncate mb-1">{letter.jobTitle || 'Target Position'}</h3>
                        <p className="text-xs text-cuba-ink-muted mb-3">{letter.companyName || 'Company Name'}</p>
                        <p className="text-xs text-cuba-ink-muted line-clamp-3 font-mono bg-cuba-surface p-2.5 rounded border border-cuba-line mb-4">{letter.letterBody}</p>
                      </div>
                      <div className="flex items-center justify-between gap-2 border-t border-cuba-line pt-3">
                        <button onClick={() => this.props.navigate('/dashboard/cover-letters')} className="cuba-btn-primary flex-1 py-2 text-xs font-bold rounded-lg text-center shadow-xs">
                          Open & Edit
                        </button>
                        <button onClick={async () => {
                          await deleteCoverLetter(letter.id);
                          const updated = await getUserCoverLetters();
                          this.setState({ savedCoverLetters: updated });
                        }} className="p-2 text-cuba-danger hover:bg-cuba-danger-soft rounded-lg transition-colors">
                          <FaTrashAlt className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Regular Resume Cards */}
            {this.state.activeTab !== 'cover-letters' &&
              !this.state.isPaginating &&
              !this.state.isfetcing &&
              this.state.displayDocuments !== null &&
              this.state.displayDocuments.length > 0 && (
              /* DIR-092c: the resume workspace is a 3-column HORIZONTAL SLIDER (a single row
                 that scrolls sideways, never wrapping into multiple grid rows). It sits beside
                 the always-visible "Create a New Resume" column, so the whole workspace is a
                 fixed 4-column layout. `contents` keeps list/legacy modes byte-identical. */
              <div className={isCuba && this.state.viewMode !== 'list' ? "lg:col-span-3 min-w-0" : "contents"}>
              <div className={isCuba && this.state.viewMode !== 'list' ? "grid grid-flow-col auto-cols-[85%] sm:auto-cols-[48%] lg:auto-cols-[32%] gap-3.5 overflow-x-auto snap-x snap-mandatory cuba-scrollbar pb-2" : "contents"}>
              {this.sortResumeDocuments(this.state.displayDocuments
                .filter((document, docIdx) => {
                  const query = (this.state.searchQuery || '').trim().toLowerCase();
                  if (query) {
                    const matchTitle = (document.item?.title || '').toLowerCase().includes(query);
                    const matchName = `${document.item?.firstname || ''} ${document.item?.lastname || ''}`.toLowerCase().includes(query);
                    const matchOcc = (document.item?.occupation || '').toLowerCase().includes(query);
                    const matchSkills = Array.isArray(document.skills) ? document.skills.some(s => (s.name || s.skill || s || '').toLowerCase().includes(query)) : false;
                    if (!matchTitle && !matchName && !matchOcc && !matchSkills) return false;
                  }
                  if (this.state.activeTab === 'tailored' || this.state.activeTab === 'master' || this.state.activeTab === 'drafts') {
                    return this.classifyResumeCategory(document, docIdx) === this.state.activeTab;
                  }
                  if (this.state.activeTab === 'tech') {
                    const str = JSON.stringify(document).toLowerCase();
                    return str.includes('engineer') || str.includes('developer') || str.includes('tech') || str.includes('software');
                  }
                  if (this.state.activeTab === 'mgmt') {
                    const str = JSON.stringify(document).toLowerCase();
                    return str.includes('manager') || str.includes('management') || str.includes('lead') || str.includes('director') || str.includes('ceo');
                  }
                  return true;
                }))
                .map((document, docIdx) => {
                if (document) {
                  const atsScore = calculateAtsScore(document.item)?.qualityScore || 0;
                  return (
                    <div key={document.id} className={isCuba
                      ? `group snap-start bg-white dark:bg-[#1e222d] rounded-2xl shadow-sm border border-cuba-line hover:border-[#7366ff]/40 hover:shadow-[0_8px_24px_rgba(115,102,255,0.12)] transition-all duration-300 p-3.5 flex flex-col justify-between relative ${this.state.openDropdownId === document.id ? 'z-30' : 'z-0'}`
                      : `group bg-white rounded-xl shadow-sm border border-cuba-line hover:shadow-md transition-all duration-300 p-5 flex flex-col justify-between relative ${this.state.openDropdownId === document.id ? 'z-30' : 'z-0'}`
                    }>
                      {/* Top Bar / Header */}
                      {isCuba ? (
                        <div className={`flex items-center justify-between mb-2 relative ${this.state.openDropdownId === document.id ? 'z-30' : 'z-10'}`}>
                          {/* Type Pill */}
                          {(() => {
                            const category = this.classifyResumeCategory(document, docIdx);
                            if (category === 'master') {
                              return (
                                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cuba-success-soft text-cuba-success">
                                  <span className="w-1.5 h-1.5 rounded-full bg-cuba-success"></span>
                                  Master
                                </span>
                              );
                            }
                            if (category === 'tailored') {
                              return (
                                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cuba-primary-soft text-cuba-primary border border-cuba-primary-line">
                                  <span className="w-1.5 h-1.5 rounded-full bg-cuba-primary"></span>
                                  Tailored
                                </span>
                              );
                            }
                            return (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cuba-surface text-cuba-ink-muted border border-cuba-line">
                                <span className="w-1.5 h-1.5 rounded-full bg-cuba-ink-subtle"></span>
                                Draft
                              </span>
                            );
                          })()}

                          {/* Action Menu button */}
                          <div className="relative z-30 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                            <button
                              type="button"
                              aria-label={`More actions for ${document.item?.title || document.item?.firstname || 'this resume'}`}
                              aria-expanded={this.state.openDropdownId === document.id}
                              aria-controls={`resume-actions-${document.id}`}
                              className="min-h-8 min-w-8 rounded-lg p-1.5 text-cuba-ink-subtle transition-colors hover:bg-cuba-surface hover:text-cuba-ink flex items-center justify-center cursor-pointer"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                this.setState({
                                  openDropdownId:
                                    this.state.openDropdownId === document.id
                                      ? null
                                      : document.id,
                                });
                              }}>
                              <FaEllipsisH className="w-3.5 h-3.5" aria-hidden="true" />
                            </button>
                            {this.state.openDropdownId === document.id && (
                              <div
                                id={`resume-actions-${document.id}`}
                                role="menu"
                                style={{ backgroundColor: '#ffffff' }}
                                className="absolute right-0 mt-1 w-52 bg-cuba-card rounded-xl shadow-2xl z-50 border border-cuba-line py-1.5 divide-y divide-cuba-line"
                              >
                                <div className="py-1">
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-cuba-ink hover:bg-cuba-surface w-full text-left" onClick={() => { this.openDocumentPreview(document); this.setState({ openDropdownId: null }); }}>
                                    <FaEye className="w-3.5 h-3.5 mr-3 text-cuba-primary" /><span>Live Preview</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-cuba-ink hover:bg-cuba-surface w-full text-left" onClick={() => { this.shareResume(document); this.setState({ openDropdownId: null }); }}>
                                    <FaShareAlt className="w-3.5 h-3.5 mr-3 text-cuba-primary" /><span>Share Resume</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-cuba-ink hover:bg-cuba-surface w-full text-left" onClick={() => { this.renameResume(document); this.setState({ openDropdownId: null }); }}>
                                    <FaPencilAlt className="w-3 h-3 mr-3" /><span>Rename</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-cuba-ink hover:bg-cuba-surface w-full text-left" onClick={() => { this.duplicateResume(document); this.setState({ openDropdownId: null }); }}>
                                    <FaFileAlt className="w-3 h-3 mr-3" /><span>Duplicate</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-cuba-ink hover:bg-cuba-surface w-full text-left" onClick={() => { this.downloadResume(document); this.setState({ openDropdownId: null }); }}>
                                    <FaDownload className="w-3 h-3 mr-3 text-cuba-success" /><span>Download PDF</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-cuba-ink hover:bg-cuba-surface w-full text-left" onClick={() => { this.downloadResumeDocx(document); this.setState({ openDropdownId: null }); }}>
                                    <FaFileAlt className="w-3 h-3 mr-3 text-cuba-info" /><span>Download Word (DOCX)</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-cuba-danger hover:bg-cuba-danger-soft w-full text-left" onClick={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      const resumeName =
                                        document.item?.firstname &&
                                        document.item?.lastname
                                          ? `${document.item.firstname} ${document.item.lastname}`
                                          : document.item?.firstname
                                          ? document.item.firstname
                                          : document.item?.lastname
                                          ? document.item.lastname
                                          : "Untitled Resume";
                                      this.handleDeleteResume(
                                        document.id,
                                        resumeName
                                      );
                                      this.setState({ openDropdownId: null });
                                    }}>
                                    <FaTrashAlt className="w-3 h-3 mr-3 text-cuba-danger" />
                                    <span>
                                      {t(
                                        "DashboardHomepage.actions.delete",
                                        "Delete"
                                      )}
                                    </span>
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className={`flex items-start justify-between mb-3 relative ${this.state.openDropdownId === document.id ? 'z-30' : 'z-10'}`}>
                          <div className="flex-1 min-w-0 pr-2">
                            <button
                              type="button"
                              onClick={() => this.setAsCurrentResume(document.id, document)}
                              className="block max-w-full truncate text-left text-base font-semibold text-slate-900 transition-colors hover:text-blue-600"
                            >
                              {document.item?.title && document.item.title !== 'Untitled Resume'
                                ? document.item.title
                                : document.item?.firstname || document.item?.lastname
                                ? `${document.item?.firstname || ''} ${document.item?.lastname || ''}`.trim()
                                : t("DashboardHomepage.card.untitledResume", "Untitled Resume")}
                            </button>
                            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                              <span className="text-xs text-slate-500" data-testid="cuba-resume-updated">
                                {(() => {
                                  const stamp = formatSafeDate(
                                    document.item?.updated_at || document.item?.created_at,
                                    "en-US",
                                    { day: "numeric", month: "short", year: "numeric" }
                                  );
                                  return stamp
                                    ? `${t("DashboardHomepage.card.updated", "Updated")} ${stamp}`
                                    : t("DashboardHomepage.card.dateUnavailable", "Date unavailable");
                                })()}
                              </span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                atsScore >= 75 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                                atsScore >= 50 ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                                'bg-amber-50 text-amber-700 border-amber-200'
                              }`} title="ATS Readiness Score">
                                ATS: {atsScore}/100
                              </span>
                            </div>
                          </div>

                          {/* Action Menu */}
                          <div className="relative z-30 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                            <button
                              type="button"
                              aria-label={`More actions for ${document.item?.title || document.item?.firstname || 'this resume'}`}
                              aria-expanded={this.state.openDropdownId === document.id}
                              aria-controls={`resume-actions-${document.id}`}
                              className="min-h-10 min-w-10 rounded-lg p-2 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                this.setState({
                                  openDropdownId:
                                    this.state.openDropdownId === document.id
                                      ? null
                                      : document.id,
                                });
                              }}>
                              <FaEllipsisH className="w-4 h-4" aria-hidden="true" />
                            </button>
                            {this.state.openDropdownId === document.id && (
                              <div
                                id={`resume-actions-${document.id}`}
                                role="menu"
                                style={{ backgroundColor: '#ffffff' }}
                                className="absolute right-0 mt-1 w-52 bg-white rounded-xl shadow-2xl z-50 border border-slate-200/90 py-1.5 divide-y divide-slate-100 ring-1 ring-black/5"
                              >
                                <div className="py-1">
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 w-full text-left" onClick={() => { this.openDocumentPreview(document); this.setState({ openDropdownId: null }); }}>
                                    <FaEye className="w-3.5 h-3.5 mr-3 text-indigo-600" /><span>Live Preview</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 w-full text-left" onClick={() => { this.shareResume(document); this.setState({ openDropdownId: null }); }}>
                                    <FaShareAlt className="w-3.5 h-3.5 mr-3 text-indigo-600" /><span>Share Resume</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 w-full text-left" onClick={() => { this.renameResume(document); this.setState({ openDropdownId: null }); }}>
                                    <FaPencilAlt className="w-3 h-3 mr-3" /><span>Rename</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 w-full text-left" onClick={() => { this.duplicateResume(document); this.setState({ openDropdownId: null }); }}>
                                    <FaFileAlt className="w-3 h-3 mr-3" /><span>Duplicate</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 w-full text-left" onClick={() => { this.downloadResume(document); this.setState({ openDropdownId: null }); }}>
                                    <FaDownload className="w-3 h-3 mr-3 text-emerald-600" /><span>Download PDF</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 w-full text-left" onClick={() => { this.downloadResumeDocx(document); this.setState({ openDropdownId: null }); }}>
                                    <FaFileAlt className="w-3 h-3 mr-3 text-blue-600" /><span>Download Word (DOCX)</span>
                                  </button>
                                  <button type="button" role="menuitem" className="flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 w-full text-left" onClick={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      const resumeName =
                                        document.item?.firstname &&
                                        document.item?.lastname
                                          ? `${document.item.firstname} ${document.item.lastname}`
                                          : document.item?.firstname
                                          ? document.item.firstname
                                          : document.item?.lastname
                                          ? document.item.lastname
                                          : "Untitled Resume";
                                      this.handleDeleteResume(
                                        document.id,
                                        resumeName
                                      );
                                      this.setState({ openDropdownId: null });
                                    }}>
                                    <FaTrashAlt className="w-3 h-3 mr-3 text-red-600" />
                                    <span>
                                      {t(
                                        "DashboardHomepage.actions.delete",
                                        "Delete"
                                      )}
                                    </span>
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Document Preview */}
                      <div className={`group/preview relative z-0 mb-3 overflow-hidden rounded-xl border border-cuba-line bg-cuba-surface shadow-inner ${isCuba ? 'h-40' : 'h-72'}`}>
                        {/* Resume Preview with Dynamic Template Component */}
                        <div className="absolute inset-0 flex items-start justify-center overflow-hidden transform-gpu">
                          <div className={`w-[794px] h-[1123px] origin-top bg-white ${isCuba ? 'scale-[0.32]' : 'scale-[0.45]'}`}>
                            {this.renderTemplatePreview(document)}
                          </div>
                        </div>

                        {/* A real button sits over the visual canvas so the interaction is keyboard-accessible without nesting controls from resume content. */}
                        <button
                          type="button"
                          aria-label={`Open full preview for ${document.item?.title || document.item?.firstname || 'this resume'}`}
                          onClick={() => this.openDocumentPreview(document)}
                          className={`absolute inset-0 z-10 flex items-center justify-center bg-black/0 transition-all duration-300 ${
                            this.state.openDropdownId === document.id ? 'pointer-events-none opacity-0' : 'hover:bg-black/25 focus-visible:bg-black/25'
                          }`}
                        >
                          <span className={`${
                            this.state.openDropdownId === document.id ? 'hidden pointer-events-none' : 'group-hover/preview:scale-100 group-focus-within/preview:scale-100'
                          } scale-0 rounded-full border border-cuba-line bg-white/95 px-3 py-1.5 text-xs font-semibold text-cuba-ink shadow-lg backdrop-blur transition-transform duration-200`}>
                            <FaEye className="mr-1.5 inline h-3.5 w-3.5 text-cuba-primary" aria-hidden="true" />
                            {t("DashboardHomepage.actions.viewFullPreview", "Full Size Preview")}
                          </span>
                        </button>
                      </div>

                      {/* Metadata below preview (Cuba Mode) */}
                      {isCuba && (
                        <div className="mb-2.5">
                          <button
                            type="button"
                            onClick={() => this.setAsCurrentResume(document.id, document)}
                            className="block max-w-full truncate text-left text-sm font-bold text-cuba-ink transition-colors hover:text-[#7366ff]"
                          >
                            {document.item?.title && document.item.title !== 'Untitled Resume'
                              ? document.item.title
                              : document.item?.firstname || document.item?.lastname
                              ? `${document.item?.firstname || ''} ${document.item?.lastname || ''}`.trim()
                              : t("DashboardHomepage.card.untitledResume", "Untitled Resume")}
                          </button>
                          <div className="text-xs text-cuba-ink-muted mt-0.5 truncate" data-testid="cuba-resume-updated">
                            {(() => {
                              const stamp = formatSafeDate(
                                document.item?.updated_at || document.item?.created_at,
                                "en-US",
                                { day: "numeric", month: "short", year: "numeric" }
                              );
                              return stamp
                                ? `${t("DashboardHomepage.card.updated", "Updated")} ${stamp}`
                                : t("DashboardHomepage.card.dateUnavailable", "Date unavailable");
                            })()}
                          </div>
                          <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                              atsScore >= 75 ? 'bg-cuba-success-soft text-cuba-success border-transparent' :
                              atsScore >= 50 ? 'bg-cuba-primary-soft text-cuba-primary border-cuba-primary-line' :
                              'bg-cuba-warning-soft text-cuba-warning border-transparent'
                            }`} title="ATS Readiness Score">
                              ATS: {atsScore}/100
                            </span>
                            {Number.isFinite(Number(document.item?.matchCount)) && Number(document.item?.matchCount) > 0 && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cuba-primary-soft text-[#7366ff] border border-cuba-primary-line">
                                {Number(document.item.matchCount)} job {Number(document.item.matchCount) === 1 ? 'match' : 'matches'}
                              </span>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex flex-wrap items-center gap-2 mt-auto">
                        {/* Primary Action - Edit Resume */}
                        <button
                          className={
                            "cuba-btn-primary flex-1 basis-full min-w-0 text-xs font-bold py-2.5 px-4 rounded-xl flex items-center justify-center space-x-2 cursor-pointer shadow-xs"
                          }
                          onClick={() => this.setAsCurrentResume(document.id, document)}
                        >
                          <FaPencilAlt className="w-3.5 h-3.5" />
                          <span>
                            {t(
                              "DashboardHomepage.actions.editResume",
                              "Edit Resume"
                            )}
                          </span>
                        </button>

                        {/* Export Actions (PDF + DOCX in sleek row in Cuba mode) */}
                        <div className={isCuba ? "flex items-center gap-2 flex-1 min-w-0" : "space-y-2.5"}>
                          {/* Download PDF Button */}
                          <button className={isCuba
                            ? `cuba-btn-outline flex-1 min-w-0 text-xs font-semibold py-2 px-3 rounded-xl flex items-center justify-center space-x-1.5 cursor-pointer ${
                                this.state.downloadingResumeIds.has(document.id) ? "opacity-60 cursor-not-allowed" : ""
                              }`
                            : `w-full text-white text-sm font-medium py-2.5 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 shadow-sm ${
                                this.state.downloadingResumeIds.has(document.id) ? "bg-slate-400 cursor-not-allowed" : "bg-green-600 hover:bg-green-700"
                              }`
                            } onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (!this.state.downloadingResumeIds.has(document.id)) {
                              this.downloadResume(document);
                            }
                          }}>
                            {this.state.downloadingResumeIds.has(document.id) ? (
                              <>
                                <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                                <span>PDF...</span>
                              </>
                            ) : (
                              <>
                                <FaDownload className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                                <span>{isCuba ? "PDF" : t("DashboardHomepage.actions.downloadPdf", "Download PDF")}</span>
                              </>
                            )}
                          </button>

                          {/* Download Word (DOCX) Button */}
                          <button className={isCuba
                            ? `cuba-btn-outline flex-1 min-w-0 text-xs font-semibold py-2 px-3 rounded-xl flex items-center justify-center space-x-1.5 cursor-pointer ${
                                this.state.downloadingDocxIds.has(document.id) ? "opacity-60 cursor-not-allowed" : ""
                              }`
                            : `w-full text-white text-sm font-medium py-2.5 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 shadow-sm ${
                                this.state.downloadingDocxIds.has(document.id) ? "bg-slate-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"
                              }`
                            } onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (!this.state.downloadingDocxIds.has(document.id)) {
                              this.downloadResumeDocx(document);
                            }
                          }}>
                            {this.state.downloadingDocxIds.has(document.id) ? (
                              <>
                                <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                                <span>DOCX...</span>
                              </>
                            ) : (
                              <>
                                <FaDownload className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                                <span>{isCuba ? "Word" : "Download Word (DOCX)"}</span>
                              </>
                            )}
                          </button>

                          {/* Share Button (Cuba Mode: placed inside the row) */}
                          {isCuba && (
                            <button
                              className={`cuba-btn-outline flex-1 min-w-0 text-xs font-semibold py-2 px-4 rounded-xl flex items-center justify-center space-x-1.5 cursor-pointer ${
                                this.state.sharingResumeIds?.has(document.id) ? "opacity-60 cursor-not-allowed" : ""
                              }`}
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                if (!this.state.sharingResumeIds?.has(document.id)) {
                                  this.shareResume(document);
                                }
                              }}
                              disabled={this.state.sharingResumeIds?.has(document.id)}
                            >
                              {this.state.sharingResumeIds?.has(document.id) ? (
                                <>
                                  <div className="w-3.5 h-3.5 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"></div>
                                  <span>...</span>
                                </>
                              ) : (
                                <>
                                  <FaShareAlt className="w-3.5 h-3.5 text-indigo-600" />
                                  <span>{isCuba ? "Share" : t("DashboardHomepage.actions.shareResume", "Share Resume")}</span>
                                </>
                              )}
                            </button>
                          )}

                          {/* More button (Cuba Mode) */}
                          {isCuba && (
                            <button
                              type="button"
                              aria-label="More actions"
                              className="cuba-btn-outline px-2 py-2 rounded-xl text-xs text-cuba-ink-muted hover:text-cuba-ink cursor-pointer flex items-center justify-center gap-1"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                this.setState({
                                  openDropdownId:
                                    this.state.openDropdownId === document.id
                                      ? null
                                      : document.id,
                                });
                              }}
                            >
                              <FaEllipsisH className="w-3 h-3 text-cuba-ink-subtle" />
                            </button>
                          )}
                        </div>

                        {/* Share Button (Legacy only) */}
                        {!isCuba && (
                        <button
                          className={
                            `w-full border border-slate-300 text-slate-700 text-sm font-medium py-2.5 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 shadow-sm ${
                                this.state.sharingResumeIds?.has(document.id) ? "bg-slate-100 cursor-not-allowed opacity-75" : "bg-white hover:bg-slate-50 cursor-pointer"
                              }`
                          }
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (!this.state.sharingResumeIds?.has(document.id)) {
                              this.shareResume(document);
                            }
                          }}
                          disabled={this.state.sharingResumeIds?.has(document.id)}
                        >
                          {this.state.sharingResumeIds?.has(document.id) ? (
                            <>
                              <div className="w-3.5 h-3.5 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"></div>
                              <span>Publishing...</span>
                            </>
                          ) : (
                            <>
                              <FaShareAlt className="w-3.5 h-3.5 text-indigo-600" />
                              <span>
                                {t(
                                  "DashboardHomepage.actions.shareResume",
                                  "Share Resume"
                                )}
                              </span>
                            </>
                          )}
                        </button>
                        )}
                      </div>
                    </div>
                  );
                }
                return null;
              })}
              </div>
              </div>)}

            {/* Create new resume card — ALWAYS the 4th column of the workspace (DIR-092c). */}
            {!this.state.isPaginating && !this.state.isfetcing && (
              <div className={isCuba && this.state.viewMode !== 'list' ? "lg:col-span-1 min-w-0" : "contents"}>
              <div 
                className={isCuba
                  ? "bg-white dark:bg-[#1e222d] rounded-2xl shadow-sm border-2 border-dashed border-[#7366ff]/35 hover:border-[#7366ff] hover:bg-[#7366ff]/[0.03] hover:shadow-[0_8px_25px_rgba(115,102,255,0.14)] transition-all duration-300 min-h-[300px] h-full flex flex-col items-center justify-center p-4 text-center group"
                  : "bg-white rounded-lg shadow-sm border-2 border-dashed border-slate-300 hover:border-slate-400 hover:bg-slate-50 transition-all duration-200 cursor-pointer group min-h-[220px]"
                } 
                onClick={!isCuba ? () => {
                  localStorage.removeItem("currentResumeId");
                  localStorage.removeItem("currentResumeItem");
                  this.props.navigate("/build-resume/heading?new=1");
                } : undefined}
              >
                <div className="p-3 text-center h-full flex flex-col items-center justify-center">
                  <div className={isCuba
                    ? "w-14 h-14 rounded-full bg-[#7366ff]/10 text-[#7366ff] group-hover:bg-[#7366ff] group-hover:text-white flex items-center justify-center mb-3 transition-all duration-200 shadow-xs"
                    : "w-16 h-16 bg-slate-100 group-hover:bg-slate-200 rounded-full flex items-center justify-center mb-6 transition-colors"
                  }>
                    <FaPlus className={isCuba ? "w-5 h-5" : "w-6 h-6 text-slate-600"} />
                  </div>
                  <h3 className={isCuba ? "text-sm font-bold text-cuba-ink mb-1" : "text-base font-medium text-slate-900 mb-2"}>
                    {isCuba ? "Create a New Resume" : t(
                      "DashboardHomepage.card.newResumeTitle",
                      "Create a New Resume"
                    )}
                  </h3>
                  <p className={isCuba ? "text-xs text-cuba-ink-muted text-center leading-relaxed max-w-[22ch] mb-3" : "text-sm text-slate-600 text-center leading-relaxed"}>
                    {isCuba ? "Start from scratch or use AI to create a professional resume." : t(
                      "DashboardHomepage.card.newResumeDescription",
                      "Start with a blank canvas or choose from 50+ templates"
                    )}
                  </p>
                  {isCuba && (
                    <div className="flex flex-col gap-2 w-full max-w-[200px]">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          localStorage.removeItem("currentResumeId");
                          localStorage.removeItem("currentResumeItem");
                          this.props.navigate("/build-resume/heading?new=1");
                        }}
                        className="cuba-btn-primary w-full py-2 px-3 rounded-xl text-xs font-bold shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        Create with AI
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          localStorage.removeItem("currentResumeId");
                          localStorage.removeItem("currentResumeItem");
                          this.props.navigate("/build-resume/heading?import=true");
                        }}
                        className="cuba-btn-outline w-full py-1.5 px-3 rounded-xl text-xs font-semibold cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <span aria-hidden="true">☁</span> Upload Resume
                      </button>
                    </div>
                  )}
                </div>
              </div>
              </div>
            )}

            {/* Import existing resume card - only show in legacy mode when enabled in admin settings (default OFF) */}
            {!isCuba && !this.state.isPaginating && !this.state.isfetcing && this.state.enableImportModule && (
              <div 
                className="bg-gradient-to-br from-purple-50/60 via-indigo-50/40 to-slate-50 rounded-lg shadow-sm border-2 border-dashed border-purple-300 hover:border-purple-500 hover:bg-purple-50/80 transition-all duration-200 cursor-pointer group" 
                onClick={() => {
                  localStorage.removeItem("currentResumeId");
                  localStorage.removeItem("currentResumeItem");
                  this.props.navigate("/build-resume/heading?import=true");
                }}
              >
                <div className="p-8 text-center h-full flex flex-col items-center justify-center">
                  <div className="w-16 h-16 bg-purple-100 group-hover:bg-purple-200 text-purple-600 rounded-full flex items-center justify-center mb-6 transition-colors shadow-inner">
                    <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                  </div>
                  <h3 className="text-base font-medium text-slate-900 mb-2">
                    Import Existing Resume
                  </h3>
                  <p className="text-sm text-slate-600 text-center leading-relaxed">
                    Upload your PDF or DOCX file to pre-fill all details automatically
                  </p>
                </div>
              </div>
            )}
          </div>



          {/* Pagination */}
          {this.state.displayDocuments !== null &&
            this.state.pagination.totalPages > 1 && (
              <div className="flex justify-center mt-6 sm:mt-8 px-4">
                <div className="flex items-center space-x-2 sm:space-x-3">
                  <button
                    onClick={() =>
                      this.setPageNumber(this.state.pagination.currentPage - 1)
                    }
                    disabled={!this.state.pagination.hasPreviousPage}
                    aria-label="Previous page"
                    className={`px-3 sm:px-4 py-2 rounded-lg font-medium transition-colors text-sm sm:text-base ${
                      this.state.pagination.hasPreviousPage
                        ? "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
                        : "bg-gray-100 text-gray-400 cursor-not-allowed"
                    }`}
                  >
                    <FaChevronRight aria-hidden="true" focusable="false" className="transform rotate-180 w-3 h-3 sm:w-4 sm:h-4" />
                  </button>

                  <span className="text-gray-600 px-2 sm:px-4 text-sm sm:text-base">
                    {t("DashboardHomepage.pagination.page", "Page")}{" "}
                    {this.state.pagination.currentPage}{" "}
                    {t("DashboardHomepage.pagination.of", "of")}{" "}
                    {this.state.pagination.totalPages}
                  </span>

                  <button
                    onClick={() =>
                      this.setPageNumber(this.state.pagination.currentPage + 1)
                    }
                    disabled={!this.state.pagination.hasNextPage}
                    aria-label="Next page"
                    className={`px-3 sm:px-4 py-2 rounded-lg font-medium transition-colors text-sm sm:text-base ${
                      this.state.pagination.hasNextPage
                        ? "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
                        : "bg-gray-100 text-gray-400 cursor-not-allowed"
                    }`}
                  >
                    <FaChevronRight aria-hidden="true" focusable="false" className="w-3 h-3 sm:w-4 sm:h-4" />
                  </button>
                </div>
              </div>
            )}
            </>
          )}

          {/* DIR-094 S5: the reference's bottom three-column analytics band.
              Mounted here — after the resume grid and its pagination — so it reads as
              the closing row of the Overview, exactly as the reference screenshot shows.

              Why this lives in DashboardHomepage rather than in CubaCandidateShell: the
              shell's Overview grid is the DIR-084 single-viewport frame, and this band is
              ordinary scrolling content inside that frame's already-scrollable child
              region. Mounting it here keeps the fold-critical geometry untouched.

              Gated on the Cuba shell so the preserved legacy chrome (the rollback target)
              is not silently restyled. Every column is driven by real data:
                • Application Progress — fetches the real authenticated job_tracker rows.
                • Top Job Matches      — fetches the real public job listings.
                • Your Next Steps      — renders this component's own measured
                  `onboardingSteps`, which DIR-058 computed but never displayed. */}
          {isCubaShellEnabled() && (
            <div
              data-testid="cuba-candidate-analytics"
              className="mt-4 grid grid-cols-1 gap-2.5 lg:grid-cols-3"
            >
              <CubaApplicationProgressChart />
              <CubaTopJobMatches onNavigate={this.props.navigate} />
              <CubaNextSteps steps={this.state.onboardingSteps} onStepClick={this.handleStepClick} />
            </div>
          )}

          {/* Delete Confirmation Modal */}
          {this.state.deleteModal.isOpen && (
            <div
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
              onClick={(e) => {
                if (
                  e.target === e.currentTarget &&
                  !this.state.deleteModal.isDeleting
                ) {
                  this.closeDeleteModal();
                }
              }}
            >
              <div className="bg-white rounded-lg shadow-xl max-w-sm sm:max-w-md w-full mx-4 transform transition-all duration-200 scale-100">
                <div className="p-4 sm:p-6">
                  <div className="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 bg-red-100 rounded-full">
                    <FaTrashAlt className="w-5 h-5 sm:w-6 sm:h-6 text-red-600" />
                  </div>

                  <div className="text-center">
                    <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-2">
                      {t(
                        "DashboardHomepage.deleteModal.title",
                        "Delete Document"
                      )}
                    </h3>
                    <p className="text-sm text-gray-500 mb-4 sm:mb-6 leading-relaxed">
                      {t(
                        "DashboardHomepage.deleteModal.message",
                        "Are you sure you want to delete"
                      )}
                      {this.state.deleteModal.resumeName && (
                        <span className="font-medium text-gray-700">
                          {" "}
                          "{this.state.deleteModal.resumeName}"
                        </span>
                      )}
                      ?{" "}
                      {t(
                        "DashboardHomepage.deleteModal.warningMessage",
                        "This action cannot be undone."
                      )}
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                    <button
                      className="flex-1 px-4 py-2.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200 order-2 sm:order-1"
                      onClick={this.closeDeleteModal}
                      disabled={this.state.deleteModal.isDeleting}
                    >
                      {t("DashboardHomepage.deleteModal.cancel", "Cancel")}
                    </button>
                    <button
                      className={`flex-1 px-4 py-2.5 text-sm font-medium text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-all duration-200 order-1 sm:order-2 ${
                        this.state.deleteModal.isDeleting
                          ? "bg-red-400 cursor-not-allowed"
                          : "bg-red-600 hover:bg-red-700"
                      }`}
                      onClick={this.confirmDeleteResume}
                      disabled={this.state.deleteModal.isDeleting}
                    >
                      {this.state.deleteModal.isDeleting ? (
                        <div className="flex items-center justify-center">
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          {t(
                            "DashboardHomepage.deleteModal.deleting",
                            "Deleting..."
                          )}
                        </div>
                      ) : (
                        t("DashboardHomepage.deleteModal.delete", "Delete")
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
          {/* Full Size Resume Preview Modal */}
          {this.state.showPreviewModal && this.state.previewingDocument && (
            <PreviewModal
              showPreview={this.state.showPreviewModal}
              setShowPreview={(val) => {
                if (!val) {
                  this.closeDocumentPreview();
                } else {
                  this.setState({ showPreviewModal: true });
                }
              }}
              resumeData={this.generateSampleCvData(this.state.previewingDocument)}
              currentTemplate={this.state.previewingDocument.template || this.state.previewingDocument.item?.template || 'Cv1'}
              getTemplateComponent={getTemplateComponent}
              getTemplateName={(tId) => tId}
              onShare={() => this.shareResume(this.state.previewingDocument)}
              isSharing={this.state.sharingResumeIds?.has(this.state.previewingDocument?.id || this.state.previewingDocument?._id)}
              onDownload={() => this.downloadResume(this.state.previewingDocument)}
              isDownloading={this.state.downloadingResumeIds.has(this.state.previewingDocument.id || this.state.previewingDocument._id)}
              onDownloadDocx={() => this.downloadResumeDocx(this.state.previewingDocument)}
              isDownloadingDocx={this.state.downloadingDocxIds.has(this.state.previewingDocument.id || this.state.previewingDocument._id)}
            />
          )}

          {/* Premium Upgrade Modal for Free Candidate download upsell */}
          <PremiumUpgradeModal
            isOpen={this.state.showPremiumUpgradeModal}
            onClose={() => this.setState({ showPremiumUpgradeModal: false, pendingDownloadDocument: null })}
            onUpgrade={() => this.setState({ showPremiumUpgradeModal: false, showSubscriptionModal: true })}
            downloadType={this.state.pendingDownloadType}
            resumeTitle={this.state.pendingDownloadDocument?.item?.firstname || "Resume"}
          />

          {/* In-Place Checkout Modal */}
          <SubscriptionModal
            isOpen={this.state.showSubscriptionModal}
            onClose={() => this.setState({ showSubscriptionModal: false, pendingDownloadDocument: null })}
            user={fire.auth().currentUser}
            onSuccess={async () => {
              this.setState({ showSubscriptionModal: false });
              const doc = this.state.pendingDownloadDocument;
              const type = this.state.pendingDownloadType;
              this.setState({ pendingDownloadDocument: null });
              if (doc) {
                if (type === 'docx') {
                  await this.downloadResumeDocx(doc);
                } else {
                  await this.downloadResume(doc);
                }
              }
            }}
          />

          {/* Authoritative Canonical Share Modal */}
          {this.state.shareModal?.isOpen && (
            <ShareModal
              isOpen={this.state.shareModal.isOpen}
              onClose={() => this.setState({ shareModal: { isOpen: false, documentId: null, documentTitle: '' } })}
              documentId={this.state.shareModal.documentId}
              documentTitle={this.state.shareModal.documentTitle}
            />
          )}
        </div>
      </div>
    );
  }
}

// Wrapper component to provide navigation to class component
const DashboardHomepageWrapper = (props) => {
  const navigate = useNavigate();
  // DIR-048: the dashboard itself is a class component and therefore cannot call
  // hooks, so the Cuba prompt dialog is owned here and handed down as a prop.
  // `renameResume` used window.prompt; it now awaits this instead. The dialog is
  // rendered by this wrapper so it is part of the real component tree.
  const { prompt, promptDialog } = usePromptDialog();
  return (
    <>
      <DashboardHomepage {...props} navigate={navigate} prompt={prompt} />
      {promptDialog}
    </>
  );
};

const MyComponent = withTranslation("common")(DashboardHomepageWrapper);
export default MyComponent;
