import React, { Component, Suspense, lazy } from 'react';
import './DashboardMain.scss';
import { Link, Navigate, Route, Routes } from 'react-router-dom';
import { AuthContext } from '../../../context/AuthContext';
import Toasts from '../../Toasts/Toats';
import fire from '../../../conf/fire';
import ProfileDisplay from '../ProfileDisplay/ProfileDisplay';
import Spinner from '../../Spinner/Spinner';
import { FaBars, FaEnvelope, FaCheckCircle, FaTimes, FaRedo } from 'react-icons/fa';

import { getFullName, getAds } from '../../../services/api/platform';
// Animation Library
import { motion, AnimatePresence } from 'framer-motion';
import { withTranslation } from 'react-i18next';
import { trackEvent, trackUserLogin, trackEngagement } from '../../../utils/ga4';
import signOutUser from '../../../utils/signOut';

import { getWebsiteData } from '../../../services/api/platform';

import DashboardToast from '../DashboardToast/DashboardToast';

const DashboardHomepage = lazy(() => import('../DashboardHomepage/DashboardHomepage'));
const DashboardSettings = lazy(() => import('../DashboardSettings/DashboardSettings'));
const DashboardFavourites = lazy(() => import('../DashboardFavourites/DashboardFavourites'));
const DashboardInterviews = lazy(() => import('../DashboardInterviews/DashboardInterviews'));
const DashboardPortfolios = lazy(() => import('../DashboardPortfolios/DashboardPortfolios'));
const AppliedJobs = lazy(() => import('../../AppliedJobs/AppliedJobs'));
const JobTracker = lazy(() => import('../../AppliedJobs/JobTracker'));
const EmployerDashboard = lazy(() => import('../EmployerDashboard/EmployerDashboard'));
const CompaniesManagement = lazy(() => import('../EmployerDashboard/CompaniesManagement'));
const DashboardMessages = lazy(() => import('../DashboardMessages/DashboardMessages'));
// DIR-026 / AC-3: the candidate messages route is gated on the administrator
// module flag so a bookmarked /dashboard/messages cannot bypass the AC-4 gate.
import MessagesModuleGate from '../../cuba/MessagesModuleGate';
const DashboardSupport = lazy(() => import('../DashboardSupport/DashboardSupport'));
const CoverLetter = lazy(() => import('../../CoverLetter/CoverLetter'));
const Billing = lazy(() => import('../../Billing/Plans/Plans'));
// Cuba design system showcase (§13). Lazy so the documentation surface costs
// nothing for the routes real users actually visit.
const DesignSystemShowcase = lazy(() => import('../../cuba/DesignSystemShowcase'));
const CubaCandidateShell = lazy(() => import('../../Candidate/CubaCandidateShell'));
import { isCubaShellEnabled } from '../../cuba/cubaShellFlag';
const MainJobListings = lazy(() => import('../../JobsListings/MainJobListings'));
// DIR-072: the dedicated full-page notifications workspace.
const DashboardNotifications = lazy(() => import('../DashboardNotifications/DashboardNotifications'));
// DIR-003 / CAND-001: the dedicated Resumes & Master CV workspace hub.
const DashboardResumes = lazy(() => import('../DashboardResumes/DashboardResumes'));
class DashboardMain extends Component {
    static contextType = AuthContext;
    constructor(props) {
        super(props);
        this.authListener = this.authListener.bind(this);
        this._isMounted = false;
        this._authGeneration = 0;
        this.unsubscribeAuth = null;
        this.state = {
            user: null,
            role: 'user',
            toast: {
                isShowed: false,
                type: '', // success , error , warning
                title: '',
                text: '',
            },
            membership: '',
            firstname: '',
            lastname: '',
            displayDocuments: [],
            fetchedDocuments: [],
            activeNav: 'Dashboard',
            isDeleteToastShowed: false,
            isDropdownShowed: false,
            pageNumber: 1,
            perPage: 2,
            isSettingsShowed: false,
            isAdsManagerShowed: false,
            isDashboardShowed: true,
            isAddPagesShowed: false,
            sidebarCollapsed: false,
            // Email verification banner
            showVerifyBanner: false,
            verifyBannerDismissed: false,
            verifyResending: false,
            verifyResendSuccess: false,
            // Meta data
            metaDataFetched: false,
            websiteTitle: '',
            websiteDescription: '',
            profile: {},
            websiteKeywords: '',
        };
        this.dropdownHandler = this.dropdownHandler.bind(this);
        this.settingsClickHandler = this.settingsClickHandler.bind(this);
        this.handleAdsClick = this.handleAdsClick.bind(this);
        this.handlePagesClick = this.handlePagesClick.bind(this);
        this.logout = this.logout.bind(this);
        this.isSettingsPath = this.isSettingsPath.bind(this);
        this.handleSidebarToggle = this.handleSidebarToggle.bind(this);

        this.showToast = this.showToast.bind(this);
    }

    /// Check if the user is authenticated
    authListener() {
        this.unsubscribeAuth = fire.auth().onAuthStateChanged(async user => {
            const generation = ++this._authGeneration;
            if (!this._isMounted) return;

            if (!user) {
                try { localStorage.removeItem('user'); } catch { /* optional compatibility storage */ }
                this.setState({
                    user: null, role: 'user', firstname: '', lastname: '', membership: '', profile: {},
                    showVerifyBanner: false, verifyBannerDismissed: false,
                });
                return;
            }

            // Clear every account-derived field immediately. This component can remain
            // mounted during a direct A → B Firebase session transition.
            this.setState({
                user: user.uid, role: 'user', firstname: '', lastname: '', membership: '', profile: {},
                showVerifyBanner: false, verifyBannerDismissed: false,
            });
            try { localStorage.setItem('user', user.uid); } catch { /* compatibility only */ }
            trackUserLogin('firebase');
            trackEngagement('dashboard_access');

            try {
                const [idToken, value] = await Promise.all([user.getIdTokenResult(), getFullName(user.uid)]);
                if (!this._isMounted || generation !== this._authGeneration || fire.auth().currentUser?.uid !== user.uid) return;
                const isAdminUser = ['ADMIN', 'SUPER_ADMIN'].includes(String(idToken.claims.role || '').toUpperCase());
                const resolvedMembership = isAdminUser
                    ? 'Admin Tier'
                    : (value?.membership && value.membership !== ';' ? value.membership : 'Basic');
                this.setState({
                    role: isAdminUser ? 'admin' : 'user',
                    firstname: value?.firstname || '',
                    lastname: value?.lastname || '',
                    membership: resolvedMembership,
                    profile: { ...(value?.profile || {}), membership: resolvedMembership },
                });
                if (isAdminUser) getAds().catch(() => {});

                const isEmailProvider = user.providerData?.some(provider => provider.providerId === 'password');
                if (isEmailProvider && !user.emailVerified) {
                    const { getSystemSettings } = await import('../../../services/api/platform');
                    const settings = await getSystemSettings();
                    if (!this._isMounted || generation !== this._authGeneration || fire.auth().currentUser?.uid !== user.uid) return;
                    if (settings?.modules?.enableEmailVerification === true) this.setState({ showVerifyBanner: true });
                }
            } catch (error) {
                if (this._isMounted && generation === this._authGeneration) {
                    console.warn('[Dashboard auth state]', error.message);
                }
            }
        });
    }
    // Show Drop down
    dropdownHandler() {
        this.setState((prevState, _props) => ({
            isDropdownShowed: !prevState.isDropdownShowed,
        }));
    }
    // Handle Settings Click
    settingsClickHandler() {
        this.setState((prevState, _props) => ({
            isSettingsShowed: !prevState.isSettingsShowed,
            isAdsManagerShowed: false,
        }));
    }

    // Handle Ads Click
    handleAdsClick() {
        this.setState((_prevState, _props) => ({
            isSettingsShowed: false,
            activeNav: 'Ads Manager',
            isDashboardShowed: false,
            isAdsManagerShowed: true,
        }));
    }
    // Handle Ads Click
    handlePagesClick() {
        this.setState((_prevState, _props) => ({
            isSettingsShowed: false,
            activeNav: 'Pages',
            isDashboardShowed: false,
            isAdsManagerShowed: false,
            isAddPagesShowed: true,
        }));
    }
    // Logout
    logout() {
        // Track logout event
        trackEvent('logout', 'User', 'Dashboard logout');

        signOutUser();
        this.currentResume = null;
    }
    // DIR-056 SUB-056-3: the legacy `handleCoverLetter()` "coming soon" toggle was
    // REMOVED. It was unreachable — nothing called it and nothing rendered
    // `isCommingSoonShowed` — and it was also self-defeating: it flipped the state
    // synchronously AND again after a 2000 ms timeout, so it always ended where it
    // started. The cover-letter surface is real and mounted at
    // /dashboard/cover-letters (see renderRoutes), so a stale "coming soon" gate
    // would have misrepresented a shipped feature.

    //show toast with a message
    showToast = (type, title, text) => {
        this.setState({
            toast: {
                isShowed: true,
                type: type, // success , error , warning
                title: title,
                text: text,
            },
        });
        // hide toast after 3 seconds
        setTimeout(() => {
            this.setState({
                toast: {
                    isShowed: false,
                    type: '', // success , error , warning
                    title: '',
                    text: '',
                },
            });
        }, 1000);
    };
    // DIR-056 SUB-056-4: the legacy `showFavorites()` modal toggle was REMOVED.
    // It was unreachable — its only caller was `DashboardActions`, a component
    // that is not mounted anywhere — so `isFavoritesShowed` was permanently
    // false and the always-mounted modal never rendered. Favourites are now a
    // real full page at /dashboard/favorites (see DashboardFavourites.jsx).

    // Handle sidebar toggle
    handleSidebarToggle(collapsed) {
        this.setState({ sidebarCollapsed: collapsed });
    }

    // Note: Language initialization is now handled globally in main.jsx
    // This method is kept for backward compatibility but does nothing
    initializeLanguage() {
        // Language initialization is now handled globally - no action needed
    }

    componentDidMount() {
        this._isMounted = true;
        this.authListener();

        // Initialize language from localStorage
        this.initializeLanguage();

        getWebsiteData().then((data) => {
            if (!this._isMounted) return; // Prevent state updates if component is unmounted
            this.setState({
                metaDataFetched: true,
                websiteTitle: data.title,
                websiteDescription: data.description,
                websiteKeywords: data.keywords,
            });
        });
        // set currentResumeItem to null
        // set currentResumeId to null
        localStorage.removeItem('currentResumeId');
        localStorage.removeItem('currentResumeItem');
    }

    componentWillUnmount() {
        this._isMounted = false;
        this._authGeneration += 1;
        // Clean up Firebase auth listener
        if (this.unsubscribeAuth) {
            this.unsubscribeAuth();
        }
    }
    // a function that returns true if we are in this path /dashboard/settings
    isSettingsPath = () => {
        return window.location.pathname === '/dashboard/settings';
    };

    /**
     * DIR-056 SUB-056-1: the ONE authoritative candidate route table.
     *
     * This dashboard renders inside two shells — the Cuba shell (default) and
     * the preserved legacy shell — and the identical 28-route table used to be
     * declared VERBATIM in both branches (56 declarations for 28 distinct
     * paths). Any future edit could therefore silently diverge between the two
     * copies and produce a route that works in one shell and 404s in the other.
     * Extracting it here makes that class of bug structurally impossible.
     */
    renderRoutes() {
        return (
                                    <Routes>
                                        <Route
                                            index
                                            element={
                                                <DashboardHomepage
                                                    profile={{
                                                        name: this.state.firstname + ' ' + this.state.lastname,
                                                        email: this.state.profile?.email || '',
                                                        phone: this.state.profile?.phone || '',
                                                        address: this.state.profile?.address || '',
                                                        city: this.state.profile?.city || '',
                                                        country: this.state.profile?.country || '',
                                                        occupation: this.state.profile?.occupation || '',
                                                    }}
                                                    membership={this.state.membership}
                                                    role={this.state.role}
                                                    showToast={this.showToast}
                                                    sidebarCollapsed={this.state.sidebarCollapsed}
                                                    handleSidebarToggle={this.handleSidebarToggle}
                                                />
                                            }
                                        />
                                        <Route path="settings" element={<DashboardSettings showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="messages" element={<MessagesModuleGate home="/dashboard" notify={this.showToast}><DashboardMessages showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} /></MessagesModuleGate>} />     
                                        <Route path="notifications" element={<DashboardNotifications showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="favorites" element={<DashboardFavourites showToast={this.showToast} />} />
                                        <Route path="resumes" element={<DashboardResumes showToast={this.showToast} membership={this.state.membership} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="interview" element={<DashboardInterviews showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="cover-letters" element={<CoverLetter />} />
                                        <Route path="portfolios" element={<DashboardPortfolios showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="applied-jobs" element={<AppliedJobs showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="job-tracker" element={<JobTracker showToast={this.showToast} />} />
                                        <Route path="jobs" element={<MainJobListings isInsideDashboard={true} showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="jobs/portal" element={<MainJobListings isInsideDashboard={true} showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="jobs/portal/:jobId" element={<MainJobListings isInsideDashboard={true} showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="jobs/browse" element={<MainJobListings isInsideDashboard={true} showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="jobs/category/:catName" element={<MainJobListings isInsideDashboard={true} showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="my-employments" element={<Navigate to="/employer/jobs" replace />} />
                                        <Route path="my-companies" element={<Navigate to="/employer/company" replace />} />
                                        <Route path="job-matching" element={<Navigate to="/dashboard/job-tracker" replace />} />
                                        <Route path="plans" element={<Billing user={this.state.user} showToast={this.showToast} />} />
                                        <Route path="support" element={<DashboardSupport showToast={this.showToast} sidebarCollapsed={this.state.sidebarCollapsed} handleSidebarToggle={this.handleSidebarToggle} />} />
                                        <Route path="tickets" element={<Navigate to="/dashboard/support" replace />} />
                                        <Route path="help" element={<Navigate to="/dashboard/support" replace />} />
                                        <Route path="profile" element={<Navigate to="/dashboard/settings?tab=profile" replace />} />
                                        <Route path="security" element={<Navigate to="/dashboard/settings?tab=security" replace />} />
                                        <Route path="account" element={<Navigate to="/dashboard/settings" replace />} />
                                        <Route path="billing" element={<Navigate to="/dashboard/plans" replace />} />
                                        <Route path="my-resumes" element={<Navigate to="/dashboard/resumes" replace />} />
                                        <Route path="cv" element={<Navigate to="/dashboard/cover-letters" replace />} />
                                        <Route path="design-system" element={<DesignSystemShowcase />} />
                                        <Route path="*" element={<Navigate to="/dashboard" replace />} />
                                    </Routes>
        );
    }

    render() {
        const { showVerifyBanner, verifyBannerDismissed, verifyResending, verifyResendSuccess } = this.state;

        // ─── Resend Branded Crypto Verification Email Handler ─────────────────
        const handleResendVerification = async () => {
            const currentUser = fire.auth().currentUser;
            const userEmail = currentUser?.email || this.state.profile?.email;
            if (!userEmail || verifyResending) return;
            this.setState({ verifyResending: true, verifyResendSuccess: false });
            try {
                const res = await fetch('/api/auth/send-verification-email', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        email: userEmail,
                        userName: currentUser?.displayName || this.state.firstname || userEmail.split('@')[0]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    this.setState({ verifyResendSuccess: true });
                } else {
                    console.warn('[VerifyBanner] Resend notice:', data.error);
                }
                // Poll until emailVerified flips true (max 5 mins, every 10s)
                let attempts = 0;
                const poll = setInterval(async () => {
                    attempts++;
                    try {
                        if (currentUser && typeof currentUser.reload === 'function') {
                            await currentUser.reload();
                            if (fire.auth().currentUser?.emailVerified) {
                                clearInterval(poll);
                                if (typeof fire.auth().currentUser.getIdToken === 'function') {
                                    await fire.auth().currentUser.getIdToken(true).catch(() => {});
                                }
                                if (this._isMounted) this.setState({ showVerifyBanner: false });
                            }
                        }
                    } catch (_e) { /* non-fatal */ }
                    if (attempts >= 30) clearInterval(poll);
                }, 10000);
            } catch (e) {
                console.warn('[VerifyBanner] Resend error:', e.message);
            } finally {
                this.setState({ verifyResending: false });
            }
        };
        // ────────────────────────────────────────────────────────────────────────

        const isSuperAdminUserView = typeof window !== 'undefined' && (sessionStorage.getItem('superadmin_role_view') === 'USER' || new URLSearchParams(window.location.search).get('superadmin_view') === '1');
        const resolvedUser = this.state.user || this.context?.uid || null;

        const roleViewBanner = isSuperAdminUserView ? (
            <div
                role="status"
                aria-live="polite"
                data-testid="superadmin-user-view-banner"
                className="sticky top-0 z-50 flex flex-wrap items-center justify-between gap-3 border-b border-amber-300 bg-linear-to-r from-amber-500 via-amber-600 to-amber-500 px-4 py-2.5 text-white shadow-md"
            >
                <div className="flex items-center gap-2 text-xs font-bold">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-white/20 text-xs">👑</span>
                    <span>
                        <strong>Super Admin Role View:</strong> Simulating candidate user dashboard. Real Super Admin authority is preserved.
                    </span>
                </div>
                <button
                    type="button"
                    onClick={() => {
                        sessionStorage.removeItem('superadmin_role_view');
                        window.location.href = '/admin/dashboard';
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1 text-xs font-black text-amber-900 transition hover:bg-amber-50 cursor-pointer shadow-xs"
                    data-testid="return-from-user-view-button"
                >
                    Return to Super Admin Console →
                </button>
            </div>
        ) : null;

        if (!resolvedUser) {
            return (
                <div className="min-h-screen bg-slate-50">
                    {roleViewBanner}
                    <Spinner />
                </div>
            );
        }
        return (
            <>
                {roleViewBanner}
                <div className="dashboardWrapper" data-testid="application-shell" data-shell-variant={isCubaShellEnabled() ? 'cuba' : 'legacy'} style={{ overflowX: 'clip' }}>
                    {/* Floating Mobile Sidebar Toggle */}
                <button
                    onClick={() => {
                        const newCollapsed = !this.state.sidebarCollapsed;
                        this.handleSidebarToggle(newCollapsed);
                        
                        // Handle mobile body scroll prevention
                        const isMobile = window.innerWidth < 1024;
                        if (isMobile) {
                            if (newCollapsed) {
                                // Remove the class to allow scrolling
                                document.body.classList.remove('mobile-sidebar-open');
                            } else {
                                // Add class to prevent scrolling
                                document.body.classList.add('mobile-sidebar-open');
                            }
                        }
                    }}
                    className="fixed top-4 left-4 z-40 lg:hidden w-10 h-10 bg-white border border-slate-200 rounded-lg shadow-lg flex items-center justify-center hover:bg-slate-50 transition-colors duration-200"
                    aria-label="Toggle sidebar"
                >
                    <FaBars className="w-4 h-4 text-slate-600" />
                </button>

                <AnimatePresence>
                    {this.state.isDeleteToastShowed && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                            <Toasts type="Delete" />
                        </motion.div>
                    )}
                </AnimatePresence>
                <DashboardToast isShowed={this.state.toast.isShowed} type={this.state.toast.type} title={this.state.toast.title} text={this.state.toast.text} />

                {/* ─── Email Verification Banner ────────────────────────────────────── */}
                {showVerifyBanner && !verifyBannerDismissed && (
                    <div style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        zIndex: 9999,
                        background: 'linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%)',
                        padding: '10px 20px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '12px',
                        boxShadow: '0 4px 16px -2px rgba(79,70,229,0.4)',
                        flexWrap: 'wrap',
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flex: 1, minWidth: 0 }}>
                            <FaEnvelope style={{ color: '#c7d2fe', flexShrink: 0, fontSize: '16px' }} />
                            <span style={{
                                color: '#ffffff',
                                fontSize: '13px',
                                fontWeight: 600,
                                fontFamily: '\'Poppins\', sans-serif',
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis'
                            }}>
                                {verifyResendSuccess
                                    ? '✅ Verification email sent! Check your inbox and click the link to verify.'
                                    : '⚠️ Your email address is not verified. Please check your inbox for a verification link.'}
                            </span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
                            <button
                                onClick={handleResendVerification}
                                disabled={verifyResending}
                                style={{
                                    background: 'rgba(255,255,255,0.18)',
                                    border: '1px solid rgba(255,255,255,0.35)',
                                    borderRadius: '6px',
                                    color: '#ffffff',
                                    fontSize: '12px',
                                    fontWeight: 700,
                                    padding: '5px 12px',
                                    cursor: verifyResending ? 'wait' : 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '5px',
                                    transition: 'background 0.2s',
                                    opacity: verifyResending ? 0.7 : 1,
                                    fontFamily: '\'Poppins\', sans-serif',
                                }}
                            >
                                <FaRedo style={{ fontSize: '10px' }} />
                                {verifyResending ? 'Sending...' : 'Resend Email'}
                            </button>
                            <button
                                onClick={() => this.setState({ verifyBannerDismissed: true, showVerifyBanner: false })}
                                style={{
                                    background: 'transparent',
                                    border: 'none',
                                    color: 'rgba(255,255,255,0.7)',
                                    cursor: 'pointer',
                                    padding: '4px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    borderRadius: '4px',
                                    transition: 'color 0.2s',
                                }}
                                title="Dismiss"
                            >
                                <FaTimes style={{ fontSize: '14px' }} />
                            </button>
                        </div>
                    </div>
                )}
                {/* ──────────────────────────────────────────────────────────────────── */}

                {isCubaShellEnabled() ? (
                    <Suspense fallback={<div className="min-h-screen bg-cuba-canvas" aria-busy="true" />}>
                        <CubaCandidateShell>
                            <div className="dashboardMainContent container-fluid p-0 w-full">
                                <Suspense fallback={<Spinner inline />}>
                                    {this.renderRoutes()}
                                </Suspense>
                            </div>
                        </CubaCandidateShell>
                    </Suspense>
                ) : (
                    <>
                        <ProfileDisplay
                            user={resolvedUser}
                            profile={{
                                name: (this.state.firstname && this.state.lastname) ? `${this.state.firstname} ${this.state.lastname}`.trim() : (this.state.profile?.name || `${this.state.profile?.firstname || ''} ${this.state.profile?.lastname || ''}`.trim() || ''),
                                firstname: this.state.firstname || this.state.profile?.firstname || '',
                                lastname: this.state.lastname || this.state.profile?.lastname || '',
                                email: this.state.profile?.email || '',
                                phone: this.state.profile?.phone || '',
                                address: this.state.profile?.address || '',
                                city: this.state.profile?.city || '',
                                country: this.state.profile?.country || '',
                                occupation: this.state.profile?.occupation || '',
                                membership: this.state.membership || this.state.profile?.membership,
                                selectedImage: this.state.profile?.selectedImage || this.state.profile?.image,
                                image: this.state.profile?.image || this.state.profile?.selectedImage,
                            }}
                            image={this.state.profile}
                            sidebarCollapsed={this.state.sidebarCollapsed}
                            onSidebarToggle={this.handleSidebarToggle}
                        />

                        <div className={`dashboardContentWrapper ${this.state.sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
                            <div className="dashboardMainContent">
                                <Suspense fallback={<Spinner inline />}>
                                    {this.renderRoutes()}
                                </Suspense>
                            </div>
                        </div>
                    </>
                )}
            </div>
            </>
        );
    }
}
const MyComponent = withTranslation('common')(DashboardMain);
export default MyComponent;
