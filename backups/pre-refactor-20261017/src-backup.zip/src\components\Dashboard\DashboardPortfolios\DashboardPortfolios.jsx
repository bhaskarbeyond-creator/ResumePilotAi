import React, { useState, useEffect } from 'react';
import { withTranslation } from 'react-i18next';
import { FiPlus, FiEye, FiEdit3, FiTrash2, FiExternalLink, FiGrid, FiList } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import fire from '../../../conf/fire';
import { getUserPortfolios, deletePortfolio } from '../../../services/api/platform';
// DIR-081: page-frame + honest empty/error states so a failed read can never be
// rendered as "you have no portfolios".
import CubaPageFrame from '../../cuba/CubaPageFrame';
import CubaEmptyState from '../../cuba/CubaEmptyState';

// Import portfolio preview images
import darkCyberPreview from '../../../assets/portfolioPreview/Dark Cyber Portfolio.JPG';
import terminalPreview from '../../../assets/portfolioPreview/Terminal Portfolio.JPG';
import artistPreview from '../../../assets/portfolioPreview/Artist Portfolio.JPG';
import cyberSecurityPreview from '../../../assets/portfolioPreview/Cyber Security Portfolio.JPG';
import modernMinimalPreview from '../../../assets/portfolioPreview/modern-minimal.png';
import executivePreview from '../../../assets/portfolioPreview/executive.png';
import creativeDarkPreview from '../../../assets/portfolioPreview/creative-dark.png';
import premiumTechPreview from '../../../assets/portfolioPreview/premium-tech.png';

/**
 * DIR-019 DEFECT 2 — resolve the PUBLIC portfolio address, or `null`.
 *
 * WHY THIS EXISTS: both the grid and the list view used to render
 * `<Link to={`/portfolio/${portfolio.slug}`}>` unconditionally. MariaDB stores
 * `slug = NULL` for unpublished drafts (no vanity address has been issued yet),
 * so the template string interpolated the literal text "null" and produced
 * `href="/portfolio/null"`, which 404s against
 * `/api/portfolios/public/null`.
 *
 * A public address is only real when the row is BOTH published AND actually
 * carries a non-placeholder slug, so this returns `null` in every other case and
 * the caller renders a "Open in Studio" action instead. The guard is
 * deliberately strict about the string sentinels too: `'null'`, `'undefined'`
 * and `''` are all treated as "no address", because a NULL column that has
 * already been coerced to a string once must not leak back into the DOM.
 */
function getPublicPortfolioHref(portfolio) {
    if (!portfolio || portfolio.isPublished !== true) return null;
    const slug = typeof portfolio.slug === 'string' ? portfolio.slug.trim() : '';
    if (!slug || slug === 'null' || slug === 'undefined') return null;
    return `/portfolio/${slug}`;
}

// eslint-disable-next-line react-refresh/only-export-components
const DashboardPortfolios = ({ t, showToast }) => {
    const [portfolios, setPortfolios] = useState([]);
    const [loading, setLoading] = useState(true);
    const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedTheme, setSelectedTheme] = useState('');
    // DIR-081: a FAILED read is tracked separately from an empty account, so the
    // page can tell the user the truth instead of showing a false empty state.
    const [loadError, setLoadError] = useState('');

    const themes = [
        { value: '', label: t('DashboardPortfolios.themes.allThemes') },
        { value: 'default', label: t('DashboardPortfolios.themes.default') },
        { value: 'dark', label: t('DashboardPortfolios.themes.darkTheme') },
        { value: 'minimal', label: t('DashboardPortfolios.themes.minimal') },
        { value: 'creative', label: t('DashboardPortfolios.themes.creative') },
        { value: 'professional', label: t('DashboardPortfolios.themes.professional') },
    ];

    useEffect(() => {
        loadUserPortfolios();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const loadUserPortfolios = async () => {
        try {
            setLoading(true);
            setLoadError('');
            const user = fire.auth().currentUser;
            if (user) {
                const userPortfolios = await getUserPortfolios(user.uid, true); // Include unpublished portfolios
                // Ensure we always have an array, even if the result is null or undefined
                setPortfolios(Array.isArray(userPortfolios) ? userPortfolios : []);
            } else {
                // No authenticated user, set empty portfolios
                setPortfolios([]);
            }
        } catch (error) {
            console.error('Error loading portfolios:', error);
            // DIR-081: previously the catch emptied the array and relied on a toast, so
            // a genuine network/API failure rendered the "no portfolios" empty state and
            // told the user their work had disappeared. Record the real error instead.
            setPortfolios([]);
            setLoadError(error?.message || t('DashboardPortfolios.messages.loadError'));
            showToast && showToast('error', 'Error', t('DashboardPortfolios.messages.loadError'));
        } finally {
            setLoading(false);
        }
    };

    const [deleteModal, setDeleteModal] = useState({ isOpen: false, portfolioId: null });

    const handleDeletePortfolio = (portfolioId) => {
        setDeleteModal({ isOpen: true, portfolioId });
    };

    const confirmDeletePortfolio = async () => {
        if (!deleteModal.portfolioId) return;
        try {
            const user = fire.auth().currentUser;
            if (user) {
                await deletePortfolio(user.uid, deleteModal.portfolioId);
                setPortfolios(portfolios.filter((p) => p.id !== deleteModal.portfolioId));
                showToast && showToast('success', 'Success', t('DashboardPortfolios.messages.deleteSuccess', 'Portfolio deleted successfully'));
            }
        } catch (error) {
            console.error('Error deleting portfolio:', error);
            showToast && showToast('error', 'Error', t('DashboardPortfolios.messages.deleteError', 'Failed to delete portfolio'));
        } finally {
            setDeleteModal({ isOpen: false, portfolioId: null });
        }
    };

    const filteredPortfolios = portfolios.filter((portfolio) => {
        // Ensure portfolio object exists and has required properties
        if (!portfolio || typeof portfolio !== 'object') {
            return false;
        }
        
        const title = portfolio.title || '';
        const description = portfolio.metadata?.description || '';
        const theme = portfolio.theme || '';
        
        const matchesSearch = 
            title.toLowerCase().includes(searchTerm.toLowerCase()) || 
            description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesTheme = !selectedTheme || theme === selectedTheme;
        return matchesSearch && matchesTheme;
    });

    // DIR-081: theme chips resolve through Cuba tokens instead of the legacy palette.
    const getThemeColor = (theme) => {
        const colors = {
            default: 'bg-cuba-primary-soft text-cuba-primary-ink-strong',
            dark: 'bg-cuba-ink text-cuba-canvas',
            minimal: 'bg-cuba-card text-cuba-ink border border-cuba-line',
            creative: 'bg-cuba-info-soft text-cuba-ink',
            professional: 'bg-cuba-success-soft text-cuba-ink',
        };
        return colors[theme] || colors.default;
    };

    const getPreviewImage = (portfolio) => {
        // First check if portfolio has a specific template that matches our previews
        const template = portfolio.data?.templateKey || portfolio.data?.template || portfolio.template;
        const theme = portfolio.theme || 'default';
        const title = portfolio.title?.toLowerCase() || '';

        if (template === 'modernMinimal' || theme === 'minimal') return modernMinimalPreview;
        if (template === 'executive' || theme === 'professional') return executivePreview;
        if (template === 'creativeDark' || theme === 'creative') return creativeDarkPreview;
        if (template === 'premiumTech') return premiumTechPreview;

        // Match based on template, theme, or title keywords
        if (template === 'darkCyber' || theme === 'dark-cyber' || title.includes('cyber') || title.includes('dark')) {
            return darkCyberPreview;
        }
        if (template === 'terminal' || theme === 'terminal' || title.includes('terminal') || title.includes('developer')) {
            return terminalPreview;
        }
        if (template === 'artist' || theme === 'artist' || theme === 'creative' || title.includes('artist') || title.includes('creative')) {
            return artistPreview;
        }
        if (template === 'cyberSecurity' || theme === 'cybersecurity' || title.includes('security') || title.includes('cybersecurity')) {
            return cyberSecurityPreview;
        }

        // Default fallback based on theme
        switch (theme) {
            case 'dark':
                return darkCyberPreview;
            case 'creative':
                return artistPreview;
            case 'professional':
                return terminalPreview;
            case 'minimal':
                return terminalPreview;
            default:
                return artistPreview; // Default to artist portfolio as it's most generic
        }
    };

    // DIR-083: a modular BENTO showcase — the newest portfolio is the featured tile (it
    // spans two columns with a taller preview on sm and up) and the rest flow into single
    // modules, so a wide desktop shows a real composition instead of a uniform strip.
    const renderGridView = () => (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5" data-testid="portfolio-bento-grid">
            {filteredPortfolios.map((portfolio, index) => (
                <div key={portfolio.id} data-testid="portfolio-bento-tile" className={`cuba-widget-texture bg-cuba-card rounded-cuba-lg border border-cuba-line hover:shadow-cuba-lg hover:-translate-y-1 transition-all duration-300 ${index === 0 ? 'sm:col-span-2' : ''}`}>
                    {/* Preview */}
                    <div className={`relative overflow-hidden rounded-t-cuba-lg bg-cuba-canvas ${index === 0 ? 'h-56 sm:h-72' : 'h-44'}`}>
                        <img
                            src={getPreviewImage(portfolio)}
                            alt={`${portfolio.title} preview`}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                                // DIR-083: degrade to a Cuba surface instead of the legacy
                                // slate-to-purple gradient.
                                e.target.style.display = 'none';
                                e.target.parentElement.classList.add('bg-cuba-primary-soft');
                            }}
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-10 hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center opacity-0 hover:opacity-100">
                            <div className="text-white text-center">
                                <FiEye className="w-8 h-8 mx-auto mb-2" />
                                <p className="text-sm font-medium">{t('DashboardPortfolios.actions.viewPreview')}</p>
                            </div>
                        </div>
                        {/* Portfolio Status Badge */}
                        <div className="absolute top-3 right-3">
                            <span className={`rounded-full px-2 py-1 text-xs font-medium ${portfolio.isPublished ? 'bg-cuba-success-soft text-cuba-success' : 'bg-cuba-warning-soft text-cuba-warning'}`}>
                                {portfolio.isPublished ? t('DashboardPortfolios.status.published') : t('DashboardPortfolios.status.draft')}
                            </span>
                        </div>
                    </div>

                    {/* Content */}
                    <div className="p-4">
                        <div className="flex items-center justify-between mb-3">
                            <h3 className="text-sm font-semibold text-cuba-ink truncate">{portfolio.title}</h3>
                            <span className={`px-2 py-1 text-xs font-medium rounded-cuba-sm ${getThemeColor(portfolio.theme)}`}>{portfolio.theme}</span>
                        </div>

                        {portfolio.metadata?.description ? (<p className="text-cuba-ink-muted text-xs mb-3 line-clamp-2 h-8">{portfolio.metadata.description}</p>) : (<div className="h-8 mb-3" />)}

                        <div className="flex items-center justify-between text-xs text-cuba-ink-subtle mb-4">
                            <span>
                                {t('DashboardPortfolios.stats.views')}: {portfolio.views || 0}
                            </span>
                            <span>
                                {t('DashboardPortfolios.stats.updated')}: {portfolio.updatedAt ? (typeof portfolio.updatedAt?.toDate === 'function' ? portfolio.updatedAt.toDate() : new Date(portfolio.updatedAt)).toLocaleDateString?.() || 'N/A' : 'N/A'}
                            </span>
                        </div>

                        {/* Actions */}
                        <div className="space-y-2">
                            {/* DIR-019 DEFECT 2: only a genuinely published,
                                slug-bearing portfolio has a public address. A
                                draft (slug IS NULL in MariaDB) gets a distinct
                                "Open in Studio" action, so href="/portfolio/null"
                                is NEVER rendered. */}
                            {(() => {
                                const publicHref = getPublicPortfolioHref(portfolio);
                                return publicHref ? (
                                    <Link
                                        to={publicHref}
                                        className="cuba-btn-primary w-full inline-flex items-center justify-center px-3 py-2 text-white text-sm font-bold rounded-lg shadow-xs">
                                        <FiEye className="w-3.5 h-3.5 mr-2" />
                                        {t('DashboardPortfolios.actions.view')}
                                    </Link>
                                ) : (
                                    <Link
                                        to={`/portfolio/builder?edit=${portfolio.id}`}
                                        data-testid="portfolio-open-draft"
                                        className="cuba-btn-outline w-full inline-flex items-center justify-center px-3 py-2 text-sm font-bold rounded-lg">
                                        <FiEdit3 className="w-3.5 h-3.5 mr-2" />
                                        {t('DashboardPortfolios.actions.openStudio')}
                                    </Link>
                                );
                            })()}
                            <div className="flex items-center gap-2">
                                <Link to={`/portfolio/builder?edit=${portfolio.id}`} className="flex-1 px-2.5 py-1.5 bg-cuba-primary-soft text-cuba-primary-ink-strong rounded-cuba-sm hover:bg-cuba-primary-soft-hover transition-colors text-xs font-medium border border-cuba-line text-center">
                                    <FiEdit3 className="w-3.5 h-3.5 inline mr-1" />
                                    Edit
                                </Link>
                                <button onClick={() => handleDeletePortfolio(portfolio.id)} className="px-2.5 py-1.5 bg-cuba-danger-soft text-cuba-danger rounded-cuba-sm hover:bg-cuba-danger-soft transition-colors text-xs font-medium border border-cuba-danger/30">
                                    <FiTrash2 className="w-3.5 h-3.5" />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );

    const renderListView = () => (
        <div className="bg-cuba-card border border-cuba-line rounded-cuba-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-cuba-line bg-cuba-card">
                <div className="grid grid-cols-12 gap-4 text-sm font-medium text-cuba-ink-muted">
                    <div className="col-span-4">{t('DashboardPortfolios.table.portfolio')}</div>
                    <div className="col-span-2">{t('DashboardPortfolios.table.theme')}</div>
                    <div className="col-span-2">{t('DashboardPortfolios.table.views')}</div>
                    <div className="col-span-2">{t('DashboardPortfolios.table.updated')}</div>
                    <div className="col-span-2">{t('DashboardPortfolios.table.actions')}</div>
                </div>
            </div>
            <div className="divide-y divide-slate-200">
                {filteredPortfolios.map((portfolio) => (
                    <div key={portfolio.id} className="px-6 py-4 hover:bg-cuba-primary-soft/40">
                        <div className="grid grid-cols-12 gap-4 items-center">
                            <div className="col-span-4">
                                <div className="flex items-center gap-3">
                                    {/* Mini Preview Image */}
                                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-cuba-canvas flex-shrink-0">
                                        <img
                                            src={getPreviewImage(portfolio)}
                                            alt={`${portfolio.title} preview`}
                                            className="w-full h-full object-cover"
                                            onError={(e) => {
                                                e.target.style.display = 'none';
                                                e.target.parentElement.classList.add('bg-cuba-primary-soft');
                                            }}
                                        />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <h3 className="text-xs font-medium text-cuba-ink truncate">{portfolio.title}</h3>
                                        {portfolio.metadata?.description && <p className="text-xs text-cuba-ink-subtle truncate">{portfolio.metadata.description}</p>}
                                        <span
                                            className={`inline-block mt-1 px-2 py-0.5 text-xs rounded-full ${portfolio.isPublished ? 'bg-cuba-success-soft text-cuba-success' : 'bg-cuba-warning-soft text-cuba-warning'}`}>
                                            {portfolio.isPublished ? t('DashboardPortfolios.status.published') : t('DashboardPortfolios.status.draft')}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-span-2">
                                <span className={`px-2 py-1 text-xs font-medium rounded ${getThemeColor(portfolio.theme)}`}>{portfolio.theme}</span>
                            </div>
                            <div className="col-span-2 text-xs text-cuba-ink-subtle">{portfolio.views || 0}</div>
                            <div className="col-span-2 text-xs text-cuba-ink-subtle">{portfolio.updatedAt ? (typeof portfolio.updatedAt?.toDate === 'function' ? portfolio.updatedAt.toDate() : new Date(portfolio.updatedAt)).toLocaleDateString?.() || 'N/A' : 'N/A'}</div>
                            <div className="col-span-2">
                                <div className="flex items-center gap-2">
                                    {/* DIR-019 DEFECT 2: same guard as the grid view —
                                        the eye (public) link is omitted entirely for a
                                        draft rather than rendered as href="/portfolio/null". */}
                                    {getPublicPortfolioHref(portfolio) && (
                                        <Link
                                            to={getPublicPortfolioHref(portfolio)}
                                            className="p-2 text-cuba-ink-muted hover:bg-cuba-primary-soft rounded transition-colors"
                                            title={t('DashboardPortfolios.tooltips.viewPortfolio')}>
                                            <FiEye className="w-4 h-4" />
                                        </Link>
                                    )}
                                    <Link
                                        to={`/portfolio/builder?edit=${portfolio.id}`}
                                        className="p-2 text-cuba-ink-muted hover:bg-cuba-primary-soft rounded transition-colors"
                                        title={t('DashboardPortfolios.tooltips.editPortfolio')}>
                                        <FiEdit3 className="w-4 h-4" />
                                    </Link>
                                    <button
                                        onClick={() => handleDeletePortfolio(portfolio.id)}
                                        className="p-2 text-cuba-danger hover:bg-cuba-danger-soft rounded transition-colors"
                                        title={t('DashboardPortfolios.tooltips.deletePortfolio')}>
                                        <FiTrash2 className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    // DIR-081: the page identity is rendered in every state, so loading and failure
    // keep the real title instead of collapsing the page body.
    // DIR-083: the starter-template strip. It renders the REAL bundled preview assets that
    // getPreviewImage() already resolves, and routes to the builder's create flow — no
    // invented template names and no fake screenshots.
    const STARTER_TEMPLATES = [
        { key: 'modernMinimal', label: t('DashboardPortfolios.themes.minimal'), image: modernMinimalPreview },
        { key: 'executive', label: t('DashboardPortfolios.themes.professional'), image: executivePreview },
        { key: 'creativeDark', label: t('DashboardPortfolios.themes.creative'), image: creativeDarkPreview },
        { key: 'premiumTech', label: t('DashboardPortfolios.themes.darkTheme'), image: premiumTechPreview },
    ];

    const renderStarterTemplates = () => (
        <section className="mb-6" aria-labelledby="portfolio-starter-templates">
            <h2 id="portfolio-starter-templates" className="mb-3 text-sm font-semibold text-cuba-ink">
                {t('DashboardPortfolios.starterTemplates', 'Starter templates')}
            </h2>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4" data-testid="portfolio-template-strip">
                {STARTER_TEMPLATES.map((template) => (
                    <Link
                        key={template.key}
                        to="/portfolio/builder?create=1"
                        className="cuba-focusable group overflow-hidden rounded-cuba-lg border border-cuba-line bg-cuba-card transition-shadow hover:shadow-cuba-lg"
                    >
                        <div className="h-24 overflow-hidden bg-cuba-canvas sm:h-28">
                            <img
                                src={template.image}
                                alt={`${template.label} template preview`}
                                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                            />
                        </div>
                        <p className="truncate px-3 py-2 text-xs font-semibold text-cuba-ink">{template.label}</p>
                    </Link>
                ))}
            </div>
        </section>
    );

    const pageIdentity = {
        title: t('DashboardPortfolios.title'),
        subtitle: t('DashboardPortfolios.subtitle'),
    };

    if (loading) {
        return <CubaPageFrame {...pageIdentity} state="loading" loadingLabel={t('DashboardPortfolios.loading', 'Loading your portfolios')} loadingRows={4} />;
    }

    if (loadError) {
        return (
            <CubaPageFrame
                {...pageIdentity}
                state="error"
                error={loadError}
                onRetry={loadUserPortfolios}
            />
        );
    }

    return (
        <div className="min-h-0 bg-cuba-canvas" data-testid="cuba-page-frame" data-page-state="ready">
            <div className="mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 py-4 sm:py-6 max-w-none w-full" style={{maxWidth: '1600px'}}>
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
                    <div className="flex items-center space-x-3">
                        <div className="p-2 bg-cuba-primary-soft rounded-lg">
                            <FiGrid className="w-5 h-5 text-cuba-primary-ink-strong" />
                        </div>
                        <div>
                            <h1 className="text-xl font-semibold text-cuba-ink">{t('DashboardPortfolios.title')}</h1>
                            <p className="text-sm text-cuba-ink-muted mt-0.5">{t('DashboardPortfolios.subtitle')}</p>
                        </div>
                    </div>
                        <Link to="/portfolio/builder?create=1" className="cuba-btn-primary inline-flex items-center px-4 py-2.5 text-white text-sm font-bold rounded-xl transition-all min-h-[44px] shadow-sm">
                            <FiPlus className="w-4 h-4 mr-2" />
                            {t('DashboardPortfolios.createPortfolio')}
                        </Link>
                </div>

                {/* Filters and Controls */}
                <div className="cuba-widget-texture bg-cuba-card rounded-[15px] border border-cuba-line shadow-[0_9px_20px_rgba(46,35,94,0.07)] p-4 mb-6">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                        {/* Search and Filter */}
                        <div className="flex flex-col sm:flex-row gap-4 flex-1">
                            <div className="flex-1">
                                <input
                                    type="text"
                                    placeholder={t('DashboardPortfolios.searchPlaceholder')}
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full pl-9 pr-3 py-2.5 text-sm border border-cuba-line-strong rounded-cuba-sm focus:outline-none focus:ring-1 focus:ring-cuba-primary focus:border-cuba-primary placeholder:text-cuba-ink-subtle"
                                />
                            </div>
                            <div className="sm:w-48">
                                <select
                                    value={selectedTheme}
                                    onChange={(e) => setSelectedTheme(e.target.value)}
                                    className="w-full px-3 py-2.5 text-sm border border-cuba-line-strong rounded-cuba-sm focus:outline-none focus:ring-1 focus:ring-cuba-primary focus:border-cuba-primary bg-cuba-canvas">
                                    {themes.map((theme) => (
                                        <option key={theme.value} value={theme.value}>
                                            {theme.label}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        {/* View Toggle */}
                        <div className="flex items-center gap-2">
                            <button
                                onClick={() => setViewMode('grid')}
                                className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-cuba-primary-soft text-cuba-primary-ink-strong' : 'text-cuba-ink-subtle hover:text-cuba-ink'}`}>
                                <FiGrid className="w-5 h-5" />
                            </button>
                            <button
                                onClick={() => setViewMode('list')}
                                className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-cuba-primary-soft text-cuba-primary-ink-strong' : 'text-cuba-ink-subtle hover:text-cuba-ink'}`}>
                                <FiList className="w-5 h-5" />
                            </button>
                        </div>
                    </div>
                </div>

                {/* Content */}
                {/* DIR-083: the starter-template strip sits above the content so the page
                    opens with real, actionable options rather than a bare grid. */}
                {renderStarterTemplates()}

                {filteredPortfolios.length === 0 ? (
                    /* DIR-081: the real Cuba empty state — no raw emoji placeholder, and a
                       genuine load failure is an error state above, never this. */
                    <CubaEmptyState
                        icon={<FiGrid className="h-5 w-5" aria-hidden="true" />}
                        title={t('DashboardPortfolios.emptyState.title')}
                        description={searchTerm || selectedTheme ? t('DashboardPortfolios.emptyState.noSearchResults') : t('DashboardPortfolios.emptyState.noPortfolios')}
                        action={(
                            <Link to="/portfolio/builder" className="cuba-btn-primary inline-flex items-center px-5 py-2.5 text-white text-sm font-bold rounded-xl transition-all min-h-[44px] shadow-sm">
                                <FiPlus className="w-5 h-5 mr-2" />
                                {t('DashboardPortfolios.emptyState.createFirstPortfolio')}
                            </Link>
                        )}
                    />
                ) : (
                    <>{viewMode === 'grid' ? renderGridView() : renderListView()}</>
                )}
            </div>

            {/* In-App Delete Confirmation Modal with ESC key handling */}
            {deleteModal.isOpen && (
                <div
                    className="fixed inset-0 z-50 bg-cuba-ink/50 backdrop-blur-xs flex items-center justify-center p-4"
                    role="presentation"
                    onKeyDown={(e) => { if (e.key === 'Escape') setDeleteModal({ isOpen: false, portfolioId: null }); }}>
                    <div
                        role="alertdialog"
                        aria-modal="true"
                        aria-labelledby="delete-portfolio-title"
                        className="bg-cuba-card rounded-cuba-lg max-w-md w-full p-6 shadow-cuba-lg space-y-4 border border-cuba-line">
                        <h3 id="delete-portfolio-title" className="text-base font-bold text-cuba-ink">
                            {t('DashboardPortfolios.deleteModal.title', 'Confirm Portfolio Deletion')}
                        </h3>
                        <p className="text-xs text-cuba-ink-muted leading-relaxed">
                            {t('DashboardPortfolios.deleteConfirmation', 'Are you sure you want to delete this portfolio? This action cannot be undone.')}
                        </p>
                        <div className="flex items-center justify-end gap-2 pt-2">
                            <button
                                type="button"
                                autoFocus
                                onClick={() => setDeleteModal({ isOpen: false, portfolioId: null })}
                                className="px-4 py-2 bg-cuba-primary-soft hover:bg-cuba-primary-soft-hover text-cuba-primary-ink-strong font-bold text-xs rounded-xl cursor-pointer">
                                {t('common.cancel', 'Cancel')}
                            </button>
                            <button
                                type="button"
                                onClick={confirmDeletePortfolio}
                                className="px-4 py-2 bg-cuba-danger text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer">
                                {t('common.delete', 'Delete Portfolio')}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

// eslint-disable-next-line react-refresh/only-export-components
export default withTranslation('common')(DashboardPortfolios);
