import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { getProfileOfUser, getAccountInfo, saveUserPreferences, changePassword, updateUserEmail, getUserTransactions, deleteUserAccountPermanently, exportUserDataJSON, beginUserTotp2FA, saveUserTotp2FA, disableUserTotp2FA, getUserTotpStatus, reauthenticateUser, recordUserLoginEvent, getUserLoginHistory, sendSmsNotification } from '../../../services/api/platform';
import { saveProfile } from '../../../services/profilePersistence';
import { generateUserAiContent, cleanSkillName } from '../../../services/aiService';
// DIR-075: clean identity parsing for the Master Profile header (no raw '()').
import { parseUserIdentity, roleBadgeFor } from '../../cuba/userIdentity';
import { FaCamera, FaTrash, FaUserCircle, FaKey, FaCalendarAlt, FaEnvelope, FaCreditCard, FaUpload, FaCheckCircle, FaExclamationTriangle, FaBriefcase, FaGraduationCap, FaTools, FaGlobe, FaPlus, FaCheck, FaShieldAlt, FaDesktop, FaDownload, FaCertificate, FaProjectDiagram, FaMagic, FaLinkedin, FaGithub, FaLink, FaSyncAlt, FaExternalLinkAlt, FaUnlink, FaLock, FaEye, FaEyeSlash, FaCrown, FaMobileAlt, FaQrcode, FaCopy, FaPrint, FaHistory, FaCrop, FaThLarge, FaTags, FaTimes, FaSearch, FaBolt, FaChevronDown, FaChevronUp, FaRocket, FaBuilding, FaCode } from 'react-icons/fa';
import { MdAutoAwesome, MdLaunch, MdSearch, MdClose, MdContentCopy, MdDeleteOutline, MdAdd, MdErrorOutline } from 'react-icons/md';
import fire from '../../../conf/fire';
import MonthYearPicker from '../../Form/MonthYearPicker';
import AiRecommendationModal from '../../Form/AiRecommendationModal';
import BulletPointsEditor, { getRolePlaceholder } from '../../Form/BulletPointsEditor';
import AutocompleteInputField from '../../BuildResume/steps/components/AutocompleteInputField';
import Field from '../../BuildResume/components/Field';
import ImageCropModal from './ImageCropModal';
import SubscriptionModal from './SubscriptionModal';
import { inferCountryFromCity } from '../../../utils/locationHelper';
import { normalizeProfileData, normalizeProfileImage } from '../../../utils/profileData';
import { calculateYearsOfExperience } from '../../../utils/resumeData';
import { getCandidateContext } from '../../../utils/candidateContext';
import { stripHtml } from '../../../utils/atsScore';
import { openPrivacyChoicesModal } from '../../PrivacyConsentBanner';
import { PROJECT_TYPES } from '../../BuildResume/steps/ProjectsStep';
import { CERT_TYPES } from '../../BuildResume/steps/CertificationsStep';
import { ACHIEVEMENT_TYPES, SUGGESTION_CHIPS, TYPE_STYLE_MAP } from '../../BuildResume/steps/AchievementsStep';

const htmlToPlainText = (val) => {
    if (!val) return '';
    if (!/<[^>]*>/g.test(val)) return String(val).trim();
    return String(val)
        .replace(/<\/(p|div|li|h[1-6])>/gi, '\n')
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<[^>]*>/g, '')
        .replace(/&nbsp;/gi, ' ')
        .replace(/&#160;/gi, ' ')
        .replace(/&amp;/gi, '&')
        .replace(/&lt;/gi, '<')
        .replace(/&gt;/gi, '>')
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/gi, "'")
        .replace(/\n{3,}/g, '\n\n')
        .trim();
};

const normalizeProfileForSave = value => {
    const authEmail = fire.auth().currentUser?.email;
    return normalizeProfileData({
        ...value,
        email: (authEmail || value?.email || '').trim().toLowerCase(),
        postalcode: value?.postalCode || '',
        website: value?.websiteUrl || ''
    });
};

const SUBTAB_CONFIG = {
    basic: {
        id: 'basic',
        name: 'Basic & Contact',
        title: 'Personal Details & Contact',
        subtitle: 'Your core identity, headline, and direct contact channels used across all resume templates.',
        statusBadge: 'Core Identity',
        isComplete: (p) => Boolean((p.firstname || p.lastname) && p.occupation && p.phone && (p.city || p.country)),
        computeGaps: (p) => {
            const gaps = [];
            if (!p.firstname && !p.lastname) gaps.push('Add your full name');
            if (!p.occupation) gaps.push('Add target job title / headline');
            if (!p.phone) gaps.push('Add phone number');
            if (!p.city && !p.country) gaps.push('Add location (city or country)');
            return gaps;
        },
        atsTips: [
            'Include target role in your headline / title',
            'Use standard international phone format (+1 / +44 etc.)',
            'Ensure contact email matches your professional profile'
        ]
    },
    experience: {
        id: 'experience',
        name: 'Work History',
        title: 'Work History & Experience',
        subtitle: 'Your career trajectory, key roles, responsibilities, and quantified achievements.',
        statusBadge: (p) => `${p.workExperiences?.length || 0} Roles`,
        getCount: (p) => p.workExperiences?.length || 0,
        isComplete: (p) => Boolean(p.workExperiences?.length > 0),
        computeGaps: (p) => {
            if (!p.workExperiences?.length) return ['Add at least one relevant work position', 'Include job title and company name'];
            const gaps = [];
            if (p.workExperiences.some(w => !w.responsibilities?.length && !w.summary)) {
                gaps.push('Add bullet points or description for all roles');
            }
            return gaps;
        },
        atsTips: [
            'Lead bullet points with active verbs like Spearheaded, Engineered, Directed',
            'Quantify impact with metrics (revenue, % gains, team size)',
            'Keep roles ordered in reverse chronological order'
        ]
    },
    education: {
        id: 'education',
        name: 'Education',
        title: 'Education & Academic History',
        subtitle: 'Degrees, diplomas, educational institutions, graduation years, and honors.',
        statusBadge: (p) => `${p.education?.length || 0} Degrees`,
        getCount: (p) => p.education?.length || 0,
        isComplete: (p) => Boolean(p.education?.length > 0),
        computeGaps: (p) => {
            if (!p.education?.length) return ['Add at least one educational qualification', 'Specify school name and degree'];
            return [];
        },
        atsTips: [
            'Spell out degree names e.g. Bachelor of Science',
            'Include graduation year or expected completion date',
            'Highlight academic honors or GPA if 3.5+'
        ]
    },
    skills: {
        id: 'skills',
        name: 'Skills',
        title: 'Core Competencies & Skills',
        subtitle: 'Hard skills, frameworks, tools, and soft competencies parsed by ATS screening engines.',
        statusBadge: (p) => `${p.skills?.length || 0} Skills`,
        getCount: (p) => p.skills?.length || 0,
        isComplete: (p) => Boolean(p.skills?.length >= 3),
        computeGaps: (p) => {
            if (!p.skills?.length) return ['Add at least 3-5 technical or core skills'];
            if (p.skills.length < 3) return ['Add at least 3 skills for keyword matching'];
            return [];
        },
        atsTips: [
            'Match skill keywords directly to target job descriptions',
            'Include both industry tools and foundational methodologies',
            'Keep skills specific (e.g. React.js rather than just Web)'
        ]
    },
    certifications: {
        id: 'certifications',
        name: 'Certifications',
        title: 'Certifications & Licenses',
        subtitle: 'Industry credentials, verified licenses, and professional certifications.',
        statusBadge: (p) => `${p.certifications?.length || 0} Credentials`,
        getCount: (p) => p.certifications?.length || 0,
        isComplete: (p) => Boolean(p.certifications?.length > 0),
        computeGaps: (p) => {
            if (!p.certifications?.length) return ['Add accredited licenses or certifications (optional)'];
            return [];
        },
        atsTips: [
            'Include the issuing authority (e.g. AWS, Microsoft, PMI)',
            'Specify credential ID or verification link if available',
            'Ensure active certifications have accurate renewal years'
        ]
    },
    projects: {
        id: 'projects',
        name: 'Projects',
        title: 'Key Projects & Portfolio',
        subtitle: 'Standout initiatives, open-source work, client deliveries, and measurable outcomes.',
        statusBadge: (p) => `${p.projects?.length || 0} Projects`,
        getCount: (p) => p.projects?.length || 0,
        isComplete: (p) => Boolean(p.projects?.length > 0),
        computeGaps: (p) => {
            if (!p.projects?.length) return ['Add prominent projects showcasing hands-on experience'];
            return [];
        },
        atsTips: [
            'State the objective, your role, and key technologies used',
            'Link to live deployment or source repository',
            'Demonstrate problem-solving and measurable results'
        ]
    },
    languages: {
        id: 'languages',
        name: 'Languages',
        title: 'Languages & Proficiency',
        subtitle: 'Spoken, written, and working languages with standardized proficiency levels.',
        statusBadge: (p) => `${p.languages?.length || 0} Languages`,
        getCount: (p) => p.languages?.length || 0,
        isComplete: (p) => Boolean(p.languages?.length > 0),
        computeGaps: (p) => {
            if (!p.languages?.length) return ['Specify at least your primary working language'];
            return [];
        },
        atsTips: [
            'Specify proficiency accurately (Native, Fluent, Professional)',
            'List multilingual proficiencies beneficial for global roles'
        ]
    },
    hobbies: {
        id: 'hobbies',
        name: 'Hobbies',
        title: 'Interests & Activities',
        subtitle: 'Extracurricular pursuits, community engagement, and personal interests.',
        statusBadge: (p) => `${(p.hobbies || []).length} Hobbies`,
        getCount: (p) => (p.hobbies || []).length,
        isComplete: (p) => Boolean((p.hobbies || []).length > 0),
        computeGaps: (p) => {
            if (!(p.hobbies || []).length) return ['Add interests that reflect leadership or teamwork'];
            return [];
        },
        atsTips: [
            'Highlight community initiatives or athletic pursuits',
            'Demonstrate well-rounded character and cultural fit'
        ]
    },
    summary: {
        id: 'summary',
        name: 'Executive Bio',
        title: 'Executive Bio & Professional Summary',
        subtitle: 'Your synthesized 3-4 sentence elevator pitch, generated from your complete work history, education, skills, and projects above.',
        statusBadge: (p) => stripHtml(p.summary).length >= 20 ? 'Active' : 'Missing',
        getCount: (p) => (stripHtml(p.summary).length >= 20 ? '✓' : undefined),
        isComplete: (p) => Boolean(p.summary && stripHtml(p.summary).length >= 20),
        computeGaps: (p) => {
            if (!p.summary || stripHtml(p.summary).length < 20) return ['Write a 2-4 sentence summary of your career focus and unique strengths'];
            return [];
        },
        atsTips: [
            'Open with target job title and total years of experience',
            'Highlight top 2-3 core strengths and greatest career win',
            'Avoid generic filler like hardworking or fast learner'
        ]
    },
    achievements: {
        id: 'achievements',
        name: 'Honors & Awards',
        title: 'Honors, Awards & Key Achievements',
        subtitle: 'Competitive awards, hackathons, academic distinctions, and recognitions.',
        statusBadge: (p) => `${(p.achievements || []).length} Awards`,
        getCount: (p) => (p.achievements || []).length,
        isComplete: (p) => Boolean((p.achievements || []).length > 0),
        computeGaps: (p) => {
            if (!(p.achievements || []).length) return ['Add notable awards or competitive distinctions (optional)'];
            return [];
        },
        atsTips: [
            'Include conferring organization and award year',
            'Explain competition scope or percentage selection rate'
        ]
    },
    references: {
        id: 'references',
        name: 'References',
        title: 'Professional References',
        subtitle: 'Endorsements and reference contacts from former managers, mentors, or colleagues.',
        statusBadge: (p) => `${(p.references || []).length} References`,
        getCount: (p) => (p.references || []).length,
        isComplete: (p) => Boolean((p.references || []).length > 0),
        computeGaps: (p) => {
            if (!(p.references || []).length) return ['Add reference contacts or indicate "Available upon request"'];
            return [];
        },
        atsTips: [
            'Confirm referee contact permission in advance',
            'Provide professional title and company association'
        ]
    },
    customSections: {
        id: 'customSections',
        name: 'Custom Modules',
        title: 'Custom Modules & Additional Sections',
        subtitle: 'Tailored sections such as publications, patents, security clearances, or speaking.',
        statusBadge: (p) => `${(p.customSections || []).length} Custom`,
        getCount: (p) => (p.customSections || []).length,
        isComplete: (p) => Boolean((p.customSections || []).length > 0),
        computeGaps: () => [],
        atsTips: [
            'Use standard, widely understood category titles',
            'Format entries consistently with work experience'
        ]
    }
};

function DashboardSettings(_props) {
    const { i18n } = useTranslation('common');
    const location = useLocation();
    const navigate = useNavigate();

    // State management
    const [selectedSettings, setSelectedSettings] = useState('Profile');
    const [profileSubTab, setProfileSubTab] = useState('basic');
    const [showProfileGuidanceRail, setShowProfileGuidanceRail] = useState(true);
    const subTabsRef = useRef(null);
    const [showStepsDropdown, setShowStepsDropdown] = useState(false);
    const stepsDropdownRef = useRef(null);

    // Close steps dropdown when clicking outside or pressing Escape
    useEffect(() => {
        const handleClickOutside = (e) => {
            if (stepsDropdownRef.current && !stepsDropdownRef.current.contains(e.target)) {
                setShowStepsDropdown(false);
            }
        };
        const handleKeyDown = (e) => {
            if (e.key === 'Escape') setShowStepsDropdown(false);
        };
        if (showStepsDropdown) {
            document.addEventListener('mousedown', handleClickOutside);
            document.addEventListener('keydown', handleKeyDown);
        }
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [showStepsDropdown]);

    const scrollSubTabs = (direction) => {
        if (subTabsRef.current) {
            const offset = direction === 'left' ? -220 : 220;
            subTabsRef.current.scrollBy({ left: offset, behavior: 'smooth' });
        }
    };

    useEffect(() => {
        if (subTabsRef.current) {
            const activeBtn = subTabsRef.current.querySelector('.step-nav-btn[aria-current="step"]');
            if (activeBtn) {
                activeBtn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
            }
        }
    }, [profileSubTab]);

    const SUB_TAB_ORDER = ['basic', 'experience', 'education', 'skills', 'certifications', 'projects', 'languages', 'hobbies', 'achievements', 'references', 'customSections', 'summary'];

    // Seamless Subtab Switching with URL Deep-Linking
    const switchProfileSubTab = (tabKey) => {
        if (!SUB_TAB_ORDER.includes(tabKey)) return;
        setProfileSubTab(tabKey);
        navigate(`?tab=Profile&subtab=${tabKey}`, { replace: true });
    };

    // Stepper Keyboard Navigation (ArrowLeft / ArrowRight)
    const handleStepperKeyDown = (e) => {
        const currentIdx = SUB_TAB_ORDER.indexOf(profileSubTab);
        if (e.key === 'ArrowRight' && currentIdx < SUB_TAB_ORDER.length - 1) {
            e.preventDefault();
            switchProfileSubTab(SUB_TAB_ORDER[currentIdx + 1]);
        } else if (e.key === 'ArrowLeft' && currentIdx > 0) {
            e.preventDefault();
            switchProfileSubTab(SUB_TAB_ORDER[currentIdx - 1]);
        }
    };

    // Interactive Copilot Gap Focusing Helper
    const handleFocusGap = (gapText) => {
        const lower = String(gapText || '').toLowerCase();
        let targetSelector = null;

        if (lower.includes('name')) targetSelector = 'input[name="firstname"], input[name="lastname"]';
        else if (lower.includes('job title') || lower.includes('headline')) targetSelector = 'input[name="occupation"]';
        else if (lower.includes('phone')) targetSelector = 'input[name="phone"]';
        else if (lower.includes('location') || lower.includes('city') || lower.includes('country')) targetSelector = 'input[name="city"], input[name="country"]';
        else if (lower.includes('summary') || lower.includes('bio')) targetSelector = 'textarea[name="summary"]';
        else if (lower.includes('work position') || lower.includes('role')) targetSelector = 'button:has-text("Add Position"), input[name="jobTitle"]';
        else if (lower.includes('education') || lower.includes('degree')) targetSelector = 'input[name="school"], input[name="degree"]';
        else if (lower.includes('skill')) targetSelector = 'input[placeholder*="skill" i], input[placeholder*="Search" i]';
        else if (lower.includes('project')) targetSelector = 'input[name="title"], input[placeholder*="Project" i]';
        else if (lower.includes('language')) targetSelector = 'input[placeholder*="Language" i], input[name="language"]';

        if (targetSelector) {
            try {
                const el = document.querySelector(targetSelector);
                if (el) {
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    el.focus();
                    el.classList.add('ring-2', 'ring-[var(--cuba-primary-ring)]');
                    setTimeout(() => el.classList.remove('ring-2', 'ring-[var(--cuba-primary-ring)]'), 2000);
                }
            } catch {
                // Ignore selector parsing nuances
            }
        }
    };

    // Reactive URL query parameter listener for ?tab=Account, ?tab=Profile, and ?subtab=...
    const pendingScrollRef = useRef(null);
    useEffect(() => {
        const searchParams = new URLSearchParams(location.search);
        const tabParam = searchParams.get('tab');
        const subTabParam = searchParams.get('subtab') || searchParams.get('section') || searchParams.get('step');
        if (tabParam) {
            const lower = tabParam.toLowerCase();
            if (lower.includes('account') || lower.includes('security') || lower === '2fa') {
                setSelectedSettings('Account');
                // DIR-074: a deep link to Security / 2FA must land ON the TOTP
                // card, not merely open the Account pane.
                pendingScrollRef.current = (lower.includes('security') || lower === '2fa') ? 'totp-security-hub' : null;
            } else if (lower.includes('profile')) {
                setSelectedSettings('Profile');
                pendingScrollRef.current = null;
            }
        }
        if (subTabParam) {
            const matched = SUB_TAB_ORDER.find(k => k.toLowerCase() === subTabParam.toLowerCase());
            if (matched) {
                setProfileSubTab(matched);
            }
        }
    }, [location.search]);

    // DIR-074: honour a pending deep-link scroll once the Account pane has
    // rendered. A short defer lets the pane mount before we scroll to its card.
    useEffect(() => {
        const targetId = pendingScrollRef.current;
        if (!targetId || selectedSettings !== 'Account') return undefined;
        pendingScrollRef.current = null;
        const timer = setTimeout(() => {
            const el = document.getElementById(targetId);
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 120);
        return () => clearTimeout(timer);
    }, [selectedSettings, location.search]);
    const [summaryTone, setSummaryTone] = useState('balanced');
    const [summaryAiDraft, setSummaryAiDraft] = useState(null);
    const [bioCopied, setBioCopied] = useState(false);
    const [showClearBioConfirm, setShowClearBioConfirm] = useState(false);
    const [_skillFilter] = useState('all');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [profileSaveState, setProfileSaveState] = useState('loading');
    // DIR-089: the account-details load previously only logged to the console, so a failed
    // fetch left the page silently half-empty. This drives a real, dismissible alert region.
    const [accountLoadError, setAccountLoadError] = useState(null);
    const [profileConflict, setProfileConflict] = useState(null);
    const persistProfileRef = useRef(null);
    const profileRef = useRef(null);
    const profileConflictRef = useRef(null);
    const profileSavingRef = useRef(null);
    const pendingProfileSaveRef = useRef(null);
    const skipNextAutosaveRef = useRef(false);
    const autosaveTimerRef = useRef(null);
    const loadedProfileUidRef = useRef(null);
    const mountedRef = useRef(true);
    const [isAiGenerating, setIsAiGenerating] = useState(false);
    const aiRequestControllerRef = useRef(null);
    const [toastState, setToastState] = useState(null);
    const [cropModalSrc, setCropModalSrc] = useState(null); // raw image src waiting to be cropped
    const [aiModalState, setAiModalState] = useState({
        isOpen: false,
        title: '',
        type: 'skills',
        items: [],
        onApply: null
    });
    const [projectSearchQuery, setProjectSearchQuery] = useState('');
    const [projectTypeFilter, setProjectTypeFilter] = useState('all');
    const [certSearchQuery, setCertSearchQuery] = useState('');
    const [certTypeFilter, setCertTypeFilter] = useState('all');
    const [achievementSearchQuery, setAchievementSearchQuery] = useState('');
    const [achievementTypeFilter, setAchievementTypeFilter] = useState('all');
    const [isPolishingAchIndex, setIsPolishingAchIndex] = useState(null);

    const [accountSettings, setAccountSettings] = useState({
        email: '',
        password: '',
    });
    const [databaseAccountSettings, setDatabaseAccountSettings] = useState({
        email: '',
        membership: '',
        membershipEnds: '',
    });
    const [accountPasswordState, setAccountPasswordState] = useState({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
    });
    const [showPasswordMap, setShowPasswordMap] = useState({
        current: false,
        new: false,
        confirm: false,
    });
    const [deleteAccountModalOpen, setDeleteAccountModalOpen] = useState(false);
    const [deleteInputText, setDeleteInputText] = useState('');
    const [deletePassword, setDeletePassword] = useState('');
    const [_userTransactions, setUserTransactions] = useState([]);
    const [preferences, setPreferences] = useState({ language: 'en', emailNotifications: true, securityNotifications: true, productUpdates: false, profileDiscoverable: false, revision: 0 });
    const [savingPreferences, setSavingPreferences] = useState(false);
    const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);

    // TOTP 2FA State Management
    const [totpStatus, setTotpStatus] = useState({ enabled: false, secret: null, backupCodes: [] });
    const [totpSetupModalOpen, setTotpSetupModalOpen] = useState(false);
    const [totpSetupStep, setTotpSetupStep] = useState(1);
    const [totpSetupSecret, setTotpSetupSecret] = useState('');
    const [totpEnrollmentSecret, setTotpEnrollmentSecret] = useState(null);
    const [totpQrCodeDataUrl, setTotpQrCodeDataUrl] = useState('');
    const [totpVerificationCode, setTotpVerificationCode] = useState('');
    const [totpDisableModalOpen, setTotpDisableModalOpen] = useState(false);
    const [totpDisablePassword, setTotpDisablePassword] = useState('');
    const [loginHistory, setLoginHistory] = useState([]);
    const userAuthProviders = (fire.auth().currentUser?.providerData || []).map(provider => provider?.providerId).filter(Boolean);
    const usesPasswordProvider = userAuthProviders.includes('password');
    const isOAuthOnly = userAuthProviders.length > 0 && !usesPasswordProvider;
    void isOAuthOnly;
    const primaryOAuthProvider = userAuthProviders.find(p => p !== 'password') === 'google.com' ? 'Google' : (userAuthProviders.find(p => p !== 'password') || 'OAuth');

    // Master Profile State matching ALL Resume & Cover Letter fields
    const [profile, setProfile] = useState({
        firstname: '',
        lastname: '',
        name: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        postalCode: '',
        country: '',
        occupation: '',
        linkedinUrl: '',
        githubUrl: '',
        websiteUrl: '',
        summary: '',
        selectedImage: null,
        workExperiences: [],
        education: [],
        skills: [],
        languages: [],
        hobbies: [],
        certifications: [],
        projects: [],
        achievements: [],
        references: [],
        customSections: [],
        revision: 0,
    });

    const candidateContext = React.useMemo(() => ({
        target: { role: profile.occupation || profile.workExperiences?.[0]?.jobTitle || '' },
        facts: {
            headline: profile.occupation || '',
            roles: profile.workExperiences || [],
            education: profile.education || [],
            skills: (profile.skills || []).map(s => typeof s === 'string' ? s : s?.name || s?.skillName || ''),
            certifications: profile.certifications || []
        }
    }), [profile.occupation, profile.workExperiences, profile.education, profile.skills, profile.certifications]);

    const [isDragging, setIsDragging] = useState(false);

    // Toast Notification helper
    const triggerNotification = (msg, type = 'success') => {
        setToastState({ msg, type });
        setTimeout(() => setToastState(null), 5000);
    };

    // Global Escape Key Listener for dismissible modal dialogs
    useEffect(() => {
        const handleGlobalEscape = (e) => {
            if (e.key === 'Escape') {
                if (deleteAccountModalOpen && !isSubmitting) setDeleteAccountModalOpen(false);
                if (totpSetupModalOpen && !isSubmitting) setTotpSetupModalOpen(false);
                if (totpDisableModalOpen && !isSubmitting) setTotpDisableModalOpen(false);
                if (cropModalSrc) setCropModalSrc(null);
                if (isSubscriptionModalOpen) setIsSubscriptionModalOpen(false);
            }
        };
        window.addEventListener('keydown', handleGlobalEscape);
        return () => window.removeEventListener('keydown', handleGlobalEscape);
    }, [deleteAccountModalOpen, totpSetupModalOpen, totpDisableModalOpen, cropModalSrc, isSubscriptionModalOpen, isSubmitting]);

    // Data normalizers for historical profile shapes
    const normalizeSkills = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (typeof item === 'string') return { id: `skill_${idx}_${Date.now()}`, name: item, level: '' };
            if (item && typeof item === 'object') return { id: item.id || `skill_${idx}`, name: item.name || item.title || '', level: item.level || '' };
            return { id: `skill_${idx}`, name: String(item || ''), level: '' };
        });
    };

    const normalizeLanguages = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (typeof item === 'string') return { id: `lang_${idx}_${Date.now()}`, name: item, level: '' };
            if (item && typeof item === 'object') return { id: item.id || `lang_${idx}`, name: item.name || item.language || '', level: item.level || item.proficiency || '' };
            return { id: `lang_${idx}`, name: String(item || ''), level: '' };
        });
    };

    const normalizeHobbies = (arr) => {
        if (!Array.isArray(arr)) {
            if (typeof arr === 'string' && arr.trim()) return [arr.trim()];
            return [];
        }
        return arr.map(item => {
            if (typeof item === 'string') return item;
            if (item && typeof item === 'object') return item.name || item.hobby || item.title || item.interest || '';
            return String(item || '');
        }).filter(Boolean);
    };

    const normalizeCertifications = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (typeof item === 'string') return { id: `cert_${idx}_${Date.now()}`, title: item, issuer: '', date: '', endDate: '', credentialId: '', url: '', certType: 'Certification', isLicense: false };
            if (item && typeof item === 'object') return {
                id: item.id || `cert_${idx}`,
                title: item.title || item.name || '',
                issuer: item.issuer || item.authority || '',
                date: item.date || item.year || '',
                endDate: item.endDate || item.expirationDate || '',
                credentialId: item.credentialId || item.idNumber || item.licenseNumber || '',
                url: item.url || item.verificationUrl || item.link || '',
                certType: item.certType || (item.isLicense ? 'License' : 'Certification'),
                isLicense: Boolean(item.isLicense || item.certType === 'License'),
            };
            return { id: `cert_${idx}`, title: String(item || ''), issuer: '', date: '', endDate: '', credentialId: '', url: '', certType: 'Certification', isLicense: false };
        });
    };

    const normalizeWorkExperiences = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (!item || typeof item !== 'object') return { id: `work_${idx}`, jobTitle: '', company: '', city: '', startDate: '', endDate: '', description: '' };
            return {
                id: item.id || `work_${idx}`,
                jobTitle: String(item.jobTitle || item.title || item.position || ''),
                company: String(item.company || item.employer || ''),
                city: String(item.city || item.location || ''),
                startDate: String(item.startDate || item.begin || ''),
                endDate: String(item.endDate || item.end || ''),
                description: String(item.description || item.summary || item.details || '')
            };
        });
    };

    const normalizeEducation = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (!item || typeof item !== 'object') return { id: `edu_${idx}`, degree: '', school: '', city: '', startDate: '', endDate: '', description: '' };
            return {
                id: item.id || `edu_${idx}`,
                degree: String(item.degree || item.qualification || ''),
                school: String(item.school || item.institution || item.university || ''),
                city: String(item.city || item.location || ''),
                startDate: String(item.startDate || item.year || ''),
                endDate: String(item.endDate || ''),
                description: String(item.description || item.summary || '')
            };
        });
    };

    const normalizeProjects = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (!item || typeof item !== 'object') return { id: `proj_${idx}`, title: '', role: '', technologies: '', link: '', url: '', projectType: 'personal', description: '' };
            const linkUrl = String(item.url || item.link || '');
            return {
                id: item.id || `proj_${idx}`,
                title: String(item.title || item.name || ''),
                role: String(item.role || ''),
                technologies: String(item.technologies || item.techStack || item.tools || ''),
                link: linkUrl,
                url: linkUrl,
                projectType: item.projectType || 'personal',
                description: String(item.description || item.summary || '')
            };
        });
    };

    const normalizeAchievements = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (!item || typeof item !== 'object') return { id: `ach_${idx}`, title: '', issuer: '', date: '', description: '', achievementType: 'Award' };
            return {
                id: item.id || `ach_${idx}`,
                title: String(item.title || item.name || ''),
                issuer: String(item.issuer || item.awarder || item.organization || ''),
                date: String(item.date || item.year || ''),
                description: String(item.description || item.summary || ''),
                achievementType: String(item.achievementType || item.type || 'Award')
            };
        });
    };

    const normalizeReferences = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (!item || typeof item !== 'object') return { id: `ref_${idx}`, name: '', position: '', company: '', email: '', phone: '', reference: '' };
            return {
                id: item.id || `ref_${idx}`,
                name: String(item.name || item.title || ''),
                position: String(item.position || ''),
                company: String(item.company || item.organization || ''),
                email: String(item.email || ''),
                phone: String(item.phone || ''),
                reference: String(item.reference || item.description || '')
            };
        });
    };

    const normalizeCustomSections = (arr) => {
        if (!Array.isArray(arr)) return [];
        return arr.map((item, idx) => {
            if (!item || typeof item !== 'object') return { id: `custom_${idx}`, title: '', content: '', items: [] };
            const rawItems = Array.isArray(item.items) ? item.items : [];
            const items = rawItems.map((sub, sIdx) => {
                if (typeof sub === 'string') return { id: `custom_${idx}_item_${sIdx}`, title: sub, description: '' };
                if (sub && typeof sub === 'object') return { id: sub.id || `custom_${idx}_item_${sIdx}`, title: sub.title || sub.name || '', description: sub.description || sub.content || '' };
                return null;
            }).filter(Boolean);
            return {
                id: item.id || `custom_${idx}`,
                title: String(item.title || item.heading || ''),
                content: String(item.content || ''),
                items
            };
        });
    };

    // Load User Profile Data
    const getProfileOfUserFront = async () => {
        const currentUser = fire.auth().currentUser;
        if (currentUser) {
            try {
                const userProfile = await getProfileOfUser(currentUser.uid);
                const profileData = userProfile || {};
                const parts = (profileData.name || currentUser.displayName || '').split(' ');
                skipNextAutosaveRef.current = true;
                setProfile({
                    firstname: profileData.firstname || parts[0] || '',
                    lastname: profileData.lastname || parts.slice(1).join(' ') || '',
                    name: profileData.name || currentUser.displayName || '',
                    email: currentUser.email || profileData.email || '',
                    phone: profileData.phone || '',
                    address: profileData.address || '',
                    city: profileData.city || '',
                    postalCode: profileData.postalCode || profileData.postalcode || '',
                    country: profileData.country || '',
                    occupation: profileData.occupation || '',
                    linkedinUrl: profileData.linkedinUrl || '',
                    githubUrl: profileData.githubUrl || '',
                    websiteUrl: profileData.websiteUrl || '',
                    summary: htmlToPlainText(profileData.summary || ''),
                    selectedImage: profileData.selectedImage || profileData.image || null,
                    isLinkedinConnected: !!(profileData.isLinkedinConnected || profileData.linkedinUrl),
                    linkedinConnectedName: profileData.linkedinConnectedName || profileData.name || '',
                    workExperiences: normalizeWorkExperiences(profileData.workExperiences),
                    education: normalizeEducation(profileData.education),
                    skills: normalizeSkills(profileData.skills),
                    languages: normalizeLanguages(profileData.languages),
                    hobbies: normalizeHobbies(profileData.hobbies || profileData.interests),
                    certifications: normalizeCertifications(profileData.certifications),
                    projects: normalizeProjects(profileData.projects),
                    achievements: normalizeAchievements(profileData.achievements || profileData.awards),
                    references: normalizeReferences(profileData.references),
                    customSections: normalizeCustomSections(profileData.customSections),
                    revision: Number(profileData.revision) || 0,
                });
                setProfileSaveState('saved');
            } catch (err) {
                console.error('[ProfileLoadError]', err);
                setProfileSaveState('saved');
            }
        }
    };

    const getAccountInfoFront = async () => {
        const fetchUserAccountData = async () => {
            const currentUser = fire.auth().currentUser;
            if (currentUser) {
                try {
                    const accInfo = await getAccountInfo(currentUser.uid);
                    if (accInfo) {
                        setDatabaseAccountSettings({
                            email: accInfo.email || currentUser.email || '',
                            membership: accInfo.membership || 'Basic',
                            membershipEnds: accInfo.membershipEnds || '',
                        });
                        setPreferences(current => ({ ...current, ...(accInfo.preferences || {}), revision: Number(accInfo.preferences?.revision || 0) }));
                    }
                    const txns = await getUserTransactions(currentUser.uid);
                    setUserTransactions(txns);
                    const totpInfo = await getUserTotpStatus(currentUser.uid);
                    if (totpInfo) setTotpStatus(totpInfo);
                    if (!sessionStorage.getItem('audit_logged_' + currentUser.uid)) {
                        await recordUserLoginEvent(currentUser.uid);
                        sessionStorage.setItem('audit_logged_' + currentUser.uid, 'true');
                    }
                    const logs = await getUserLoginHistory(currentUser.uid);
                    setLoginHistory(logs);
                    // DIR-089: a clean load clears any previous failure banner.
                    setAccountLoadError(null);
                } catch (err) {
                    console.error('Error loading user account info:', err);
                    // DIR-089: surface the failure instead of leaving the hub silently empty.
                    if (mountedRef?.current !== false) {
                        setAccountLoadError('We could not load your account details. Transactions, login history and security status may be incomplete.');
                    }
                }
            }
        };
        fetchUserAccountData();
    };


    useEffect(() => {
        const unsubscribe = fire.auth().onAuthStateChanged(async currentUser => {
            if (!currentUser) { loadedProfileUidRef.current = null; navigate('/'); return; }
            if (loadedProfileUidRef.current && loadedProfileUidRef.current !== currentUser.uid) {
                setProfile(current => ({ ...current, firstname: '', lastname: '', name: '', email: '', phone: '', address: '', city: '', postalCode: '', country: '', occupation: '', linkedinUrl: '', githubUrl: '', websiteUrl: '', summary: '', selectedImage: null, workExperiences: [], education: [], skills: [], languages: [], hobbies: [], certifications: [], projects: [], achievements: [], references: [], customSections: [], revision: 0 }));
                setUserTransactions([]); setLoginHistory([]); setPreferences({ language: 'en', emailNotifications: true, securityNotifications: true, productUpdates: false, profileDiscoverable: false, revision: 0 }); setProfileConflict(null); setProfileSaveState('loading');
            }
            loadedProfileUidRef.current = currentUser.uid;
            await Promise.all([getProfileOfUserFront(), getAccountInfoFront()]);
        });
        return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [navigate]);

    const handleInputChange = (e) => {
        const field = e.target.name;
        const value = e.target.value;
        setProfile((prev) => {
            const updated = { ...prev, [field]: value };
            if (field === 'firstname' || field === 'lastname') {
                updated.name = `${updated.firstname || ''} ${updated.lastname || ''}`.trim();
            }
            if (field === 'city' && value) {
                const inferredCountry = inferCountryFromCity(value);
                if (inferredCountry) {
                    updated.country = inferredCountry;
                }
            }
            return updated;
        });
    };


    useEffect(() => { profileRef.current = profile; }, [profile]);
    useEffect(() => { profileConflictRef.current = profileConflict; }, [profileConflict]);
    useEffect(() => () => { mountedRef.current = false; }, []);

    const persistProfile = ({ profile: profileSnapshot, expectedRevision, notify = false } = {}) => new Promise((resolve, reject) => {
        if (profileSavingRef.current) {
            pendingProfileSaveRef.current = {
                waiters: [...(pendingProfileSaveRef.current?.waiters || []), profileSavingRef.current, { resolve, reject }],
                notify: pendingProfileSaveRef.current?.notify || notify,
            };
            return;
        }
        profileSavingRef.current = { resolve, reject, notify };
        setProfileSaveState('saving');
        (async () => {
            let waiter;
            try {
                while (true) {
                    const currentUser = fire.auth().currentUser;
                    if (!mountedRef.current) throw Object.assign(new Error('Profile save cancelled.'), { code: 'PROFILE_SAVE_CANCELLED' });
                    if (!currentUser) throw new Error('Sign in again before saving your profile.');
                    if (profileConflictRef.current) throw new Error('Resolve the newer profile revision before saving.');

                    const snapshot = profileSnapshot || profileRef.current;
                    const baseRevision = Number.isSafeInteger(Number(expectedRevision))
                        ? Number(expectedRevision)
                        : (Number.isSafeInteger(Number(snapshot?.revision)) ? Number(snapshot.revision) : 0);
                    const profileToSave = normalizeProfileForSave(snapshot);
                    const result = await saveProfile(currentUser.uid, profileToSave, baseRevision);
                    if (!mountedRef.current) throw Object.assign(new Error('Profile save cancelled.'), { code: 'PROFILE_SAVE_CANCELLED' });
                    if (!result.success) throw Object.assign(new Error(result.error || 'Profile save failed.'), { code: result.code, remoteRevision: result.remoteRevision });

                    const stripRev = p => {
                        const n = normalizeProfileForSave(p);
                        delete n.revision;
                        return n;
                    };
                    const latestProfile = profileRef.current;
                    const needsFollowUp = latestProfile.revision === snapshot.revision
                        && JSON.stringify(stripRev(latestProfile)) !== JSON.stringify(stripRev(result.profile));

                    skipNextAutosaveRef.current = true;
                    profileRef.current = { ...profileRef.current, revision: result.revision };
                    setProfile(current => ({ ...current, revision: result.revision }));
                    setProfileSaveState('saved');
                    window.dispatchEvent(new CustomEvent('profileUpdated', { detail: result.profile }));
                    if (notify) triggerNotification('Master Profile saved successfully.');
                    waiter = profileSavingRef.current;

                    if (pendingProfileSaveRef.current || needsFollowUp) {
                        const pending = pendingProfileSaveRef.current;
                        pendingProfileSaveRef.current = needsFollowUp ? { waiters: [], notify: false } : null;
                        profileSnapshot = null;
                        expectedRevision = result.revision;
                        notify = pending?.notify || false;
                        pending?.waiters.forEach(item => item.resolve(result));
                        continue;
                    }
                    waiter.resolve(result);
                    break;
                }
            } catch (error) {
                const pending = pendingProfileSaveRef.current;
                pendingProfileSaveRef.current = null;
                if (error.code === 'PROFILE_CONFLICT') setProfileConflict({ remoteRevision: error.remoteRevision });
                if (mountedRef.current) setProfileSaveState(error.code === 'PROFILE_CONFLICT' ? 'conflict' : 'failed');
                waiter?.reject(error);
                pending?.waiters.forEach(item => item.reject(error));
            } finally {
                profileSavingRef.current = null;
            }
        })();
    });
    persistProfileRef.current = (options = {}) => persistProfile(options);
    const reloadProfileConflict = async () => { setProfileConflict(null); setProfileSaveState('loading'); await getProfileOfUserFront(); triggerNotification('Latest profile loaded.'); };
    const overwriteProfileConflict = () => { setProfile(current => ({ ...current, revision: profileConflict.remoteRevision })); setProfileConflict(null); setProfileSaveState('pending'); triggerNotification('Conflict acknowledged. Your local profile will save as the next revision.'); };

    const handleSubmit = async (e) => {
        e?.preventDefault?.();
        if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);
        setIsSubmitting(true);
        try { await persistProfile({ notify: true }); return true; }
        catch (error) { triggerNotification(error.message || 'Failed to save profile.', 'error'); return false; }
        finally { setIsSubmitting(false); }
    };

    const handleSaveAndNext = async () => {
        const saved = await handleSubmit();
        if (!saved) return;
        const currentIdx = SUB_TAB_ORDER.indexOf(profileSubTab);
        const nextTab = SUB_TAB_ORDER[currentIdx + 1];
        if (nextTab) {
            switchProfileSubTab(nextTab);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };

    const handleAccountSubmit = async (e) => {
        if (e) e.preventDefault();
        setIsSubmitting(true);
        try {
            let updatedSomething = false;

            // Check what changed
            const isEmailChanged = databaseAccountSettings.email && databaseAccountSettings.email !== (fire.auth().currentUser?.email || '');
            const isPasswordChanged = !!accountPasswordState.newPassword;

            // Only require current password if user has a traditional password provider
            if (usesPasswordProvider && (isEmailChanged || isPasswordChanged) && !accountPasswordState.currentPassword) {
                triggerNotification('Current password is required to verify identity for credential updates.', 'error');
                setIsSubmitting(false);
                return;
            }

            // 1. Email update
            if (isEmailChanged) {
                await updateUserEmail(usesPasswordProvider ? accountPasswordState.currentPassword : '', databaseAccountSettings.email);
                updatedSomething = true;
            }

            // 2. Password update / creation
            if (isPasswordChanged) {
                if (accountPasswordState.newPassword.length < 8) {
                    triggerNotification('Security password must be at least 8 characters long.', 'error');
                    setIsSubmitting(false);
                    return;
                }
                if (accountPasswordState.newPassword !== accountPasswordState.confirmPassword) {
                    triggerNotification('New passwords do not match. Please verify.', 'error');
                    setIsSubmitting(false);
                    return;
                }
                await changePassword(usesPasswordProvider ? accountPasswordState.currentPassword : '', accountPasswordState.newPassword);
                updatedSomething = true;
                setAccountPasswordState({ currentPassword: '', newPassword: '', confirmPassword: '' });
            }

            if (updatedSomething) {
                triggerNotification(
                    usesPasswordProvider
                        ? 'Account security credentials updated successfully!'
                        : 'Account security password created successfully! You can now sign in using either email & password or OAuth.'
                );
            } else {
                triggerNotification('No changes detected in account credentials.');
            }
        } catch (err) {
            console.error('Account Security Update Error:', err);
            let msg = err.message || 'Failed to update account security credentials.';
            if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
                msg = 'Incorrect Current Password. Authentication failed.';
            } else if (err.code === 'auth/requires-recent-login') {
                msg = 'For security, please sign out and sign in again before updating credentials.';
            }
            triggerNotification(msg, 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    const handlePreferencesSave = async () => {
        const user = fire.auth().currentUser;
        if (!user) return;
        setSavingPreferences(true);
        const result = await saveUserPreferences(user.uid, preferences, preferences.revision);
        if (result.success) {
            setPreferences(result.preferences);
            if (result.preferences.language && result.preferences.language !== i18n.language) await i18n.changeLanguage(result.preferences.language);
            triggerNotification('Preferences saved successfully.');
        } else triggerNotification(result.error || 'Unable to save preferences.', 'error');
        setSavingPreferences(false);
    };

    const handleSendVerificationEmail = async () => {
        const user = fire.auth().currentUser;
        if (user && user.email) {
            try {
                const response = await fetch('/api/auth/send-verification-email', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        email: user.email,
                        userName: user.displayName || user.email.split('@')[0]
                    })
                });
                if (!response.ok) throw new Error('Verification email request failed.');
                triggerNotification('Verification link sent to ' + user.email + '.');
            } catch (err) {
                triggerNotification(err.message || 'Failed to send verification email.', 'error');
            }
        }
    };

    const handleExportUserData = async () => {
        try {
            setIsSubmitting(true);
            const data = await exportUserDataJSON();
            const jsonStr = JSON.stringify(data, null, 2);
            const blob = new Blob([jsonStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `user_data_export_${data.userId || 'account'}_${Date.now()}.json`;
            a.click();
            URL.revokeObjectURL(url);
            const warningCount = data.exportWarnings?.length || 0;
            triggerNotification(warningCount
                ? `Data export downloaded with ${warningCount} unavailable section${warningCount === 1 ? '' : 's'}. Review exportWarnings in the file.`
                : 'Account data export downloaded successfully.');
        } catch (err) {
            triggerNotification(err.message || 'Failed to export data', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteAccountConfirmed = async () => {
        try {
            setIsSubmitting(true);
            const result = await deleteUserAccountPermanently(deletePassword);
            const retained = result.retainedRecordTypes?.length ? ` Legally/operationally retained records: ${result.retainedRecordTypes.join(', ')}.` : '';
            triggerNotification(`${result.message}${retained}`);
            setDeleteAccountModalOpen(false);
            // DIR-047 [SWOT-W]: the purge is confirmed and the session is being torn
            // down; navigate at once. The prior 1000ms timer served no purpose and
            // delayed the one redirect a user cannot undo.
            window.location.href = '/';
        } catch (err) {
            console.error('Delete Account Error:', err);
            let msg = err.message || 'Failed to delete account.';
            if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
                msg = 'Incorrect Current Password. Deletion cancelled for security.';
            }
            triggerNotification(msg, 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    // TOTP 2FA Setup & Disable Handlers
    const handleStartTotpSetup = async () => {
        setIsSubmitting(true);
        try {
            const enrollment = await beginUserTotp2FA();
            setTotpEnrollmentSecret(enrollment.secret);
            setTotpSetupSecret(enrollment.secretKey);
            setTotpQrCodeDataUrl(enrollment.qrCodeDataUrl);
            setTotpVerificationCode('');
            setTotpSetupStep(1);
            setTotpSetupModalOpen(true);
        } catch (error) {
            triggerNotification(error.message || 'Unable to start MFA enrollment. Reauthenticate and try again.', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleVerifyAndEnableTotp = async () => {
        if (!totpVerificationCode || totpVerificationCode.trim().length !== 6) {
            triggerNotification('Please enter a valid 6-digit verification code from your authenticator app.', 'error');
            return;
        }
        setIsSubmitting(true);
        try {
            const status = await saveUserTotp2FA(totpEnrollmentSecret, totpVerificationCode);
            setTotpStatus(status);
            setTotpSetupStep(3); // Advance to backup codes screen
            triggerNotification('TOTP Two-Factor Authentication enabled successfully! 🛡️');
        } catch (err) {
            triggerNotification(err.message || 'Failed to enable 2FA', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDisableTotpConfirmed = async () => {
        if (usesPasswordProvider && !totpDisablePassword) {
            triggerNotification('Current password is required to disable 2FA.', 'error');
            return;
        }
        setIsSubmitting(true);
        try {
            // Re-authenticate user first
            await reauthenticateUser(totpDisablePassword);
            const status = await disableUserTotp2FA();
            setTotpStatus(status);
            setTotpDisableModalOpen(false);
            setTotpDisablePassword('');
            triggerNotification('TOTP 2FA has been disabled for your account.');
        } catch (err) {
            console.error('Disable 2FA error:', err);
            let msg = err.message || 'Failed to disable 2FA.';
            if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
                msg = 'Incorrect Current Password. 2FA remains enabled for security.';
            }
            triggerNotification(msg, 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    // Automatic background auto-saver for Master Profile Settings
    const isFirstProfileLoadRef = React.useRef(true);
    useEffect(() => {
        if (isFirstProfileLoadRef.current) { isFirstProfileLoadRef.current = false; return undefined; }
        if (skipNextAutosaveRef.current) { skipNextAutosaveRef.current = false; return undefined; }
        if (profileConflict) return undefined;
        if (profileSavingRef.current) { setProfileSaveState('pending'); return undefined; }
        setProfileSaveState('pending');
        if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);
        autosaveTimerRef.current = setTimeout(async () => {
            try { await persistProfileRef.current?.(); }
            catch (error) { if (error.code !== 'PROFILE_CONFLICT') triggerNotification(error.message || 'Profile autosave failed. Retry with Save.', 'error'); }
        }, 1500);
        return () => {
            if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);
        };
    }, [profile, profileConflict]);

    useEffect(() => () => { const controller = aiRequestControllerRef.current; aiRequestControllerRef.current = null; controller?.abort(); }, []);

    const runProfileAi = async (operation, payload) => {
        aiRequestControllerRef.current?.abort();
        const controller = new AbortController();
        aiRequestControllerRef.current = controller;
        try {
            return await generateUserAiContent(operation, payload, { signal: controller.signal });
        } finally {
            if (aiRequestControllerRef.current === controller) aiRequestControllerRef.current = null;
        }
    };

    // Summary rewriting and AI Executive Bio generation
    const handleWriteAiSummary = async () => {
        const cleanText = value => String(value || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
        const candCtx = getCandidateContext(profile);
        const latestWorkRole = cleanText(profile.workExperiences?.[0]?.jobTitle);
        const primaryRole = candCtx.target.role || cleanText(profile.occupation) || latestWorkRole;

        const yearsExp = calculateYearsOfExperience(profile.workExperiences || []);
        const expDetails = (profile.workExperiences || []).map(work => {
            const role = cleanText(work?.jobTitle);
            const employer = cleanText(work?.company);
            const dates = [cleanText(work?.startDate), cleanText(work?.endDate)].filter(Boolean).join(' to ');
            return [[role, employer ? `${role ? 'at ' : ''}${employer}` : ''].filter(Boolean).join(' '), dates, cleanText(work?.description)]
                .filter(Boolean).join('; ');
        }).filter(Boolean).join(' | ');
        const eduDetails = (profile.education || []).map(education =>
            [cleanText(education?.degree), cleanText(education?.school), [cleanText(education?.startDate), cleanText(education?.endDate)].filter(Boolean).join(' to '), cleanText(education?.description)]
                .filter(Boolean).join('; ')
        ).filter(Boolean).join(' | ');
        const skillsDetails = (profile.skills || []).map(skill => cleanText(typeof skill === 'string' ? skill : skill?.name || skill?.skillName)).filter(Boolean).join(', ');
        const certsDetails = (profile.certifications || []).map(cert => cleanText(typeof cert === 'string' ? cert : [cert?.title || cert?.name, cert?.issuer].filter(Boolean).join(' — '))).filter(Boolean).join(', ');
        const projectsDetails = (profile.projects || []).map(project => [cleanText(project?.title || project?.name), cleanText(project?.description)].filter(Boolean).join(': ')).filter(Boolean).join(' | ');
        const existingText = cleanText(profile.summary);

        const hasAnyEvidence = primaryRole || expDetails || eduDetails || skillsDetails || existingText;
        if (!hasAnyEvidence) {
            triggerNotification('Add your target role, work history, or education before generating an AI bio.', 'error');
            return;
        }

        const sourceFacts = [
            primaryRole ? `Target Role: ${primaryRole}` : '',
            candCtx.facts.experienceYears ? `Tenure: ${candCtx.facts.experienceYears} years` : (yearsExp ? `Tenure: ${yearsExp} years` : ''),
            expDetails ? `Work History: ${expDetails}` : '',
            eduDetails ? `Education: ${eduDetails}` : '',
            skillsDetails ? `Skills: ${skillsDetails}` : '',
            certsDetails ? `Certifications: ${certsDetails}` : '',
            projectsDetails ? `Projects: ${projectsDetails}` : '',
        ].filter(Boolean).join(' | ');

        setIsAiGenerating(true);
        try {
            const data = await runProfileAi('generate-summary', {
                name: [cleanText(profile.firstname), cleanText(profile.lastname)].filter(Boolean).join(' '),
                jobTitle: primaryRole || 'Professional',
                targetRole: primaryRole || 'Professional',
                occupation: primaryRole || 'Professional',
                experience: candCtx.facts.experienceYears ? `${candCtx.facts.experienceYears} years` : (yearsExp ? `${yearsExp} years` : ''),
                workHistory: expDetails,
                education: eduDetails,
                skills: (profile.skills || []).map(s => typeof s === 'string' ? s : s?.name || s?.skillName).filter(Boolean).slice(0, 40),
                certifications: (profile.certifications || []).map(c => typeof c === 'string' ? c : c?.title || c?.name).filter(Boolean).slice(0, 10),
                projects: (profile.projects || []).map(p => typeof p === 'string' ? p : p?.title || p?.name).filter(Boolean).slice(0, 5),
                sourceFacts,
                existingText,
                tone: summaryTone || 'executive',
                context: candCtx,
            });
            const rawSummary = data?.summary || data?.executiveSummary || data?.professionalSummary || data?.bio || data?.description || (typeof data === 'string' ? data : null);
            const summaryText = typeof rawSummary === 'string' ? stripHtml(rawSummary) : (typeof rawSummary === 'object' && rawSummary ? stripHtml(Object.values(rawSummary).join(' ')) : '');
            if (!summaryText.trim()) {
                throw new Error('No summary was returned by AI provider');
            }
            setSummaryAiDraft(summaryText.trim());
            triggerNotification('AI Executive Bio draft ready for review!');
        } catch (err) {
            if (err?.name === 'AbortError') return;
            console.error('AI summary error:', err);
            const msg = (err?.code === 'AI_DAILY_QUOTA_EXCEEDED' || err?.status === 429)
                ? 'Daily AI limit reached. Please upgrade your plan or try again later.'
                : (err?.message || 'Unable to generate Executive Bio at this time.');
            triggerNotification(msg, 'error');
        } finally {
            setIsAiGenerating(false);
        }
    };

    // Work Experience Bullet Enhancement with AI
    const handleEnhanceWorkDescriptionWithAi = async (index) => {
        const job = (profile.workExperiences || [])[index];
        if (!job || !job.jobTitle) {
            triggerNotification('Please enter the Job Title for this position first.', 'error');
            return;
        }
        setIsAiGenerating(true);
        try {
            const data = await runProfileAi('generate-work-description', {
                jobTitle: job.jobTitle,
                employer: job.company || 'Organization',
                city: job.city || '',
                startDate: job.startDate || '',
                endDate: job.endDate || '',
                current: Boolean(job.current),
                existingText: job.description || '',
                tone: 'metrics',
            });
            let cleanSuggestions = [];
            if (Array.isArray(data?.suggestions)) {
                cleanSuggestions = data.suggestions.map(item =>
                    String(typeof item === 'object' ? item.text || item.suggestion || Object.values(item)[0] || '' : item).trim()
                ).filter(Boolean);
            }
            if (!cleanSuggestions.length) {
                triggerNotification('No bullet points generated. Please provide more role details.', 'error');
                return;
            }
            const bulletText = cleanSuggestions.map(s => `• ${s.replace(/^[•\-*]\s*/, '')}`).join('\n');
            const currentDesc = String(job.description || '').trim();
            const merged = currentDesc ? `${currentDesc}\n${bulletText}` : bulletText;
            updateWorkExperience(index, 'description', merged);
            triggerNotification('AI Work Experience bullet points added!');
        } catch (err) {
            if (err?.name === 'AbortError') return;
            console.error('AI Work Description Error:', err);
            const msg = (err?.code === 'AI_DAILY_QUOTA_EXCEEDED' || err?.status === 429)
                ? 'Daily AI limit reached. Please upgrade your plan or try again later.'
                : (err?.message || 'Unable to generate bullet points at this time.');
            triggerNotification(msg, 'error');
        } finally {
            setIsAiGenerating(false);
        }
    };

    // DYNAMIC AI RECOMMENDATIONS FOR SKILLS
    const handleRecommendAiSkills = async () => {
        const effectiveRole = String(profile.occupation || profile.workExperiences?.[0]?.jobTitle || '').trim();
        if (!effectiveRole) {
            triggerNotification('Please enter your Occupation or at least one Job Title in Basic Details before requesting AI recommendations.', 'error');
            return;
        }
        setIsAiGenerating(true);
        try {
            const expDetails = (profile.workExperiences || []).map(w => `${w.jobTitle || 'Role'} at ${w.company || ''}`).filter(Boolean).join('; ');
            const eduDetails = (profile.education || []).map(e => `${e.degree || ''} from ${e.school || ''}`).filter(Boolean).join('; ');
            const projDetails = (profile.projects || []).map(p => p?.title || p?.name).filter(Boolean).join(', ');
            const existing = (profile.skills || []).map(skill =>
                String(typeof skill === 'string' ? skill : skill?.name || skill?.skillName || '').trim()
            ).filter(Boolean);

            const data = await runProfileAi('generate-skills', {
                targetRole: effectiveRole,
                jobTitle: effectiveRole,
                occupation: effectiveRole,
                workHistory: expDetails,
                education: eduDetails,
                projects: projDetails,
                existingSkills: existing,
                context: {
                    target: { role: effectiveRole },
                    facts: {
                        roles: (profile.workExperiences || []).map(w => ({
                            title: w.jobTitle || '',
                            employer: w.company || '',
                            description: w.description || ''
                        })),
                        skills: existing,
                        education: (profile.education || []).map(e => ({
                            degree: e.degree || '',
                            school: e.school || '',
                            description: e.description || ''
                        })),
                        certifications: (profile.certifications || []).map(c => ({
                            title: typeof c === 'string' ? c : c?.title || c?.name || '',
                            issuer: typeof c === 'object' ? c?.issuer || '' : ''
                        })),
                        projects: (profile.projects || []).map(p => ({
                            title: p?.title || p?.name || '',
                            description: p?.description || ''
                        }))
                    }
                }
            });

            const rawSkills = Array.isArray(data?.skills)
                ? data.skills
                : (Array.isArray(data?.data?.skills)
                    ? data.data.skills
                    : (Array.isArray(data?.suggestions)
                        ? data.suggestions
                        : (Array.isArray(data) ? data : [])));

            if (!rawSkills.length) {
                const note = data?.note || 'AI skill suggestions are currently unavailable. Please verify your role and try again.';
                triggerNotification(note, 'info');
                return;
            }

            const unadded = rawSkills.filter(s => {
                const name = typeof s === 'string' ? s : s?.name || s?.skill || s?.title;
                return name && !existing.some(e => e.toLowerCase() === name.toLowerCase());
            });

            const itemsToReview = unadded.map((s, idx) => {
                const raw = typeof s === 'string' ? s : s?.name || s?.skill || s?.title;
                const cleaned = cleanSkillName(raw);
                const category = (typeof s === 'object' && s?.category && ['mandatory', 'recommended'].includes(s.category)) ? s.category : (idx < 5 ? 'mandatory' : 'recommended');
                return { name: cleaned, category };
            }).filter(s => s.name);

            if (!itemsToReview.length) {
                triggerNotification('All recommended skills for this role are already in your profile!', 'info');
                return;
            }

            setAiModalState({
                isOpen: true,
                title: `Review AI Recommended Skills for ${effectiveRole}`,
                type: 'skills',
                items: itemsToReview,
                onApply: (approvedItems) => {
                    const newSkills = approvedItems.map(item => ({
                        id: `skill_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
                        name: cleanSkillName(item.name || item.title),
                        level: 'Expert',
                    })).filter(item => item.name);
                    setProfile(prev => {
                        const existingNames = new Set((prev.skills || []).map(skill => String(typeof skill === 'string' ? skill : skill.name || '').toLowerCase()));
                        return { ...prev, skills: [...(prev.skills || []), ...newSkills.filter(skill => !existingNames.has(skill.name.toLowerCase()))] };
                    });
                    triggerNotification(`Added ${approvedItems.length} approved ATS skills to your profile!`);
                },
            });
        } catch (err) {
            if (err?.name === 'AbortError') return;
            console.error('AI skill recommendation error:', err);
            const msg = (err?.code === 'AI_DAILY_QUOTA_EXCEEDED' || err?.status === 429)
                ? 'Daily AI limit reached. Please upgrade your plan or try again later.'
                : (err?.message || 'Unable to generate skills recommendations.');
            triggerNotification(msg, 'error');
        } finally {
            setIsAiGenerating(false);
        }
    };

    // DYNAMIC AI RECOMMENDATIONS FOR CERTIFICATIONS
    const handleRecommendAiCertifications = async () => {
        const effectiveRole = String(profile.occupation || profile.workExperiences?.[0]?.jobTitle || '').trim();
        if (!effectiveRole) {
            triggerNotification('Please enter your Occupation or at least one Job Title in Basic Details before requesting AI recommendations.', 'error');
            return;
        }
        setIsAiGenerating(true);
        try {
            const expDetails = (profile.workExperiences || []).map(w => `${w.jobTitle || 'Role'} at ${w.company || ''}`).filter(Boolean).join('; ');
            const eduDetails = (profile.education || []).map(e => `${e.degree || ''} from ${e.school || ''}`).filter(Boolean).join('; ');
            const skillsDetails = (profile.skills || []).map(s => (typeof s === 'string' ? s : s?.name || s?.skillName)).filter(Boolean).join(', ');
            const existingCerts = (profile.certifications || []).map(c => typeof c === 'string' ? c : c?.title || c?.name).filter(Boolean);

            const data = await runProfileAi('generate-certifications', {
                targetRole: effectiveRole,
                jobTitle: effectiveRole,
                occupation: effectiveRole,
                workHistory: expDetails,
                education: eduDetails,
                skills: skillsDetails,
                existingCertifications: existingCerts,
                context: {
                    target: { role: effectiveRole },
                    facts: {
                        roles: (profile.workExperiences || []).map(w => ({
                            title: w.jobTitle || '',
                            employer: w.company || '',
                            description: w.description || ''
                        })),
                        skills: (profile.skills || []).map(s => typeof s === 'string' ? s : s?.name || s?.skillName || '').filter(Boolean),
                        education: (profile.education || []).map(e => ({
                            degree: e.degree || '',
                            school: e.school || '',
                            description: e.description || ''
                        })),
                        certifications: (profile.certifications || []).map(c => ({
                            title: typeof c === 'string' ? c : c?.title || c?.name || '',
                            issuer: typeof c === 'object' ? c?.issuer || '' : ''
                        }))
                    }
                }
            });

            let certsList = Array.isArray(data?.certifications)
                ? data.certifications
                : (Array.isArray(data?.data?.certifications)
                    ? data.data.certifications
                    : (Array.isArray(data?.certs)
                        ? data.certs
                        : (Array.isArray(data?.suggestions)
                            ? data.suggestions
                            : (Array.isArray(data) ? data : []))));

            if (!certsList.length) {
                const note = data?.note || 'AI credential suggestions are currently unavailable. Please verify your role and try again.';
                triggerNotification(note, 'info');
                return;
            }

            const unadded = certsList.filter(c => {
                const title = typeof c === 'string' ? c : c?.title || c?.name;
                return title && !existingCerts.some(e => e.toLowerCase() === title.toLowerCase());
            });

            const itemsToReview = unadded.map((c, idx) => {
                const title = typeof c === 'string' ? c : (c?.title || c?.name || '');
                const issuer = typeof c === 'object' ? (c?.issuer || '') : '';
                const category = (typeof c === 'object' && c?.category && ['mandatory', 'recommended'].includes(c.category)) ? c.category : (idx < 3 ? 'mandatory' : 'recommended');
                const certType = typeof c === 'object' ? (c?.certType || (c?.isLicense ? 'License' : 'Certification')) : 'Certification';
                const isLicense = typeof c === 'object' ? Boolean(c?.isLicense || c?.certType === 'License') : false;
                return { title, issuer, category, name: title, certType, isLicense };
            }).filter(c => c.title);

            if (!itemsToReview.length) {
                triggerNotification('All recommended credentials for this role are already in your Master Profile!', 'info');
                return;
            }

            setAiModalState({
                isOpen: true,
                title: `Review Industry Certifications for ${effectiveRole}`,
                type: 'certifications',
                items: itemsToReview,
                onApply: (approvedItems) => {
                    const newCerts = approvedItems.map((c, i) => ({
                        id: `cert_ai_${Date.now()}_${i}`,
                        title: c.title || c.name,
                        issuer: c.issuer || '',
                        date: '',
                        endDate: '',
                        credentialId: '',
                        url: '',
                        certType: c.certType || (c.isLicense ? 'License' : 'Certification'),
                        isLicense: Boolean(c.isLicense || c.certType === 'License'),
                    }));
                    setProfile(prev => ({
                        ...prev,
                        certifications: [...(prev.certifications || []), ...newCerts]
                    }));
                    triggerNotification(`Added ${approvedItems.length} credentials to your Master Profile!`);
                }
            });
        } catch (err) {
            if (err?.name === 'AbortError') return;
            console.error('AI Certifications Recommendation Error:', err);

            // No curated/template credentials on failure — report the unavailable state.
            const msg = (err?.code === 'AI_DAILY_QUOTA_EXCEEDED' || err?.status === 429)
                ? 'Daily AI limit reached. Please upgrade your plan or try again later.'
                : 'AI credential recommendations are unavailable right now. Please try again in a moment.';
            triggerNotification(msg, 'error');
        } finally {
            setIsAiGenerating(false);
        }
    };

    // Reorder items helper
    const moveItem = (arrayField, index, direction) => {
        setProfile((prev) => {
            const list = [...(prev[arrayField] || [])];
            const targetIdx = index + direction;
            if (targetIdx < 0 || targetIdx >= list.length) return prev;
            const [moved] = list.splice(index, 1);
            list.splice(targetIdx, 0, moved);
            return { ...prev, [arrayField]: list };
        });
    };

    // Work Experience Array Handlers
    const addWorkExperience = () => {
        setProfile((prev) => ({
            ...prev,
            workExperiences: [
                ...prev.workExperiences,
                { id: `job_${Date.now()}`, jobTitle: '', company: '', city: '', startDate: '', endDate: '', description: '' }
            ]
        }));
    };

    const updateWorkExperience = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...prev.workExperiences];
            updated[index] = { ...updated[index], [field]: rawVal };
            return { ...prev, workExperiences: updated };
        });
    };

    const removeWorkExperience = (index) => {
        setProfile((prev) => ({
            ...prev,
            workExperiences: prev.workExperiences.filter((_, i) => i !== index)
        }));
    };

    // Education Array Handlers
    const addEducation = () => {
        setProfile((prev) => ({
            ...prev,
            education: [
                ...prev.education,
                { id: `edu_${Date.now()}`, degree: '', school: '', city: '', startDate: '', endDate: '', description: '' }
            ]
        }));
    };

    const updateEducation = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...prev.education];
            updated[index] = { ...updated[index], [field]: rawVal };
            return { ...prev, education: updated };
        });
    };

    const removeEducation = (index) => {
        setProfile((prev) => ({
            ...prev,
            education: prev.education.filter((_, i) => i !== index)
        }));
    };

    // Skills Handlers
    const addSkill = () => {
        setProfile((prev) => ({
            ...prev,
            skills: [...prev.skills, { name: '', level: '' }]
        }));
    };

    const updateSkill = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...prev.skills];
            updated[index] = { ...updated[index], [field]: rawVal };
            return { ...prev, skills: updated };
        });
    };

    const removeSkill = (index) => {
        setProfile((prev) => ({
            ...prev,
            skills: prev.skills.filter((_, i) => i !== index)
        }));
    };

    // Certifications Handlers
    const addCertification = () => {
        setProfile((prev) => ({
            ...prev,
            certifications: [
                ...(prev.certifications || []),
                {
                    id: `cert_${Date.now()}`,
                    title: '',
                    issuer: '',
                    date: '',
                    endDate: '',
                    credentialId: '',
                    url: '',
                    certType: 'Certification',
                    isLicense: false,
                }
            ]
        }));
    };

    const duplicateCertification = (index) => {
        setProfile((prev) => {
            const list = [...(prev.certifications || [])];
            const item = list[index];
            if (!item) return prev;
            const duplicated = {
                ...item,
                id: `cert_${Date.now()}`,
                title: item.title ? `${item.title} (Copy)` : '',
            };
            list.splice(index + 1, 0, duplicated);
            return { ...prev, certifications: list };
        });
    };

    const updateCertification = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...(prev.certifications || [])];
            if (!updated[index]) return prev;
            updated[index] = { ...updated[index], [field]: rawVal };
            return { ...prev, certifications: updated };
        });
    };

    const removeCertification = (index) => {
        setProfile((prev) => ({
            ...prev,
            certifications: (prev.certifications || []).filter((_, i) => i !== index)
        }));
    };

    // DYNAMIC AI RECOMMENDATIONS FOR PROJECTS
    const handleRecommendAiProjects = async () => {
        const effectiveRole = String(
            profile.occupation ||
            profile.workExperiences?.[0]?.jobTitle ||
            profile.education?.[0]?.degree ||
            ''
        ).trim();

        if (!effectiveRole) {
            triggerNotification('Please enter your Occupation or at least one Job Title in Basic Details before requesting AI recommendations.', 'error');
            return;
        }

        setIsAiGenerating(true);
        try {
            const existingTitles = new Set((profile.projects || []).map(p => String(p.title || p.name || '').trim().toLowerCase()).filter(Boolean));
            // Only AI results for this request are offered; no role-template ideas.
            let curatedList = [];
            let aiUnavailable = false;

            try {
                const aiResult = await runProfileAi('generate-projects', {
                    targetRole: effectiveRole || 'Professional',
                    occupation: effectiveRole || 'Professional',
                    candidateFacts: {
                        roles: (profile.workExperiences || []).map(w => ({
                            title: w.jobTitle || '',
                            employer: w.company || '',
                            description: w.description || ''
                        })),
                        skills: (profile.skills || []).map(s => typeof s === 'string' ? s : s?.name || s?.skillName || '').filter(Boolean),
                        education: profile.education || [],
                        summary: profile.summary || '',
                    },
                    context: {
                        target: { role: effectiveRole },
                    },
                    existingTitles: Array.from(existingTitles),
                    language: 'en',
                });

                if (aiResult?.aiUnavailable) aiUnavailable = true;
                const candidateProjects = Array.isArray(aiResult?.projects)
                    ? aiResult.projects
                    : (Array.isArray(aiResult?.items) ? aiResult.items : (Array.isArray(aiResult) ? aiResult : null));

                if (candidateProjects && candidateProjects.length > 0) {
                    curatedList = candidateProjects.map(cp => ({
                        name: cp.name || cp.title,
                        role: cp.role || '',
                        issuer: cp.technologies ? (cp.technologies.startsWith('Stack: ') || cp.technologies.startsWith('Tools: ') ? cp.technologies : `Tools: ${cp.technologies}`) : (cp.issuer || ''),
                        category: cp.category === 'mandatory' ? 'mandatory' : 'recommended',
                        projectType: cp.projectType || 'enterprise',
                    })).filter(p => Boolean(p.name));
                }
            } catch {
                aiUnavailable = true;
            }

            if (!curatedList.length) {
                triggerNotification(aiUnavailable
                    ? 'AI project recommendations are unavailable right now. Please try again in a moment.'
                    : 'AI could not suggest projects from your current details. Add more about your work or skills, then try again.', 'info');
                return;
            }

            const unadded = curatedList.filter(item => !existingTitles.has(String(item.name || item.title || '').trim().toLowerCase()));

            if (!unadded.length) {
                triggerNotification('All recommended project ideas for this role are already in your Master Profile!', 'info');
                return;
            }

            setAiModalState({
                isOpen: true,
                title: `Review AI Recommended Projects for ${effectiveRole}`,
                type: 'projects',
                items: unadded,
                onApply: (approvedItems) => {
                    const toAdd = approvedItems.map((item, idx) => {
                        const rawIssuer = String(item.issuer || item.technologies || '');
                        const stack = rawIssuer.startsWith('Stack: ') || rawIssuer.startsWith('Tools: ')
                            ? rawIssuer.replace(/^(?:Stack|Tools):\s*/, '')
                            : rawIssuer;

                        return {
                            id: `proj_ai_${Date.now()}_${idx}_${Math.random().toString(36).substr(2, 4)}`,
                            title: item.name || item.title,
                            role: item.role || '',
                            technologies: stack,
                            projectType: item.projectType || 'enterprise',
                            link: '',
                            url: '',
                            description: '',
                        };
                    });

                    setProfile(prev => ({
                        ...prev,
                        projects: [...(prev.projects || []), ...toAdd]
                    }));
                    triggerNotification(`Added ${toAdd.length} project(s) to your Master Profile!`);
                }
            });
        } catch (err) {
            if (err?.name === 'AbortError') return;
            console.error('AI Project Recommendation Error:', err);
            const msg = (err?.code === 'AI_DAILY_QUOTA_EXCEEDED' || err?.status === 429)
                ? 'Daily AI limit reached. Please upgrade your plan or try again later.'
                : (err?.message || 'Unable to fetch project ideas. Please try again.');
            triggerNotification(msg, 'error');
        } finally {
            setIsAiGenerating(false);
        }
    };

    // Projects Handlers
    const addProject = () => {
        setProfile((prev) => ({
            ...prev,
            projects: [
                ...prev.projects,
                {
                    id: `proj_${Date.now()}`,
                    title: '',
                    role: '',
                    technologies: '',
                    url: '',
                    link: '',
                    projectType: 'personal',
                    description: ''
                }
            ]
        }));
    };

    const updateProject = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...prev.projects];
            updated[index] = { ...updated[index], [field]: rawVal };
            if (field === 'url') updated[index].link = rawVal;
            if (field === 'link') updated[index].url = rawVal;
            return { ...prev, projects: updated };
        });
    };

    const removeProject = (index) => {
        setProfile((prev) => ({
            ...prev,
            projects: prev.projects.filter((_, i) => i !== index)
        }));
    };

    // Languages Handlers
    const PROFICIENCY_LEVELS = ['Native / Bilingual', 'Full Professional (Fluent)', 'Professional Working (Advanced)', 'Limited Working (Intermediate)', 'Elementary (Basic)'];
    const addLanguage = () => {
        setProfile((prev) => ({
            ...prev,
            languages: [...prev.languages, { id: `lang_${Date.now()}`, name: '', level: '' }]
        }));
    };
    const updateLanguage = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...prev.languages];
            updated[index] = { ...updated[index], [field]: rawVal };
            return { ...prev, languages: updated };
        });
    };
    const removeLanguage = (index) => {
        setProfile((prev) => ({
            ...prev,
            languages: prev.languages.filter((_, i) => i !== index)
        }));
    };
    const POPULAR_LANGUAGES = ['English','Hindi','Telugu','Tamil','Kannada','Malayalam','Marathi','Bengali','Gujarati','Punjabi','Spanish','French','German','Mandarin','Arabic','Portuguese','Japanese','Russian','Korean'];

    // Hobbies Handlers
    const [hobbyInput, setHobbyInput] = useState('');
    const POPULAR_HOBBIES = ['Photography', 'Chess', 'Marathon Running', 'Open Source Contributor', 'Reading', 'Hiking', 'Writing', 'Cooking', 'Traveling', 'Volunteering', 'Music Production'];
    const addHobby = (hobbyName) => {
        const trimmed = (hobbyName || hobbyInput).trim();
        if (!trimmed) return;
        const exists = (profile.hobbies || []).some(h => (typeof h === 'string' ? h : h.name || h.hobby || '').toLowerCase() === trimmed.toLowerCase());
        if (!exists) {
            setProfile(prev => ({ ...prev, hobbies: [...(prev.hobbies || []), trimmed] }));
        }
        setHobbyInput('');
    };
    const removeHobby = (index) => {
        setProfile(prev => ({ ...prev, hobbies: (prev.hobbies || []).filter((_, i) => i !== index) }));
    };

    // Work Experience Duplication
    const duplicateWorkExperience = (index) => {
        const source = (profile.workExperiences || [])[index];
        if (!source) return;
        const copy = { ...source, id: `work_${Date.now()}`, jobTitle: `${source.jobTitle || 'Position'} (Copy)` };
        setProfile(prev => ({
            ...prev,
            workExperiences: [...prev.workExperiences.slice(0, index + 1), copy, ...prev.workExperiences.slice(index + 1)]
        }));
        triggerNotification('Work Experience position duplicated!');
    };

    // Multi-Skill Bulk Paste Ingestion & View Mode
    const [bulkSkillsInput, setBulkSkillsInput] = useState('');
    const [skillsViewMode, setSkillsViewMode] = useState('grid'); // 'grid' | 'compact'
    const [showBulkSkills, setShowBulkSkills] = useState(false);
    const [skillsSearchQuery, setSkillsSearchQuery] = useState('');

    const cycleSkillLevel = (index) => {
        const levels = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
        setProfile((prev) => {
            const current = (prev.skills[index]?.level || 'Intermediate');
            const currentIndex = levels.findIndex(l => l.toLowerCase() === current.toLowerCase());
            const nextLevel = levels[(currentIndex + 1) % levels.length];
            const updated = [...prev.skills];
            updated[index] = { ...updated[index], level: nextLevel };
            return { ...prev, skills: updated };
        });
    };
    const handleBulkSkillAdd = () => {
        if (!bulkSkillsInput || !bulkSkillsInput.trim()) return;
        const tokens = bulkSkillsInput.split(/[,;\n]+/).map(t => cleanSkillName(t)).filter(Boolean);
        if (tokens.length > 0) {
            setProfile(prev => {
                const existingNames = new Set((prev.skills || []).map(s => String(typeof s === 'string' ? s : s?.name || s?.skillName || '').trim().toLowerCase()));
                const toAdd = [];
                for (const token of tokens) {
                    const norm = token.trim().toLowerCase();
                    if (norm && !existingNames.has(norm)) {
                        existingNames.add(norm);
                        toAdd.push({ id: `skill_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`, name: token, level: 'Advanced' });
                    }
                }
                if (toAdd.length > 0) {
                    triggerNotification(`Added ${toAdd.length} skill(s) to Master Profile!`);
                    return { ...prev, skills: [...prev.skills, ...toAdd] };
                } else {
                    triggerNotification('All entered skills already exist in profile.', 'info');
                    return prev;
                }
            });
            setBulkSkillsInput('');
        }
    };

    // Achievements Handlers
    const addAchievement = () => {
        setProfile((prev) => ({
            ...prev,
            achievements: [...(prev.achievements || []), { id: `ach_${Date.now()}`, title: '', issuer: '', awarder: '', date: '', description: '', achievementType: 'Award' }]
        }));
    };
    const duplicateAchievement = (index) => {
        setProfile((prev) => {
            const list = [...(prev.achievements || [])];
            const source = list[index];
            if (!source) return prev;
            const copy = {
                ...source,
                id: `ach_${Date.now()}`,
                title: source.title ? `${source.title} (Copy)` : 'Achievement (Copy)',
            };
            list.splice(index + 1, 0, copy);
            return { ...prev, achievements: list };
        });
        triggerNotification('Achievement duplicated!');
    };
    const updateAchievement = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...(prev.achievements || [])];
            const currentItem = updated[index] || {};
            const nextItem = { ...currentItem, [field]: rawVal };
            if (field === 'awarder') nextItem.issuer = rawVal;
            if (field === 'issuer') nextItem.awarder = rawVal;
            updated[index] = nextItem;
            return { ...prev, achievements: updated };
        });
    };
    const removeAchievement = (index) => {
        setProfile((prev) => ({
            ...prev,
            achievements: (prev.achievements || []).filter((_, i) => i !== index)
        }));
        triggerNotification('Achievement removed', 'info');
    };
    const polishAchievementDescription = async (index) => {
        const ach = profile.achievements?.[index];
        if (!ach) return;
        setIsPolishingAchIndex(index);
        const title = ach.title || ach.name || 'Achievement';
        const currentDesc = ach.description || '';
        const awarder = ach.awarder || ach.issuer || '';

        try {
            const prompt = `Rewrite this resume achievement as 1-2 concise, ATS-readable sentences using ONLY the facts given below. Do not add numbers, percentages, rankings, dates, scope or impact that are not stated. If the draft is empty, describe only what the title and awarding organization state. Achievement: "${title}". Awarding Organization: "${awarder}". Draft: "${currentDesc}".`;
            const res = await runProfileAi('generate-summary', {
                prompt,
                targetRole: profile.occupation || 'Professional',
                context: `${title} conferred by ${awarder}`,
                language: 'en',
            });
            const text = res?.content || res?.summary || res?.data?.content;
            if (text && typeof text === 'string') {
                const cleaned = text.replace(/^["']|["']$/g, '').trim();
                updateAchievement(index, 'description', cleaned);
                triggerNotification('Achievement description polished with AI!');
                return;
            }
        } catch {
            // AI unavailable: handled below without generating any text.
        } finally {
            setIsPolishingAchIndex(null);
        }

        // Never synthesize a description; keep the candidate's text unchanged.
        triggerNotification(
            currentDesc
                ? 'AI polishing is unavailable right now. Your description was left unchanged.'
                : 'AI polishing is unavailable right now. Add a sentence describing what you were recognized for, then try again.',
            'info'
        );
    };

    // References Handlers
    const addReference = () => {
        setProfile((prev) => ({
            ...prev,
            references: [...(prev.references || []), { id: `ref_${Date.now()}`, name: '', position: '', company: '', email: '', phone: '', reference: '' }]
        }));
    };
    const updateReference = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...(prev.references || [])];
            updated[index] = { ...updated[index], [field]: rawVal };
            return { ...prev, references: updated };
        });
    };
    const removeReference = (index) => {
        setProfile((prev) => ({
            ...prev,
            references: (prev.references || []).filter((_, i) => i !== index)
        }));
    };

    // Custom Sections Handlers
    const addCustomSection = () => {
        setProfile((prev) => ({
            ...prev,
            customSections: [...(prev.customSections || []), { id: `custom_${Date.now()}`, title: 'Custom Section', content: '', items: [] }]
        }));
    };
    const updateCustomSection = (index, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...(prev.customSections || [])];
            updated[index] = { ...updated[index], [field]: rawVal };
            return { ...prev, customSections: updated };
        });
    };
    const removeCustomSection = (index) => {
        setProfile((prev) => ({
            ...prev,
            customSections: (prev.customSections || []).filter((_, i) => i !== index)
        }));
    };
    const addCustomSectionItem = (sectionIndex) => {
        setProfile((prev) => {
            const updated = [...(prev.customSections || [])];
            const section = updated[sectionIndex] || { items: [] };
            const nextItems = [...(section.items || []), { id: `item_${Date.now()}`, title: '', description: '' }];
            updated[sectionIndex] = { ...section, items: nextItems };
            return { ...prev, customSections: updated };
        });
    };
    const updateCustomSectionItem = (sectionIndex, itemIndex, field, value) => {
        const rawVal = (value && typeof value === 'object' && value.target !== undefined) ? value.target.value : value;
        setProfile((prev) => {
            const updated = [...(prev.customSections || [])];
            const section = updated[sectionIndex];
            if (!section) return prev;
            const items = [...(section.items || [])];
            items[itemIndex] = { ...items[itemIndex], [field]: rawVal };
            updated[sectionIndex] = { ...section, items };
            return { ...prev, customSections: updated };
        });
    };
    const removeCustomSectionItem = (sectionIndex, itemIndex) => {
        setProfile((prev) => {
            const updated = [...(prev.customSections || [])];
            const section = updated[sectionIndex];
            if (!section) return prev;
            const items = (section.items || []).filter((_, i) => i !== itemIndex);
            updated[sectionIndex] = { ...section, items };
            return { ...prev, customSections: updated };
        });
    };

    // Drag & Drop Avatar
    const handleDragOver = (e) => { e.preventDefault(); setIsDragging(true); };
    const handleDragLeave = () => setIsDragging(false);
    const handleDrop = (e) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            processImageFile(e.dataTransfer.files[0]);
        }
    };
    const handleImageUpload = (e) => {
        if (e.target.files && e.target.files[0]) processImageFile(e.target.files[0]);
    };
    const processImageFile = (imageFile) => {
        if (!['image/png', 'image/jpeg', 'image/webp'].includes(imageFile?.type)) { triggerNotification('Avatar must be a PNG, JPEG, or WebP image.', 'error'); return; }
        if (imageFile.size > 5 * 1024 * 1024) { triggerNotification('Avatar must be 5 MB or smaller.', 'error'); return; }
        const reader = new FileReader();
        reader.onerror = () => triggerNotification('Unable to read that image. Try another file.', 'error');
        reader.onloadend = () => setCropModalSrc(reader.result);
        reader.readAsDataURL(imageFile);
    };
    const handleCroppedImage = async (croppedDataUrl) => {
        setCropModalSrc(null);
        const currentUser = fire.auth().currentUser;
        if (!currentUser) { triggerNotification('Sign in again before uploading an avatar.', 'error'); return; }
        if (profileConflictRef.current) { triggerNotification('Resolve the newer profile revision before replacing the avatar.', 'error'); return; }
        setProfileSaveState('saving');
        const avatarOnly = { ...profileRef.current, selectedImage: croppedDataUrl };
        const result = await saveProfile(currentUser.uid, avatarOnly, Number.isSafeInteger(Number(profileRef.current?.revision)) ? Number(profileRef.current.revision) : 0);
        if (!result.success) {
            setProfileSaveState(result.code === 'PROFILE_CONFLICT' ? 'conflict' : 'failed');
            if (result.code === 'PROFILE_CONFLICT') setProfileConflict({ remoteRevision: result.remoteRevision });
            triggerNotification(result.error || 'Avatar upload failed.', 'error');
            return;
        }
        skipNextAutosaveRef.current = true;
        setProfile(prev => ({ ...prev, selectedImage: result.profile.selectedImage, revision: result.revision }));
        setProfileSaveState('saved');
        triggerNotification('Avatar updated successfully.');
    };

    const getPasswordStrength = (password) => {
        if (!password) return { strength: '', width: 'w-0', color: 'bg-[var(--cuba-line)]', text: '' };
        if (password.length < 6) return { strength: 'weak', width: 'w-1/4', color: 'bg-[var(--cuba-danger)]', text: 'Weak' };
        if (password.length < 8) return { strength: 'fair', width: 'w-2/4', color: 'bg-[var(--cuba-warning)]', text: 'Fair' };
        if (password.length < 10) return { strength: 'good', width: 'w-3/4', color: 'bg-[var(--cuba-primary)]', text: 'Good' };
        return { strength: 'strong', width: 'w-full', color: 'bg-[var(--cuba-success)]', text: 'Strong' };
    };

    getPasswordStrength(accountSettings.password);
    // DIR-075: sanitize the header identity so a parenthetical role in the
    // display name ('Bhaskar Beyond (Super Admin)') renders as a clean name plus
    // a dedicated role badge — never raw '()' in the <h1>.
    const headerIdentity = parseUserIdentity({
        name: `${profile.firstname || ''} ${profile.lastname || ''}`.trim() || profile.name || '',
    });
    const candidateFullName = headerIdentity.name;
    const candidateRoleBadge = roleBadgeFor(headerIdentity.role);
    const effectiveMembership = databaseAccountSettings.membership || 'Basic';
    const completedProfileStepCount = SUB_TAB_ORDER.filter(k => SUBTAB_CONFIG[k]?.isComplete(profile)).length;
    const profileProgressPercentage = Math.min(100, Math.round((completedProfileStepCount / SUB_TAB_ORDER.length) * 100));

    return (
        <>
        <div className="min-h-0 bg-cuba-canvas text-cuba-ink font-sans">
            <div className="w-full max-w-[1440px] mx-auto px-3 sm:px-5 lg:px-6 py-4 sm:py-6 space-y-4 sm:space-y-6 pb-8 sm:pb-12">

                {/* DIR-089: honest failure surface. The account-details fetch used to fail
                    silently (console only), leaving the hub half-empty with no explanation. */}
                {accountLoadError && (
                    <div
                        role="alert"
                        data-testid="settings-load-error"
                        className="flex flex-wrap items-center gap-2 rounded-xl border border-[var(--cuba-danger-soft)] bg-[var(--cuba-danger-soft)] px-3.5 py-2.5"
                    >
                        <MdErrorOutline className="h-4 w-4 flex-none text-[var(--cuba-danger)]" aria-hidden="true" />
                        <p className="min-w-0 flex-1 text-xs font-semibold text-[var(--cuba-danger)]">{accountLoadError}</p>
                        <button
                            type="button"
                            onClick={() => { setAccountLoadError(null); window.location.reload(); }}
                            className="cuba-focusable rounded-lg border border-[var(--cuba-danger)] px-2.5 py-1 text-[11px] font-bold text-[var(--cuba-danger)]"
                        >
                            Retry
                        </button>
                    </div>
                )}

                {/* Hero Master Profile Overview Card — Styled after StepShell Header */}
                <div className="bg-white border border-[var(--cuba-line)] rounded-xl p-4 sm:p-5 shadow-2xs relative overflow-hidden">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        {/* Left Avatar & Right Details Container */}
                        <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                            {/* Left Column: Avatar Image + Badge Underneath */}
                            <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                                <div className="relative">
                                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-gradient-to-br from-indigo-50 to-purple-50 border border-[var(--cuba-line)] shadow-2xs flex items-center justify-center">
                                        {normalizeProfileImage(profile.selectedImage) ? (
                                            <img src={normalizeProfileImage(profile.selectedImage)} alt="Profile avatar" className="w-full h-full object-cover" />
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center bg-[var(--cuba-ink)] text-white font-bold text-lg">
                                                {candidateFullName ? candidateFullName.charAt(0).toUpperCase() : 'U'}
                                            </div>
                                        )}
                                    </div>
                                    {fire.auth().currentUser?.emailVerified && <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[var(--cuba-success)] rounded-full border-2 border-white flex items-center justify-center shadow-2xs" title="Email verified" aria-label="Email verified">
                                        <FaCheck className="w-2 h-2 text-white" />
                                    </div>}
                                </div>

                                {/* Membership Badge — directly UNDER avatar image */}
                                <span className="px-2 py-0.5 text-[10px] font-bold text-[var(--cuba-primary-ink-strong)] bg-[var(--cuba-primary-soft)] border border-[var(--cuba-primary-line)]/80 rounded-md flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-[var(--cuba-success)]"></span>
                                    {effectiveMembership}
                                </span>
                            </div>

                            {/* Right Column: Name, Occupation, Email & Profile Strength Badge */}
                            <div className="flex-1 min-w-0">
                                <div className="flex flex-wrap items-center gap-2">
                                    <h1 className="text-base sm:text-lg font-bold tracking-tight text-[var(--cuba-ink)] break-words">
                                        {candidateFullName || 'Master User Profile'}
                                    </h1>
                                    {headerIdentity.roleLabel && (
                                        <span
                                            data-testid="profile-role-badge"
                                            className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${candidateRoleBadge.className}`}
                                        >
                                            {headerIdentity.roleLabel}
                                        </span>
                                    )}
                                    {(() => {
                                        let score = 0;
                                        if (profile.firstname || profile.lastname) score += 15;
                                        if (profile.email) score += 10;
                                        if (profile.phone) score += 10;
                                        if (profile.occupation) score += 15;
                                        if (profile.city || profile.country) score += 10;
                                        if (profile.summary && stripHtml(profile.summary).length >= 20) score += 15;
                                        if (profile.workExperiences && profile.workExperiences.length > 0) score += 10;
                                        if (profile.education && profile.education.length > 0) score += 5;
                                        if (profile.skills && profile.skills.length >= 3) score += 10;
                                        const compScore = Math.min(100, score);
                                        return (
                                            <span className="inline-flex items-center gap-1.5 rounded-md border border-[var(--cuba-success-soft)] bg-[var(--cuba-success-soft)] px-2 py-0.5 text-[10px] sm:text-[11px] font-bold text-[var(--cuba-success)]">
                                                <span className="w-1.5 h-1.5 rounded-full bg-[var(--cuba-success)]"></span>
                                                <span>{compScore}% Profile Strength</span>
                                            </span>
                                        );
                                    })()}
                                </div>
                                {profile.occupation && (
                                    <p className="text-xs font-semibold text-[var(--cuba-primary-ink-strong)] mt-0.5 truncate">
                                        {profile.occupation}
                                    </p>
                                )}
                                {profile.email && (
                                    <p className="text-xs text-[var(--cuba-ink-subtle)] mt-0.5 truncate">
                                        {profile.email}
                                    </p>
                                )}
                            </div>
                        </div>

                        {/* Right Action Cluster: Expand View / Show Guidance toggle.
                            DIR-075: the redundant in-page [Master Profile | Account &
                            Security] switcher was removed — the sidebar already
                            exposes 'Security & 2FA Hub' (?tab=Security) and
                            'Subscription & Plans' (/dashboard/plans) as first-class
                            destinations, so Master Profile Data is now a pure,
                            dedicated workspace driven by the URL. */}
                        <div className="flex items-center gap-2 self-stretch md:self-center flex-shrink-0">
                            {selectedSettings === 'Profile' && (
                                <button
                                    type="button"
                                    onClick={() => setShowProfileGuidanceRail(prev => !prev)}
                                    className="hidden lg:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-ink)] bg-white hover:bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] shadow-2xs transition-all cursor-pointer"
                                    title={showProfileGuidanceRail ? 'Expand view (hide copilot rail)' : 'Show copilot guidance rail'}
                                >
                                    <span>{showProfileGuidanceRail ? 'Expand View' : 'Show Guidance'}</span>
                                </button>
                            )}
                        </div>
                    </div>
                </div>

                {selectedSettings === 'Profile' && (profileSaveState === 'failed' || profileSaveState === 'conflict' || profileConflict) && (
                    <div className={`rounded-xl border px-3.5 py-2.5 text-xs ${profileSaveState === 'failed' || profileSaveState === 'conflict' ? 'border-[var(--cuba-warning-soft)] bg-[var(--cuba-warning-soft)] text-[var(--cuba-warning)]' : 'border-[var(--cuba-line)] bg-white text-[var(--cuba-ink-muted)] shadow-2xs'}`} aria-live="polite">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                                <span className={`w-2 h-2 rounded-full ${profileSaveState === 'saved' ? 'bg-[var(--cuba-success)]' : profileSaveState === 'saving' || profileSaveState === 'pending' ? 'bg-[var(--cuba-primary)] animate-pulse' : profileSaveState === 'failed' || profileSaveState === 'conflict' ? 'bg-[var(--cuba-warning)]' : 'bg-[var(--cuba-line-strong)]'}`}></span>
                                <span><strong>Profile save:</strong> {profileSaveState === 'saving' ? 'Saving…' : profileSaveState === 'pending' ? 'Pending autosave' : profileSaveState === 'saved' ? 'Saved' : profileSaveState === 'conflict' ? 'Conflict—action required' : profileSaveState === 'failed' ? 'Failed—retry with Save' : 'Loading…'}</span>
                            </div>
                            {profileSaveState === 'failed' && (
                                <button
                                    type="button"
                                    onClick={() => persistProfileRef.current?.({ notify: true })}
                                    className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-lg bg-[var(--cuba-warning)] hover:bg-[var(--cuba-warning)] text-white shadow-xs transition"
                                >
                                    Retry Save
                                </button>
                            )}
                        </div>
                        {profileConflict && (
                            <div className="mt-2 flex flex-wrap gap-2">
                                <button type="button" onClick={reloadProfileConflict} className="rounded border border-[var(--cuba-warning-soft)] bg-white px-3 py-1 text-xs font-semibold">Discard local changes and load latest</button>
                                <button type="button" onClick={overwriteProfileConflict} className="rounded bg-[var(--cuba-warning)] px-3 py-1 text-xs font-semibold text-white">Overwrite latest with local profile</button>
                            </div>
                        )}
                    </div>
                )}

                {/* Inline Toast Banner */}
                {toastState && (
                    <div role={toastState.type === 'error' ? 'alert' : 'status'} aria-live="polite" className={`p-4 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-xs animate-in fade-in duration-200 ${
                        toastState.type === 'error' ? 'bg-[var(--cuba-danger-soft)] border-[var(--cuba-danger-soft)] text-[var(--cuba-danger)]' : 'bg-[var(--cuba-success-soft)] border-[var(--cuba-success-soft)] text-[var(--cuba-success)]'
                    }`}>
                        <div className="flex items-center gap-2">
                            {toastState.type === 'error' ? <FaExclamationTriangle className="w-4 h-4 text-[var(--cuba-danger)]" /> : <FaCheckCircle className="w-4 h-4 text-[var(--cuba-success)]" />}
                            <span>{toastState.msg}</span>
                        </div>
                    </div>
                )}

                {/* Main Content Area */}
                {selectedSettings === 'Profile' ? (
                    <div className="space-y-5">

                        {/* Horizontal Step Navigation Ribbon (Sticky with Backdrop Blur & Autosave) */}
                        <nav aria-label="Master Profile Steps Stepper" className="step-nav-ribbon step-nav sticky top-0 sm:top-2 z-30 bg-white/95 backdrop-blur-md border border-[var(--cuba-line)]/90 rounded-xl pl-14 sm:pl-4 pr-3 sm:pr-4 py-2 sm:py-2.5 flex items-center justify-between gap-2 shadow-xs transition-all overflow-hidden relative">
                            {/* Scroll Left Button */}
                            <button
                                type="button"
                                onClick={() => scrollSubTabs('left')}
                                className="hidden sm:flex items-center justify-center w-7 h-7 rounded-lg bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-ink)] border border-[var(--cuba-line)] transition-colors shrink-0 cursor-pointer"
                                aria-label="Scroll steps left"
                                title="Scroll left"
                            >
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
                                </svg>
                            </button>

                            {/* Horizontal Steps Container with Tablist ARIA & Keyboard Navigation */}
                            <div
                                ref={subTabsRef}
                                role="tablist"
                                aria-label="Profile Sections"
                                onKeyDown={handleStepperKeyDown}
                                className="flex items-center gap-1.5 overflow-x-auto scroll-smooth no-scrollbar py-0.5 min-w-0 flex-1 focus:outline-none"
                            >
                                {SUB_TAB_ORDER.map((tabKey, index) => {
                                    const conf = SUBTAB_CONFIG[tabKey] || SUBTAB_CONFIG.basic;
                                    const isActive = profileSubTab === tabKey;
                                    const isCompleted = conf.isComplete(profile);
                                    const count = conf.getCount ? conf.getCount(profile) : undefined;

                                    return (
                                        <button
                                            key={tabKey}
                                            type="button"
                                            role="tab"
                                            aria-selected={isActive}
                                            onClick={() => switchProfileSubTab(tabKey)}
                                            className={`step-nav-btn flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                                                isActive
                                                    ? 'bg-[var(--cuba-primary)] text-white shadow-2xs ring-2 ring-[var(--cuba-primary-ring)]/25 font-bold'
                                                    : isCompleted
                                                    ? 'bg-[var(--cuba-success-soft)] text-[var(--cuba-success)] border border-[var(--cuba-success-soft)]/80 hover:bg-[var(--cuba-success-soft)] font-semibold'
                                                    : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] border border-[var(--cuba-line)] hover:bg-[var(--cuba-canvas)] hover:text-[var(--cuba-ink)]'
                                            }`}
                                            aria-current={isActive ? 'step' : undefined}
                                            title={`${conf.name} (${isCompleted ? 'Completed' : 'Pending'}) — Use Left/Right keys to navigate`}
                                        >
                                            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                                isActive
                                                    ? 'bg-white text-[var(--cuba-primary-ink-strong)]'
                                                    : isCompleted
                                                    ? 'bg-[var(--cuba-success)] text-white'
                                                    : 'bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)]'
                                            }`}>
                                                {isCompleted ? '✓' : index + 1}
                                            </span>
                                            <span>{conf.name}</span>
                                            {count !== undefined && count !== 0 && (
                                                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                                                    isActive
                                                        ? 'bg-[var(--cuba-primary-strong)] text-white'
                                                        : isCompleted
                                                        ? 'bg-[var(--cuba-success-soft)]/80 text-[var(--cuba-success)]'
                                                        : 'bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)]'
                                                }`}>
                                                    {count}
                                                </span>
                                            )}
                                        </button>
                                    );
                                })}
                            </div>

                            {/* Scroll Right Button */}
                            <button
                                type="button"
                                onClick={() => scrollSubTabs('right')}
                                className="hidden sm:flex items-center justify-center w-7 h-7 rounded-lg bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-ink)] border border-[var(--cuba-line)] transition-colors shrink-0 cursor-pointer"
                                aria-label="Scroll steps right"
                                title="Scroll right"
                            >
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                                </svg>
                            </button>

                            {/* Stepper Overview Dropdown Trigger & Consolidated Progress Summary (Exact BuildResume Header Matching) */}
                            <div className="flex items-center gap-2 pl-2 border-l border-[var(--cuba-line)] shrink-0 text-xs" ref={stepsDropdownRef}>
                                {/* Live Autosave Status Indicator */}
                                <span className="hidden xl:inline-flex items-center gap-1.5 text-[11px] font-medium text-[var(--cuba-ink-muted)]" title={`Profile Save: ${profileSaveState}`}>
                                    <span className={`w-2 h-2 rounded-full shrink-0 ${
                                        profileSaveState === 'saved'
                                            ? 'bg-[var(--cuba-success)]'
                                            : profileSaveState === 'saving' || profileSaveState === 'pending'
                                            ? 'bg-[var(--cuba-primary)] animate-pulse'
                                            : profileSaveState === 'failed' || profileSaveState === 'conflict'
                                            ? 'bg-[var(--cuba-warning)]'
                                            : 'bg-[var(--cuba-line-strong)]'
                                    }`}></span>
                                    <span className="font-semibold">
                                        {profileSaveState === 'saving'
                                            ? 'Saving…'
                                            : profileSaveState === 'pending'
                                            ? 'Pending…'
                                            : profileSaveState === 'saved'
                                            ? 'Saved'
                                            : profileSaveState === 'conflict'
                                            ? 'Conflict'
                                            : profileSaveState === 'failed'
                                            ? 'Failed'
                                            : 'Loading…'}
                                    </span>
                                </span>

                                {profileSaveState === 'failed' && (
                                    <button
                                        type="button"
                                        onClick={() => persistProfileRef.current?.({ notify: true })}
                                        className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] font-bold rounded-md bg-[var(--cuba-warning)] hover:bg-[var(--cuba-warning)] text-white shadow-xs transition cursor-pointer shrink-0"
                                        title="Retry saving profile"
                                    >
                                        Retry
                                    </button>
                                )}

                                {/* BuildResume Style Stepper Overview Dropdown Button */}
                                <button
                                    type="button"
                                    onClick={() => setShowStepsDropdown(prev => !prev)}
                                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-line)] text-[var(--cuba-ink)] text-xs font-semibold border border-[var(--cuba-line)]/90 transition-all cursor-pointer shadow-2xs"
                                    aria-expanded={showStepsDropdown}
                                    aria-haspopup="dialog"
                                    title="View all profile sections in detail and jump directly without scrolling"
                                >
                                    <span className="w-2 h-2 rounded-full bg-[var(--cuba-success)]"></span>
                                    <span>{completedProfileStepCount} of {SUB_TAB_ORDER.length} complete</span>
                                    <span className="text-[var(--cuba-ink-subtle)]">·</span>
                                    <span className="text-[var(--cuba-primary-ink-strong)] font-bold">{profileProgressPercentage}%</span>
                                    <svg className={`w-3 h-3 text-[var(--cuba-ink-subtle)] transition-transform duration-200 ${showStepsDropdown ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                    </svg>
                                </button>
                            </div>

                            {/* Sleek Gradient Stepper Completion Bar */}
                            <div className="absolute bottom-0 left-0 right-0 h-1 bg-[var(--cuba-canvas)]/80 overflow-hidden" aria-hidden="true">
                                <div
                                    className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500 transition-all duration-500 ease-out"
                                    style={{ width: `${profileProgressPercentage}%` }}
                                />
                            </div>
                        </nav>

                        {/* All 12 Sections Stepper Overview Modal — portaled to <body> for smooth layering without horizontal scrollbar clipping */}
                        {typeof document !== 'undefined' && createPortal(
                            <AnimatePresence>
                                {showStepsDropdown && (
                                    <motion.div
                                        initial={{ opacity: 0 }}
                                        animate={{ opacity: 1 }}
                                        exit={{ opacity: 0 }}
                                        className="fixed inset-0 z-[70] bg-[var(--cuba-ink)]/40 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6"
                                        onClick={() => setShowStepsDropdown(false)}
                                    >
                                        <motion.div
                                            initial={{ scale: 0.95, opacity: 0, y: 10 }}
                                            animate={{ scale: 1, opacity: 1, y: 0 }}
                                            exit={{ scale: 0.95, opacity: 0, y: 10 }}
                                            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                                            className="w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-[var(--cuba-line)]/90 overflow-hidden flex flex-col max-h-[90vh]"
                                            onClick={(e) => e.stopPropagation()}
                                            role="dialog"
                                            aria-modal="true"
                                            aria-label="Profile Sections & Step Overview"
                                        >
                                            {/* Modal Header */}
                                            <div className="px-6 py-5 border-b border-[var(--cuba-line)] flex items-center justify-between bg-[var(--cuba-canvas)]/80">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 rounded-2xl bg-[var(--cuba-primary)] text-white flex items-center justify-center shadow-md shadow-indigo-600/20 font-bold">
                                                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                                        </svg>
                                                    </div>
                                                    <div>
                                                        <h3 className="text-base font-extrabold text-[var(--cuba-ink)] tracking-tight">Profile Sections Overview (12 Sections)</h3>
                                                        <p className="text-xs text-[var(--cuba-ink-subtle)] font-medium">Jump instantly to any section or inspect overall completion</p>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    onClick={() => setShowStepsDropdown(false)}
                                                    className="p-2 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-line)]/60 rounded-xl transition-colors cursor-pointer"
                                                    aria-label="Close overview modal"
                                                >
                                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                                    </svg>
                                                </button>
                                            </div>

                                            {/* Overall Progress Gauge Bar */}
                                            <div className="px-6 py-3 bg-[var(--cuba-primary-soft)]/60 border-b border-[var(--cuba-primary-line)]/60 flex items-center justify-between gap-4">
                                                <div className="flex items-center gap-2 text-xs font-bold text-[var(--cuba-primary-ink-strong)]">
                                                    <span>Overall Completion:</span>
                                                    <span className="text-[var(--cuba-primary-ink-strong)] font-extrabold">{completedProfileStepCount} of {SUB_TAB_ORDER.length} Sections Finished</span>
                                                </div>
                                                <div className="flex items-center gap-3 flex-1 max-w-xs">
                                                    <div className="flex-1 h-2 bg-[var(--cuba-primary-soft)]/80 rounded-full overflow-hidden">
                                                        <div
                                                            className="h-full bg-[var(--cuba-primary)] rounded-full transition-all duration-500"
                                                            style={{ width: `${profileProgressPercentage}%` }}
                                                        ></div>
                                                    </div>
                                                    <span className="text-xs font-black text-[var(--cuba-primary-ink-strong)]">{profileProgressPercentage}%</span>
                                                </div>
                                            </div>

                                            {/* Steps Grid */}
                                            <div className="p-6 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 bg-[var(--cuba-canvas)]/40">
                                                {SUB_TAB_ORDER.map((tabKey, index) => {
                                                    const conf = SUBTAB_CONFIG[tabKey] || SUBTAB_CONFIG.basic;
                                                    const isActive = profileSubTab === tabKey;
                                                    const isCompleted = conf.isComplete(profile);
                                                    const count = conf.getCount ? conf.getCount(profile) : undefined;

                                                    return (
                                                        <button
                                                            key={tabKey}
                                                            type="button"
                                                            onClick={() => {
                                                                switchProfileSubTab(tabKey);
                                                                setShowStepsDropdown(false);
                                                            }}
                                                            className={`p-3.5 rounded-2xl border text-left transition-all duration-150 flex flex-col justify-between gap-2.5 cursor-pointer shadow-2xs hover:shadow-md ${
                                                                isActive
                                                                    ? 'bg-[var(--cuba-primary)] text-white border-[var(--cuba-primary-line)] ring-2 ring-[var(--cuba-primary-ring)]/25 shadow-md'
                                                                    : isCompleted
                                                                    ? 'bg-white text-[var(--cuba-ink)] border-[var(--cuba-success-soft)]/90 hover:border-[var(--cuba-success)]'
                                                                    : 'bg-white text-[var(--cuba-ink-muted)] border-[var(--cuba-line)] hover:border-[var(--cuba-line-strong)]'
                                                            }`}
                                                        >
                                                            <div className="flex items-center justify-between w-full">
                                                                <div className="flex items-center gap-2">
                                                                    <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold ${
                                                                        isActive
                                                                            ? 'bg-white/20 text-white'
                                                                            : isCompleted
                                                                            ? 'bg-[var(--cuba-success)] text-white'
                                                                            : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-subtle)]'
                                                                    }`}>
                                                                        {isCompleted ? '✓' : index + 1}
                                                                    </span>
                                                                    <span className={`text-xs font-bold truncate ${isActive ? 'text-white' : 'text-[var(--cuba-ink)]'}`}>
                                                                        {conf.name}
                                                                    </span>
                                                                </div>
                                                                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                                                                    isActive
                                                                        ? 'bg-white text-[var(--cuba-primary-ink-strong)]'
                                                                        : isCompleted
                                                                        ? 'bg-[var(--cuba-success-soft)] text-[var(--cuba-success)] border border-[var(--cuba-success-soft)]'
                                                                        : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-subtle)]'
                                                                }`}>
                                                                    {isActive ? 'Current' : isCompleted ? 'Completed' : 'Pending'}
                                                                </span>
                                                            </div>

                                                            <p className={`text-[11px] line-clamp-1 ${isActive ? 'text-[var(--cuba-ink-inverse)]' : 'text-[var(--cuba-ink-subtle)]'}`}>
                                                                {count !== undefined && count > 0 ? `${count} ${count === 1 ? 'entry' : 'entries'} saved` : conf.description || (isCompleted ? 'Finished & verified' : 'Needs information')}
                                                            </p>
                                                        </button>
                                                    );
                                                })}
                                            </div>

                                            {/* Modal Footer */}
                                            <div className="px-6 py-4 bg-white border-t border-[var(--cuba-line)] flex items-center justify-between">
                                                <span className="text-xs text-[var(--cuba-ink-subtle)] font-medium">Click any section to jump directly</span>
                                                <button
                                                    type="button"
                                                    onClick={() => setShowStepsDropdown(false)}
                                                    className="px-5 py-2 bg-[var(--cuba-ink)] hover:bg-[var(--cuba-ink)] text-white text-xs font-bold rounded-xl transition-all shadow-2xs cursor-pointer"
                                                >
                                                    Close Overview
                                                </button>
                                            </div>
                                        </motion.div>
                                    </motion.div>
                                )}
                            </AnimatePresence>,
                            document.body
                        )}

                        {/* 2-Column Responsive Workspace Grid */}
                        <div className={`grid grid-cols-1 ${showProfileGuidanceRail ? 'lg:grid-cols-12' : ''} gap-5 items-start`}>
                            {/* Left Column: Form & StepShell */}
                            <div className={`${showProfileGuidanceRail ? 'lg:col-span-8 xl:col-span-9' : 'w-full'} min-w-0 space-y-4`}>
                                
                                {/* StepShell Header Card (Identical to Build Resume) */}
                                {(() => {
                                    const activeConf = SUBTAB_CONFIG[profileSubTab] || SUBTAB_CONFIG.basic;
                                    const stepIdx = SUB_TAB_ORDER.indexOf(profileSubTab);
                                    const isComp = activeConf.isComplete(profile);
                                    const badgeText = typeof activeConf.statusBadge === 'function' ? activeConf.statusBadge(profile) : activeConf.statusBadge;

                                    return (
                                        <header className="rounded-xl border border-[var(--cuba-line)] bg-white px-4 py-3.5 sm:px-5 shadow-2xs">
                                            <div className="flex items-center justify-between gap-3 min-w-0">
                                                <div className="flex items-center gap-3 min-w-0 flex-1">
                                                    <div
                                                        className={`flex h-8 w-8 sm:h-9 sm:w-9 shrink-0 items-center justify-center rounded-lg text-xs sm:text-sm font-bold ${
                                                            isComp ? 'bg-[var(--cuba-success)] text-white' : 'bg-[var(--cuba-ink)] text-white'
                                                        }`}
                                                        aria-label={`Step ${stepIdx + 1} of 12`}
                                                    >
                                                        {isComp ? <FaCheck className="w-3.5 h-3.5" /> : stepIdx + 1}
                                                    </div>
                                                    <div className="min-w-0 flex-1">
                                                        <div className="flex flex-wrap items-center gap-2">
                                                            <h1 className="text-sm sm:text-base font-bold tracking-tight text-[var(--cuba-ink)]">{activeConf.title}</h1>
                                                            {badgeText ? (
                                                                <span className="rounded-md border border-[var(--cuba-line)] bg-[var(--cuba-canvas)] px-2 py-0.5 text-[11px] font-semibold text-[var(--cuba-ink-muted)]">
                                                                    {badgeText}
                                                                </span>
                                                            ) : null}
                                                            <span
                                                                className={`rounded-md border px-2 py-0.5 text-[10px] font-bold ${
                                                                    isComp
                                                                        ? 'border-[var(--cuba-success-soft)] bg-[var(--cuba-success-soft)] text-[var(--cuba-success)]'
                                                                        : 'border-[var(--cuba-warning-soft)] bg-[var(--cuba-warning-soft)] text-[var(--cuba-warning)]'
                                                                }`}
                                                            >
                                                                {isComp ? 'Complete' : 'In progress'}
                                                            </span>
                                                        </div>
                                                        {activeConf.subtitle ? (
                                                            <p className="mt-0.5 text-xs leading-relaxed text-[var(--cuba-ink-subtle)] max-w-2xl">{activeConf.subtitle}</p>
                                                        ) : null}
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2 shrink-0">
                                                    <button
                                                        type="button"
                                                        onClick={() => setShowProfileGuidanceRail(prev => !prev)}
                                                        className="hidden lg:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-[var(--cuba-line)] bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] text-xs font-semibold transition-colors cursor-pointer"
                                                        title={showProfileGuidanceRail ? 'Collapse Guide' : 'Expand Guide'}
                                                    >
                                                        <span>{showProfileGuidanceRail ? 'Hide Guide' : 'Show Guide'}</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </header>
                                    );
                                })()}

                                {/* Subtab Form Card */}
                                <div className="bg-white rounded-xl border border-[var(--cuba-line)] p-4 sm:p-6 shadow-2xs space-y-5">

                        {/* Sub-Tab 1: Basic Details & Social Links — Styled after HeadingStep */}
                        {profileSubTab === 'basic' && (
                            <div className="space-y-5">
                                {/* Identity: Photo Upload + Name & Title */}
                                <div className="space-y-3">
                                    <div className="flex flex-col sm:flex-row gap-4 sm:gap-5 items-start">
                                        {/* Photo Upload Area - Compact, matching HeadingStep */}
                                        <div className="shrink-0 pt-0.5 self-center sm:self-start">
                                            <div className="space-y-1.5">
                                                <label className="block text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                    Profile Photo
                                                </label>
                                                <div
                                                    className={`w-24 h-24 sm:w-28 sm:h-28 rounded-xl border-2 overflow-hidden relative group transition-all duration-200 flex items-center justify-center ${
                                                        isDragging ? 'border-[var(--cuba-primary-line)] bg-[var(--cuba-primary-soft)]/50' : 'border-[var(--cuba-line)] bg-[var(--cuba-canvas)] shadow-2xs hover:border-[var(--cuba-line-strong)]'
                                                    }`}
                                                    onDragOver={handleDragOver}
                                                    onDragLeave={handleDragLeave}
                                                    onDrop={handleDrop}>
                                                    {profile.selectedImage ? (
                                                        <>
                                                            <img src={profile.selectedImage} alt="Avatar" className="w-full h-full object-cover" />
                                                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 rounded-xl flex items-center justify-center gap-1.5">
                                                                <button
                                                                    type="button"
                                                                    onClick={() => setCropModalSrc(profile.selectedImage)}
                                                                    className="p-1.5 bg-white rounded-full hover:bg-[var(--cuba-canvas)] transition-all text-[var(--cuba-primary-ink-strong)] shadow-xs"
                                                                    title="Crop & Adjust Photo">
                                                                    <FaCrop className="w-3 h-3" />
                                                                </button>
                                                                <label className="p-1.5 bg-white rounded-full hover:bg-[var(--cuba-canvas)] transition-all text-[var(--cuba-ink-muted)] shadow-xs cursor-pointer" title="Change photo">
                                                                    <input type="file" onChange={handleImageUpload} className="sr-only" accept="image/png,image/jpeg,image/webp" />
                                                                    <FaUpload className="w-3 h-3" />
                                                                </label>
                                                            </div>
                                                        </>
                                                    ) : (
                                                        <label className="w-full h-full flex flex-col items-center justify-center p-2 text-center cursor-pointer hover:bg-[var(--cuba-primary-soft)]/50 transition-colors">
                                                            <input type="file" onChange={handleImageUpload} className="sr-only" accept="image/png,image/jpeg,image/webp" />
                                                            <div className="w-9 h-9 rounded-full bg-[var(--cuba-line)] flex items-center justify-center text-[var(--cuba-ink-muted)] font-bold text-sm mb-1">
                                                                {candidateFullName ? candidateFullName.charAt(0).toUpperCase() : <FaUpload className="w-3.5 h-3.5 text-[var(--cuba-ink-subtle)]" />}
                                                            </div>
                                                            <span className="text-[10px] font-bold text-[var(--cuba-primary-ink-strong)]">Upload</span>
                                                            <span className="text-[9px] text-[var(--cuba-ink-subtle)]">{isDragging ? 'Drop here' : 'PNG, JPG'}</span>
                                                        </label>
                                                    )}
                                                </div>
                                            </div>
                                        </div>

                                        {/* Name & Target Occupation */}
                                        <div className="flex-1 min-w-0 w-full space-y-3">
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                                <div>
                                                    <label className="mb-1.5 flex items-baseline gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                        <span>First Name</span>
                                                        <span aria-hidden="true" className="text-[var(--cuba-danger)] font-medium">*</span>
                                                    </label>
                                                    <input
                                                        type="text"
                                                        name="firstname"
                                                        value={profile.firstname}
                                                        onChange={handleInputChange}
                                                        placeholder="Your first name"
                                                        className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                                    />
                                                </div>
                                                <div>
                                                    <label className="mb-1.5 flex items-baseline gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                        <span>Last Name</span>
                                                        <span aria-hidden="true" className="text-[var(--cuba-danger)] font-medium">*</span>
                                                    </label>
                                                    <input
                                                        type="text"
                                                        name="lastname"
                                                        value={profile.lastname}
                                                        onChange={handleInputChange}
                                                        placeholder="Your last name"
                                                        className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                                    />
                                                </div>
                                            </div>
                                            <div>
                                                <AutocompleteInputField
                                                    label="Target Professional Title / Occupation"
                                                    name="occupation"
                                                    value={profile.occupation}
                                                    onChange={handleInputChange}
                                                    placeholder="e.g. Senior Full Stack Engineer"
                                                    suggestionType="jobTitle"
                                                    inputClassName="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                                    labelClassName="mb-1.5 flex items-baseline gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Contact & Location */}
                                <div className="space-y-3 border-t border-[var(--cuba-line)] pt-4">
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        <div>
                                            <div className="mb-1.5 flex items-baseline justify-between gap-1.5">
                                                <label className="text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                    <span>Email Address (Identity)</span>
                                                    <span aria-hidden="true" className="text-[var(--cuba-danger)] font-medium ml-1">*</span>
                                                </label>
                                                <button
                                                    type="button"
                                                    onClick={() => { setSelectedSettings('Account'); navigate('?tab=Account', { replace: true }); }}
                                                    className="text-[11px] font-semibold text-[var(--cuba-primary-ink-strong)] hover:text-[var(--cuba-primary-ink-strong)] transition-colors cursor-pointer flex items-center gap-1"
                                                    title="Switch to Account & Security to update primary email"
                                                >
                                                    <span>Managed in Account</span>
                                                    <span aria-hidden="true">→</span>
                                                </button>
                                            </div>
                                            <input
                                                type="email"
                                                name="email"
                                                value={fire.auth().currentUser?.email || profile.email || ''}
                                                readOnly
                                                disabled
                                                className="w-full rounded-lg border border-[var(--cuba-line)] bg-[var(--cuba-canvas)] px-3 py-2 text-sm text-[var(--cuba-ink-subtle)] shadow-2xs cursor-not-allowed select-none"
                                            />
                                        </div>
                                        <div>
                                            <label className="mb-1.5 flex items-baseline gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                <span>Phone Number</span>
                                                <span aria-hidden="true" className="text-[var(--cuba-danger)] font-medium">*</span>
                                            </label>
                                            <input
                                                type="text"
                                                name="phone"
                                                value={profile.phone}
                                                onChange={handleInputChange}
                                                placeholder="With country code, e.g. +91 98765 43210"
                                                className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                            />
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        <div>
                                            <AutocompleteInputField
                                                label="City & State"
                                                name="city"
                                                value={profile.city}
                                                onChange={(e) => handleInputChange({ target: { name: 'city', value: e.target.value } })}
                                                onSelect={(val) => handleInputChange({ target: { name: 'city', value: val } })}
                                                placeholder="City, State"
                                                suggestionType="city"
                                                inputClassName="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                                labelClassName="mb-1.5 flex items-baseline gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]"
                                            />
                                        </div>
                                        <div>
                                            <label className="mb-1.5 flex items-baseline gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                <span>Country</span>
                                                <span className="text-[11px] font-medium text-[var(--cuba-ink-subtle)]">optional</span>
                                            </label>
                                            <input
                                                type="text"
                                                name="country"
                                                value={profile.country}
                                                onChange={handleInputChange}
                                                placeholder="Country (e.g. India)"
                                                spellCheck="false"
                                                className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* Online Presence & Address */}
                                <div className="space-y-3 border-t border-[var(--cuba-line)] pt-4">
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        <div>
                                            <label className="mb-1.5 flex items-baseline gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                <span>Street Address</span>
                                                <span className="text-[11px] font-medium text-[var(--cuba-ink-subtle)]">optional</span>
                                            </label>
                                            <input
                                                type="text"
                                                name="address"
                                                value={profile.address}
                                                onChange={handleInputChange}
                                                placeholder="Street address"
                                                className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                            />
                                        </div>
                                        <div>
                                            <label className="mb-1.5 flex items-baseline gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                <span>Postal Code</span>
                                                <span className="text-[11px] font-medium text-[var(--cuba-ink-subtle)]">optional</span>
                                            </label>
                                            <input
                                                type="text"
                                                name="postalCode"
                                                value={profile.postalCode}
                                                onChange={handleInputChange}
                                                placeholder="PIN / postal code"
                                                className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                            />
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        <div>
                                            <label className="mb-1.5 flex items-center gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                <FaLinkedin className="w-3.5 h-3.5 text-[var(--cuba-info)] shrink-0" />
                                                <span>LinkedIn Profile URL</span>
                                                <span className="text-[11px] font-medium text-[var(--cuba-ink-subtle)]">optional</span>
                                            </label>
                                            <input
                                                type="url"
                                                name="linkedinUrl"
                                                value={profile.linkedinUrl}
                                                onChange={handleInputChange}
                                                placeholder="https://linkedin.com/in/username"
                                                className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                            />
                                        </div>
                                        <div>
                                            <label className="mb-1.5 flex items-center gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                <FaGithub className="w-3.5 h-3.5 text-[var(--cuba-ink)] shrink-0" />
                                                <span>GitHub / Portfolio URL</span>
                                                <span className="text-[11px] font-medium text-[var(--cuba-ink-subtle)]">optional</span>
                                            </label>
                                            <input
                                                type="url"
                                                name="githubUrl"
                                                value={profile.githubUrl}
                                                onChange={handleInputChange}
                                                placeholder="https://github.com/username"
                                                className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="mb-1.5 flex items-center gap-1.5 text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                            <FaGlobe className="w-3.5 h-3.5 text-[var(--cuba-primary-ink-strong)] shrink-0" />
                                            <span>Personal Website / Portfolio URL</span>
                                            <span className="text-[11px] font-medium text-[var(--cuba-ink-subtle)]">optional</span>
                                        </label>
                                        <input
                                            type="url"
                                            name="websiteUrl"
                                            value={profile.websiteUrl}
                                            onChange={handleInputChange}
                                            placeholder="https://yourwebsite.com"
                                            className="w-full rounded-lg border border-[var(--cuba-line)] bg-white px-3 py-2 text-sm text-[var(--cuba-ink)] shadow-2xs transition-colors placeholder:text-[var(--cuba-ink-subtle)] focus:outline-none focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 font-normal"
                                        />
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Sub-Tab 2: Professional Bio / source-grounded summary rewrite */}
                        {profileSubTab === 'summary' && (() => {
                            const plainBio = stripHtml(profile.summary || '').trim();
                            const bioCharCount = plainBio.length;
                            const bioWordCount = plainBio ? plainBio.split(/\s+/).filter(Boolean).length : 0;
                            const getBioProgress = () => {
                                if (bioCharCount === 0) return { text: 'Empty', color: 'text-[var(--cuba-ink-subtle)]', bar: 'bg-[var(--cuba-line)]' };
                                if (bioCharCount < 100) return { text: 'Getting started', color: 'text-[var(--cuba-warning)]', bar: 'bg-[var(--cuba-warning)]' };
                                if (bioCharCount <= 450) return { text: 'Good length', color: 'text-[var(--cuba-success)]', bar: 'bg-[var(--cuba-success)]' };
                                return { text: 'Long — consider trimming', color: 'text-[var(--cuba-warning)]', bar: 'bg-[var(--cuba-warning)]' };
                            };
                            const bioProgress = getBioProgress();

                            const bioRolesCount = (profile.workExperiences || []).length;
                            const bioSkillsCount = (profile.skills || []).length;
                            const bioEduCount = (profile.education || []).length;
                            const bioCertsCount = (profile.certifications || []).length;
                            const bioYearsExp = calculateYearsOfExperience(profile.workExperiences || []);

                            const handleCopyBio = () => {
                                if (!plainBio) return;
                                navigator.clipboard.writeText(plainBio).then(() => {
                                    setBioCopied(true);
                                    triggerNotification('Executive Bio copied to clipboard!');
                                    setTimeout(() => setBioCopied(false), 2000);
                                }).catch(() => {
                                    triggerNotification('Failed to copy to clipboard', 'error');
                                });
                            };

                            return (
                                <div className="space-y-5">
                                    {/* Header & Character Progress Meter */}
                                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                        <div>
                                            <h3 className="text-base font-bold text-[var(--cuba-ink)] tracking-tight">Executive Bio &amp; Professional Summary</h3>
                                            <p className="text-xs text-[var(--cuba-ink-subtle)] mt-0.5">Synthesizes your verified career history, education, skills, and projects into an authoritative executive overview for all resumes.</p>
                                        </div>
                                        <div className="flex items-center gap-2.5 shrink-0 rounded-xl border border-[var(--cuba-line)] bg-[var(--cuba-canvas)] px-3 py-1.5 shadow-2xs">
                                            <div className="w-24 bg-[var(--cuba-line)] rounded-full h-1.5 overflow-hidden">
                                                <div
                                                    className={`h-full ${bioProgress.bar} transition-all duration-300`}
                                                    style={{ width: `${Math.min(100, (bioCharCount / 400) * 100)}%` }}
                                                />
                                            </div>
                                            <span className={`text-[11px] font-bold ${bioProgress.color}`}>{bioCharCount}/400 · {bioProgress.text}</span>
                                        </div>
                                    </div>

                                    {/* Action Toolbar: Tone Selector + AI Generator + Copy + Clear */}
                                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 bg-[var(--cuba-canvas)] p-2.5 rounded-xl border border-[var(--cuba-line)]/80">
                                        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }} role="group" aria-label="Tone preference">
                                            <span className="text-[11px] font-bold text-[var(--cuba-ink-subtle)] uppercase tracking-wider mr-1 shrink-0">Tone:</span>
                                            {['balanced', 'concise', 'technical', 'executive'].map((toneKey) => (
                                                <button
                                                    key={toneKey}
                                                    type="button"
                                                    onClick={() => setSummaryTone(toneKey)}
                                                    aria-pressed={summaryTone === toneKey}
                                                    className={`px-2.5 py-1 rounded-lg text-xs font-bold capitalize transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                                                        summaryTone === toneKey
                                                            ? 'bg-[var(--cuba-primary)] text-white shadow-2xs'
                                                            : 'bg-white text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-canvas)] border border-[var(--cuba-line)]'
                                                    }`}>
                                                    {toneKey.replace('-', ' ')}
                                                </button>
                                            ))}
                                        </div>
                                        <div className="flex items-center gap-2 shrink-0 flex-wrap sm:flex-nowrap">
                                            {bioCharCount > 0 && (
                                                <>
                                                    <button
                                                        type="button"
                                                        onClick={handleCopyBio}
                                                        title="Copy Executive Bio to clipboard"
                                                        className="px-2.5 py-2 bg-white hover:bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] text-[var(--cuba-ink-muted)] rounded-lg text-xs font-semibold transition-all shadow-2xs flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                                                    >
                                                        {bioCopied ? <FaCheck className="w-3.5 h-3.5 text-[var(--cuba-success)]" /> : <FaCopy className="w-3.5 h-3.5 text-[var(--cuba-ink-subtle)]" />}
                                                        <span>{bioCopied ? 'Copied!' : 'Copy'}</span>
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={() => setShowClearBioConfirm(true)}
                                                        title="Clear Executive Bio"
                                                        className="p-2 bg-white hover:bg-[var(--cuba-danger-soft)] border border-[var(--cuba-line)] hover:border-[var(--cuba-danger-soft)] text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] rounded-lg text-xs font-semibold transition-all shadow-2xs flex items-center justify-center shrink-0 cursor-pointer"
                                                    >
                                                        <FaTrash className="w-3.5 h-3.5" />
                                                    </button>
                                                </>
                                            )}
                                            <button
                                                type="button"
                                                onClick={handleWriteAiSummary}
                                                disabled={isAiGenerating}
                                                title="Synthesize profile history into an authoritative Executive Bio"
                                                className="w-full sm:w-auto whitespace-nowrap px-4 py-2 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-lg text-xs font-bold transition-all shadow-2xs flex items-center justify-center gap-2 shrink-0 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed">
                                                <FaMagic className={`w-3.5 h-3.5 ${isAiGenerating ? 'animate-spin' : ''}`} />
                                                <span>{isAiGenerating ? 'Generating Bio...' : 'Generate Executive Bio (AI)'}</span>
                                            </button>
                                        </div>
                                    </div>

                                    {/* Career Evidence Digest Badge */}
                                    <div className="flex items-center gap-2 text-xs text-[var(--cuba-ink-subtle)] flex-wrap">
                                        <span className="inline-flex items-center gap-1.5 font-semibold text-[var(--cuba-ink-muted)] bg-[var(--cuba-canvas)] px-2.5 py-1 rounded-lg">
                                            <FaBolt className="w-3 h-3 text-[var(--cuba-warning)]" />
                                            <span>Synthesizes:</span>
                                        </span>
                                        <span>
                                            {bioYearsExp ? <strong className="text-[var(--cuba-ink-muted)]">{bioYearsExp} yrs exp · </strong> : null}
                                            <strong className="text-[var(--cuba-ink-muted)]">{bioRolesCount}</strong> {bioRolesCount === 1 ? 'position' : 'positions'} ·{' '}
                                            <strong className="text-[var(--cuba-ink-muted)]">{bioSkillsCount}</strong> skills
                                            {bioEduCount > 0 ? <> · <strong className="text-[var(--cuba-ink-muted)]">{bioEduCount}</strong> {bioEduCount === 1 ? 'degree' : 'degrees'}</> : null}
                                            {bioCertsCount > 0 ? <> · <strong className="text-[var(--cuba-ink-muted)]">{bioCertsCount}</strong> credentials</> : null}
                                        </span>
                                    </div>

                                    {/* Clear Confirmation Dialog */}
                                    {showClearBioConfirm && (
                                        <div className="p-3.5 rounded-xl bg-[var(--cuba-warning-soft)] border border-[var(--cuba-warning-soft)] text-[var(--cuba-warning)] text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in duration-200">
                                            <span className="font-semibold">Clear your Executive Bio from Master Profile?</span>
                                            <div className="flex items-center gap-2 shrink-0">
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        setProfile(prev => ({ ...prev, summary: '' }));
                                                        setShowClearBioConfirm(false);
                                                        triggerNotification('Executive Bio cleared.');
                                                    }}
                                                    className="px-3 py-1.5 bg-[var(--cuba-warning)] hover:bg-[var(--cuba-warning)] text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                                                >
                                                    Confirm Clear
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={() => setShowClearBioConfirm(false)}
                                                    className="px-3 py-1.5 bg-white hover:bg-[var(--cuba-warning-soft)]/60 border border-[var(--cuba-warning-soft)] text-[var(--cuba-warning)] rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                                                >
                                                    Cancel
                                                </button>
                                            </div>
                                        </div>
                                    )}

                                    {/* AI Review / Draft Gate (Invariant 7: Zero Silent Overwrites) */}
                                    {summaryAiDraft !== null && (
                                        <div className="p-4 rounded-xl border border-[var(--cuba-primary-line)] bg-gradient-to-br from-indigo-50/70 via-purple-50/40 to-white shadow-xs space-y-3 animate-in fade-in duration-200">
                                            <div className="flex items-center justify-between gap-2 border-b border-[var(--cuba-primary-line)] pb-2.5">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-6 h-6 rounded-lg bg-[var(--cuba-primary)] text-white flex items-center justify-center shadow-2xs">
                                                        <FaMagic className="w-3 h-3" />
                                                    </div>
                                                    <div>
                                                        <h4 className="text-xs font-bold text-[var(--cuba-ink)]">AI Executive Bio Draft</h4>
                                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)]">Synthesized from your verified profile facts · Editable before applying</p>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    onClick={() => setSummaryAiDraft(null)}
                                                    className="text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)] p-1 rounded-lg hover:bg-[var(--cuba-canvas)] transition-colors cursor-pointer"
                                                    title="Dismiss draft"
                                                >
                                                    <FaTimes className="w-3.5 h-3.5" />
                                                </button>
                                            </div>
                                            <textarea
                                                value={summaryAiDraft}
                                                onChange={(e) => setSummaryAiDraft(e.target.value)}
                                                rows={4}
                                                className="w-full text-xs p-3 bg-white border border-[var(--cuba-primary-line)] rounded-lg font-sans leading-relaxed text-[var(--cuba-ink)] shadow-2xs focus:border-[var(--cuba-primary-line)] focus:ring-1 focus:ring-[var(--cuba-primary-ring)] focus:outline-none"
                                                placeholder="Review and edit the AI draft..."
                                            />
                                            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 pt-1">
                                                <span className="text-[11px] text-[var(--cuba-ink-subtle)] font-medium">
                                                    {stripHtml(summaryAiDraft).length} characters · {summaryAiDraft.trim().split(/\s+/).filter(Boolean).length} words
                                                </span>
                                                <div className="flex items-center gap-2">
                                                    <button
                                                        type="button"
                                                        onClick={handleWriteAiSummary}
                                                        disabled={isAiGenerating}
                                                        className="px-3 py-1.5 bg-white hover:bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] text-[var(--cuba-ink-muted)] rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
                                                    >
                                                        <FaSyncAlt className={`w-3 h-3 ${isAiGenerating ? 'animate-spin' : ''}`} />
                                                        <span>Regenerate</span>
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            const clean = summaryAiDraft.trim();
                                                            setProfile(prev => ({ ...prev, summary: clean }));
                                                            setSummaryAiDraft(null);
                                                            triggerNotification('Executive Bio applied to Master Profile!');
                                                        }}
                                                        className="px-3.5 py-1.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-lg text-xs font-bold transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
                                                    >
                                                        <FaCheck className="w-3 h-3" />
                                                        <span>Apply Bio to Profile</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* Editor Textarea Container */}
                                    <div className="space-y-1.5">
                                        <textarea
                                            name="summary"
                                            value={profile.summary}
                                            onChange={handleInputChange}
                                            spellCheck="true"
                                            rows={7}
                                            placeholder="Who you are professionally, what you have done, and what you do well — in your own words."
                                            className="w-full text-sm p-3.5 bg-white border border-[var(--cuba-line)] rounded-lg font-sans leading-relaxed text-[var(--cuba-ink)] shadow-2xs focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/25 focus:outline-none"
                                        />
                                        <div className="flex items-center justify-between text-[11px] text-[var(--cuba-ink-subtle)] px-1 font-medium">
                                            <span>{bioWordCount} words</span>
                                            <span>Recommended: 2–4 sentences (50–90 words)</span>
                                        </div>
                                    </div>

                                    {/* Empty State Informational Helper */}
                                    {bioCharCount === 0 && (
                                        <div className="p-3.5 rounded-xl border border-dashed border-[var(--cuba-line)] bg-[var(--cuba-canvas)]/60 text-[var(--cuba-ink-subtle)] text-xs flex items-start gap-2.5">
                                            <FaBolt className="w-4 h-4 text-[var(--cuba-primary-ink-strong)] shrink-0 mt-0.5" />
                                            <div className="space-y-0.5">
                                                <p className="font-semibold text-[var(--cuba-ink-muted)]">Lifelong Master Executive Bio</p>
                                                <p className="text-[11px] text-[var(--cuba-ink-subtle)]">Your Master Executive Bio automatically pre-populates all new resumes and can be imported with 1-click in the resume builder. Use the AI button above to synthesize your profile history into an authentic overview.</p>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            );
                        })()}

                        {/* Sub-Tab 3: Work History Array */}
                        {profileSubTab === 'experience' && (
                            <div className="space-y-6">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Work History & Past Positions</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Add past employment details to pre-populate all future resumes automatically.</p>
                                    </div>
                                    <button type="button" onClick={addWorkExperience} className="w-full sm:w-auto whitespace-nowrap flex-shrink-0 px-3.5 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs">
                                        <FaPlus className="w-3 h-3" /> Add Position
                                    </button>
                                </div>

                                {profile.workExperiences.length === 0 ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl">
                                        <p className="text-xs font-semibold text-[var(--cuba-ink-muted)] mb-1">No work history saved in Master Profile</p>
                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)] mb-4">Click "Add Position" above or sync LinkedIn to store your experience once for all resumes.</p>
                                    </div>
                                ) : (
                                    profile.workExperiences.map((job, idx) => (
                                        <div key={job.id || idx} className="p-5 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)]/90 rounded-2xl space-y-4">
                                            <div className="flex items-center justify-between border-b border-[var(--cuba-line)]/60 pb-2">
                                                <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--cuba-ink-subtle)]">
                                                    Position #{idx + 1}
                                                </span>
                                                <div className="flex items-center gap-1">
                                                    <button
                                                        type="button"
                                                        disabled={idx === 0}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('workExperiences', idx, -1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 disabled:hover:text-[var(--cuba-ink-subtle)] rounded-lg hover:bg-[var(--cuba-line)]/70 transition-all cursor-pointer text-xs font-bold"
                                                        title="Move position up">
                                                        ▲
                                                    </button>
                                                    <button
                                                        type="button"
                                                        disabled={idx === profile.workExperiences.length - 1}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('workExperiences', idx, 1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 disabled:hover:text-[var(--cuba-ink-subtle)] rounded-lg hover:bg-[var(--cuba-line)]/70 transition-all cursor-pointer text-xs font-bold"
                                                        title="Move position down">
                                                        ▼
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); duplicateWorkExperience(idx); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] rounded-lg hover:bg-[var(--cuba-primary-soft)] cursor-pointer ml-1"
                                                        title="Duplicate position">
                                                        <FaCopy className="w-3.5 h-3.5" />
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeWorkExperience(idx); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] transition-colors rounded-lg hover:bg-[var(--cuba-danger-soft)] cursor-pointer ml-1"
                                                        title="Delete position">
                                                        <FaTrash className="w-3.5 h-3.5" />
                                                    </button>
                                                </div>
                                            </div>
                                            {/* Row 1: Primary Details */}
                                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                                <div className="pr-8 sm:pr-0">
                                                    <AutocompleteInputField
                                                        label="Job Title"
                                                        name="jobTitle"
                                                        value={job.jobTitle}
                                                        onChange={(e) => updateWorkExperience(idx, 'jobTitle', e.target.value)}
                                                        placeholder="e.g. Senior Developer"
                                                        suggestionType="jobTitle"
                                                        inputClassName="w-full text-xs p-2.5 pr-8 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                        labelClassName="block text-[11px] font-bold text-[var(--cuba-ink-muted)] mb-1"
                                                    />
                                                </div>
                                                <div>
                                                    <AutocompleteInputField
                                                        label="Company Name"
                                                        name="company"
                                                        value={job.company}
                                                        onChange={(e) => updateWorkExperience(idx, 'company', e.target.value)}
                                                        placeholder="e.g. TechCorp"
                                                        suggestionType="company"
                                                        inputClassName="w-full text-xs p-2.5 pr-8 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                        labelClassName="block text-[11px] font-bold text-[var(--cuba-ink-muted)] mb-1"
                                                    />
                                                </div>
                                                <div className="sm:pr-8">
                                                    <AutocompleteInputField
                                                        label="City / Location"
                                                        name="city"
                                                        value={job.city || ''}
                                                        onChange={(e) => updateWorkExperience(idx, 'city', e.target.value)}
                                                        onSelect={(val) => updateWorkExperience(idx, 'city', val)}
                                                        placeholder="e.g. Visakhapatnam, India"
                                                        suggestionType="city"
                                                        inputClassName="w-full text-xs p-2.5 pr-8 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                        labelClassName="block text-[11px] font-bold text-[var(--cuba-ink-muted)] mb-1"
                                                    />
                                                </div>
                                            </div>

                                            {/* Row 2: Duration Dates */}
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl">
                                                <div>
                                                    <MonthYearPicker
                                                        label="Start Date"
                                                        value={job.startDate}
                                                        onChange={(val) => updateWorkExperience(idx, 'startDate', val)}
                                                    />
                                                </div>
                                                <div>
                                                    <MonthYearPicker
                                                        label="End Date"
                                                        value={job.endDate || (job.startDate && job.startDate.includes('Present') ? 'Present' : '')}
                                                        onChange={(val) => updateWorkExperience(idx, 'endDate', val)}
                                                        showPresentCheck
                                                        isCurrent={job.current || job.endDate === 'Present'}
                                                        onCurrentChange={(isCur) => {
                                                            updateWorkExperience(idx, 'current', isCur);
                                                            if (isCur) updateWorkExperience(idx, 'endDate', 'Present');
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                            <div>
                                                <div className="flex items-center justify-between mb-2">
                                                    <label className="block text-xs font-bold text-[var(--cuba-ink)]">Responsibilities &amp; Accomplishments</label>
                                                    <button
                                                        type="button"
                                                        onClick={() => handleEnhanceWorkDescriptionWithAi(idx)}
                                                        disabled={isAiGenerating || !job.jobTitle}
                                                        className="px-2.5 py-1 text-[11px] font-bold text-[var(--cuba-primary-ink-strong)] hover:text-[var(--cuba-primary-ink-strong)] bg-[var(--cuba-primary-soft)] hover:bg-[var(--cuba-primary-soft)] border border-[var(--cuba-primary-line)] rounded-lg transition-all flex items-center gap-1 shadow-2xs cursor-pointer disabled:opacity-50">
                                                        <FaMagic className={`w-3 h-3 text-[var(--cuba-primary-ink-strong)] ${isAiGenerating ? 'animate-spin' : ''}`} />
                                                        <span>Enhance Bullets (AI)</span>
                                                    </button>
                                                </div>
                                                <BulletPointsEditor
                                                    value={job.description}
                                                    onChange={(val) => updateWorkExperience(idx, 'description', val)}
                                                    jobTitle={job.jobTitle}
                                                    company={job.company}
                                                    location={job.location}
                                                    placeholder={getRolePlaceholder(job.jobTitle)}
                                                />
                                            </div>
                                        </div>
                                    ))
                                )}

                                {profile.workExperiences.length > 0 && (
                                    <div className="pt-2">
                                        <button type="button" onClick={addWorkExperience} className="w-full py-3 bg-[var(--cuba-primary-soft)] hover:bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-primary-line)] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-2xs">
                                            <FaPlus className="w-3.5 h-3.5" /> Add Position
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Sub-Tab 4: Education Array */}
                        {profileSubTab === 'education' && (
                            <div className="space-y-6">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Education & Academic Degrees</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Save degrees to automatically populate education sections in resumes.</p>
                                    </div>
                                    <button type="button" onClick={addEducation} className="w-full sm:w-auto whitespace-nowrap flex-shrink-0 px-3.5 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs">
                                        <FaPlus className="w-3 h-3" /> Add Degree
                                    </button>
                                </div>

                                {profile.education.length === 0 ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl">
                                        <p className="text-xs font-semibold text-[var(--cuba-ink-muted)] mb-1">No education entries saved in Master Profile</p>
                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)]">Click "Add Degree" to save your educational background.</p>
                                    </div>
                                ) : (
                                    profile.education.map((edu, idx) => (
                                        <div key={edu.id || idx} className="p-5 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)]/90 rounded-2xl space-y-4">
                                            <div className="flex items-center justify-between border-b border-[var(--cuba-line)]/60 pb-2">
                                                <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--cuba-ink-subtle)]">
                                                    Degree #{idx + 1}
                                                </span>
                                                <div className="flex items-center gap-1">
                                                    <button
                                                        type="button"
                                                        disabled={idx === 0}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('education', idx, -1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 disabled:hover:text-[var(--cuba-ink-subtle)] rounded-lg hover:bg-[var(--cuba-line)]/70 transition-all cursor-pointer text-xs font-bold"
                                                        title="Move degree up">
                                                        ▲
                                                    </button>
                                                    <button
                                                        type="button"
                                                        disabled={idx === profile.education.length - 1}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('education', idx, 1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 disabled:hover:text-[var(--cuba-ink-subtle)] rounded-lg hover:bg-[var(--cuba-line)]/70 transition-all cursor-pointer text-xs font-bold"
                                                        title="Move degree down">
                                                        ▼
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeEducation(idx); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] transition-colors rounded-lg hover:bg-[var(--cuba-danger-soft)] cursor-pointer ml-1"
                                                        title="Delete education degree">
                                                        <FaTrash className="w-3.5 h-3.5" />
                                                    </button>
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                                <div className="pr-8 sm:pr-0">
                                                    <AutocompleteInputField
                                                        label="Degree / Qualification"
                                                        name="degree"
                                                        value={edu.degree}
                                                        onChange={(e) => updateEducation(idx, 'degree', e.target.value)}
                                                        placeholder="e.g. B.S. Computer Science"
                                                        suggestionType="degree"
                                                        inputClassName="w-full text-xs p-2.5 pr-8 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                        labelClassName="block text-[11px] font-bold text-[var(--cuba-ink-muted)] mb-1"
                                                    />
                                                </div>
                                                <div>
                                                    <AutocompleteInputField
                                                        label="University / School"
                                                        name="school"
                                                        value={edu.school}
                                                        onChange={(e) => updateEducation(idx, 'school', e.target.value)}
                                                        placeholder="e.g. Stanford University"
                                                        suggestionType="school"
                                                        inputClassName="w-full text-xs p-2.5 pr-8 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                        labelClassName="block text-[11px] font-bold text-[var(--cuba-ink-muted)] mb-1"
                                                    />
                                                </div>
                                                <div className="sm:pr-8">
                                                    <MonthYearPicker
                                                        label="Graduation Date / Period"
                                                        value={edu.startDate || edu.endDate || ''}
                                                        onChange={(val) => updateEducation(idx, 'startDate', val)}
                                                    />
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                                <div>
                                                    <AutocompleteInputField
                                                        label="City / Location"
                                                        name={`edu_city_${idx}`}
                                                        value={edu.city || ''}
                                                        onChange={(e) => updateEducation(idx, 'city', e.target.value)}
                                                        onSelect={(val) => updateEducation(idx, 'city', val)}
                                                        placeholder="e.g. Cambridge, MA"
                                                        suggestionType="city"
                                                        inputClassName="w-full text-xs p-2.5 pr-8 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                        labelClassName="block text-[11px] font-bold text-[var(--cuba-ink-muted)] mb-1"
                                                    />
                                                </div>
                                                <div>
                                                    <label className="block text-[11px] font-bold text-[var(--cuba-ink-muted)] mb-1">GPA / Academic Honors (Optional)</label>
                                                    <input
                                                        type="text"
                                                        value={edu.grade || edu.gpa || ''}
                                                        onChange={(e) => updateEducation(idx, 'grade', e.target.value)}
                                                        placeholder="e.g. 3.9/4.0 GPA, Summa Cum Laude"
                                                        className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                )}

                                {profile.education.length > 0 && (
                                    <div className="pt-2">
                                        <button type="button" onClick={addEducation} className="w-full py-3 bg-[var(--cuba-primary-soft)] hover:bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-primary-line)] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-2xs">
                                            <FaPlus className="w-3.5 h-3.5" /> Add Degree
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Sub-Tab 5: Skills */}
                        {profileSubTab === 'skills' && (
                            <div className="space-y-5">
                                {/* Header & Actions Toolbar (Row 1: Title & Primary Actions | Row 2: Search & View Utilities) */}
                                <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[var(--cuba-line)]/90 shadow-2xs space-y-3.5">
                                    {/* Row 1: Title, Counter Badge & Primary Creation Actions */}
                                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--cuba-line)]">
                                        <div className="min-w-0">
                                            <div className="flex items-center gap-2.5 flex-wrap">
                                                <h3 className="text-sm font-bold text-[var(--cuba-ink)] tracking-tight whitespace-nowrap">
                                                    Skills & Technical Competencies
                                                </h3>
                                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-primary-line)]/80 whitespace-nowrap shrink-0">
                                                    {profile.skills.length} {profile.skills.length === 1 ? 'Skill' : 'Skills'}
                                                </span>
                                            </div>
                                            <p className="text-xs text-[var(--cuba-ink-subtle)] mt-1">
                                                Save core technical competencies and soft skills parsed by ATS screening engines.
                                            </p>
                                        </div>
                                        <div className="flex items-center gap-2 shrink-0 self-start sm:self-center">
                                            {/* Auto-Recommend Skills */}
                                            <button
                                                type="button"
                                                onClick={handleRecommendAiSkills}
                                                disabled={isAiGenerating}
                                                className="whitespace-nowrap px-3.5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer shrink-0">
                                                <FaMagic className={`w-3.5 h-3.5 ${isAiGenerating ? 'animate-spin' : ''}`} />
                                                <span>Auto-Recommend (AI)</span>
                                            </button>

                                            {/* Add Single Skill */}
                                            <button
                                                type="button"
                                                onClick={addSkill}
                                                className="whitespace-nowrap px-3.5 py-2 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer shrink-0">
                                                <FaPlus className="w-3 h-3" /> Add Skill
                                            </button>
                                        </div>
                                    </div>

                                    {/* Row 2: Search Filter + View & Utility Controls */}
                                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                                        {/* Search / Filter Input */}
                                        <div className="relative flex-1 max-w-md">
                                            <FaSearch className="w-3.5 h-3.5 text-[var(--cuba-ink-subtle)] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                                            <input
                                                type="text"
                                                value={skillsSearchQuery}
                                                onChange={(e) => setSkillsSearchQuery(e.target.value)}
                                                placeholder={profile.skills.length > 0 ? `Search across ${profile.skills.length} skills...` : "Filter skills..."}
                                                className="w-full text-xs pl-9 pr-8 py-2 bg-[var(--cuba-canvas)]/80 hover:bg-white focus:bg-white border border-[var(--cuba-line)]/90 rounded-xl text-[var(--cuba-ink)] placeholder:text-[var(--cuba-ink-subtle)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none transition-all"
                                            />
                                            {skillsSearchQuery && (
                                                <button
                                                    type="button"
                                                    onClick={() => setSkillsSearchQuery('')}
                                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)] p-0.5 cursor-pointer"
                                                    title="Clear search">
                                                    <FaTimes className="w-3 h-3" />
                                                </button>
                                            )}
                                        </div>

                                        {/* View & Utility Controls */}
                                        <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                                            {/* Quick Bulk Paste Toggle */}
                                            <button
                                                type="button"
                                                onClick={() => setShowBulkSkills(prev => !prev)}
                                                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 border cursor-pointer ${
                                                    showBulkSkills || bulkSkillsInput.trim()
                                                        ? 'bg-[var(--cuba-primary-soft)] border-[var(--cuba-primary-line)] text-[var(--cuba-primary-ink-strong)] shadow-2xs font-bold'
                                                        : 'bg-white border-[var(--cuba-line)] hover:border-[var(--cuba-line-strong)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-canvas)]'
                                                }`}
                                                title="Toggle quick bulk paste ingestion">
                                                <FaBolt className={`w-3 h-3 ${showBulkSkills || bulkSkillsInput.trim() ? 'text-[var(--cuba-primary-ink-strong)]' : 'text-[var(--cuba-warning)]'}`} />
                                                <span>Bulk Paste</span>
                                                {showBulkSkills ? <FaChevronUp className="w-2.5 h-2.5 opacity-60" /> : <FaChevronDown className="w-2.5 h-2.5 opacity-60" />}
                                            </button>

                                            {/* View Mode Switcher */}
                                            <div className="flex items-center bg-[var(--cuba-canvas)] p-0.5 rounded-xl border border-[var(--cuba-line)]/80">
                                                <button
                                                    type="button"
                                                    onClick={() => setSkillsViewMode('grid')}
                                                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                                                        skillsViewMode === 'grid'
                                                            ? 'bg-white text-[var(--cuba-primary-ink-strong)] shadow-2xs'
                                                            : 'text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-ink)]'
                                                    }`}
                                                    title="Cards View (Detailed view with proficiency controls)">
                                                    <FaThLarge className="w-3 h-3" />
                                                    <span>Cards</span>
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={() => setSkillsViewMode('compact')}
                                                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                                                        skillsViewMode === 'compact'
                                                            ? 'bg-white text-[var(--cuba-primary-ink-strong)] shadow-2xs'
                                                            : 'text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-ink)]'
                                                    }`}
                                                    title="Compact Tags View (High-density overview of all skills)">
                                                    <FaTags className="w-3 h-3" />
                                                    <span>Tags</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Collapsible Bulk Skills Ingestion Drawer */}
                                {(showBulkSkills || bulkSkillsInput.trim()) && (
                                    <div className="p-4 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-2xl space-y-2.5 transition-all">
                                        <div className="flex items-center justify-between">
                                            <label className="block text-[11px] font-bold text-[var(--cuba-ink-muted)] uppercase tracking-wider flex items-center gap-1.5">
                                                <span>⚡ Quick Bulk Paste Ingestion</span>
                                                <span className="text-[10px] text-[var(--cuba-ink-subtle)] font-normal lowercase">(comma, semicolon, or newline separated)</span>
                                            </label>
                                            <button
                                                type="button"
                                                onClick={() => setShowBulkSkills(false)}
                                                className="text-[11px] font-semibold text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)] cursor-pointer">
                                                Hide
                                            </button>
                                        </div>
                                        <div className="flex gap-2">
                                            <textarea
                                                value={bulkSkillsInput}
                                                onChange={(e) => setBulkSkillsInput(e.target.value)}
                                                onKeyDown={(e) => {
                                                    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                                                        e.preventDefault();
                                                        handleBulkSkillAdd();
                                                    }
                                                }}
                                                placeholder="Paste multiple skills at once (e.g. React.js, TypeScript, Node.js, Docker, Kubernetes, Clinical Leadership)..."
                                                className="flex-1 text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none resize-none h-14"
                                            />
                                            <button
                                                type="button"
                                                onClick={handleBulkSkillAdd}
                                                disabled={!bulkSkillsInput.trim()}
                                                className="px-4 py-2 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] disabled:opacity-40 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs shrink-0 cursor-pointer h-14"
                                            >
                                                <FaPlus className="w-3.5 h-3.5" /> Add All
                                            </button>
                                        </div>
                                    </div>
                                )}


                                {/* Skills Presentation: Empty State vs Cards vs Compact Tags */}
                                {profile.skills.length === 0 ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl space-y-3">
                                        <p className="text-xs font-semibold text-[var(--cuba-ink-muted)]">No skills saved in Master Profile</p>
                                        <div className="flex items-center justify-center gap-2">
                                            <button
                                                type="button"
                                                onClick={handleRecommendAiSkills}
                                                disabled={isAiGenerating}
                                                className="px-4 py-2 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer">
                                                <FaMagic className={`w-3.5 h-3.5 ${isAiGenerating ? 'animate-spin' : ''}`} />
                                                <span>Auto-Recommend Top Skills (AI)</span>
                                            </button>
                                            <button type="button" onClick={addSkill} className="px-4 py-2 bg-[var(--cuba-line)] hover:bg-[var(--cuba-line-strong)] text-[var(--cuba-ink)] rounded-xl text-xs font-bold cursor-pointer">
                                                Add Skill
                                            </button>
                                        </div>
                                    </div>
                                ) : skillsViewMode === 'compact' ? (
                                    /* High-Density Compact Tags / Quick View */
                                    <div className="p-4 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)]/90 rounded-2xl space-y-3">
                                        <div className="flex items-center justify-between">
                                            <span className="text-xs font-bold text-[var(--cuba-ink-muted)] uppercase tracking-wider">
                                                Quick Skill Matrix ({profile.skills.length})
                                            </span>
                                            <span className="text-[11px] text-[var(--cuba-ink-subtle)]">
                                                Click badge to cycle level • Reorder with arrows • Click × to delete
                                            </span>
                                        </div>
                                        <div className="flex flex-wrap gap-2 pt-1">
                                            {profile.skills
                                                .map((skill, originalIndex) => ({ ...skill, originalIndex }))
                                                .filter(skill => {
                                                    if (!skillsSearchQuery.trim()) return true;
                                                    const q = skillsSearchQuery.toLowerCase().trim();
                                                    return (skill.name || '').toLowerCase().includes(q) || (skill.level || '').toLowerCase().includes(q);
                                                })
                                                .map((skill) => {
                                                    const idx = skill.originalIndex;
                                                    const currentLvl = skill.level || 'Intermediate';
                                                    const lvlColors = {
                                                        expert: 'bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border-[var(--cuba-primary-line)]',
                                                        advanced: 'bg-[var(--cuba-success-soft)] text-[var(--cuba-success)] border-[var(--cuba-success-soft)]',
                                                        intermediate: 'bg-[var(--cuba-info-soft)] text-[var(--cuba-info)] border-[var(--cuba-info-soft)]',
                                                        beginner: 'bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)] border-[var(--cuba-line-strong)]'
                                                    }[currentLvl.toLowerCase()] || 'bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border-[var(--cuba-primary-line)]';

                                                    return (
                                                        <div
                                                            key={skill.id || idx}
                                                            className="group inline-flex items-center gap-2 pl-3 pr-2 py-1.5 bg-white border border-[var(--cuba-line)] hover:border-[var(--cuba-primary-line)] rounded-xl shadow-2xs transition-all"
                                                        >
                                                            <span className="text-xs font-semibold text-[var(--cuba-ink)]">
                                                                {skill.name || <span className="text-[var(--cuba-ink-subtle)] italic">Untitled Skill</span>}
                                                            </span>
                                                            <button
                                                                type="button"
                                                                onClick={() => cycleSkillLevel(idx)}
                                                                className={`text-[10px] px-2 py-0.5 rounded-lg font-bold border transition-all cursor-pointer ${lvlColors}`}
                                                                title="Click to cycle: Beginner → Intermediate → Advanced → Expert"
                                                            >
                                                                {currentLvl}
                                                            </button>
                                                            <div className="flex items-center gap-0.5 opacity-40 group-hover:opacity-100 transition-opacity">
                                                                <button
                                                                    type="button"
                                                                    disabled={idx === 0}
                                                                    onClick={() => moveItem('skills', idx, -1)}
                                                                    className="w-4 h-4 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-20 text-[9px] cursor-pointer"
                                                                    title="Move up"
                                                                >
                                                                    ▲
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    disabled={idx === profile.skills.length - 1}
                                                                    onClick={() => moveItem('skills', idx, 1)}
                                                                    className="w-4 h-4 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-20 text-[9px] cursor-pointer"
                                                                    title="Move down"
                                                                >
                                                                    ▼
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    onClick={() => removeSkill(idx)}
                                                                    className="w-4 h-4 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] ml-0.5 cursor-pointer"
                                                                    title="Delete skill"
                                                                >
                                                                    <FaTimes className="w-2.5 h-2.5" />
                                                                </button>
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                            <button
                                                type="button"
                                                onClick={addSkill}
                                                className="inline-flex items-center gap-1 px-3 py-1.5 bg-[var(--cuba-primary-soft)] hover:bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border border-dashed border-[var(--cuba-primary-line)] rounded-xl text-xs font-bold transition-all cursor-pointer"
                                            >
                                                <FaPlus className="w-2.5 h-2.5" /> Add Skill
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    /* Spacious 2-Column Cards View with Segmented Controls */
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                                        {profile.skills
                                            .map((skill, originalIndex) => ({ ...skill, originalIndex }))
                                            .filter(skill => {
                                                if (!skillsSearchQuery.trim()) return true;
                                                const q = skillsSearchQuery.toLowerCase().trim();
                                                return (skill.name || '').toLowerCase().includes(q) || (skill.level || '').toLowerCase().includes(q);
                                            })
                                            .map((skill) => {
                                                const idx = skill.originalIndex;
                                                const currentLvl = skill.level || 'Intermediate';
                                                return (
                                                    <div
                                                        key={skill.id || idx}
                                                        className="group relative p-3.5 bg-white hover:bg-[var(--cuba-canvas)]/50 border border-[var(--cuba-line)]/90 hover:border-[var(--cuba-primary-line)] rounded-2xl transition-all shadow-2xs hover:shadow-xs space-y-2.5"
                                                    >
                                                        {/* Header: Skill Name Input with Autocomplete + Compact Action Pod */}
                                                        <div className="flex items-center gap-2">
                                                            <div className="flex-1 min-w-0">
                                                                <AutocompleteInputField
                                                                    hideLabel
                                                                    name={`skill_${idx}`}
                                                                    value={skill.name}
                                                                    onChange={(e) => updateSkill(idx, 'name', e.target.value)}
                                                                    placeholder="Skill name (e.g. React.js, Python, Medical Leadership)"
                                                                    suggestionType="skill"
                                                                    inputClassName="w-full text-xs p-2.5 pr-8 bg-[var(--cuba-canvas)]/70 hover:bg-white focus:bg-white border border-[var(--cuba-line)] focus:border-[var(--cuba-primary-line)] rounded-xl font-semibold text-[var(--cuba-ink)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none transition-all"
                                                                />
                                                            </div>
                                                            <div className="flex items-center gap-0.5 shrink-0 bg-[var(--cuba-canvas)]/90 p-0.5 rounded-xl border border-[var(--cuba-line)]/70">
                                                                <button
                                                                    type="button"
                                                                    disabled={idx === 0}
                                                                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('skills', idx, -1); }}
                                                                    className="w-6 h-6 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-20 rounded-lg hover:bg-white text-[10px] font-bold transition-all cursor-pointer"
                                                                    title="Move skill up">
                                                                    ▲
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    disabled={idx === profile.skills.length - 1}
                                                                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('skills', idx, 1); }}
                                                                    className="w-6 h-6 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-20 rounded-lg hover:bg-white text-[10px] font-bold transition-all cursor-pointer"
                                                                    title="Move skill down">
                                                                    ▼
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeSkill(idx); }}
                                                                    className="w-6 h-6 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] hover:bg-[var(--cuba-danger-soft)] rounded-lg transition-colors cursor-pointer"
                                                                    title="Delete skill">
                                                                    <FaTrash className="w-2.5 h-2.5" />
                                                                </button>
                                                            </div>
                                                        </div>

                                                        {/* Proficiency Level Segmented Control */}
                                                        <div className="space-y-1">
                                                            <div className="flex items-center justify-between text-[11px] px-1">
                                                                <span className="font-semibold text-[var(--cuba-ink-subtle)] text-[10px] uppercase tracking-wider">Proficiency</span>
                                                                <span className="text-[10px] font-bold text-[var(--cuba-primary-ink-strong)] flex items-center gap-1">
                                                                    <span className="w-1.5 h-1.5 rounded-full bg-[var(--cuba-primary)] inline-block" />
                                                                    {currentLvl}
                                                                </span>
                                                            </div>
                                                            <div className="grid grid-cols-4 gap-1 p-0.5 bg-[var(--cuba-canvas)]/80 rounded-xl border border-[var(--cuba-line)]/60">
                                                                {['Beginner', 'Intermediate', 'Advanced', 'Expert'].map((lvl) => {
                                                                    const isSelected = currentLvl.toLowerCase() === lvl.toLowerCase();
                                                                    return (
                                                                        <button
                                                                            key={lvl}
                                                                            type="button"
                                                                            onClick={() => updateSkill(idx, 'level', lvl)}
                                                                            className={`py-1 text-[10px] font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
                                                                                isSelected
                                                                                    ? 'bg-[var(--cuba-primary)] text-white shadow-2xs'
                                                                                    : 'text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-ink)] hover:bg-white/80'
                                                                            }`}
                                                                        >
                                                                            {lvl}
                                                                        </button>
                                                                    );
                                                                })}
                                                            </div>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                    </div>
                                )}

                                {/* Bottom Quick Actions */}
                                {profile.skills.length > 0 && (
                                    <div className="pt-2 flex flex-col sm:flex-row gap-2">
                                        <button
                                            type="button"
                                            onClick={handleRecommendAiSkills}
                                            disabled={isAiGenerating}
                                            className="flex-1 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer">
                                            <FaMagic className={`w-3.5 h-3.5 ${isAiGenerating ? 'animate-spin' : ''}`} />
                                            <span>Auto-Recommend Skills (AI)</span>
                                        </button>
                                        <button type="button" onClick={addSkill} className="flex-1 py-3 bg-[var(--cuba-primary-soft)] hover:bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-primary-line)] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer">
                                            <FaPlus className="w-3.5 h-3.5" /> Add Skill
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}


                        {/* Sub-Tab 6: Certifications & Licenses */}
                        {profileSubTab === 'certifications' && (
                            <div className="space-y-6">
                                {/* Header / Action Toolbar */}
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Professional Certifications &amp; Credentials</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Industry credentials, verified licenses, and professional certifications you hold.</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <button
                                            type="button"
                                            onClick={handleRecommendAiCertifications}
                                            disabled={isAiGenerating}
                                            className="h-9 px-3.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-700 hover:to-purple-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all hover:shadow-md disabled:opacity-50 cursor-pointer"
                                            title="Open AI Recommendations Popup for your target role"
                                        >
                                            <MdAutoAwesome className="w-4 h-4" />
                                            <span>{isAiGenerating ? 'Analyzing...' : '🪄 Auto-Recommend (AI)'}</span>
                                        </button>

                                        <button
                                            type="button"
                                            onClick={addCertification}
                                            className="h-9 px-3.5 rounded-xl bg-white hover:bg-[var(--cuba-primary-soft)]/50 border border-[var(--cuba-line-strong)] hover:border-[var(--cuba-primary-line)] text-[var(--cuba-ink)] hover:text-[var(--cuba-primary-ink-strong)] text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer"
                                        >
                                            <MdAdd className="w-4 h-4 text-[var(--cuba-primary-ink-strong)]" />
                                            <span>Add Credential</span>
                                        </button>
                                    </div>
                                </div>

                                {/* Toolbar Row 2: Live Search & Category Filter Pills (when > 1 credential) */}
                                {(profile.certifications || []).length > 1 && (
                                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                                        {/* Live Search */}
                                        <div className="relative flex-1 max-w-sm">
                                            <MdSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--cuba-ink-subtle)]" />
                                            <input
                                                type="text"
                                                value={certSearchQuery}
                                                onChange={(e) => setCertSearchQuery(e.target.value)}
                                                placeholder="Search credentials, issuers, or IDs..."
                                                className="w-full h-9 pl-9 pr-8 text-xs bg-white border border-[var(--cuba-line)] rounded-xl focus:border-[var(--cuba-primary-line)] focus:ring-1 focus:ring-[var(--cuba-primary-ring)] transition-all"
                                            />
                                            {certSearchQuery && (
                                                <button
                                                    type="button"
                                                    onClick={() => setCertSearchQuery('')}
                                                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)] cursor-pointer"
                                                >
                                                    <MdClose className="w-3.5 h-3.5" />
                                                </button>
                                            )}
                                        </div>

                                        {/* Category Filter Pills */}
                                        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                                            <button
                                                type="button"
                                                onClick={() => setCertTypeFilter('all')}
                                                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                                                    certTypeFilter === 'all'
                                                        ? 'bg-[var(--cuba-ink)] text-white'
                                                        : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-line)]'
                                                }`}
                                            >
                                                All ({(profile.certifications || []).length})
                                            </button>
                                            {CERT_TYPES.map(t => {
                                                const count = (profile.certifications || []).filter(c => (c.certType || (c.isLicense ? 'License' : 'Certification')) === t.id).length;
                                                if (count === 0 && certTypeFilter !== t.id) return null;
                                                return (
                                                    <button
                                                        key={t.id}
                                                        type="button"
                                                        onClick={() => setCertTypeFilter(t.id)}
                                                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                                                            certTypeFilter === t.id
                                                                ? 'bg-[var(--cuba-primary)] text-white'
                                                                : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-line)]'
                                                        }`}
                                                    >
                                                        {t.label} ({count})
                                                    </button>
                                                );
                                            })}
                                        </div>
                                    </div>
                                )}

                                {/* Credentials Cards List */}
                                {(profile.certifications || []).length === 0 ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl space-y-3">
                                        <div className="w-10 h-10 mx-auto rounded-full bg-[var(--cuba-primary-soft)] border border-[var(--cuba-primary-line)] flex items-center justify-center text-[var(--cuba-primary-ink-strong)]">
                                            <FaCertificate className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <p className="text-xs font-bold text-[var(--cuba-ink)] mb-0.5">No certifications saved in Master Profile</p>
                                            <p className="text-[11px] text-[var(--cuba-ink-subtle)] max-w-sm mx-auto">
                                                Add accredited certifications, state/national licenses, registrations, or completed courses.
                                            </p>
                                        </div>
                                        <div className="flex items-center justify-center gap-2 pt-1">
                                            <button
                                                type="button"
                                                onClick={handleRecommendAiCertifications}
                                                disabled={isAiGenerating}
                                                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-700 hover:to-purple-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer"
                                            >
                                                <MdAutoAwesome className="w-3.5 h-3.5" />
                                                <span>Auto-Recommend Certifications (AI)</span>
                                            </button>
                                            <button
                                                type="button"
                                                onClick={addCertification}
                                                className="px-3.5 py-2 rounded-xl bg-white border border-[var(--cuba-line-strong)] hover:bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer"
                                            >
                                                <MdAdd className="w-3.5 h-3.5 text-[var(--cuba-primary-ink-strong)]" />
                                                <span>Add Credential</span>
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    (() => {
                                        const certList = (profile.certifications || [])
                                            .map((cert, originalIdx) => ({ ...cert, originalIdx }))
                                            .filter(c => {
                                                const activeType = c.certType || (c.isLicense ? 'License' : 'Certification');
                                                const matchesType = certTypeFilter === 'all' || activeType === certTypeFilter;
                                                if (!matchesType) return false;

                                                const q = certSearchQuery.trim().toLowerCase();
                                                if (!q) return true;

                                                const title = String(c.title || c.name || '').toLowerCase();
                                                const issuer = String(c.issuer || '').toLowerCase();
                                                const date = String(c.date || '').toLowerCase();
                                                const endDate = String(c.endDate || '').toLowerCase();
                                                const id = String(c.credentialId || '').toLowerCase();
                                                const type = String(activeType).toLowerCase();
                                                return title.includes(q) || issuer.includes(q) || date.includes(q) || endDate.includes(q) || id.includes(q) || type.includes(q);
                                            });

                                        if (certList.length === 0 && (profile.certifications || []).length > 0) {
                                            return (
                                                <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-2xl space-y-2">
                                                    <p className="text-xs font-bold text-[var(--cuba-ink-muted)]">No credentials match your filter criteria.</p>
                                                    <button
                                                        type="button"
                                                        onClick={() => { setCertSearchQuery(''); setCertTypeFilter('all'); }}
                                                        className="text-xs font-bold text-[var(--cuba-primary-ink-strong)] hover:text-[var(--cuba-primary-ink-strong)] cursor-pointer"
                                                    >
                                                        Reset filters
                                                    </button>
                                                </div>
                                            );
                                        }

                                        return certList.map((cert) => {
                                            const idx = cert.originalIdx;
                                            const activeType = cert.certType || (cert.isLicense ? 'License' : 'Certification');
                                            const typeConfig = CERT_TYPES.find(t => t.id === activeType) || CERT_TYPES[0];
                                            const TypeIcon = typeConfig.icon;
                                            const certTitle = cert.title || cert.name || '';

                                            const subtitleParts = [
                                                cert.issuer,
                                                cert.date ? `Earned ${cert.date}` : '',
                                                cert.credentialId ? `ID: ${cert.credentialId}` : '',
                                            ].filter(Boolean);

                                            const subtitle = subtitleParts.length > 0
                                                ? subtitleParts.join(' • ')
                                                : 'Add issuer, dates, and credential details';

                                            return (
                                                <div
                                                    key={cert.id || idx}
                                                    className="p-5 bg-white border border-[var(--cuba-line)]/90 rounded-2xl space-y-4 hover:border-[var(--cuba-line-strong)] shadow-2xs hover:shadow-xs transition-all"
                                                >
                                                    {/* Card Header */}
                                                    <div className="flex items-center justify-between border-b border-[var(--cuba-line)]/70 pb-3">
                                                        <div className="flex items-center gap-2.5 min-w-0 pr-2">
                                                            <span className="w-7 h-7 rounded-lg bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] font-extrabold flex items-center justify-center text-xs shrink-0 border border-[var(--cuba-primary-line)]/80">
                                                                #{idx + 1}
                                                            </span>
                                                            <div className="min-w-0">
                                                                <h4 className="text-xs font-bold text-[var(--cuba-ink)] truncate">
                                                                    {certTitle || 'Untitled Credential'}
                                                                </h4>
                                                                <p className="text-[11px] text-[var(--cuba-ink-subtle)] truncate">
                                                                    {subtitle}
                                                                </p>
                                                            </div>
                                                            <span className={`ml-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border shrink-0 flex items-center gap-1 ${typeConfig.badgeClass}`}>
                                                                <TypeIcon className="w-3 h-3" />
                                                                <span>{typeConfig.label}</span>
                                                            </span>
                                                        </div>

                                                        <div className="flex items-center gap-1 shrink-0">
                                                            <button
                                                                type="button"
                                                                disabled={idx === 0}
                                                                onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('certifications', idx, -1); }}
                                                                className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-canvas)] text-xs font-bold transition-colors cursor-pointer"
                                                                title="Move credential up"
                                                            >
                                                                ▲
                                                            </button>
                                                            <button
                                                                type="button"
                                                                disabled={idx === (profile.certifications || []).length - 1}
                                                                onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('certifications', idx, 1); }}
                                                                className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-canvas)] text-xs font-bold transition-colors cursor-pointer"
                                                                title="Move credential down"
                                                            >
                                                                ▼
                                                            </button>
                                                            <button
                                                                type="button"
                                                                onClick={(e) => { e.preventDefault(); e.stopPropagation(); duplicateCertification(idx); }}
                                                                className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] hover:bg-[var(--cuba-primary-soft)] rounded-lg transition-colors cursor-pointer"
                                                                title="Duplicate credential"
                                                            >
                                                                <MdContentCopy className="w-3.5 h-3.5" />
                                                            </button>
                                                            <button
                                                                type="button"
                                                                onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeCertification(idx); }}
                                                                className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] hover:bg-[var(--cuba-danger-soft)] rounded-lg transition-colors cursor-pointer ml-0.5"
                                                                title="Delete credential"
                                                            >
                                                                <MdDeleteOutline className="w-4 h-4" />
                                                            </button>
                                                        </div>
                                                    </div>

                                                    {/* Card Body */}
                                                    <div className="space-y-4 pt-1">
                                                        {/* Row 1: Credential Type Selector Pills */}
                                                        <div className="space-y-1.5">
                                                            <label className="block text-xs font-bold uppercase tracking-wider text-[var(--cuba-ink-muted)]">
                                                                Credential Classification
                                                            </label>
                                                            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                                                                {CERT_TYPES.map(type => {
                                                                    const Icon = type.icon;
                                                                    const isSelected = activeType === type.id;
                                                                    return (
                                                                        <button
                                                                            key={type.id}
                                                                            type="button"
                                                                            onClick={() => {
                                                                                updateCertification(idx, 'certType', type.id);
                                                                                updateCertification(idx, 'isLicense', type.id === 'License');
                                                                            }}
                                                                            className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                                                                                isSelected
                                                                                    ? `${type.badgeClass} ring-2 ring-[var(--cuba-primary-ring)]/20 shadow-xs`
                                                                                    : 'bg-white border-[var(--cuba-line)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-canvas)]'
                                                                            }`}
                                                                        >
                                                                            <Icon className="w-3.5 h-3.5" />
                                                                            <span>{type.label}</span>
                                                                        </button>
                                                                    );
                                                                })}
                                                            </div>
                                                        </div>

                                                        {/* Row 2: Credential Name & Issuing Organization */}
                                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                                                            <AutocompleteInputField
                                                                label="Credential name"
                                                                name={`certification-title-${cert.id || idx}`}
                                                                placeholder="e.g. AWS Solutions Architect, PMP, RN License"
                                                                value={certTitle}
                                                                onChange={(e) => updateCertification(idx, 'title', e.target.value)}
                                                                required
                                                                suggestionType="certification"
                                                                context={candidateContext}
                                                            />
                                                            <AutocompleteInputField
                                                                label="Issuing organization"
                                                                name={`certification-issuer-${cert.id || idx}`}
                                                                placeholder="e.g. Amazon Web Services, PMI, State Board"
                                                                value={cert.issuer || ''}
                                                                onChange={(e) => updateCertification(idx, 'issuer', e.target.value)}
                                                                suggestionType="certificationIssuer"
                                                                context={candidateContext}
                                                            />
                                                        </div>

                                                        {/* Row 3: Date Earned & Expiration Date */}
                                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                                                            <Field
                                                                label="Date earned"
                                                                name={`certification-date-${cert.id || idx}`}
                                                                placeholder="e.g. 2024 or Nov 2023"
                                                                value={cert.date || ''}
                                                                onChange={(e) => updateCertification(idx, 'date', e.target.value)}
                                                            />
                                                            <Field
                                                                label="Expiration / Renewal Date"
                                                                name={`certification-end-date-${cert.id || idx}`}
                                                                placeholder="e.g. 2027 or Ongoing / No Expiry"
                                                                value={cert.endDate || ''}
                                                                onChange={(e) => updateCertification(idx, 'endDate', e.target.value)}
                                                                optional
                                                            />
                                                        </div>

                                                        {/* Row 4: Credential ID & Verification URL */}
                                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                                                            <Field
                                                                label="Credential ID / License #"
                                                                name={`certification-id-${cert.id || idx}`}
                                                                placeholder="e.g. AWS-12345, RN-987654"
                                                                value={cert.credentialId || ''}
                                                                onChange={(e) => updateCertification(idx, 'credentialId', e.target.value)}
                                                                optional
                                                            />
                                                            <div>
                                                                <Field
                                                                    label="Verification URL"
                                                                    name={`certification-url-${cert.id || idx}`}
                                                                    type="url"
                                                                    placeholder="https://www.credly.com/badges/..."
                                                                    value={cert.url || cert.link || ''}
                                                                    onChange={(e) => updateCertification(idx, 'url', e.target.value)}
                                                                    optional
                                                                />
                                                                {(cert.url || cert.link) && /^https?:\/\//i.test(String(cert.url || cert.link)) && (
                                                                    <div className="mt-1.5 flex items-center justify-end">
                                                                        <a
                                                                            href={cert.url || cert.link}
                                                                            target="_blank"
                                                                            rel="noreferrer"
                                                                            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--cuba-primary-ink-strong)] hover:text-[var(--cuba-primary-ink-strong)] transition-colors"
                                                                        >
                                                                            <span>Test live URL</span>
                                                                            <MdLaunch className="w-3.5 h-3.5" />
                                                                        </a>
                                                                    </div>
                                                                )}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        });
                                    })()
                                )}

                                {/* Add Another Credential Secondary Button */}
                                {(profile.certifications || []).length > 0 && (
                                    <button
                                        type="button"
                                        onClick={addCertification}
                                        className="w-full h-11 rounded-2xl border border-dashed border-[var(--cuba-line-strong)] hover:border-[var(--cuba-primary-line)] hover:bg-[var(--cuba-primary-soft)]/40 text-sm font-bold text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-primary-ink-strong)] flex items-center justify-center gap-2 transition-all shadow-2xs cursor-pointer"
                                    >
                                        <MdAdd className="w-4 h-4 text-[var(--cuba-primary-ink-strong)]" />
                                        <span>Add Another Credential</span>
                                    </button>
                                )}
                            </div>
                        )}

                        {/* Sub-Tab 8: Languages */}
                        {profileSubTab === 'languages' && (
                            <div className="space-y-6">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Languages & Proficiency</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Add languages you speak and your level of proficiency.</p>
                                    </div>
                                    <button type="button" onClick={addLanguage} className="w-full sm:w-auto whitespace-nowrap flex-shrink-0 px-3.5 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs">
                                        <FaPlus className="w-3 h-3" /> Add Language
                                    </button>
                                </div>

                                {/* Quick-add pills */}
                                {profile.languages.length < 8 && (
                                    <div className="flex flex-wrap gap-2">
                                        {POPULAR_LANGUAGES.filter(l => !profile.languages.some(ex => (ex.name || '').toLowerCase() === l.toLowerCase())).slice(0, 10).map((lang) => (
                                            <button
                                                key={lang}
                                                type="button"
                                                onClick={() => setProfile((prev) => ({ ...prev, languages: [...prev.languages, { id: `lang_${Date.now()}`, name: lang, level: '' }] }))}
                                                className="px-3 py-1.5 text-[11px] font-semibold bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-primary-soft)] hover:text-[var(--cuba-primary-ink-strong)] text-[var(--cuba-ink-muted)] rounded-lg border border-[var(--cuba-line)] hover:border-[var(--cuba-primary-line)] transition-all"
                                            >
                                                + {lang}
                                            </button>
                                        ))}
                                    </div>
                                )}

                                {profile.languages.length === 0 ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl">
                                        <p className="text-2xl mb-2">🌐</p>
                                        <p className="text-xs font-semibold text-[var(--cuba-ink-muted)] mb-1">No languages saved in Master Profile</p>
                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)]">Click "Add Language" or tap a language pill above.</p>
                                    </div>
                                ) : (
                                    <div className="space-y-3">
                                        {profile.languages.map((lang, idx) => (
                                            <div key={lang.id || idx} className="p-4 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-2xl flex items-center gap-4">
                                                <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
                                                    <AutocompleteInputField
                                                        hideLabel
                                                        name={`lang_name_${idx}`}
                                                        value={lang.name || ''}
                                                        onChange={(e) => updateLanguage(idx, 'name', e.target.value)}
                                                        placeholder="Language (e.g. English)"
                                                        suggestionType="language"
                                                        inputClassName="w-full text-xs p-2.5 pr-8 bg-white border border-[var(--cuba-line-strong)] rounded-lg font-semibold text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    />
                                                    <select
                                                        value={lang.level || ''}
                                                        onChange={(e) => updateLanguage(idx, 'level', e.target.value)}
                                                        className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    >
                                                        <option value="" disabled>Select your proficiency</option>
                                                        {PROFICIENCY_LEVELS.map((lvl) => (
                                                            <option key={lvl} value={lvl}>{lvl}</option>
                                                        ))}
                                                    </select>
                                                </div>
                                                <div className="flex items-center gap-1 shrink-0">
                                                    <button
                                                        type="button"
                                                        disabled={idx === 0}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('languages', idx, -1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-line)]/70 text-xs font-bold"
                                                        title="Move language up">
                                                        ▲
                                                    </button>
                                                    <button
                                                        type="button"
                                                        disabled={idx === profile.languages.length - 1}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('languages', idx, 1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-line)]/70 text-xs font-bold"
                                                        title="Move language down">
                                                        ▼
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeLanguage(idx); }}
                                                        className="w-8 h-8 flex items-center justify-center bg-white hover:bg-[var(--cuba-danger-soft)] text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] border border-[var(--cuba-line)] hover:border-[var(--cuba-danger-soft)] rounded-xl transition-all cursor-pointer flex-shrink-0"
                                                        title="Delete language">
                                                        <FaTrash className="w-3.5 h-3.5" />
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                {profile.languages.length > 0 && (
                                    <div className="pt-2">
                                        <button type="button" onClick={addLanguage} className="w-full py-3 bg-[var(--cuba-primary-soft)] hover:bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-primary-line)] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-2xs">
                                            <FaPlus className="w-3.5 h-3.5" /> Add Language
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Sub-Tab: Hobbies & Personal Interests */}
                        {profileSubTab === 'hobbies' && (
                            <div className="space-y-6">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Hobbies &amp; Personal Interests</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Showcase your passions, sports, or creative activities to add personality to your resume.</p>
                                    </div>
                                </div>

                                {/* Quick-add pills */}
                                <div className="space-y-2">
                                    <label className="block text-[11px] font-bold text-[var(--cuba-ink-muted)] uppercase tracking-wider">Quick Add Popular Hobbies</label>
                                    <div className="flex flex-wrap gap-2">
                                        {POPULAR_HOBBIES.filter(h => !(profile.hobbies || []).some(ex => (typeof ex === 'string' ? ex : ex.name || ex.hobby || '').toLowerCase() === h.toLowerCase())).map((hobby) => (
                                            <button
                                                key={hobby}
                                                type="button"
                                                onClick={() => addHobby(hobby)}
                                                className="px-3 py-1.5 text-[11px] font-semibold bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-primary-soft)] hover:text-[var(--cuba-primary-ink-strong)] text-[var(--cuba-ink-muted)] rounded-lg border border-[var(--cuba-line)] hover:border-[var(--cuba-primary-line)] transition-all cursor-pointer"
                                            >
                                                + {hobby}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {/* Custom Hobby Input with AI Dropdown Suggestion */}
                                <div className="flex gap-2 items-start">
                                    <div className="flex-1">
                                        <AutocompleteInputField
                                            hideLabel
                                            name="hobbyInput"
                                            value={hobbyInput}
                                            onChange={(e) => setHobbyInput(e.target.value)}
                                            onSelect={(val) => {
                                                addHobby(val);
                                                setHobbyInput('');
                                            }}
                                            onKeyDown={(e) => {
                                                if (e.key === 'Enter') {
                                                    e.preventDefault();
                                                    addHobby();
                                                }
                                            }}
                                            placeholder="Type a custom hobby (e.g. Marathon Running, Open Source, Astronomy)..."
                                            suggestionType="hobby"
                                            inputClassName="w-full text-xs p-3 bg-white border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none h-[42px]"
                                        />
                                    </div>
                                    <button
                                        type="button"
                                        onClick={() => addHobby()}
                                        disabled={!hobbyInput.trim()}
                                        className="px-4 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer h-[42px] shrink-0"
                                    >
                                        <FaPlus className="w-3 h-3" /> Add Hobby
                                    </button>
                                </div>

                                {/* Active Hobbies List */}
                                {(!profile.hobbies || profile.hobbies.length === 0) ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl">
                                        <p className="text-2xl mb-2">⚽</p>
                                        <p className="text-xs font-semibold text-[var(--cuba-ink-muted)] mb-1">No hobbies saved in Master Profile</p>
                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)]">Click a quick-add suggestion above or type a custom hobby.</p>
                                    </div>
                                ) : (
                                    <div className="p-4 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-2xl">
                                        <label className="block text-[11px] font-bold text-[var(--cuba-ink-muted)] uppercase tracking-wider mb-2.5">
                                            Active Hobbies ({profile.hobbies.length})
                                        </label>
                                        <div className="flex flex-wrap gap-2">
                                            {profile.hobbies.map((hobby, idx) => {
                                                const name = typeof hobby === 'string' ? hobby : (hobby.name || hobby.hobby || '');
                                                return (
                                                    <span
                                                        key={idx}
                                                        className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white border border-[var(--cuba-line-strong)] text-[var(--cuba-ink)] rounded-lg text-xs font-semibold shadow-2xs hover:border-[var(--cuba-line-strong)] transition-all"
                                                    >
                                                        <span>{name}</span>
                                                        <button
                                                            type="button"
                                                            onClick={() => removeHobby(idx)}
                                                            className="text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] transition-colors cursor-pointer"
                                                            title="Remove hobby"
                                                        >
                                                            ✕
                                                        </button>
                                                    </span>
                                                );
                                            })}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Sub-Tab 7: Personal Projects */}
                        {profileSubTab === 'projects' && (
                            <div className="space-y-6">
                                {/* Header / Action Toolbar */}
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Portfolio & Personal Projects</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Highlight key technical or personal projects that demonstrate your practical skills and impact.</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <button
                                            type="button"
                                            onClick={handleRecommendAiProjects}
                                            disabled={isAiGenerating}
                                            className="h-9 px-3.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-700 hover:to-purple-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all hover:shadow-md disabled:opacity-50"
                                        >
                                            <MdAutoAwesome className="w-4 h-4" />
                                            <span>{isAiGenerating ? 'Analyzing...' : '🪄 Auto-Recommend (AI)'}</span>
                                        </button>

                                        <button
                                            type="button"
                                            onClick={addProject}
                                            className="h-9 px-3.5 rounded-xl bg-white hover:bg-[var(--cuba-primary-soft)]/50 border border-[var(--cuba-line-strong)] hover:border-[var(--cuba-primary-line)] text-[var(--cuba-ink)] hover:text-[var(--cuba-primary-ink-strong)] text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all"
                                        >
                                            <FaPlus className="w-3 h-3 text-[var(--cuba-primary-ink-strong)]" />
                                            <span>Add Project</span>
                                        </button>
                                    </div>
                                </div>

                                {/* Toolbar Row 2: Live Search & Category Filter Pills (when > 1 project) */}
                                {(profile.projects || []).length > 1 && (
                                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                                        {/* Live Search */}
                                        <div className="relative flex-1 max-w-sm">
                                            <MdSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--cuba-ink-subtle)]" />
                                            <input
                                                type="text"
                                                value={projectSearchQuery}
                                                onChange={(e) => setProjectSearchQuery(e.target.value)}
                                                placeholder="Search projects, roles, or tools..."
                                                className="w-full h-9 pl-9 pr-8 text-xs bg-white border border-[var(--cuba-line)] rounded-xl focus:border-[var(--cuba-primary-line)] focus:ring-1 focus:ring-[var(--cuba-primary-ring)] transition-all"
                                            />
                                            {projectSearchQuery && (
                                                <button
                                                    type="button"
                                                    onClick={() => setProjectSearchQuery('')}
                                                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)]"
                                                >
                                                    <MdClose className="w-3.5 h-3.5" />
                                                </button>
                                            )}
                                        </div>

                                        {/* Category Filter Pills */}
                                        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                                            <button
                                                type="button"
                                                onClick={() => setProjectTypeFilter('all')}
                                                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                                                    projectTypeFilter === 'all'
                                                        ? 'bg-[var(--cuba-ink)] text-white'
                                                        : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-line)]'
                                                }`}
                                            >
                                                All ({(profile.projects || []).length})
                                            </button>
                                            {PROJECT_TYPES.map(t => {
                                                const count = (profile.projects || []).filter(p => (p.projectType || 'personal') === t.id).length;
                                                if (count === 0 && projectTypeFilter !== t.id) return null;
                                                return (
                                                    <button
                                                        key={t.id}
                                                        type="button"
                                                        onClick={() => setProjectTypeFilter(t.id)}
                                                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors whitespace-nowrap ${
                                                            projectTypeFilter === t.id
                                                                ? 'bg-[var(--cuba-primary)] text-white'
                                                                : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-line)]'
                                                        }`}
                                                    >
                                                        {t.label} ({count})
                                                    </button>
                                                );
                                            })}
                                        </div>
                                    </div>
                                )}

                                {/* Projects List */}
                                {(profile.projects || []).length === 0 ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl space-y-3">
                                        <div className="w-10 h-10 mx-auto rounded-full bg-[var(--cuba-primary-soft)] border border-[var(--cuba-primary-line)] flex items-center justify-center text-[var(--cuba-primary-ink-strong)]">
                                            <FaRocket className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <p className="text-xs font-bold text-[var(--cuba-ink)] mb-0.5">No portfolio projects saved in Master Profile</p>
                                            <p className="text-[11px] text-[var(--cuba-ink-subtle)] max-w-sm mx-auto">
                                                Add prominent projects, open-source work, or applications showcasing hands-on experience.
                                            </p>
                                        </div>
                                        <div className="flex items-center justify-center gap-2 pt-1">
                                            <button
                                                type="button"
                                                onClick={handleRecommendAiProjects}
                                                disabled={isAiGenerating}
                                                className="px-3 py-1.5 rounded-xl bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs"
                                            >
                                                <MdAutoAwesome className="w-3.5 h-3.5" />
                                                <span>Auto-Recommend (AI)</span>
                                            </button>
                                            <button
                                                type="button"
                                                onClick={addProject}
                                                className="px-3 py-1.5 rounded-xl bg-white border border-[var(--cuba-line-strong)] hover:bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] text-xs font-bold flex items-center gap-1.5 shadow-2xs"
                                            >
                                                <FaPlus className="w-3 h-3 text-[var(--cuba-primary-ink-strong)]" />
                                                <span>Add Project</span>
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    (profile.projects || [])
                                        .map((proj, originalIdx) => ({ ...proj, originalIdx }))
                                        .filter(p => {
                                            const query = projectSearchQuery.trim().toLowerCase();
                                            const matchesSearch = !query || [
                                                p.title,
                                                p.role,
                                                p.technologies,
                                                p.url || p.link,
                                            ].some(val => String(val || '').toLowerCase().includes(query));

                                            const matchesType = projectTypeFilter === 'all' || (p.projectType || 'personal') === projectTypeFilter;
                                            return matchesSearch && matchesType;
                                        })
                                        .map((proj) => {
                                            const idx = proj.originalIdx;
                                            const typeConfig = PROJECT_TYPES.find(t => t.id === (proj.projectType || 'personal')) || PROJECT_TYPES[0];
                                            const subtitleParts = [
                                                proj.role,
                                                proj.technologies,
                                            ].filter(Boolean);

                                            const subtitle = subtitleParts.length > 0
                                                ? subtitleParts.join(' • ')
                                                : ((proj.url || proj.link) ? String(proj.url || proj.link).replace(/^https?:\/\//, '').slice(0, 45) : 'Add role, tools & details');

                                            return (
                                                <div key={proj.id || idx} className="p-5 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-2xl space-y-4 hover:border-[var(--cuba-line-strong)] transition-colors">
                                                    {/* Card Header */}
                                                    <div className="flex items-center justify-between border-b border-[var(--cuba-line)]/70 pb-3">
                                                        <div className="flex items-center gap-2 min-w-0 pr-2">
                                                            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[var(--cuba-ink-subtle)] shrink-0">
                                                                #{idx + 1}
                                                            </span>
                                                            <div className="min-w-0">
                                                                <h4 className="text-xs font-bold text-[var(--cuba-ink)] truncate">
                                                                    {proj.title || 'Untitled Project'}
                                                                </h4>
                                                                <p className="text-[11px] text-[var(--cuba-ink-subtle)] truncate">
                                                                    {subtitle}
                                                                </p>
                                                            </div>
                                                            <span className={`ml-1 px-2 py-0.5 rounded-full text-[10px] font-bold border shrink-0 ${typeConfig.badgeClass}`}>
                                                                {typeConfig.label}
                                                            </span>
                                                        </div>

                                                        <div className="flex items-center gap-1 shrink-0">
                                                            <button
                                                                type="button"
                                                                disabled={idx === 0}
                                                                onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('projects', idx, -1); }}
                                                                className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-line)]/70 text-xs font-bold"
                                                                title="Move project up"
                                                            >
                                                                ▲
                                                            </button>
                                                            <button
                                                                type="button"
                                                                disabled={idx === (profile.projects || []).length - 1}
                                                                onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('projects', idx, 1); }}
                                                                className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-line)]/70 text-xs font-bold"
                                                                title="Move project down"
                                                            >
                                                                ▼
                                                            </button>
                                                            <button
                                                                type="button"
                                                                onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeProject(idx); }}
                                                                className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] hover:bg-[var(--cuba-danger-soft)] rounded-lg transition-colors cursor-pointer ml-1"
                                                                title="Delete project"
                                                            >
                                                                <FaTrash className="w-3.5 h-3.5" />
                                                            </button>
                                                        </div>
                                                    </div>

                                                    {/* Card Body */}
                                                    <div className="space-y-3.5">
                                                        {/* Row 1: Project Name & Role */}
                                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                                                            <div className="space-y-1">
                                                                <label className="block text-xs font-bold text-[var(--cuba-ink-muted)]">
                                                                    Project Name <span className="text-[var(--cuba-danger)]">*</span>
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    value={proj.title || ''}
                                                                    onChange={(e) => updateProject(idx, 'title', e.target.value)}
                                                                    placeholder="e.g. Distributed E-Commerce Backend, Real-Time Chat App"
                                                                    className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-xl font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-1 focus:ring-[var(--cuba-primary-ring)] transition-all"
                                                                />
                                                            </div>
                                                            <div className="space-y-1">
                                                                <label className="block text-xs font-bold text-[var(--cuba-ink-muted)]">
                                                                    Your Role in Project
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    value={proj.role || ''}
                                                                    onChange={(e) => updateProject(idx, 'role', e.target.value)}
                                                                    placeholder="e.g. Lead Architect, Full Stack Developer, Creator"
                                                                    className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-xl focus:border-[var(--cuba-primary-line)] focus:ring-1 focus:ring-[var(--cuba-primary-ring)] transition-all"
                                                                />
                                                            </div>
                                                        </div>

                                                        {/* Row 2: Technologies & URL */}
                                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                                                            <div className="space-y-1">
                                                                <label className="block text-xs font-bold text-[var(--cuba-ink-muted)]">
                                                                    Technologies / Tools Used
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    value={proj.technologies || ''}
                                                                    onChange={(e) => updateProject(idx, 'technologies', e.target.value)}
                                                                    placeholder="e.g. React, Node.js, PostgreSQL, Docker, AWS, TailwindCSS"
                                                                    className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-xl focus:border-[var(--cuba-primary-line)] focus:ring-1 focus:ring-[var(--cuba-primary-ring)] transition-all"
                                                                />
                                                            </div>
                                                            <div className="space-y-1">
                                                                <label className="block text-xs font-bold text-[var(--cuba-ink-muted)]">
                                                                    Project / Portfolio URL
                                                                </label>
                                                                <input
                                                                    type="url"
                                                                    value={proj.url || proj.link || ''}
                                                                    onChange={(e) => updateProject(idx, 'url', e.target.value)}
                                                                    placeholder="https://github.com/... or https://..."
                                                                    className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-xl focus:border-[var(--cuba-primary-line)] focus:ring-1 focus:ring-[var(--cuba-primary-ring)] transition-all"
                                                                />
                                                                {(proj.url || proj.link) && /^https?:\/\//i.test(String(proj.url || proj.link)) && (
                                                                    <div className="mt-1 flex items-center justify-end">
                                                                        <a
                                                                            href={proj.url || proj.link}
                                                                            target="_blank"
                                                                            rel="noreferrer"
                                                                            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--cuba-primary-ink-strong)] hover:text-[var(--cuba-primary-ink-strong)] transition-colors"
                                                                        >
                                                                            <span>Test live URL</span>
                                                                            <MdLaunch className="w-3.5 h-3.5" />
                                                                        </a>
                                                                    </div>
                                                                )}
                                                            </div>
                                                        </div>

                                                        {/* Row 3: Project Type / Category Selector */}
                                                        <div className="space-y-1.5 pt-1">
                                                            <label className="block text-[11px] font-bold uppercase tracking-wider text-[var(--cuba-ink-muted)]">
                                                                Project Type / Category
                                                            </label>
                                                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                                                {PROJECT_TYPES.map(type => {
                                                                    const Icon = type.icon;
                                                                    const isSelected = (proj.projectType || 'personal') === type.id;
                                                                    return (
                                                                        <button
                                                                            key={type.id}
                                                                            type="button"
                                                                            onClick={() => updateProject(idx, 'projectType', type.id)}
                                                                            className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-2 ${
                                                                                isSelected
                                                                                    ? `${type.badgeClass} ring-2 ring-[var(--cuba-primary-ring)]/20 shadow-xs`
                                                                                    : 'bg-white border-[var(--cuba-line)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-canvas)]'
                                                                            }`}
                                                                        >
                                                                            <Icon className="w-3.5 h-3.5" />
                                                                            <span>{type.label}</span>
                                                                        </button>
                                                                    );
                                                                })}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })
                                )}

                                {/* Add Another Project secondary button */}
                                {(profile.projects || []).length > 0 && (
                                    <button
                                        type="button"
                                        onClick={addProject}
                                        className="w-full h-11 rounded-2xl border border-dashed border-[var(--cuba-line-strong)] hover:border-[var(--cuba-primary-line)] hover:bg-[var(--cuba-primary-soft)]/40 text-sm font-bold text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-primary-ink-strong)] flex items-center justify-center gap-2 transition-all shadow-2xs"
                                    >
                                        <FaPlus className="w-3.5 h-3.5 text-[var(--cuba-primary-ink-strong)]" />
                                        <span>Add Another Project</span>
                                    </button>
                                )}
                            </div>
                        )}

                        {/* Sub-Tab 10: Honors & Awards */}
                        {profileSubTab === 'achievements' && (() => {
                            const filteredAchievements = (profile.achievements || []).filter(ach => {
                                const q = achievementSearchQuery.trim().toLowerCase();
                                const matchesSearch = !q ||
                                    (ach.title || ach.name || '').toLowerCase().includes(q) ||
                                    (ach.issuer || ach.awarder || '').toLowerCase().includes(q) ||
                                    (ach.description || '').toLowerCase().includes(q);

                                const activeType = ach.achievementType || 'Award';
                                const matchesType = achievementTypeFilter === 'all' || activeType === achievementTypeFilter;

                                return matchesSearch && matchesType;
                            });

                            return (
                                <div className="space-y-6">
                                    {/* Header / Action Toolbar */}
                                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                        <div>
                                            <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Honors, Awards &amp; Key Achievements</h3>
                                            <p className="text-xs text-[var(--cuba-ink-subtle)]">Record industry accolades, hackathon wins, academic distinctions, or notable career milestones.</p>
                                        </div>
                                        <button
                                            type="button"
                                            onClick={addAchievement}
                                            className="h-9 px-3.5 rounded-xl bg-[var(--cuba-ink)] hover:bg-[var(--cuba-ink)] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer whitespace-nowrap"
                                        >
                                            <MdAdd className="w-4 h-4 text-white" />
                                            <span>Add Award / Achievement</span>
                                        </button>
                                    </div>

                                    {/* Toolbar Row 2: Live Search & Category Filter Pills (when > 1 achievement) */}
                                    {(profile.achievements || []).length > 1 && (
                                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                                            {/* Live Search */}
                                            <div className="relative flex-1 max-w-sm">
                                                <MdSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--cuba-ink-subtle)]" />
                                                <input
                                                    type="text"
                                                    value={achievementSearchQuery}
                                                    onChange={(e) => setAchievementSearchQuery(e.target.value)}
                                                    placeholder="Search honors, awards, or organizations..."
                                                    className="w-full h-9 pl-9 pr-8 text-xs bg-white border border-[var(--cuba-line)] rounded-xl focus:border-[var(--cuba-primary-line)] focus:ring-1 focus:ring-[var(--cuba-primary-ring)] transition-all"
                                                />
                                                {achievementSearchQuery && (
                                                    <button
                                                        type="button"
                                                        onClick={() => setAchievementSearchQuery('')}
                                                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)] cursor-pointer"
                                                    >
                                                        <MdClose className="w-3.5 h-3.5" />
                                                    </button>
                                                )}
                                            </div>

                                            {/* Category Filter Pills */}
                                            <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                                                <button
                                                    type="button"
                                                    onClick={() => setAchievementTypeFilter('all')}
                                                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                                                        achievementTypeFilter === 'all'
                                                            ? 'bg-[var(--cuba-ink)] text-white'
                                                            : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-line)]'
                                                    }`}
                                                >
                                                    All ({(profile.achievements || []).length})
                                                </button>
                                                {ACHIEVEMENT_TYPES.map(t => {
                                                    const count = (profile.achievements || []).filter(a => (a.achievementType || 'Award') === t.id).length;
                                                    if (count === 0 && achievementTypeFilter !== t.id) return null;
                                                    return (
                                                        <button
                                                            key={t.id}
                                                            type="button"
                                                            onClick={() => setAchievementTypeFilter(t.id)}
                                                            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                                                                achievementTypeFilter === t.id
                                                                    ? 'bg-[var(--cuba-primary)] text-white'
                                                                    : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-line)]'
                                                            }`}
                                                        >
                                                            {t.label} ({count})
                                                        </button>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    )}

                                    {(!profile.achievements || profile.achievements.length === 0) ? (
                                        <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl">
                                            <p className="text-2xl mb-2">🏆</p>
                                            <p className="text-xs font-semibold text-[var(--cuba-ink-muted)] mb-1">No achievements saved in Master Profile</p>
                                            <p className="text-[11px] text-[var(--cuba-ink-subtle)] mb-3">Add awards, competitive honors, or leadership recognitions to stand out to recruiters.</p>
                                            <button
                                                type="button"
                                                onClick={addAchievement}
                                                className="px-4 py-2 bg-[var(--cuba-ink)] hover:bg-[var(--cuba-ink)] text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                                            >
                                                <MdAdd className="w-4 h-4 text-white" />
                                                <span>Add First Achievement</span>
                                            </button>
                                        </div>
                                    ) : filteredAchievements.length === 0 ? (
                                        <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line)] rounded-2xl space-y-2">
                                            <p className="text-xs font-bold text-[var(--cuba-ink-muted)]">No achievements match your filter criteria.</p>
                                            <button
                                                type="button"
                                                onClick={() => { setAchievementSearchQuery(''); setAchievementTypeFilter('all'); }}
                                                className="text-xs font-bold text-[var(--cuba-primary-ink-strong)] hover:text-[var(--cuba-primary-ink-strong)] cursor-pointer"
                                            >
                                                Reset filters
                                            </button>
                                        </div>
                                    ) : (
                                        <div className="space-y-4">
                                            {filteredAchievements.map((ach) => {
                                                const originalIndex = (profile.achievements || []).findIndex(a => (a.id && a.id === ach.id) || a === ach);
                                                const activeType = ach.achievementType || 'Award';
                                                const typeConfig = ACHIEVEMENT_TYPES.find(t => t.id === activeType) || ACHIEVEMENT_TYPES[0];
                                                const theme = TYPE_STYLE_MAP[activeType] || TYPE_STYLE_MAP.Award;
                                                const TypeIcon = typeConfig.icon;
                                                const achTitle = ach.title || ach.name || '';

                                                const subtitleParts = [
                                                    ach.issuer || ach.awarder,
                                                    ach.date ? `Received ${ach.date}` : '',
                                                ].filter(Boolean);

                                                const subtitle = subtitleParts.length > 0
                                                    ? subtitleParts.join(' • ')
                                                    : 'Add awarding organization, dates, and significance';

                                                return (
                                                    <div
                                                        key={ach.id || originalIndex}
                                                        className={`bg-white border ${theme.cardBorder} rounded-2xl shadow-xs hover:shadow-md transition-all overflow-hidden`}
                                                    >
                                                        {/* Card Header */}
                                                        <div className={`p-3.5 sm:p-4 border-b border-[var(--cuba-line)] bg-gradient-to-r ${theme.headerGradient} flex items-center justify-between gap-3`}>
                                                            <div className="flex items-center gap-2.5 min-w-0 pr-2">
                                                                <span className={`w-6 h-6 rounded-md ${theme.indexBadge} font-extrabold flex items-center justify-center text-[11px] shrink-0 shadow-2xs`}>
                                                                    #{originalIndex + 1}
                                                                </span>
                                                                <div className="min-w-0">
                                                                    <div className="flex items-center gap-2 flex-wrap">
                                                                        <h4 className="text-xs sm:text-sm font-bold text-[var(--cuba-ink)] truncate">
                                                                            {achTitle || 'Untitled Honor / Award'}
                                                                        </h4>
                                                                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border shrink-0 flex items-center gap-1 ${theme.badgeClass}`}>
                                                                            <TypeIcon className="w-3 h-3" />
                                                                            <span>{typeConfig.label}</span>
                                                                        </span>
                                                                    </div>
                                                                    <p className="text-[11px] text-[var(--cuba-ink-subtle)] truncate mt-0.5">
                                                                        {subtitle}
                                                                    </p>
                                                                </div>
                                                            </div>

                                                            {/* Action Button Group */}
                                                            <div className="flex items-center gap-0.5 bg-white/95 backdrop-blur-xs p-1 rounded-xl border border-[var(--cuba-line)]/80 shadow-2xs shrink-0">
                                                                <button
                                                                    type="button"
                                                                    disabled={originalIndex === 0}
                                                                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('achievements', originalIndex, -1); }}
                                                                    className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink)] disabled:opacity-20 rounded-lg hover:bg-[var(--cuba-canvas)] text-[11px] font-bold transition-all cursor-pointer"
                                                                    title="Move award up"
                                                                >
                                                                    ▲
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    disabled={originalIndex === (profile.achievements || []).length - 1}
                                                                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('achievements', originalIndex, 1); }}
                                                                    className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink)] disabled:opacity-20 rounded-lg hover:bg-[var(--cuba-canvas)] text-[11px] font-bold transition-all cursor-pointer"
                                                                    title="Move award down"
                                                                >
                                                                    ▼
                                                                </button>
                                                                <div className="w-[1px] h-3.5 bg-[var(--cuba-line)] mx-0.5" />
                                                                <button
                                                                    type="button"
                                                                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); duplicateAchievement(originalIndex); }}
                                                                    className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] rounded-lg hover:bg-[var(--cuba-primary-soft)]/70 transition-all cursor-pointer"
                                                                    title="Duplicate award"
                                                                >
                                                                    <MdContentCopy className="w-3.5 h-3.5" />
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeAchievement(originalIndex); }}
                                                                    className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] rounded-lg hover:bg-[var(--cuba-danger-soft)]/70 transition-all cursor-pointer ml-0.5"
                                                                    title="Delete award"
                                                                >
                                                                    <MdDeleteOutline className="w-4 h-4" />
                                                                </button>
                                                            </div>
                                                        </div>

                                                        {/* Card Body */}
                                                        <div className="p-4 sm:p-5 space-y-4">
                                                            {/* Category Selector Segmented Bar */}
                                                            <div>
                                                                <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] uppercase tracking-wider mb-1.5">
                                                                    Category &amp; Recognition Type
                                                                </label>
                                                                <div className="flex flex-wrap items-center gap-1.5 p-1 bg-[var(--cuba-canvas)]/70 border border-[var(--cuba-line)]/80 rounded-xl">
                                                                    {ACHIEVEMENT_TYPES.map(type => {
                                                                        const Icon = type.icon;
                                                                        const isSelected = activeType === type.id;
                                                                        return (
                                                                            <button
                                                                                key={type.id}
                                                                                type="button"
                                                                                onClick={() => updateAchievement(originalIndex, 'achievementType', type.id)}
                                                                                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                                                                                    isSelected
                                                                                        ? 'bg-white text-[var(--cuba-ink)] shadow-xs border border-[var(--cuba-line)]/90 font-bold'
                                                                                        : 'text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-ink)] hover:bg-white/60 border border-transparent'
                                                                                }`}
                                                                            >
                                                                                <Icon className={`w-3.5 h-3.5 ${isSelected ? theme.iconColor : 'text-[var(--cuba-ink-subtle)]'}`} />
                                                                                <span>{type.label}</span>
                                                                            </button>
                                                                        );
                                                                    })}
                                                                </div>
                                                            </div>

                                                            {/* Row 1: Award Title & Date Received */}
                                                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                                                <div className="sm:col-span-2">
                                                                    <Field
                                                                        label="Award or Honor Title"
                                                                        name={`achievement-title-${originalIndex}`}
                                                                        placeholder="Award or Honor Title (e.g. Employee of the Year, Hackathon 1st Place)"
                                                                        value={achTitle}
                                                                        onChange={(e) => updateAchievement(originalIndex, 'title', e.target.value)}
                                                                        required
                                                                    />
                                                                </div>
                                                                <div>
                                                                    <Field
                                                                        label="Date Received"
                                                                        name={`achievement-date-${originalIndex}`}
                                                                        placeholder="e.g. Nov 2024"
                                                                        value={ach.date || ''}
                                                                        onChange={(e) => updateAchievement(originalIndex, 'date', e.target.value)}
                                                                        optional
                                                                    />
                                                                </div>
                                                            </div>

                                                            {/* Row 2: Awarding Organization / Issuer */}
                                                            <div>
                                                                <Field
                                                                    label="Awarding Organization or Issuer"
                                                                    name={`achievement-issuer-${originalIndex}`}
                                                                    placeholder="Awarding Organization or Issuer (e.g. IEEE, Google Cloud, University)"
                                                                    value={ach.issuer || ach.awarder || ''}
                                                                    onChange={(e) => updateAchievement(originalIndex, 'issuer', e.target.value)}
                                                                    optional
                                                                />
                                                            </div>

                                                            {/* Row 3: Description with AI Polish & Quick Starter Chips */}
                                                            <div className="space-y-2">
                                                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                                                                    <div>
                                                                        <label className="text-[13px] font-semibold text-[var(--cuba-ink-muted)]">
                                                                            Accomplishment &amp; Significance
                                                                        </label>
                                                                        <span className="block sm:inline sm:ml-1.5 text-[11px] text-[var(--cuba-ink-subtle)] font-normal">
                                                                            — scope, measurable impact, or why this honor was awarded
                                                                        </span>
                                                                    </div>
                                                                    <button
                                                                        type="button"
                                                                        disabled={isPolishingAchIndex === originalIndex}
                                                                        onClick={() => polishAchievementDescription(originalIndex)}
                                                                        className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-indigo-50 to-purple-50 hover:from-indigo-100 hover:to-purple-100 text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-primary-line)]/80 rounded-lg text-xs font-bold transition-all shadow-2xs hover:shadow-xs cursor-pointer disabled:opacity-50 self-start sm:self-auto shrink-0"
                                                                        title="Auto-enhance phrasing with impact metrics and action verbs"
                                                                    >
                                                                        <MdAutoAwesome className={`w-3.5 h-3.5 text-[var(--cuba-primary-ink-strong)] ${isPolishingAchIndex === originalIndex ? 'animate-spin' : ''}`} />
                                                                        <span>{isPolishingAchIndex === originalIndex ? 'Polishing...' : '🪄 Enhance with AI'}</span>
                                                                    </button>
                                                                </div>

                                                                <textarea
                                                                    value={ach.description || ''}
                                                                    onChange={(e) => updateAchievement(originalIndex, 'description', e.target.value)}
                                                                    placeholder="Brief description of the accomplishment and its significance..."
                                                                    className="w-full min-h-[78px] text-xs p-3.5 bg-[var(--cuba-canvas)]/50 hover:bg-white focus:bg-white border border-[var(--cuba-line)]/90 rounded-xl font-medium text-[var(--cuba-ink)] placeholder:text-[var(--cuba-ink-subtle)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-ring)]/15 outline-none resize-y transition-all shadow-2xs leading-relaxed"
                                                                />

                                                                {/* Quick Starter Chips */}
                                                                <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                                                                    <span className="text-[11px] font-semibold text-[var(--cuba-ink-subtle)]">Quick starters:</span>
                                                                    {SUGGESTION_CHIPS.map((chip, cIdx) => (
                                                                        <button
                                                                            key={cIdx}
                                                                            type="button"
                                                                            onClick={() => {
                                                                                const current = (ach.description || '').trim();
                                                                                const separator = current ? (current.endsWith('.') ? ' ' : '. ') : '';
                                                                                updateAchievement(originalIndex, 'description', `${current}${separator}${chip.text}`);
                                                                            }}
                                                                            className="inline-flex items-center text-[11px] font-medium px-2.5 py-1 rounded-lg bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-primary-soft)]/80 text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-line)] hover:border-[var(--cuba-primary-line)] transition-all cursor-pointer shadow-2xs"
                                                                        >
                                                                            {chip.label}
                                                                        </button>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    )}

                                    {(profile.achievements || []).length > 0 && (
                                        <button
                                            type="button"
                                            onClick={addAchievement}
                                            className="w-full h-11 rounded-2xl border border-dashed border-[var(--cuba-line-strong)] hover:border-[var(--cuba-primary-line)] hover:bg-[var(--cuba-primary-soft)]/40 text-sm font-bold text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-primary-ink-strong)] flex items-center justify-center gap-2 transition-all shadow-2xs cursor-pointer"
                                        >
                                            <MdAdd className="w-4 h-4 text-[var(--cuba-primary-ink-strong)]" />
                                            <span>Add Another Achievement</span>
                                        </button>
                                    )}
                                </div>
                            );
                        })()}

                        {/* Sub-Tab 11: References */}
                        {profileSubTab === 'references' && (
                            <div className="space-y-6">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Professional &amp; Academic References</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Store references securely. Choose whether to show them on resumes or provide upon request.</p>
                                    </div>
                                    <button type="button" onClick={addReference} className="w-full sm:w-auto whitespace-nowrap flex-shrink-0 px-3.5 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer">
                                        <FaPlus className="w-3 h-3" /> Add Reference
                                    </button>
                                </div>

                                {(!profile.references || profile.references.length === 0) ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl">
                                        <p className="text-2xl mb-2">👥</p>
                                        <p className="text-xs font-semibold text-[var(--cuba-ink-muted)] mb-1">No references saved in Master Profile</p>
                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)] mb-3">Add managers, mentors, or colleagues who can vouch for your work.</p>
                                        <button type="button" onClick={addReference} className="px-4 py-2 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer">
                                            <FaPlus className="w-3 h-3" /> Add First Reference
                                        </button>
                                    </div>
                                ) : (
                                    (profile.references || []).map((ref, idx) => (
                                        <div key={ref.id || idx} className="p-5 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-2xl space-y-3">
                                            <div className="flex items-center justify-between border-b border-[var(--cuba-line)]/60 pb-2">
                                                <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--cuba-ink-subtle)] flex items-center gap-1.5">
                                                    👥 Reference #{idx + 1}
                                                </span>
                                                <div className="flex items-center gap-1">
                                                    <button
                                                        type="button"
                                                        disabled={idx === 0}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('references', idx, -1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-line)]/70 text-xs font-bold cursor-pointer"
                                                        title="Move up">
                                                        ▲
                                                    </button>
                                                    <button
                                                        type="button"
                                                        disabled={idx === profile.references.length - 1}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('references', idx, 1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-line)]/70 text-xs font-bold cursor-pointer"
                                                        title="Move down">
                                                        ▼
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeReference(idx); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] hover:bg-[var(--cuba-danger-soft)] rounded-lg transition-colors cursor-pointer ml-1"
                                                        title="Delete reference">
                                                        <FaTrash className="w-3.5 h-3.5" />
                                                    </button>
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                                <div>
                                                    <input
                                                        type="text"
                                                        value={ref.name || ''}
                                                        onChange={(e) => updateReference(idx, 'name', e.target.value)}
                                                        placeholder="Referee Full Name (e.g. Dr. Jane Smith)"
                                                        className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg font-semibold text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    />
                                                </div>
                                                <div>
                                                    <input
                                                        type="text"
                                                        value={ref.position || ''}
                                                        onChange={(e) => updateReference(idx, 'position', e.target.value)}
                                                        placeholder="Job Title / Position (e.g. VP of Engineering)"
                                                        className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    />
                                                </div>
                                                <div>
                                                    <input
                                                        type="text"
                                                        value={ref.company || ''}
                                                        onChange={(e) => updateReference(idx, 'company', e.target.value)}
                                                        placeholder="Company / Institution (e.g. Acme Corp)"
                                                        className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    />
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                                <div>
                                                    <input
                                                        type="email"
                                                        value={ref.email || ''}
                                                        onChange={(e) => updateReference(idx, 'email', e.target.value)}
                                                        placeholder="Email Address (e.g. jane.smith@acme.com)"
                                                        className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    />
                                                </div>
                                                <div>
                                                    <input
                                                        type="tel"
                                                        value={ref.phone || ''}
                                                        onChange={(e) => updateReference(idx, 'phone', e.target.value)}
                                                        placeholder="Phone Number (e.g. +1 555-0199)"
                                                        className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    />
                                                </div>
                                            </div>
                                            <div>
                                                <textarea
                                                    value={ref.reference || ''}
                                                    onChange={(e) => updateReference(idx, 'reference', e.target.value)}
                                                    placeholder="Relationship notes or reference quote (e.g. 'Direct manager at Acme Corp for 3 years')..."
                                                    className="w-full h-14 text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none resize-none"
                                                />
                                            </div>
                                        </div>
                                    ))
                                )}

                                {(profile.references || []).length > 0 && (
                                    <div className="pt-2">
                                        <button type="button" onClick={addReference} className="w-full py-3 bg-[var(--cuba-primary-soft)] hover:bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-primary-line)] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-2xs cursor-pointer">
                                            <FaPlus className="w-3.5 h-3.5" /> Add Another Reference
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Sub-Tab 12: Custom Sections */}
                        {profileSubTab === 'customSections' && (
                            <div className="space-y-6">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider">Custom Profile Modules &amp; Bespoke Sections</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Create bespoke sections (e.g. Publications, Patents, Speaking Engagements, Volunteering, Military Service).</p>
                                    </div>
                                    <button type="button" onClick={addCustomSection} className="w-full sm:w-auto whitespace-nowrap flex-shrink-0 px-3.5 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer">
                                        <FaPlus className="w-3 h-3" /> Add Custom Module
                                    </button>
                                </div>

                                {(!profile.customSections || profile.customSections.length === 0) ? (
                                    <div className="p-8 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line-strong)] rounded-2xl">
                                        <p className="text-2xl mb-2">🧩</p>
                                        <p className="text-xs font-semibold text-[var(--cuba-ink-muted)] mb-1">No custom modules created in Master Profile</p>
                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)] mb-3">Add any specialized section required for your unique career or industry background.</p>
                                        <button type="button" onClick={addCustomSection} className="px-4 py-2 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer">
                                            <FaPlus className="w-3 h-3" /> Add First Custom Section
                                        </button>
                                    </div>
                                ) : (
                                    (profile.customSections || []).map((sec, sIdx) => (
                                        <div key={sec.id || sIdx} className="p-5 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-2xl space-y-4">
                                            <div className="flex items-center justify-between border-b border-[var(--cuba-line)]/60 pb-2">
                                                <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--cuba-ink-subtle)] flex items-center gap-1.5">
                                                    🧩 Custom Section #{sIdx + 1}
                                                </span>
                                                <div className="flex items-center gap-1">
                                                    <button
                                                        type="button"
                                                        disabled={sIdx === 0}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('customSections', sIdx, -1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-line)]/70 text-xs font-bold cursor-pointer"
                                                        title="Move up">
                                                        ▲
                                                    </button>
                                                    <button
                                                        type="button"
                                                        disabled={sIdx === profile.customSections.length - 1}
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); moveItem('customSections', sIdx, 1); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] disabled:opacity-30 rounded-lg hover:bg-[var(--cuba-line)]/70 text-xs font-bold cursor-pointer"
                                                        title="Move down">
                                                        ▼
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeCustomSection(sIdx); }}
                                                        className="w-7 h-7 flex items-center justify-center text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] hover:bg-[var(--cuba-danger-soft)] rounded-lg transition-colors cursor-pointer ml-1"
                                                        title="Delete custom section">
                                                        <FaTrash className="w-3.5 h-3.5" />
                                                    </button>
                                                </div>
                                            </div>

                                            <div className="space-y-3">
                                                <div>
                                                    <label className="block text-[11px] font-bold text-[var(--cuba-ink-muted)] uppercase tracking-wider mb-1">Section Title</label>
                                                    <input
                                                        type="text"
                                                        value={sec.title || ''}
                                                        onChange={(e) => updateCustomSection(sIdx, 'title', e.target.value)}
                                                        placeholder="Section Title (e.g. Publications, Patents, Keynote Talks, Volunteer Experience)"
                                                        className="w-full text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg font-bold text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                    />
                                                </div>
                                                <div>
                                                    <label className="block text-[11px] font-bold text-[var(--cuba-ink-muted)] uppercase tracking-wider mb-1">Section Overview (Optional)</label>
                                                    <textarea
                                                        value={sec.content || ''}
                                                        onChange={(e) => updateCustomSection(sIdx, 'content', e.target.value)}
                                                        placeholder="Optional summary or introductory text for this entire section..."
                                                        className="w-full h-16 text-xs p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none resize-none"
                                                    />
                                                </div>

                                                {/* Nested Items in Custom Section */}
                                                <div className="pt-2 space-y-2">
                                                    <div className="flex items-center justify-between">
                                                        <label className="block text-[11px] font-bold text-[var(--cuba-ink-muted)] uppercase tracking-wider">
                                                            Section Entries ({((sec.items || []).length)})
                                                        </label>
                                                        <button
                                                            type="button"
                                                            onClick={() => addCustomSectionItem(sIdx)}
                                                            className="text-[11px] font-bold text-[var(--cuba-primary-ink-strong)] hover:text-[var(--cuba-primary-ink-strong)] flex items-center gap-1 cursor-pointer"
                                                        >
                                                            <FaPlus className="w-2.5 h-2.5" /> Add Entry
                                                        </button>
                                                    </div>

                                                    {(!sec.items || sec.items.length === 0) ? (
                                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)] italic bg-white p-3 rounded-lg border border-dashed border-[var(--cuba-line)]">
                                                            No item entries added. Click "Add Entry" to add bullet entries, publications, or events.
                                                        </p>
                                                    ) : (
                                                        sec.items.map((item, iIdx) => (
                                                            <div key={item.id || iIdx} className="p-3 bg-white border border-[var(--cuba-line)] rounded-xl space-y-2">
                                                                <div className="flex items-center justify-between gap-2">
                                                                    <input
                                                                        type="text"
                                                                        value={item.title || ''}
                                                                        onChange={(e) => updateCustomSectionItem(sIdx, iIdx, 'title', e.target.value)}
                                                                        placeholder="Entry Title (e.g. 'Neural Attention Mechanisms Paper', 'Patent US102938')"
                                                                        className="flex-1 text-xs p-2 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-lg font-semibold text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] outline-none"
                                                                    />
                                                                    <button
                                                                        type="button"
                                                                        onClick={() => removeCustomSectionItem(sIdx, iIdx)}
                                                                        className="text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-danger)] p-1.5 rounded transition-colors cursor-pointer"
                                                                        title="Delete entry"
                                                                    >
                                                                        <FaTrash className="w-3 h-3" />
                                                                    </button>
                                                                </div>
                                                                <textarea
                                                                    value={item.description || ''}
                                                                    onChange={(e) => updateCustomSectionItem(sIdx, iIdx, 'description', e.target.value)}
                                                                    placeholder="Entry details, citations, or metrics..."
                                                                    className="w-full h-14 text-xs p-2 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-lg text-[var(--cuba-ink)] focus:border-[var(--cuba-primary-line)] outline-none resize-none"
                                                                />
                                                            </div>
                                                        ))
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                )}

                                {(profile.customSections || []).length > 0 && (
                                    <div className="pt-2">
                                        <button type="button" onClick={addCustomSection} className="w-full py-3 bg-[var(--cuba-primary-soft)] hover:bg-[var(--cuba-primary-soft)] text-[var(--cuba-primary-ink-strong)] border border-[var(--cuba-primary-line)] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-2xs cursor-pointer">
                                            <FaPlus className="w-3.5 h-3.5" /> Add Another Custom Section
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Save Master Profile Button — Back + Save + Save & Next */}
                        <div className="pt-6 border-t border-[var(--cuba-line)]">
                            {/* Mobile progress indicator */}
                            <div className="flex items-center justify-between mb-4 sm:hidden">
                                <span className="text-xs text-[var(--cuba-ink-subtle)] font-medium">
                                    Step {SUB_TAB_ORDER.indexOf(profileSubTab) + 1} of {SUB_TAB_ORDER.length}
                                </span>
                                <div className="flex gap-1">
                                    {SUB_TAB_ORDER.map((tab, _i) => (
                                        <button
                                            key={tab}
                                            type="button"
                                            onClick={() => switchProfileSubTab(tab)}
                                            className={`w-2 h-2 rounded-full transition-all cursor-pointer ${
                                                tab === profileSubTab ? 'bg-[var(--cuba-primary)] w-5' : 'bg-[var(--cuba-line-strong)]'
                                            }`}
                                        />
                                    ))}
                                </div>
                            </div>

                            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                                <div>
                                    {SUB_TAB_ORDER.indexOf(profileSubTab) > 0 && (
                                        <button
                                            type="button"
                                            onClick={() => switchProfileSubTab(SUB_TAB_ORDER[SUB_TAB_ORDER.indexOf(profileSubTab) - 1])}
                                            className="px-4 py-2.5 rounded-xl border border-[var(--cuba-line)] hover:bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                                        >
                                            <span>← Back</span>
                                        </button>
                                    )}
                                </div>
                                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                                    <button
                                        type="button"
                                        onClick={handleSubmit}
                                        disabled={isSubmitting}
                                        className={`px-5 py-2.5 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
                                            SUB_TAB_ORDER.indexOf(profileSubTab) === SUB_TAB_ORDER.length - 1
                                                ? 'bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white shadow-2xs'
                                                : 'bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)] border border-[var(--cuba-line)]/80'
                                        }`}>
                                        <FaCheckCircle className="w-3.5 h-3.5" />
                                        <span>{isSubmitting ? 'Saving...' : SUB_TAB_ORDER.indexOf(profileSubTab) === SUB_TAB_ORDER.length - 1 ? 'Save Master Profile ✓' : 'Save'}</span>
                                    </button>
                                    {SUB_TAB_ORDER.indexOf(profileSubTab) < SUB_TAB_ORDER.length - 1 && (
                                        <button
                                            type="button"
                                            onClick={handleSaveAndNext}
                                            disabled={isSubmitting}
                                            className="px-5 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white font-bold text-xs rounded-xl shadow-2xs transition-all flex items-center justify-center gap-2 cursor-pointer">
                                            <FaCheckCircle className="w-3.5 h-3.5" />
                                            <span>{isSubmitting ? 'Saving...' : `Save & Next → ${SUBTAB_CONFIG[SUB_TAB_ORDER[SUB_TAB_ORDER.indexOf(profileSubTab) + 1]]?.name || 'Next'}`}</span>
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right Column: StepGuide Rail (Identical to Build Resume design) */}
                {showProfileGuidanceRail && (
                    <aside aria-label="Master Profile Guide" className="hidden lg:block lg:col-span-4 xl:col-span-3 sticky top-6 space-y-4">
                        {(() => {
                            const conf = SUBTAB_CONFIG[profileSubTab] || SUBTAB_CONFIG.basic;
                            const gaps = conf.computeGaps(profile);
                            const isReady = gaps.length === 0;

                            return (
                                <>
                                    {/* StepGuide Card */}
                                    <div className="rounded-xl border border-[var(--cuba-line)] bg-white p-4 shadow-2xs">
                                        <div className="flex items-center justify-between gap-2">
                                            <h2 className="text-[11px] font-black uppercase tracking-widest text-[var(--cuba-ink-subtle)]">GUIDE</h2>
                                            <span
                                                className={`inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-bold ${
                                                    isReady
                                                        ? 'bg-[var(--cuba-success-soft)] text-[var(--cuba-success)] border border-[var(--cuba-success-soft)]'
                                                        : 'bg-[var(--cuba-warning-soft)] text-[var(--cuba-warning)] border border-[var(--cuba-warning-soft)]'
                                                }`}
                                            >
                                                <FaCheckCircle className="w-3 h-3" />
                                                {isReady ? 'Ready' : 'Needs attention'}
                                            </span>
                                        </div>

                                        {gaps.length > 0 && (
                                            <ul className="mt-3 space-y-1.5" aria-label="What is missing in this section">
                                                {gaps.map((gap, index) => (
                                                    <li key={`${gap}-${index}`}>
                                                        <button
                                                            type="button"
                                                            onClick={() => handleFocusGap(gap)}
                                                            className="w-full text-left flex items-start gap-2 text-[13px] leading-snug text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-primary-ink-strong)] hover:bg-[var(--cuba-primary-soft)]/60 p-1.5 -mx-1.5 rounded-lg transition-colors cursor-pointer group"
                                                            title="Click to jump to this field"
                                                        >
                                                            <span className="mt-1.5 w-1.5 h-1.5 rounded-xs shrink-0 bg-[var(--cuba-warning)] group-hover:bg-[var(--cuba-primary)] transition-colors" />
                                                            <span className="flex-1">{gap}</span>
                                                            <span className="opacity-0 group-hover:opacity-100 text-[var(--cuba-primary-ink-strong)] text-[11px] transition-opacity font-bold shrink-0">
                                                                Jump →
                                                            </span>
                                                        </button>
                                                    </li>
                                                ))}
                                            </ul>
                                        )}

                                        {conf.atsTips && conf.atsTips.length > 0 && (
                                            <div className="mt-4 border-t border-[var(--cuba-line)] pt-3">
                                                <h3 className="text-[10px] font-black uppercase tracking-wider text-[var(--cuba-ink-subtle)]">
                                                    What the ATS check says
                                                </h3>
                                                <ul className="mt-2 space-y-1.5">
                                                    {conf.atsTips.map((tip, index) => (
                                                        <li key={`${tip}-${index}`} className="flex items-start gap-2 text-[13px] leading-snug text-[var(--cuba-ink-muted)]">
                                                            <span className="mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 bg-[var(--cuba-line-strong)]" />
                                                            <span>{tip}</span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}

                                        {isReady && (
                                            <div className="mt-3 space-y-1.5 rounded-lg border border-[var(--cuba-success-soft)]/90 bg-[var(--cuba-success-soft)]/70 p-3">
                                                <div className="flex items-center gap-1.5 text-xs font-bold text-[var(--cuba-success)]">
                                                    <FaCheckCircle className="w-3.5 h-3.5 text-[var(--cuba-success)]" />
                                                    <span>Optimized for screening ✓</span>
                                                </div>
                                                <p className="text-[12px] leading-relaxed text-[var(--cuba-success)]/90">
                                                    All essential fields and formatting checks for this section are satisfied.
                                                </p>
                                            </div>
                                        )}
                                    </div>

                                    {/* Live AI Sync / Master Source card — Clean Light */}
                                    <div className="rounded-xl border border-[var(--cuba-line)] bg-white p-4 shadow-2xs space-y-3">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2">
                                                <span className="w-2 h-2 rounded-full bg-[var(--cuba-success)] animate-pulse"></span>
                                                <span className="text-xs font-bold text-[var(--cuba-ink)]">Master Sync Active</span>
                                            </div>
                                            <span className="text-[10px] font-bold text-[var(--cuba-primary-ink-strong)] bg-[var(--cuba-primary-soft)] border border-[var(--cuba-primary-line)] px-2 py-0.5 rounded-md">
                                                Single Source
                                            </span>
                                        </div>
                                        <p className="text-xs leading-relaxed text-[var(--cuba-ink-muted)]">
                                            Data saved here automatically synchronizes across all <strong>51 AI Resume Templates</strong>, Cover Letters, and Portfolio.
                                        </p>
                                        <button
                                            type="button"
                                            onClick={() => navigate('/build-resume/heading')}
                                            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white text-xs font-bold shadow-2xs transition-colors cursor-pointer"
                                        >
                                            <span>Build / Edit Resumes</span>
                                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                            </svg>
                                        </button>
                                    </div>

                                    {/* Sovereign MariaDB Data Protection Trust Badge — Clean Light */}
                                    <div className="rounded-xl border border-[var(--cuba-line)] bg-[var(--cuba-canvas)]/80 p-3.5 text-xs text-[var(--cuba-ink-muted)] space-y-1.5 shadow-2xs">
                                        <div className="flex items-center gap-2 font-bold text-[var(--cuba-ink)]">
                                            <FaShieldAlt className="w-3.5 h-3.5 text-[var(--cuba-success)] shrink-0" />
                                            <span>Sovereign Storage</span>
                                        </div>
                                        <p className="text-[11px] leading-relaxed text-[var(--cuba-ink-subtle)]">
                                            Protected with AES-256 GCM encryption at rest and in transit. Private, isolated by account, and GDPR compliant.
                                        </p>
                                    </div>
                                </>
                            );
                        })()}
                    </aside>
                )}
            </div>
        </div>
    ) : (
                    /* Account & Security Settings — 10/10 World Class Security Center */
                    <div className="space-y-6">
                        {/* Card 1: Subscription Tier Overview & Billing CTA */}
                        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-5 sm:p-6 text-white shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                            <div className="flex items-center gap-3.5 min-w-0">
                                <div className="w-12 h-12 rounded-2xl bg-[var(--cuba-primary)]/20 border border-[var(--cuba-primary-line)]/30 flex items-center justify-center text-[var(--cuba-primary-ink-strong)] font-extrabold text-lg shrink-0">
                                    <FaCrown className="w-6 h-6 text-[var(--cuba-warning)]" />
                                </div>
                                <div className="min-w-0">
                                    <div className="flex items-center gap-2 mb-0.5">
                                        <h3 className="text-sm font-bold text-white uppercase tracking-wider">Subscription Tier</h3>
                                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold text-[var(--cuba-ink-inverse)] bg-[var(--cuba-primary)]/30 border border-[var(--cuba-primary-line)]/40 uppercase">
                                            {effectiveMembership || 'Basic'}
                                        </span>
                                    </div>
                                    <p className="text-xs text-[var(--cuba-ink-subtle)] font-normal">
                                        {effectiveMembership === 'Enterprise'
                                            ? 'Enterprise workspace access with dedicated organization governance & AI quotas.'
                                            : effectiveMembership === 'Premium' || effectiveMembership === 'Pro'
                                                ? 'Active PRO membership with STAR AI bullet synthesizer, clean PDF & Word DocX export.'
                                                : 'Free Basic tier. Access to all 51 ATS templates, real-time score, and basic AI.'}
                                    </p>
                                </div>
                            </div>
                            <a
                                href="/dashboard/plans"
                                className="px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer">
                                <FaCrown className="w-3.5 h-3.5 text-[var(--cuba-warning)]" />
                                <span>{effectiveMembership === 'Enterprise' ? 'Manage Enterprise & Plans' : (effectiveMembership === 'Premium' || effectiveMembership === 'Pro') ? 'Manage Subscription & Plans' : 'Upgrade to PRO Career Pass'}</span>
                            </a>
                        </div>

                        {/* Card 2: Account Credentials & Password Change Form */}
                        <div className="bg-white rounded-2xl border border-[var(--cuba-line)] p-6 sm:p-8 shadow-sm space-y-6">
                            <div className="flex items-center space-x-3 pb-4 border-b border-[var(--cuba-line)]">
                                <div className="p-2.5 bg-[var(--cuba-primary-soft)] rounded-xl">
                                    <FaShieldAlt className="w-5 h-5 text-[var(--cuba-primary-ink-strong)]" />
                                </div>
                                <div>
                                    <h2 className="text-base font-bold text-[var(--cuba-ink)]">Account Credentials &amp; Security</h2>
                                    <p className="text-xs text-[var(--cuba-ink-subtle)]">Update your primary login email and security authentication password.</p>
                                </div>
                            </div>

                            <form onSubmit={handleAccountSubmit} className="space-y-6">
                                {/* Account Email Address Input */}
                                <div>
                                    <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1 flex items-center gap-1.5">
                                        <FaEnvelope className="w-3.5 h-3.5 text-[var(--cuba-primary-ink-strong)]" /> Account Email Address
                                    </label>
                                    <input
                                        type="email"
                                        name="email"
                                        value={databaseAccountSettings.email}
                                        onChange={(e) => setDatabaseAccountSettings({ ...databaseAccountSettings, email: e.target.value })}
                                        placeholder="name@example.com"
                                        className="w-full text-xs p-3 bg-white border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                    />
                                </div>

                                {/* Password Change / Creation Grid */}
                                <div className="border-t border-[var(--cuba-line)] pt-6 space-y-4">
                                    <h3 className="text-xs font-bold text-[var(--cuba-ink)] uppercase tracking-wider flex items-center gap-1.5">
                                        <FaKey className="w-3.5 h-3.5 text-[var(--cuba-primary-ink-strong)]" /> {usesPasswordProvider ? 'Security Password Update & Re-authentication' : 'Create Account Security Password'}
                                    </h3>

                                    {usesPasswordProvider ? (
                                        /* Current Password Input for Identity Verification */
                                        <div>
                                            <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1">Current Password (Required for Email or Password Change)</label>
                                            <div className="relative">
                                                <input
                                                    type={showPasswordMap.current ? 'text' : 'password'}
                                                    value={accountPasswordState.currentPassword}
                                                    onChange={(e) => setAccountPasswordState({ ...accountPasswordState, currentPassword: e.target.value })}
                                                    placeholder="Enter current password to re-authenticate"
                                                    className="w-full text-xs p-3 pr-10 bg-white border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                />
                                                <button
                                                    type="button"
                                                    onClick={() => setShowPasswordMap({ ...showPasswordMap, current: !showPasswordMap.current })}
                                                    className="absolute right-3 top-3 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)]">
                                                    {showPasswordMap.current ? <FaEyeSlash className="w-3.5 h-3.5" /> : <FaEye className="w-3.5 h-3.5" />}
                                                </button>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="p-3.5 bg-[var(--cuba-info-soft)]/80 border border-[var(--cuba-info-soft)]/80 rounded-xl text-xs text-[var(--cuba-info)] space-y-1">
                                            <div className="font-bold flex items-center gap-1.5 text-[var(--cuba-info)]">
                                                <FaShieldAlt className="w-3.5 h-3.5 text-[var(--cuba-info)]" />
                                                <span>OAuth-Authenticated Account ({primaryOAuthProvider})</span>
                                            </div>
                                            <p className="text-[var(--cuba-info)] text-[11px] leading-relaxed">
                                                You are currently signed in with {primaryOAuthProvider}. Set an independent security password below to also enable direct email and password login without affecting your {primaryOAuthProvider} account.
                                            </p>
                                        </div>
                                    )}

                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        {/* New Security Password */}
                                        <div>
                                            <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1">{usesPasswordProvider ? 'New Security Password' : 'Set Security Password'}</label>
                                            <div className="relative">
                                                <input
                                                    type={showPasswordMap.new ? 'text' : 'password'}
                                                    value={accountPasswordState.newPassword}
                                                    onChange={(e) => setAccountPasswordState({ ...accountPasswordState, newPassword: e.target.value })}
                                                    placeholder="Min. 8 characters"
                                                    className="w-full text-xs p-3 pr-10 bg-white border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                />
                                                <button
                                                    type="button"
                                                    onClick={() => setShowPasswordMap({ ...showPasswordMap, new: !showPasswordMap.new })}
                                                    className="absolute right-3 top-3 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)]">
                                                    {showPasswordMap.new ? <FaEyeSlash className="w-3.5 h-3.5" /> : <FaEye className="w-3.5 h-3.5" />}
                                                </button>
                                            </div>
                                        </div>

                                        {/* Confirm New Password */}
                                        <div>
                                            <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1">{usesPasswordProvider ? 'Confirm New Password' : 'Confirm Password'}</label>
                                            <div className="relative">
                                                <input
                                                    type={showPasswordMap.confirm ? 'text' : 'password'}
                                                    value={accountPasswordState.confirmPassword}
                                                    onChange={(e) => setAccountPasswordState({ ...accountPasswordState, confirmPassword: e.target.value })}
                                                    placeholder="Re-enter password"
                                                    className="w-full text-xs p-3 pr-10 bg-white border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-primary-line)] focus:ring-2 focus:ring-[var(--cuba-primary-soft)] outline-none"
                                                />
                                                <button
                                                    type="button"
                                                    onClick={() => setShowPasswordMap({ ...showPasswordMap, confirm: !showPasswordMap.confirm })}
                                                    className="absolute right-3 top-3 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)]">
                                                    {showPasswordMap.confirm ? <FaEyeSlash className="w-3.5 h-3.5" /> : <FaEye className="w-3.5 h-3.5" />}
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Password Criteria Real-Time Checklist */}
                                    {accountPasswordState.newPassword && (
                                        <div className="p-3 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-xl text-xs space-y-1.5">
                                            <span className="font-bold text-[var(--cuba-ink-muted)] block text-[11px] uppercase tracking-wider mb-1">Security Standards Checklist</span>
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-semibold">
                                                <div className={`flex items-center gap-1.5 ${accountPasswordState.newPassword.length >= 8 ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`}>
                                                    <FaCheckCircle className={`w-3 h-3 ${accountPasswordState.newPassword.length >= 8 ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`} />
                                                    <span>At least 8 characters</span>
                                                </div>
                                                <div className={`flex items-center gap-1.5 ${/[A-Z]/.test(accountPasswordState.newPassword) ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`}>
                                                    <FaCheckCircle className={`w-3 h-3 ${/[A-Z]/.test(accountPasswordState.newPassword) ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`} />
                                                    <span>Uppercase letter (A-Z)</span>
                                                </div>
                                                <div className={`flex items-center gap-1.5 ${/\d/.test(accountPasswordState.newPassword) || /[^A-Za-z0-9]/.test(accountPasswordState.newPassword) ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`}>
                                                    <FaCheckCircle className={`w-3 h-3 ${/\d/.test(accountPasswordState.newPassword) || /[^A-Za-z0-9]/.test(accountPasswordState.newPassword) ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`} />
                                                    <span>Number or special character</span>
                                                </div>
                                                <div className={`flex items-center gap-1.5 ${accountPasswordState.newPassword && accountPasswordState.newPassword === accountPasswordState.confirmPassword ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`}>
                                                    <FaCheckCircle className={`w-3 h-3 ${accountPasswordState.newPassword && accountPasswordState.newPassword === accountPasswordState.confirmPassword ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`} />
                                                    <span>Passwords match</span>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    <div className="flex justify-end pt-4 border-t border-[var(--cuba-line)]">
                                        <button
                                            type="submit"
                                            disabled={isSubmitting}
                                            className="w-full sm:w-auto px-6 py-3.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2">
                                            <FaCheckCircle className="w-3.5 h-3.5" />
                                            <span>{isSubmitting ? 'Updating Account...' : (usesPasswordProvider ? 'Update Account Security ✓' : 'Create Account Security Password ✓')}</span>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        {/* Card 2.5: Twilio Mobile SMS Security & Alerts Center */}
                        <div className="bg-white rounded-2xl border border-[var(--cuba-line)] p-6 sm:p-8 shadow-sm space-y-6">
                            <div className="flex items-center space-x-3 pb-4 border-b border-[var(--cuba-line)]">
                                <div className="p-2.5 bg-[var(--cuba-danger-soft)] rounded-xl">
                                    <FaMobileAlt className="w-5 h-5 text-[var(--cuba-danger)]" />
                                </div>
                                <div>
                                    <h2 className="text-base font-bold text-[var(--cuba-ink)]">Mobile SMS Security &amp; Outgoing Alerts</h2>
                                    <p className="text-xs text-[var(--cuba-ink-subtle)]">Configure your primary mobile number for instant SMS security notifications upon logins, 2FA updates, or password changes.</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1 flex items-center gap-1.5">
                                        <FaMobileAlt className="w-3.5 h-3.5 text-[var(--cuba-danger)]" /> Mobile Phone Number (with Country Code)
                                    </label>
                                    <input
                                        type="tel"
                                        value={profile?.phone || ''}
                                        onChange={(e) => setProfile(prev => ({ ...prev, phone: e.target.value }))}
                                        placeholder="+1 415 555 2671 / +91 9876543210"
                                        className="w-full text-xs p-3 bg-white border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-danger)] focus:ring-2 focus:ring-[var(--cuba-danger-soft)] outline-none"
                                    />
                                </div>

                                <div className="flex flex-col justify-end">
                                    <button
                                        type="button"
                                        onClick={async () => {
                                            const phoneToUse = profile?.phone;
                                            if (!phoneToUse || !phoneToUse.trim()) {
                                                setToastState({ type: 'error', msg: 'Please enter a valid mobile phone number first.' });
                                                return;
                                            }
                                            setToastState({ type: 'info', msg: 'Dispatching test SMS via Twilio Gateway...' });
                                            const res = await sendSmsNotification(phoneToUse, 'AI Resume Builder Security Alert: Test SMS notification successful!');
                                            if (res.success) {
                                                setToastState({ type: 'success', msg: `SMS Security Alert sent successfully to ${phoneToUse}! (SID: ${res.messageSid || 'OK'})` });
                                            } else {
                                                setToastState({ type: 'error', msg: `SMS Dispatch Failed: ${res.error}` });
                                            }
                                        }}
                                        className="w-full sm:w-auto px-5 py-3 bg-[var(--cuba-ink)] hover:bg-[var(--cuba-ink)] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer">
                                        <FaMobileAlt className="w-3.5 h-3.5 text-[var(--cuba-danger)]" />
                                        <span>Dispatch Test SMS Alert</span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Card 4: Two-Factor Authentication (TOTP 2FA) */}
                        <div id="totp-security-hub" className="bg-white rounded-2xl border border-[var(--cuba-line)] p-6 sm:p-8 shadow-sm space-y-4 scroll-mt-24">
                            <div className="flex items-center justify-between gap-3 pb-3 border-b border-[var(--cuba-line)]">
                                <div className="flex items-center space-x-3">
                                    <div className="p-2.5 bg-[var(--cuba-primary-soft)] rounded-xl">
                                        <FaMobileAlt className="w-5 h-5 text-[var(--cuba-primary-ink-strong)]" />
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold text-[var(--cuba-ink)]">Two-Factor Authentication (TOTP 2FA)</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Protect your account using Google Authenticator, Authy, Microsoft Authenticator, or 1Password.</p>
                                    </div>
                                </div>
                                <span className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                                    totpStatus.enabled
                                        ? 'bg-[var(--cuba-success-soft)] text-[var(--cuba-success)] border border-[var(--cuba-success-soft)]'
                                        : 'bg-[var(--cuba-canvas)] text-[var(--cuba-ink-muted)] border border-[var(--cuba-line)]'
                                }`}>
                                    <FaShieldAlt className={`w-3 h-3 ${totpStatus.enabled ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-ink-subtle)]'}`} />
                                    <span>{totpStatus.enabled ? '2FA Active 🟢' : 'Not Enrolled ⚪'}</span>
                                </span>
                            </div>

                            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-xl">
                                <div className="text-xs text-[var(--cuba-ink-muted)] space-y-1">
                                    <p className="font-bold text-[var(--cuba-ink)]">
                                        {totpStatus.enabled ? 'Your account is secured with 2FA.' : 'Add an extra layer of security to your account.'}
                                    </p>
                                    <p className="text-[11px] text-[var(--cuba-ink-subtle)]">
                                        {totpStatus.enabled
                                            ? 'Each login will require entering a 6-digit dynamic code generated by your mobile authenticator app.'
                                            : 'Scan a QR code in Google Authenticator or Authy to generate dynamic login codes.'}
                                    </p>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                    {totpStatus.enabled ? (
                                        <>
                                            <button
                                                type="button"
                                                onClick={() => setTotpDisableModalOpen(true)}
                                                className="px-3.5 py-2 bg-[var(--cuba-danger-soft)] hover:bg-[var(--cuba-danger-soft)] border border-[var(--cuba-danger-soft)] text-[var(--cuba-danger)] text-xs font-bold rounded-xl transition-all shadow-2xs cursor-pointer">
                                                Disable 2FA
                                            </button>
                                        </>
                                    ) : (
                                        <button
                                            type="button"
                                            onClick={handleStartTotpSetup}
                                            className="px-4 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer">
                                            <FaQrcode className="w-3.5 h-3.5" />
                                            <span>Enable 2FA (Authenticator App)</span>
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Card 5: Email Verification & Authentication Status */}
                        <div className="bg-white rounded-2xl border border-[var(--cuba-line)] p-6 sm:p-8 shadow-sm space-y-4">
                            <div className="flex items-center justify-between gap-3 pb-3 border-b border-[var(--cuba-line)]">
                                <div className="flex items-center space-x-3">
                                    <div className="p-2.5 bg-[var(--cuba-primary-soft)] rounded-xl">
                                        <FaEnvelope className="w-5 h-5 text-[var(--cuba-primary-ink-strong)]" />
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold text-[var(--cuba-ink)]">Email Verification Status</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Verify your email address for account recovery and notification delivery.</p>
                                    </div>
                                </div>
                                <span className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                                    fire.auth().currentUser?.emailVerified
                                        ? 'bg-[var(--cuba-success-soft)] text-[var(--cuba-success)] border border-[var(--cuba-success-soft)]'
                                        : 'bg-[var(--cuba-warning-soft)] text-[var(--cuba-warning)] border border-[var(--cuba-warning-soft)]'
                                }`}>
                                    <FaCheckCircle className={`w-3 h-3 ${fire.auth().currentUser?.emailVerified ? 'text-[var(--cuba-success)]' : 'text-[var(--cuba-warning)]'}`} />
                                    <span>{fire.auth().currentUser?.emailVerified ? 'Verified Email 🟢' : 'Unverified Email 🟡'}</span>
                                </span>
                            </div>

                            {!fire.auth().currentUser?.emailVerified && (
                                <div className="p-4 bg-[var(--cuba-warning-soft)]/60 border border-[var(--cuba-warning-soft)] rounded-xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                                    <div className="text-xs text-[var(--cuba-warning)]">
                                        <p className="font-bold">Your email address has not been verified yet.</p>
                                        <p className="text-[11px] text-[var(--cuba-warning)]">Click below to send a verification confirmation link to <strong>{fire.auth().currentUser?.email}</strong>.</p>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={handleSendVerificationEmail}
                                        className="px-4 py-2 bg-[var(--cuba-warning)] hover:bg-[var(--cuba-warning)] text-white text-xs font-bold rounded-xl transition-all shadow-2xs shrink-0">
                                        Resend Verification Email
                                    </button>
                                </div>
                            )}
                        </div>

                        <div className="bg-white rounded-2xl border border-[var(--cuba-line)] p-6 sm:p-8 shadow-sm space-y-4">
                            <div><h3 className="text-sm font-bold text-[var(--cuba-ink)]">Preferences &amp; Privacy</h3><p className="text-xs text-[var(--cuba-ink-subtle)]">These account-scoped choices do not change analytics consent or payment state.</p></div>
                            <label className="block text-xs font-bold text-[var(--cuba-ink-muted)]" htmlFor="account-language">Language<select id="account-language" value={preferences.language} onChange={event => setPreferences(current => ({ ...current, language: event.target.value }))} className="mt-1 w-full rounded-xl border border-[var(--cuba-line-strong)] p-3 text-sm font-normal"><option value="en">English</option><option value="hi">हिन्दी</option><option value="es">Español</option><option value="fr">Français</option><option value="de">Deutsch</option><option value="pt">Português</option><option value="it">Italiano</option><option value="nl">Nederlands</option></select></label>
                            <div className="grid gap-3 sm:grid-cols-2">{[['emailNotifications','Email notifications'],['securityNotifications','Security notifications'],['productUpdates','Product updates'],['profileDiscoverable','Discoverable public profile']].map(([key,label]) => <label key={key} className="flex items-center gap-2 rounded-xl border border-[var(--cuba-line)] p-3 text-xs font-semibold"><input type="checkbox" checked={Boolean(preferences[key])} onChange={event => setPreferences(current => ({ ...current, [key]: event.target.checked }))} />{label}</label>)}</div>
                            <div className="flex flex-wrap items-center gap-3 pt-1">
                                <button type="button" onClick={handlePreferencesSave} disabled={savingPreferences} className="rounded-xl bg-[var(--cuba-primary)] px-4 py-2 text-xs font-bold text-white hover:bg-[var(--cuba-primary-strong)] disabled:opacity-50 transition-all">{savingPreferences ? 'Saving…' : 'Save preferences'}</button>
                                <button type="button" onClick={openPrivacyChoicesModal} className="rounded-xl border border-[var(--cuba-line-strong)] bg-white px-4 py-2 text-xs font-bold text-[var(--cuba-ink-muted)] hover:bg-[var(--cuba-canvas)] transition-all shadow-2xs">Manage Cookie &amp; Analytics Choices</button>
                            </div>
                        </div>

                        {/* Card 5: GDPR Data Portability & Export */}
                        <div className="bg-white rounded-2xl border border-[var(--cuba-line)] p-6 sm:p-8 shadow-sm space-y-4">
                            <div className="flex items-center justify-between gap-3 pb-3 border-b border-[var(--cuba-line)]">
                                <div className="flex items-center space-x-3">
                                    <div className="p-2.5 bg-[var(--cuba-info-soft)] rounded-xl">
                                        <FaDownload className="w-5 h-5 text-[var(--cuba-info)]" />
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold text-[var(--cuba-ink)]">GDPR Data Portability &amp; Backup</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Download JSON for your profile, resumes, cover letters, Portfolios, CMS posts, employer content, applications, and accessible transactions. Provider-held identity/billing/audit records may require support export channels.</p>
                                    </div>
                                </div>
                                <button
                                    type="button"
                                    onClick={handleExportUserData}
                                    disabled={isSubmitting}
                                    className="px-4 py-2.5 bg-[var(--cuba-info)] hover:bg-[var(--cuba-info)] text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center gap-2 shrink-0">
                                    <FaDownload className="w-3.5 h-3.5" />
                                    <span>Download All My Data (JSON)</span>
                                </button>
                            </div>
                        </div>

                        {/* Card 6: Active Device Sessions & Security Logs */}
                        <div className="bg-white rounded-2xl border border-[var(--cuba-line)] p-6 sm:p-8 shadow-sm space-y-4">
                            <div className="flex items-center justify-between gap-3 pb-3 border-b border-[var(--cuba-line)]">
                                <div className="flex items-center space-x-3">
                                    <div className="p-2.5 bg-[var(--cuba-success-soft)] rounded-xl">
                                        <FaDesktop className="w-5 h-5 text-[var(--cuba-success)]" />
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold text-[var(--cuba-ink)]">Active Device Sessions</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Manage device logins and authenticated browser sessions.</p>
                                    </div>
                                </div>
                            </div>

                            <div className="p-4 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-xl flex items-center justify-between gap-3">
                                <div className="flex items-center gap-3">
                                    <div className="w-9 h-9 rounded-lg bg-[var(--cuba-success-soft)] border border-[var(--cuba-success-soft)] flex items-center justify-center text-[var(--cuba-success)] font-bold text-xs shrink-0">
                                        💻
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <span className="text-xs font-bold text-[var(--cuba-ink)]">Current Session</span>
                                            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-[var(--cuba-success-soft)] text-[var(--cuba-success)]">Active Now</span>
                                        </div>
                                        <p className="text-[11px] text-[var(--cuba-ink-subtle)] font-medium">
                                            {navigator.platform || 'Desktop'} • {navigator.userAgent.includes('Chrome') ? 'Chrome Web Browser' : 'Modern Browser'}
                                        </p>
                                    </div>
                                </div>
                                <button
                                    type="button"
                                    onClick={() => triggerNotification('Session security verified. Current device authenticated.')}
                                    className="px-3.5 py-2 bg-white hover:bg-[var(--cuba-canvas)] border border-[var(--cuba-line-strong)] text-[var(--cuba-ink-muted)] text-xs font-bold rounded-xl transition-all shadow-2xs">
                                    Verify Active Session
                                </button>
                            </div>
                        </div>

                        {/* Card 7: Historical Login Audit Trail */}
                        <div className="bg-white rounded-2xl border border-[var(--cuba-line)] p-6 sm:p-8 shadow-sm space-y-4">
                            <div className="flex items-center justify-between gap-3 pb-3 border-b border-[var(--cuba-line)]">
                                <div className="flex items-center space-x-3">
                                    <div className="p-2.5 bg-[var(--cuba-canvas)] rounded-xl">
                                        <FaHistory className="w-5 h-5 text-[var(--cuba-ink-muted)]" />
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold text-[var(--cuba-ink)]">Historical Login Audit Trail</h3>
                                        <p className="text-xs text-[var(--cuba-ink-subtle)]">Security history of authenticated logins, devices, browsers, and timestamps.</p>
                                    </div>
                                </div>
                                <button
                                    type="button"
                                    onClick={async () => {
                                        const user = fire.auth().currentUser;
                                        if (user) {
                                            const logs = await getUserLoginHistory(user.uid);
                                            setLoginHistory(logs);
                                            triggerNotification('Login audit trail updated!');
                                        }
                                    }}
                                    className="px-3 py-1.5 bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)] text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer">
                                    <FaSyncAlt className="w-3 h-3" /> Refresh Trail
                                </button>
                            </div>

                            {loginHistory.length === 0 ? (
                                <div className="p-6 text-center bg-[var(--cuba-canvas)] border border-dashed border-[var(--cuba-line)] rounded-xl space-y-1">
                                    <p className="text-xs font-semibold text-[var(--cuba-ink-muted)]">Recent Login Session Recorded</p>
                                    <p className="text-[11px] text-[var(--cuba-ink-subtle)]">Future login sessions will automatically build your security audit trail here.</p>
                                </div>
                            ) : (
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left text-xs">
                                        <thead>
                                            <tr className="border-b border-[var(--cuba-line)] text-[var(--cuba-ink-subtle)] font-bold uppercase tracking-wider text-[10px]">
                                                <th className="pb-2">Date &amp; Time</th>
                                                <th className="pb-2">Device OS</th>
                                                <th className="pb-2">Browser</th>
                                                <th className="pb-2">Sign-In Provider</th>
                                                <th className="pb-2 text-right">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-[var(--cuba-line)]">
                                            {loginHistory.map((log, idx) => (
                                                <tr key={log.id || idx} className="hover:bg-[var(--cuba-canvas)]/80 transition-colors">
                                                    <td className="py-3 font-semibold text-[var(--cuba-ink)]">
                                                        {log.date ? `${log.date} ${log.time || ''}` : new Date(log.timestamp).toLocaleString()}
                                                    </td>
                                                    <td className="py-3 text-[var(--cuba-ink-muted)] font-medium">{log.device || 'Windows PC'}</td>
                                                    <td className="py-3 text-[var(--cuba-ink-muted)] font-medium">{log.browser || 'Google Chrome'}</td>
                                                    <td className="py-3 text-[var(--cuba-ink-muted)] font-mono text-[11px]">{log.authMethod || 'Email & Password'}</td>
                                                    <td className="py-3 text-right">
                                                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[var(--cuba-success-soft)] text-[var(--cuba-success)] border border-[var(--cuba-success-soft)]">
                                                            <FaCheckCircle className="w-2.5 h-2.5 text-[var(--cuba-success)]" />
                                                            <span>{log.status || 'Success 🟢'}</span>
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>

                        {/* Card 4: Danger Zone — Account Deletion */}
                        <div className="bg-[var(--cuba-danger-soft)]/50 border border-[var(--cuba-danger-soft)]/80 rounded-2xl p-6 sm:p-8 space-y-4 shadow-2xs">
                            <div className="flex items-center justify-between gap-3">
                                <div className="flex items-center space-x-3">
                                    <div className="p-2.5 bg-[var(--cuba-danger-soft)] rounded-xl">
                                        <FaExclamationTriangle className="w-5 h-5 text-[var(--cuba-danger)]" />
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold text-[var(--cuba-danger)]">Danger Zone — Account Deletion</h3>
                                        <p className="text-xs text-[var(--cuba-danger)]">Permanently delete your account, master profile, saved resumes, and subscription data.</p>
                                    </div>
                                </div>
                                <button
                                    type="button"
                                    onClick={() => setDeleteAccountModalOpen(true)}
                                    className="px-4 py-2.5 bg-[var(--cuba-danger)] hover:bg-[var(--cuba-danger)] text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 shrink-0">
                                    <FaTrash className="w-3.5 h-3.5" />
                                    <span>Delete Account</span>
                                </button>
                                </div>
                            </div>
                        </div>
                )}
            </div>
        </div>

        {/* Image Crop Modal — shown when user picks a photo */}
        {cropModalSrc && (
            <ImageCropModal
                imageSrc={cropModalSrc}
                onCrop={handleCroppedImage}
                onCancel={() => setCropModalSrc(null)}
            />
        )}

        {/* Danger Zone Account Deletion Confirmation Modal */}
        {deleteAccountModalOpen && (
            <div className="fixed inset-0 z-50 bg-[var(--cuba-ink)]/60 backdrop-blur-xs flex items-center justify-center p-4" role="presentation" onKeyDown={event => { if (event.key === 'Escape' && !isSubmitting) setDeleteAccountModalOpen(false); }}>
                <div role="alertdialog" aria-modal="true" aria-labelledby="delete-account-title" aria-describedby="delete-account-description" className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4 border border-[var(--cuba-line)]">
                    <div className="flex items-center gap-3 text-[var(--cuba-danger)]">
                        <FaExclamationTriangle className="w-6 h-6 shrink-0" />
                        <h3 id="delete-account-title" className="text-base font-bold text-[var(--cuba-ink)]">Confirm Permanent Account Deletion</h3>
                    </div>
                    <p id="delete-account-description" className="text-xs text-[var(--cuba-ink-muted)] leading-relaxed">
                        This action is <strong>irreversible</strong>. Your identity and owned profile, resume, cover-letter, Portfolio, CMS, employer, job, application, notification, and messaging data will be removed. Payment, invoice, transaction, subscription, and security-audit records may be retained for legal, fraud-prevention, and accounting obligations.
                    </p>
                    <div className="space-y-3">
                        {usesPasswordProvider ? (
                            <div>
                                <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1">Current Password (Required for Identity Verification):</label>
                                <input type="password" value={deletePassword} onChange={(e) => setDeletePassword(e.target.value)} placeholder="Enter current password" className="w-full text-xs p-3 bg-[var(--cuba-canvas)] border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-danger)] outline-none" />
                            </div>
                        ) : (
                            <p className="text-xs text-[var(--cuba-ink-muted)]">Your identity provider or recent verified sign-in will be used for confirmation.</p>
                        )}
                        <div>
                            <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1">
                                Type <span className="font-mono text-[var(--cuba-danger)] font-bold">DELETE</span> to confirm:
                            </label>
                            <input
                                type="text"
                                value={deleteInputText}
                                onChange={(e) => setDeleteInputText(e.target.value)}
                                placeholder="DELETE"
                                className="w-full text-xs p-3 bg-[var(--cuba-canvas)] border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] font-mono font-bold focus:border-[var(--cuba-danger)] outline-none"
                            />
                        </div>
                    </div>
                    <div className="flex items-center justify-end gap-2 pt-2">
                        <button
                            type="button"
                            autoFocus
                            onClick={() => { setDeleteAccountModalOpen(false); setDeleteInputText(''); setDeletePassword(''); }}
                            className="px-4 py-2 bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)] font-bold text-xs rounded-xl cursor-pointer">
                            Cancel
                        </button>
                        <button
                            type="button"
                            disabled={deleteInputText !== 'DELETE' || (usesPasswordProvider && !deletePassword) || isSubmitting}
                            onClick={handleDeleteAccountConfirmed}
                            className="px-4 py-2 bg-[var(--cuba-danger)] hover:bg-[var(--cuba-danger)] disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer">
                            {isSubmitting ? 'Purging Account...' : 'Permanently Delete Account'}
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* TOTP 2FA Setup Wizard Modal */}
        {totpSetupModalOpen && (
            <div className="fixed inset-0 z-50 bg-[var(--cuba-ink)]/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto" role="presentation" onKeyDown={event => { if (event.key === 'Escape' && !isSubmitting) setTotpSetupModalOpen(false); }}>
                <div role="dialog" aria-modal="true" aria-labelledby="totp-setup-title" className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl space-y-5 border border-[var(--cuba-line)] my-8">
                    {/* Header */}
                    <div className="flex items-center justify-between border-b border-[var(--cuba-line)] pb-3">
                        <div className="flex items-center gap-2.5">
                            <div className="p-2 bg-[var(--cuba-primary-soft)] rounded-lg text-[var(--cuba-primary-ink-strong)] font-bold">
                                <FaQrcode className="w-5 h-5" />
                            </div>
                            <div>
                                <h3 id="totp-setup-title" className="text-base font-bold text-[var(--cuba-ink)]">Set Up Authenticator App (2FA)</h3>
                                <p className="text-[11px] text-[var(--cuba-ink-subtle)]">Step {totpSetupStep} of 3 • Google Authenticator / Authy</p>
                            </div>
                        </div>
                        <button
                            type="button"
                            onClick={() => setTotpSetupModalOpen(false)}
                            className="text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-ink-muted)] text-lg font-bold">
                            ✕
                        </button>
                    </div>

                    {/* Step 1: Scan QR Code & View Base32 Secret Key */}
                    {totpSetupStep === 1 && (
                        <div className="space-y-4">
                            <div className="p-3 bg-[var(--cuba-primary-soft)]/70 border border-[var(--cuba-primary-line)] rounded-xl text-xs text-[var(--cuba-primary-ink-strong)] leading-relaxed">
                                <strong>1. Open Google Authenticator or Authy</strong> on your mobile phone and tap <strong>"+"</strong> to add a new account, then scan the QR code below.
                            </div>

                            <div className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-2xl">
                                <div className="p-2 bg-white rounded-xl shadow-xs border border-[var(--cuba-line)] shrink-0">
                                    <img
                                        src={totpQrCodeDataUrl}
                                        alt="2FA QR Code"
                                        className="w-36 h-36"
                                    />
                                </div>
                                <div className="space-y-2 text-xs min-w-0 flex-1">
                                    <span className="font-bold text-[var(--cuba-ink-muted)] block uppercase tracking-wider text-[10px]">Can't scan? Enter key manually:</span>
                                    <div className="flex items-center gap-2 p-2.5 bg-white border border-[var(--cuba-line-strong)] rounded-xl font-mono text-xs font-bold text-[var(--cuba-primary-ink-strong)]">
                                        <span className="truncate select-all">{totpSetupSecret}</span>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                navigator.clipboard.writeText(totpSetupSecret);
                                                triggerNotification('Secret key copied to clipboard!');
                                            }}
                                            className="p-1 text-[var(--cuba-ink-subtle)] hover:text-[var(--cuba-primary-ink-strong)] shrink-0"
                                            title="Copy key">
                                            <FaCopy className="w-3.5 h-3.5" />
                                        </button>
                                    </div>
                                    <p className="text-[10px] text-[var(--cuba-ink-subtle)]">Account Type: Time-based (TOTP), 6 digits, 30s period.</p>
                                </div>
                            </div>

                            <div className="flex justify-end gap-2 pt-2 border-t border-[var(--cuba-line)]">
                                <button
                                    type="button"
                                    onClick={() => setTotpSetupModalOpen(false)}
                                    className="px-4 py-2 bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)] font-bold text-xs rounded-xl">
                                    Cancel
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setTotpSetupStep(2)}
                                    className="px-5 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] text-white font-bold text-xs rounded-xl shadow-xs">
                                    Next: Verify Code →
                                </button>
                            </div>
                        </div>
                    )}

                    {/* Step 2: 6-Digit TOTP Verification */}
                    {totpSetupStep === 2 && (
                        <div className="space-y-4">
                            <div className="p-3 bg-[var(--cuba-canvas)] border border-[var(--cuba-line)] rounded-xl text-xs text-[var(--cuba-ink-muted)] leading-relaxed">
                                Enter the <strong>6-digit security code</strong> currently generated by Google Authenticator / Authy to verify setup.
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1">6-Digit Verification Code</label>
                                <input
                                    type="text"
                                    maxLength={6}
                                    value={totpVerificationCode}
                                    onChange={(e) => setTotpVerificationCode(e.target.value.replace(/\D/g, ''))}
                                    placeholder="123456"
                                    className="w-full text-center text-xl tracking-widest font-mono p-3.5 bg-[var(--cuba-canvas)] border border-[var(--cuba-primary-line)] rounded-xl text-[var(--cuba-primary-ink-strong)] font-extrabold focus:border-[var(--cuba-primary-line)] outline-none"
                                />
                            </div>

                            <div className="flex items-center justify-between pt-2 border-t border-[var(--cuba-line)]">
                                <button
                                    type="button"
                                    onClick={() => setTotpSetupStep(1)}
                                    className="px-3.5 py-2 text-[var(--cuba-ink-muted)] hover:text-[var(--cuba-ink)] text-xs font-bold">
                                    ← Back to QR Code
                                </button>
                                <button
                                    type="button"
                                    disabled={totpVerificationCode.length !== 6 || isSubmitting}
                                    onClick={handleVerifyAndEnableTotp}
                                    className="px-5 py-2.5 bg-[var(--cuba-primary)] hover:bg-[var(--cuba-primary-strong)] disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-xs">
                                    {isSubmitting ? 'Verifying...' : 'Verify & Enable 2FA ✓'}
                                </button>
                            </div>
                        </div>
                    )}

                    {/* Step 3: Native Firebase MFA enrollment complete */}
                    {totpSetupStep === 3 && (
                        <div className="space-y-4">
                            <div className="p-4 bg-[var(--cuba-success-soft)] border border-[var(--cuba-success-soft)] rounded-xl text-xs text-[var(--cuba-success)] leading-relaxed">
                                <strong>Two-factor authentication is active.</strong> Firebase Identity Platform will require your authenticator code during sign-in. IME365 does not store or display reusable recovery codes.
                            </div>
                            <div className="flex justify-end pt-2 border-t border-[var(--cuba-line)]">
                                <button type="button" onClick={() => setTotpSetupModalOpen(false)} className="px-5 py-2.5 bg-[var(--cuba-success)] hover:bg-[var(--cuba-success)] text-white font-bold text-xs rounded-xl shadow-xs">
                                    Done &amp; Close ✓
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        )}

        {/* Disable TOTP 2FA Confirmation Modal */}
        {totpDisableModalOpen && (
            <div className="fixed inset-0 z-50 bg-[var(--cuba-ink)]/60 backdrop-blur-xs flex items-center justify-center p-4" role="presentation" onKeyDown={event => { if (event.key === 'Escape' && !isSubmitting) setTotpDisableModalOpen(false); }}>
                <div role="alertdialog" aria-modal="true" aria-labelledby="totp-disable-title" className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4 border border-[var(--cuba-line)]">
                    <div className="flex items-center gap-3 text-[var(--cuba-danger)]">
                        <FaExclamationTriangle className="w-6 h-6 shrink-0" />
                        <h3 id="totp-disable-title" className="text-base font-bold text-[var(--cuba-ink)]">Disable Two-Factor Authentication</h3>
                    </div>
                    <p className="text-xs text-[var(--cuba-ink-muted)] leading-relaxed">
                        Disabling 2FA reduces your account security. Reauthenticate with your account provider to confirm.
                    </p>
                    <div className="space-y-3">
                        {usesPasswordProvider ? (
                            <div>
                                <label className="block text-xs font-bold text-[var(--cuba-ink-muted)] mb-1">Current Account Password (Required):</label>
                                <input type="password" value={totpDisablePassword} onChange={(e) => setTotpDisablePassword(e.target.value)} placeholder="Enter current password" className="w-full text-xs p-3 bg-[var(--cuba-canvas)] border border-[var(--cuba-line-strong)] rounded-xl text-[var(--cuba-ink)] font-semibold focus:border-[var(--cuba-danger)] outline-none" />
                            </div>
                        ) : (
                            <p className="text-xs text-[var(--cuba-ink-muted)]">Your identity provider will open a secure reauthentication popup.</p>
                        )}
                    </div>
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-[var(--cuba-line)]">
                        <button
                            type="button"
                            onClick={() => { setTotpDisableModalOpen(false); setTotpDisablePassword(''); }}
                            className="px-4 py-2 bg-[var(--cuba-canvas)] hover:bg-[var(--cuba-line)] text-[var(--cuba-ink-muted)] font-bold text-xs rounded-xl">
                            Cancel
                        </button>
                        <button
                            type="button"
                            disabled={(usesPasswordProvider && !totpDisablePassword) || isSubmitting}
                            onClick={handleDisableTotpConfirmed}
                            className="px-4 py-2 bg-[var(--cuba-danger)] hover:bg-[var(--cuba-danger)] disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-xs">
                            {isSubmitting ? 'Disabling...' : 'Confirm Disable 2FA'}
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* Native In-Dashboard Subscription Plans & Checkout Modal Popup */}
        <SubscriptionModal
            isOpen={isSubscriptionModalOpen}
            onClose={() => setIsSubscriptionModalOpen(false)}
            user={fire.auth().currentUser}
        />

        {/* AI Recommendation Review Modal */}
        <AiRecommendationModal
            isOpen={aiModalState.isOpen}
            onClose={() => setAiModalState((prev) => ({ ...prev, isOpen: false }))}
            title={aiModalState.title}
            type={aiModalState.type}
            items={aiModalState.items}
            onApply={aiModalState.onApply || (() => {})}
        />
        </>
    );
}

export default DashboardSettings;
