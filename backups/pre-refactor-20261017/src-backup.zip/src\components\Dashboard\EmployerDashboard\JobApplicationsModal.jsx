import { sanitizeUrl } from '../../../utils/sanitizeHtml';
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { sanitizeRichText } from '../../../utils/sanitizeHtml';
import { withTranslation } from 'react-i18next';
import './JobApplicationsModal.css';
import SendMessageDialog from './SendMessageDialog';
import { updateApplicationStatusWithMessage, getEmployerApplicationResume } from '../../../services/api/platform';
import RejectionReasonModal from './RejectionReasonModal';
import CubaInlineNotice from '../../cuba/CubaInlineNotice';
import { formatSafeDate } from '../../../utils/subscriptionUtils.js';
import { downloadResumePdf } from '../../../utils/exportDownloader';
import { FaTimes, FaUser, FaEnvelope, FaCalendar, FaFileAlt, FaDownload, FaCheckCircle, FaTimesCircle, FaUsers, FaClock, FaEye, FaChevronDown, FaChevronUp, FaSearch, FaFilter, FaExpand, FaCompress, FaCommentAlt } from 'react-icons/fa';

// eslint-disable-next-line react-refresh/only-export-components
const JobApplicationsModal = ({ isOpen, onClose, job, applications, isLoadingApplications = false, onUpdateStatus, showToast, t }) => {
    const [filteredApplications, setFilteredApplications] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');
    const [expandedApplication, setExpandedApplication] = useState(null);
    const [updatingStatus, setUpdatingStatus] = useState(null);
    const [messageApplicant, setMessageApplicant] = useState(null);

    useEffect(() => {
        if (applications) {
            filterApplications();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [applications, searchTerm, statusFilter]);

    const filterApplications = () => {
        let filtered = [...applications];

        // Filter by search term
        if (searchTerm) {
            const searchLower = searchTerm.toLowerCase();
            filtered = filtered.filter(
                (app) =>
                    app.applicantName.toLowerCase().includes(searchLower) ||
                    app.applicantEmail.toLowerCase().includes(searchLower) ||
                    app.skills.some((skill) => skill.toLowerCase().includes(searchLower))
            );
        }

        // Filter by status
        if (statusFilter !== 'all') {
            filtered = filtered.filter((app) => app.status === statusFilter);
        }

        setFilteredApplications(filtered);
    };

const [selectedApplication, setSelectedApplication] = useState(null);
    const [isRejectionModalOpen, setRejectionModalOpen] = useState(false);
    // DIR-048: replacement for the native alert() fallback — an inline, themed
    // notice inside the dialog, shown only when the host supplies no showToast.
    const [actionNotice, setActionNotice] = useState('');
    // DIR-048: the Download Resume control was a dead button; it tracks its own
    // in-flight state so a double click cannot fire two exports.
    const [downloadingResumeId, setDownloadingResumeId] = useState(null);

    const handleStatusUpdate = async (applicationId, newStatus, rejectionMessage = '') => {
        const target = filteredApplications.find(application => application.id === applicationId);
        if (!target) return;
        setUpdatingStatus(applicationId);
        try {
            const result = await updateApplicationStatusWithMessage(applicationId, newStatus, rejectionMessage, { status: target.status, revision: target.revision });

            if (result.success) {
                setFilteredApplications((previous) => previous.map(application => application.id === applicationId
                    ? { ...application, status: result.status, revision: result.revision, statusUpdatedAt: new Date() }
                    : application));

                // Also call the parent callback if provided
                if (onUpdateStatus) {
                    onUpdateStatus(applicationId, result.status, result.revision);
                }

                // Show success toast
                if (showToast) {
                    showToast('success', 'Success', `Application status updated to ${newStatus}`);
                }
            } else {
                const message = result.error || 'Failed to update application status.';
                if (showToast) showToast('error', result.code === 'APPLICATION_CHANGED' ? 'Application changed' : 'Error', message);
                else setActionNotice(message);
            }
        } catch (error) {
            const message = error.message || 'An error occurred while updating the application status.';
            if (showToast) showToast('error', 'Error', message);
            else setActionNotice(message);
        } finally {
            setUpdatingStatus(null);
            setRejectionModalOpen(false);
        }
    };

    const openRejectionModal = (application) => {
        setSelectedApplication(application);
        setRejectionModalOpen(true);
    };

    const handleSendMessage = (applicant) => {
        setMessageApplicant(applicant);
    };

    const handleSendEmail = (application) => {
        const subject = `Regarding your application for ${job.title}`;
        const body = `Dear ${application.applicantName},\n\nThank you for your interest in the ${job.title} position at our company.\n\nWe have reviewed your application and would like to discuss it further.\n\nBest regards,\n[Your Name]`;
        
        const mailtoLink = `mailto:${application.applicantEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        
        // Open the default email client
        window.location.href = mailtoLink;
    };

    /** True when any list filter is narrowing the pipeline. */
    const filtersActive = searchTerm.trim().length > 0 || statusFilter !== 'all';
    const clearFilters = () => {
        setSearchTerm('');
        setStatusFilter('all');
    };

    /**
     * DIR-048 S8: the Download Resume control was a dead button (no handler).
     * A candidate's resume is rendered for a non-owner by the PUBLIC export
     * pipeline, which only serves resumes the candidate has published — so this
     * downloads the real, high-fidelity PDF when one exists and states the
     * situation honestly when it does not. No file is ever fabricated.
     */
    const handleDownloadResume = async (application) => {
        if (downloadingResumeId) return;
        setDownloadingResumeId(application.id);
        setActionNotice('');
        try {
            const data = await getEmployerApplicationResume(job.id, application.id);
            const resume = data?.resume || null;
            const resumeId = String(resume?.id || application.resumeId || '');
            const resumeName = String(resume?.template || application.selectedResume?.template || '');
            const language = String(resume?.language || 'en');
            if (!resumeId || !resumeName) {
                setActionNotice('This applicant has no downloadable resume attached.');
                return;
            }
            const [first = '', last = ''] = String(application.applicantName || '').trim().split(/\s+/);
            // DIR-064: same-origin public export via the ONE centralized client, which
            // enforces %PDF- magic-byte validation before saving.
            await downloadResumePdf({
                endpoint: '/api/public-export',
                withAuth: false,
                resumeId,
                resumeName,
                language,
                firstname: first,
                lastname: last,
                analytics: false,
            });
        } catch (error) {
            const status = error?.response?.status;
            if (status === 404) {
                setActionNotice('This applicant has not published a downloadable copy of their resume yet.');
            } else if (error?.code === 'EXPORT_NOT_PDF') {
                setActionNotice(error.message);
            } else {
                setActionNotice('The resume could not be downloaded. Please try again.');
            }
        } finally {
            setDownloadingResumeId(null);
        }
    };

    const getStatusBadge = (status) => {
        /**
     * DIR-010 §2: status pills resolve to the canonical OPAQUE `.cuba-pill-*` tokens.
     *
     * The previous `bg-amber-50 text-amber-700 border-amber-200` recipe only cleared
     * 4.5:1 against the single light surface it was tuned for; inside this glass modal
     * the same pair fell below WCAG AA. The opaque token set is surface-independent, so
     * it holds over the modal, over --cuba-canvas and in dark mode alike.
     *
     * The tone map mirrors STAGE_TONE in EmployerApplicantPipeline.jsx so the ATS
     * pipeline card and this modal render the SAME stage in the SAME token.
     */
    const statusConfig = {
        pending: { tone: 'cuba-pill-warning', icon: FaClock, label: t('JobsUpdate.JobApplicationsModal.status.pending', 'Pending') },
        interview: { tone: 'cuba-pill-info', icon: FaUsers, label: t('JobsUpdate.JobApplicationsModal.status.interview', 'Interview') },
        accepted: { tone: 'cuba-pill-success', icon: FaCheckCircle, label: t('JobsUpdate.JobApplicationsModal.status.accepted', 'Accepted') },
        rejected: { tone: 'cuba-pill-danger', icon: FaTimesCircle, label: t('JobsUpdate.JobApplicationsModal.status.rejected', 'Rejected') },
    };

    const config = statusConfig[status] || statusConfig.pending;
    const IconComponent = config.icon;

    return (
        <span className={`cuba-pill-${config.tone.replace('cuba-pill-', '')} px-2 py-1 text-xs font-medium`}>
            <IconComponent className="w-2.5 h-2.5 mr-1" />
            {config.label}
        </span>
    );
};

    // DIR-048: routed through the shared safe-date contract — a value the
    // browser cannot parse renders an honest fallback, never "Invalid Date".
    const formatDate = (dateString) => (
        formatSafeDate(dateString, 'en-US', { year: 'numeric', month: 'short', day: 'numeric' }) || 'Date unavailable'
    );

    const toggleApplicationExpansion = (applicationId) => {
        setExpandedApplication(expandedApplication === applicationId ? null : applicationId);
    };

    const renderSafeHTML = (htmlContent) => ({ __html: sanitizeRichText(htmlContent || '') });

    if (!isOpen) return null;

    return (
    <>
            <div
                className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
                style={{ background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.1) 0%, rgba(30, 41, 59, 0.2) 100%)' }}
                role="presentation"
                onKeyDown={event => { if (event.key === 'Escape' && !updatingStatus) onClose(); }}
                onClick={(e) => {
                    if (e.target === e.currentTarget && !updatingStatus) onClose();
                }}>
                <motion.div
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="job-applications-title"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    // `flex flex-col` + `min-h-0` on the scrolling body below is what
                    // makes `max-h-[90vh]` behave: the panel caps its height, the
                    // applicant list scrolls INSIDE it, and the header/filter chrome
                    // stays pinned. Without the column the `overflow-hidden` panel
                    // simply clipped tall applicant cards (DIR-010 §2, unclipped
                    // in-modal candidate review).
                    className="bg-white rounded-lg shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden border border-slate-200 flex flex-col"
                    onClick={(e) => e.stopPropagation()}>
                    {/* DIR-048: inline error notice replaces the alert() fallback. */}
                    {actionNotice && (
                        <div className="px-4 pt-3">
                            <CubaInlineNotice
                                tone="error"
                                message={actionNotice}
                                onDismiss={() => setActionNotice('')}
                                testId="job-applications-notice"
                            />
                        </div>
                    )}
                    {/* Header */}
                    <div className="flex items-center justify-between p-4 border-b border-slate-200">
                        <div>
                            <h2 id="job-applications-title" className="text-lg font-semibold text-slate-900">{t('JobsUpdate.JobApplicationsModal.header.title', 'Applications for')} {job?.title}</h2>
                            <p className="text-slate-600 text-sm mt-0.5" id="job-applications-total">
                                {/* While the pipeline is still being fetched, `applications`
                                     * is legitimately empty. Reporting "0 total applications"
                                     * here is what made a genuine 1-applicant requisition
                                     * render as an empty pipeline: the modal opens on the same
                                     * tick the fetch starts, so the count was read before the
                                     * response landed. Announce the load instead of a count we
                                     * do not yet have. */}
                                {isLoadingApplications
                                    ? t('JobsUpdate.JobApplicationsModal.header.loading', 'Loading applicants…')
                                    : `${applications?.length || 0} ${t('JobsUpdate.JobApplicationsModal.header.totalApplications', 'total applications')}`}
                            </p>
                        </div>
                        <button type="button" onClick={onClose} disabled={Boolean(updatingStatus)} aria-label="Close applications dialog" className="p-2 hover:bg-slate-100 rounded-md transition-colors disabled:opacity-50">
                            <FaTimes className="w-4 h-4 text-slate-500" />
                        </button>
                    </div>

                    {/* Filters */}
                    <div className="p-4 border-b border-slate-200">
                        <div className="flex flex-col sm:flex-row gap-3">
                            {/* Search */}
                            <div className="flex-1">
                                <label htmlFor="application-search" className="sr-only">Search applications</label>
                                <div className="relative">
                                    <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-3.5 h-3.5" />
                                    <input
                                        id="application-search"
                                        type="text"
                                        placeholder={t('JobsUpdate.JobApplicationsModal.search.placeholder', 'Search by name, email, or skills...')}
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-400 focus:border-slate-400 placeholder-slate-400"
                                    />
                                </div>
                            </div>

                            {/* Status Filter */}
                            <div className="sm:w-40">
                                <label htmlFor="application-status-filter" className="sr-only">Filter by status</label>
                                <select
                                    id="application-status-filter"
                                    value={statusFilter}
                                    onChange={(e) => setStatusFilter(e.target.value)}
                                    className="w-full px-3 py-2.5 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-400 focus:border-slate-400 bg-white">
                                    <option value="all">{t('JobsUpdate.JobApplicationsModal.filters.allStatus', 'All Status')}</option>
                                    <option value="pending">{t('JobsUpdate.JobApplicationsModal.filters.pending', 'Pending')}</option>
                                    <option value="interview">{t('JobsUpdate.JobApplicationsModal.filters.interview', 'Interview')}</option>
                                    <option value="accepted">{t('JobsUpdate.JobApplicationsModal.filters.accepted', 'Accepted')}</option>
                                    <option value="rejected">{t('JobsUpdate.JobApplicationsModal.filters.rejected', 'Rejected')}</option>
                                </select>
                            </div>

                            {/* DIR-048: a filter reset — the census flagged that a
                                narrowed pipeline had no way back to the full list. */}
                            {filtersActive && (
                                <button
                                    type="button"
                                    onClick={clearFilters}
                                    data-testid="job-applications-clear-filters"
                                    className="flex items-center justify-center gap-1.5 rounded-md border border-cuba-line px-3 py-2.5 text-xs font-semibold text-cuba-primary transition-colors hover:bg-cuba-canvas sm:w-auto"
                                >
                                    <FaTimes className="w-3 h-3" />
                                    {t('JobsUpdate.JobApplicationsModal.filters.clear', 'Clear filters')}
                                </button>
                            )}
                        </div>
                    </div>

                    {/* Applications List */}
                    {/* `min-h-0` is REQUIRED here, not cosmetic. In a column flex
                     * container a scroll item keeps `min-height: auto`, so it refuses
                     * to shrink below its content and pushes the panel past max-h,
                     * which is exactly how the applicant rows ended up clipped behind
                     * the panel's own `overflow-hidden`. min-h-0 lets the item shrink so
                     * `flex-1 overflow-y-auto` can actually scroll INSIDE the panel. */}
                    <div className="flex-1 min-h-0 overflow-y-auto p-4" aria-busy={isLoadingApplications}>
                        {/* The empty state is only truthful AFTER the fetch settles. Rendering
                             * it during the load is what produced a false "No one has applied
                             * to this job yet" for a requisition that genuinely holds an
                             * applicant. `role="status"` announces the transition to assistive
                             * tech instead of silently swapping content. */}
                        {isLoadingApplications ? (
                            <div className="flex flex-col items-center justify-center py-10 text-center" role="status" aria-live="polite">
                                <FaClock className="w-8 h-8 text-slate-400 mb-3 animate-pulse" />
                                <p className="text-sm text-slate-600">
                                    {t('JobsUpdate.JobApplicationsModal.loading.body', 'Loading applicants…')}
                                </p>
                            </div>
                        ) : filteredApplications.length === 0 ? (
                            <div className="text-center py-8">
                                <FaUsers className="w-10 h-10 text-slate-400 mx-auto mb-3" />
                                <h3 className="text-base font-medium text-slate-900 mb-2">{t('JobsUpdate.JobApplicationsModal.emptyState.title', 'No applications found')}</h3>
                                <p className="text-slate-600 text-sm">
                                    {applications?.length === 0 
                                        ? t('JobsUpdate.JobApplicationsModal.emptyState.noApplications', 'No one has applied to this job yet.') 
                                        : t('JobsUpdate.JobApplicationsModal.emptyState.noResults', 'No applications match your current filters.')}
                                </p>
                                {/* DIR-048: the reset lives where the dead end is noticed. */}
                                {applications?.length > 0 && filtersActive && (
                                    <button
                                        type="button"
                                        onClick={clearFilters}
                                        className="mt-3 inline-flex items-center gap-1.5 rounded-md border border-cuba-line px-3 py-1.5 text-xs font-semibold text-cuba-primary transition-colors hover:bg-cuba-canvas"
                                    >
                                        <FaTimes className="w-3 h-3" />
                                        {t('JobsUpdate.JobApplicationsModal.filters.clear', 'Clear filters')}
                                    </button>
                                )}
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {filteredApplications.map((application) => (
                                    <motion.div
                                        key={application.id}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="bg-white rounded-lg p-4 border border-slate-200 hover:border-slate-300 transition-all duration-200">
                                        <div className="flex items-start justify-between">
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center gap-3 mb-2">
                                                    <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center flex-shrink-0">
                                                        <FaUser className="w-3.5 h-3.5 text-slate-600" />
                                                    </div>
                                                    <div className="min-w-0 flex-1">
                                                        <h3 className="text-sm font-medium text-slate-900 truncate">{application.applicantName}</h3>
                                                        <p className="text-xs text-slate-600 truncate">{application.applicantEmail}</p>
                                                    </div>
                                                </div>

                                                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 mb-3 ml-11">
                                                    <div className="flex items-center gap-1">
                                                        <FaCalendar className="w-3 h-3" />
                                                        <span>Applied {formatDate(application.appliedDate)}</span>
                                                    </div>
                                                    <div className="flex items-center gap-1">
                                                        <FaUser className="w-3 h-3" />
                                                        <span>{application.experience} {t('JobsUpdate.JobApplicationsModal.applicantInfo.experience', 'experience')}</span>
                                                    </div>
                                                    <div className="flex items-center gap-1">
                                                        <FaFileAlt className="w-3 h-3" />
                                                        <span>{t('JobsUpdate.JobApplicationsModal.applicantInfo.resumeAttached', 'Resume attached')}</span>
                                                    </div>
                                                </div>

                                                <div className="flex flex-wrap gap-1.5 mb-3 ml-11">
                                                    {application.skills?.slice(0, 4).map((skill, index) => (
                                                        <span key={index} className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-xs font-medium">
                                                            {skill}
                                                        </span>
                                                    ))}
                                                    {application.skills?.length > 4 && (
                                                        <span className="px-2 py-1 bg-slate-100 text-slate-500 rounded text-xs">+{application.skills.length - 4} {t('JobsUpdate.JobApplicationsModal.applicantInfo.more', 'more')}</span>
                                                    )}
                                                </div>
                                            </div>

                                            <div className="flex items-center gap-3 ml-3 flex-shrink-0">
                                                {/* Status Badge */}
                                                {getStatusBadge(application.status)}

                                                {/* Send Message Button */}
                                                <button
                                                    onClick={() => handleSendMessage(application)}
                                                    className="cuba-btn-primary px-2.5 py-1.5 rounded-md text-xs font-medium disabled:opacity-50 flex items-center gap-1"
                                                    title="Send Message">
                                                    <FaCommentAlt className="w-3 h-3" />
                                                    {t('JobsUpdate.JobApplicationsModal.buttons.message', 'Message')}
                                                </button>

                                                {/* Status Update Buttons */}
                                                {application.status === 'pending' && (
                                                    <>
                                                        <button
                                                            onClick={() => handleStatusUpdate(application.id, 'interview')}
                                                            disabled={updatingStatus === application.id}
                                                            className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium rounded-md transition-colors disabled:opacity-50">
                                                            {t('JobsUpdate.JobApplicationsModal.buttons.interview', 'Interview')}
                                                        </button>
                                                        <button
                                                            onClick={() => openRejectionModal(application)}
                                                            disabled={updatingStatus === application.id}
                                                            className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-medium rounded-md transition-colors disabled:opacity-50">
                                                            Reject
                                                        </button>
                                                    </>
                                                )}

                                                {application.status === 'interview' && (
                                                    <>
                                                        <button
                                                            onClick={() => handleStatusUpdate(application.id, 'accepted')}
                                                            disabled={updatingStatus === application.id}
                                                            className="cuba-btn-primary px-2.5 py-1.5 rounded-md text-xs font-medium disabled:opacity-50">
                                                            {t('JobsUpdate.JobApplicationsModal.buttons.accept', 'Accept')}
                                                        </button>
                                                        <button
                                                            onClick={() => openRejectionModal(application)}
                                                            disabled={updatingStatus === application.id}
                                                            className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-medium rounded-md transition-colors disabled:opacity-50">
                                                            Reject
                                                        </button>
                                                    </>
                                                )}

                                                <button
                                                    type="button"
                                                    aria-expanded={expandedApplication === application.id}
                                                    aria-label={`${expandedApplication === application.id ? 'Collapse' : 'Expand'} application from ${application.applicantName}`}
                                                    onClick={() => toggleApplicationExpansion(application.id)}
                                                    className="p-2 text-slate-400 hover:text-slate-600 transition-colors rounded-md hover:bg-slate-50">
                                                    {expandedApplication === application.id ? <FaChevronUp className="w-3 h-3" /> : <FaChevronDown className="w-3 h-3" />}
                                                </button>
                                            </div>
                                        </div>

                                        {/* Expanded Application Details */}
                                        {expandedApplication === application.id && (
                                            <motion.div
                                                initial={{ opacity: 0, height: 0 }}
                                                animate={{ opacity: 1, height: 'auto' }}
                                                exit={{ opacity: 0, height: 0 }}
                                                className="mt-3 pt-3 border-t border-slate-200">
                                                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                                                    <div className="lg:col-span-2">
                                                        <h4 className="text-sm font-medium text-slate-900 mb-2">Cover Letter</h4>
                                                        <div
                                                            className="text-slate-600 text-xs leading-relaxed mb-3 p-3 bg-slate-50 rounded-md border border-slate-200 max-h-40 overflow-y-auto rich-text-content"
                                                            style={{
                                                                fontSize: '12px',
                                                                lineHeight: '1.5',
                                                            }}
                                                            dangerouslySetInnerHTML={renderSafeHTML(application.coverLetter)}
                                                        />

                                                        <h4 className="text-sm font-medium text-slate-900 mb-2 mt-4">Additional Information</h4>
                                                        <div className="space-y-2 text-xs">
                                                            <div className="flex items-center justify-between py-1">
                                                                <span className="text-slate-500">Experience:</span>
                                                                <span className="text-slate-900 font-medium">{application.experience || 'Not specified'}</span>
                                                            </div>
                                                            <div className="flex items-center justify-between py-1">
                                                                <span className="text-slate-500">Applied:</span>
                                                                <span className="text-slate-900 font-medium">{formatDate(application.appliedDate)}</span>
                                                            </div>
                                                            <div className="flex items-center justify-between py-1">
                                                                <span className="text-slate-500">Resume:</span>
                                                                <span className="text-slate-900 font-medium">{application.resume ? 'Attached' : 'Not provided'}</span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="flex flex-col gap-2">
                                                        <button
                                                            type="button"
                                                            onClick={() => handleDownloadResume(application)}
                                                            disabled={Boolean(downloadingResumeId)}
                                                            className="flex items-center gap-2 px-3 py-2 bg-slate-50 text-slate-700 rounded-md hover:bg-slate-100 transition-colors text-xs font-medium border border-slate-200 disabled:opacity-50 disabled:cursor-not-allowed">
                                                            <FaDownload className="w-3 h-3" />
                                                            {downloadingResumeId === application.id
                                                                ? t('JobsUpdate.JobApplicationsModal.buttons.preparingResume', 'Preparing…')
                                                                : t('JobsUpdate.JobApplicationsModal.buttons.downloadResume', 'Download Resume')}
                                                        </button>
                                                        <button 
                                                            onClick={() => handleSendEmail(application)}
                                                            className="flex items-center gap-2 px-3 py-2 bg-slate-50 text-slate-700 rounded-md hover:bg-slate-100 transition-colors text-xs font-medium border border-slate-200">
                                                            <FaEnvelope className="w-3 h-3" />
                                                            {t('JobsUpdate.JobApplicationsModal.buttons.sendEmail', 'Send Email')}
                                                        </button>
                                                        <button 
                                                            onClick={() => {
                                                                let resumeUrl = application.resumeUrl || application.selectedResume?.shareableLink;
                                                                if (resumeUrl) {
                                                                    // Correct the URL if it uses the old pattern
                                                                    if (resumeUrl.includes('/resume/')) {
                                                                        resumeUrl = resumeUrl.replace('/resume/', '/shared/');
                                                                    }
                                                                    window.open(sanitizeUrl(resumeUrl), '_blank');
                                                                } else {
                                                                    // DIR-048: inline notice replaces the native alert().
                                                                    setActionNotice('Resume link not available');
                                                                }
                                                            }}
                                                            className="flex items-center gap-2 px-3 py-2 bg-slate-50 text-slate-700 rounded-md hover:bg-slate-100 transition-colors text-xs font-medium border border-slate-200">
                                                            <FaEye className="w-3 h-3" />
                                                            {t('JobsUpdate.JobApplicationsModal.buttons.showResume', 'Show Resume')}
                                                        </button>
                                                    </div>
                                                </div>
                                            </motion.div>
                                        )}
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </div>
</motion.div>
            </div>
            {messageApplicant && (
                <SendMessageDialog 
                    isOpen={!!messageApplicant}
                    onClose={() => setMessageApplicant(null)}
                    applicationId={messageApplicant.id}
                    applicantName={messageApplicant.applicantName}
                    showToast={showToast}
                />
            )}

            <RejectionReasonModal
                isOpen={isRejectionModalOpen}
                onClose={() => setRejectionModalOpen(false)}
                onSubmit={(message) => handleStatusUpdate(selectedApplication.id, 'rejected', message)}
                applicationData={selectedApplication}
                loading={updatingStatus === selectedApplication?.id}
            />
        </>
    );
};

// eslint-disable-next-line react-refresh/only-export-components
export default withTranslation('common')(JobApplicationsModal);
