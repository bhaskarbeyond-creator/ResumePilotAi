import React, { Suspense, lazy, useCallback, useEffect, useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import DashboardToast from '../Dashboard/DashboardToast/DashboardToast';
import CubaPortalShell from '../cuba/CubaPortalShell';
import { COPILOT_PORTALS } from '../cuba/copilotActions';
import { EMPLOYER_PORTAL_NAVIGATION } from '../cuba/portalNavigation';
import { ACCOUNT_PORTALS } from '../cuba/accountLinks';
import Spinner from '../Spinner/Spinner';

/**
 * Cuba recruiter console — Phase 5 wrapper for `/employer/*`.
 *
 * SCOPE, stated precisely:
 *   This wraps the recruiter console in the shared Cuba chrome. It mounts the
 *   SAME child components the existing `EmployerPortal` mounts, and preserves the
 *   exact same `showToast` contract, so all existing recruiter capability —
 *   job postings, applicant ATS pipeline, candidate messages, company profile,
 *   hiring preferences, the AddCompanyModal / EditJobModal / JobApplicationsModal
 *   dialogs — continues to work unchanged (§47).
 *
 *   Nothing is reimplemented: the children own their data, their `/api/employer/*`
 *   reads, their mutations and their states. No metric is recomputed here, so the
 *   overview can never disagree with the pipeline below it.
 *
 *   The default `/employer/*` route still mounts `EmployerPortal`. This variant
 *   is reached only when the `ime365_cuba_shell_v2` flag is on, so recruiter
 *   behaviour is preserved for every existing user (§49).
 */
const EmployerOverview = lazy(() => import('./EmployerOverview'));
const EmployerJobPostings = lazy(() => import('./EmployerJobPostings'));
const EmployerApplicantPipeline = lazy(() => import('./EmployerApplicantPipeline'));
const EmployerCompanyProfile = lazy(() => import('./EmployerCompanyProfile'));
const EmployerHiringPreferences = lazy(() => import('./EmployerHiringPreferences'));
const EmployerCandidateMessages = lazy(() => import('./EmployerCandidateMessages'));
// DIR-026 / AC-3: the administrator module gate for the recruiter messages route.
import MessagesModuleGate from '../cuba/MessagesModuleGate';

const TOAST_VISIBLE_MS = 5000;

const NAV = EMPLOYER_PORTAL_NAVIGATION.map((group) => ({
    ...group,
    items: group.items.map((item) => ({ ...item, href: item.to })),
}));

const EmployerPortalCuba = () => {
    const [toast, setToast] = useState({ isShowed: false, type: '', title: '', text: '' });

    // Same contract as EmployerPortal: every child receives a real function, so
    // no descendant can ever call an undefined showToast.
    const showToast = useCallback((type, title, text) => {
        setToast({
            isShowed: true,
            type: String(type || 'info'),
            title: String(title || ''),
            text: String(text || ''),
        });
    }, []);

    useEffect(() => {
        if (!toast.isShowed) return undefined;
        const timer = setTimeout(() => {
            setToast((previous) => ({ ...previous, isShowed: false }));
        }, TOAST_VISIBLE_MS);
        return () => clearTimeout(timer);
    }, [toast.isShowed]);

    return (
        <CubaPortalShell className="container-fluid p-0 bs-employer-portal-shell"
            persona="Recruiter & Hiring"
            title="Recruiter Overview"
            navigation={NAV}
            // DIR-025: a recruiter's account menu must land on recruiter routes.
            // Without this the shared shell defaulted to the candidate
            // `/dashboard/*` table, so "Security & MFA" left the console entirely.
            portal={ACCOUNT_PORTALS.RECRUITER}
            // DIR-021: recruiter-context chips (candidate pool, scorecard,
            // outreach). Navigation-owned work routes to the applicants module
            // rather than pretending to generate a pipeline summary.
            copilotPortal={COPILOT_PORTALS.RECRUITER}
        >
            <DashboardToast
                isShowed={toast.isShowed}
                type={toast.type}
                title={toast.title}
                text={toast.text}
            />
            <Suspense fallback={<div className="flex min-h-[40vh] items-center justify-center"><Spinner inline /></div>}>
                <Routes>
                    <Route index element={<EmployerOverview showToast={showToast} />} />
                    <Route path="jobs" element={<EmployerJobPostings showToast={showToast} />} />
                    <Route path="applicants" element={<EmployerApplicantPipeline showToast={showToast} />} />
                    <Route path="company" element={<EmployerCompanyProfile showToast={showToast} />} />
                    {/* DIR-026 / AC-3: the recruiter messages surface is gated on the
                        administrator module flag, so a bookmarked or typed
                        /employer/messages cannot bypass the AC-4 backend gate. */}
                    <Route
                        path="messages"
                        element={(
                            <MessagesModuleGate home="/employer" notify={showToast}>
                                <EmployerCandidateMessages showToast={showToast} />
                            </MessagesModuleGate>
                        )}
                    />
                    <Route path="settings" element={<EmployerHiringPreferences showToast={showToast} />} />
                    <Route path="*" element={<Navigate to="/employer" replace />} />
                </Routes>
            </Suspense>
        </CubaPortalShell>
    );
};

export default EmployerPortalCuba;
