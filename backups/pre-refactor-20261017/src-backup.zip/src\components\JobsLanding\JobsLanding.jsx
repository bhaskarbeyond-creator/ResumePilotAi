import React, { useState, useContext } from 'react';
import { AuthContext } from '../../context/AuthContext';
import HomepageNavbar from '../Marketing/elements/HomepageNavbar';
import HomepageFooter from '../Marketing/elements/HomepageFooter';
import GridBackground from '../Marketing/elements/GridBackground';
import JobsLandingHero from './JobsLandingHero';
import LandingJobTopCompanies from './LandingJobTopCompanies';
import LandingJobsFeatured from './LandingJobsFeatured';
import AuthWrapper from '../auth/authWrapper/AuthWrapper';
import { motion, AnimatePresence } from 'framer-motion';
import fire from '../../conf/fire';

const JobsLanding = () => {
    const user = useContext(AuthContext);
    const [showAuthModal, setShowAuthModal] = useState(false);


    const handleAuthButtonClick = () => {
        setShowAuthModal(!showAuthModal);
    };

    const closeAuthModal = () => {
        setShowAuthModal(false);
    };

    const handleLogout = () => {
        fire.auth().signOut().then(() => {
        }).catch((error) => {
            console.error('Error signing out:', error);
        });
    };
    
    return (
        <div className="card bs-card-executive jobs-landing-wrapper relative min-h-screen h-full w-full">
            <GridBackground className="z-0" />
            <div className="relative z-10 bg-transparent h-full w-full">
                <HomepageNavbar 
                    authBtnHandler={handleAuthButtonClick}
                    user={user}
                    logout={handleLogout}
                />
                <JobsLandingHero 
                    authBtnHandler={handleAuthButtonClick}
                    user={user}
                />
                <LandingJobTopCompanies />
                <LandingJobsFeatured />
                <HomepageFooter />
            </div>
            
            {/* Auth Modal with framer-motion animation */}
            <AnimatePresence>
                {showAuthModal && (
                    <motion.div 
                        className="wrapper"
                        style={{
                            backgroundColor: 'rgba(0, 0, 0, 0.7)'
                        }}
                
                    >
                        <AuthWrapper closeModal={closeAuthModal} />
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default JobsLanding;
