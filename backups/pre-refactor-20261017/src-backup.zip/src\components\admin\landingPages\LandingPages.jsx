import React, { useState, useEffect } from 'react';
import { getFrontendStats, setFrontendStats } from '../../../services/api/platform';
import { FiSave, FiRefreshCw, FiEye } from 'react-icons/fi';
import PagesSettings from '../settings/pagesSettings';

const LandingPages = () => {
    const [activeTab, setActiveTab] = useState('jobs');
    const [stats, setStats] = useState({
        activeJobs: '',
        rating: '',
        partnerCompanies: '',
        successfulHires: '',
        featuredJobs: '',
        successRate: '',
        topCompanies: '',
        sourceUrl: '',
        verifiedAt: '',
        published: false,
        revision: 0,
    });
    
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState('');
    const [confirmSave, setConfirmSave] = useState(false);

    useEffect(() => {
        fetchStats();
    }, []);

    useEffect(() => {
        const handleGlobalKeyDown = (e) => {
            if (e.key === 'Escape' && !saving && confirmSave) {
                setConfirmSave(false);
            }
        };
        window.addEventListener('keydown', handleGlobalKeyDown);
        return () => window.removeEventListener('keydown', handleGlobalKeyDown);
    }, [saving, confirmSave]);

    const fetchStats = async () => {
        try {
            setLoading(true);
            const fetchedStats = await getFrontendStats({ admin: true });
            if (fetchedStats) {
                setStats(current => ({ ...current, ...fetchedStats }));
            }
        } catch (error) {
            console.error('Error fetching stats:', error);
            setMessage('Error loading stats');
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (field, value) => {
        setStats(prev => ({
            ...prev,
            [field]: value
        }));
    };

    const handleSave = async () => {
        try {
            setSaving(true);
            const result = await setFrontendStats(stats, Number(stats.revision || 0));
            if (result.success) {
                setStats(current => ({ ...current, ...result.content }));
                setConfirmSave(false);
                setMessage('Marketing display content saved and audited.');
            } else {
                setMessage('Error updating content: ' + result.message);
                if (result.code === 'ADMIN_TARGET_CHANGED') { setConfirmSave(false); await fetchStats(); }
            }
        } catch (error) {
            console.error('Error saving landing marketing content:', error);
            setMessage(`Error: ${error.message || 'Landing content could not be saved.'}`);
            setConfirmSave(false);
        } finally {
            setSaving(false);
        }
    };

    const handlePreview = () => {
        window.open('/jobs-landing', '_blank');
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    return (
        <div className="card bs-card-executive container-fluid p-6 max-w-6xl mx-auto">
            {confirmSave && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" role="presentation" onKeyDown={event => { if (event.key === 'Escape' && !saving) setConfirmSave(false); }}><div role="alertdialog" aria-modal="true" aria-labelledby="landing-save-title" className="w-full max-w-md rounded-lg bg-white p-6"><h2 id="landing-save-title" className="text-lg font-bold">{stats.published ? 'Publish verified landing claims?' : 'Save landing claims as a draft?'}</h2><p className="mt-2 text-sm text-gray-600">{stats.published ? 'All values will become public. The evidence URL and review date are required, publication is revision-guarded, and the change is audited.' : 'Draft values remain private and will not render on the public landing page.'}</p><div className="mt-6 flex justify-end gap-3"><button type="button" autoFocus onClick={() => setConfirmSave(false)} disabled={saving} className="rounded border px-4 py-2">Cancel</button><button type="button" onClick={handleSave} disabled={saving} className="rounded bg-blue-700 px-4 py-2 text-white">{saving ? 'Saving…' : stats.published ? 'Publish verified claims' : 'Save draft'}</button></div></div></div>}
            {/* Header */}
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Landing Pages Management</h1>
                <p className="text-gray-600">Manage public marketing display copy. These values are not live operational statistics.</p>
            </div>

            {/* Tab Navigation */}
            <div className="mb-8">
                <nav className="flex space-x-8" aria-label="Tabs">
                    <button
                        onClick={() => setActiveTab('jobs')}
                        className={`whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm ${
                            activeTab === 'jobs'
                                ? 'border-blue-500 text-blue-600'
                                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                        }`}
                    >
                        Jobs Landing Page
                    </button>
                    <button
                        onClick={() => setActiveTab('cms')}
                        className={`whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm ${
                            activeTab === 'cms'
                                ? 'border-blue-500 text-blue-600'
                                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                        }`}
                    >
                        Custom CMS Pages
                    </button>
                </nav>
            </div>

            {/* Jobs Landing Page Tab */}
            {activeTab === 'jobs' && (
                <div className="space-y-8">
                    {/* Hero Section Stats */}
                    <div className="bg-white rounded-lg shadow-md p-6">
                        <h2 className="text-xl font-semibold text-gray-900 mb-4">Hero Section</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Active Jobs Count
                                </label>
                                <input
                                    type="text"
                                    value={stats.activeJobs}
                                    onChange={(e) => handleInputChange('activeJobs', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter evidence-backed display value"
                                />
                                <p className="text-xs text-gray-500 mt-1">Displayed as "{stats.activeJobs} Active Jobs"</p>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Rating (out of 5)
                                </label>
                                <input
                                    type="text"
                                    value={stats.rating}
                                    onChange={(e) => handleInputChange('rating', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter evidence-backed display value"
                                />
                                <p className="text-xs text-gray-500 mt-1">Displayed as "{stats.rating}/5 Rating"</p>
                            </div>
                        </div>
                    </div>

                    {/* Top Companies Section Stats */}
                    <div className="bg-white rounded-lg shadow-md p-6">
                        <h2 className="text-xl font-semibold text-gray-900 mb-4">Top Companies Section</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Partner Companies
                                </label>
                                <input
                                    type="text"
                                    value={stats.partnerCompanies}
                                    onChange={(e) => handleInputChange('partnerCompanies', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter evidence-backed display value"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Active Jobs
                                </label>
                                <input
                                    type="text"
                                    value={stats.activeJobs}
                                    onChange={(e) => handleInputChange('activeJobs', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter evidence-backed display value"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Successful Hires
                                </label>
                                <input
                                    type="text"
                                    value={stats.successfulHires}
                                    onChange={(e) => handleInputChange('successfulHires', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter evidence-backed display value"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Featured Jobs Section Stats */}
                    <div className="bg-white rounded-lg shadow-md p-6">
                        <h2 className="text-xl font-semibold text-gray-900 mb-4">Featured Jobs Section</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Featured Jobs
                                </label>
                                <input
                                    type="text"
                                    value={stats.featuredJobs}
                                    onChange={(e) => handleInputChange('featuredJobs', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter evidence-backed display value"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Success Rate (%)
                                </label>
                                <input
                                    type="text"
                                    value={stats.successRate}
                                    onChange={(e) => handleInputChange('successRate', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter evidence-backed display value"
                                />
                                <p className="text-xs text-gray-500 mt-1">Displayed as "{stats.successRate}%"</p>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Top Companies
                                </label>
                                <input
                                    type="text"
                                    value={stats.topCompanies}
                                    onChange={(e) => handleInputChange('topCompanies', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter evidence-backed display value"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-md p-6">
                        <h2 className="text-xl font-semibold text-gray-900 mb-2">Evidence &amp; publication</h2>
                        <p className="mb-5 text-sm text-gray-600">Public claims fail closed unless every value has current, reviewable evidence. Evidence must be reviewed again within 180 days.</p>
                        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                            <label className="block text-sm font-medium text-gray-700">
                                Evidence URL
                                <input
                                    type="url"
                                    value={stats.sourceUrl}
                                    onChange={(event) => handleInputChange('sourceUrl', event.target.value)}
                                    className="mt-2 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="https://…"
                                    required={stats.published}
                                />
                            </label>
                            <label className="block text-sm font-medium text-gray-700">
                                Evidence reviewed on
                                <input
                                    type="date"
                                    value={stats.verifiedAt ? String(stats.verifiedAt).slice(0, 10) : ''}
                                    onChange={(event) => handleInputChange('verifiedAt', event.target.value)}
                                    className="mt-2 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    required={stats.published}
                                />
                            </label>
                        </div>
                        <label className="mt-5 flex items-start gap-3 rounded-md border border-gray-200 bg-gray-50 p-4 text-sm text-gray-700">
                            <input
                                type="checkbox"
                                checked={stats.published === true}
                                onChange={(event) => handleInputChange('published', event.target.checked)}
                                className="mt-0.5"
                            />
                            <span><strong>Publish these verified claims.</strong> Clear this checkbox to keep the revision as a private draft.</span>
                        </label>
                        <p className="mt-3 text-xs text-gray-500">Current revision: {Number(stats.revision || 0)}</p>
                    </div>
                </div>
            )}

            {/* Custom CMS Pages Tab */}
            {activeTab === 'cms' && (
                <PagesSettings />
            )}

            {/* Message Display */}
            {message && (
                <div role={message.includes('Error') ? 'alert' : 'status'} aria-live="polite" className={`mt-4 p-4 rounded-md ${
                    message.includes('Error') ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'
                }`}>
                    {message}
                </div>
            )}

            {/* Action Buttons */}
            {activeTab !== 'cms' && (
                <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
                    <button
                        onClick={handlePreview}
                        className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <FiEye className="w-4 h-4" />
                        Preview Landing Page
                    </button>
                    
                    <div className="flex gap-3">
                        <button
                            onClick={fetchStats}
                            disabled={loading}
                            className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                        >
                            <FiRefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                            Refresh
                        </button>
                        
                        <button
                            onClick={() => setConfirmSave(true)}
                            disabled={saving}
                            className="inline-flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                        >
                            <FiSave className="w-4 h-4" />
                            {saving ? 'Saving...' : 'Save Changes'}
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default LandingPages;
