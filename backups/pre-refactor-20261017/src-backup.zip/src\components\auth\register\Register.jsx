import React, { Component } from 'react';
import './Register.scss';
import GoogleImage from '../../../assets/google.png';
import FacebookImage from '../../../assets/facebook.png';
import Input from '../../Form/simple-input/SimpleInput';
// FIX: Import addUser from auth.js (deduplication + authProvider tracking) NOT dbOperations
import addUser, { updateUserOnLogin } from '../../../services/api/users';
import fire, { googleProvider, facebookProvider } from '../../../conf/fire';
import Toast from '../../Toasts/Toats';
import { withTranslation } from 'react-i18next';
import { resolveOAuthSettings, fetchOAuthAvailability, applyOAuthAvailability } from '../../../utils/oauthResolver';
import { describeOAuthRedirectError, stripOAuthRedirectError } from '../../../utils/oauthRedirectError';
import { getSafeAuthErrorMessage } from '../../../utils/authErrorMessages';

// LinkedIn & GitHub SVG icons (inline — no extra dependencies)
const LinkedInIcon = () => (
    <svg viewBox="0 0 24 24" width="18" height="18" fill="white" style={{ flexShrink: 0 }}>
        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
);

const GitHubIcon = () => (
    <svg viewBox="0 0 24 24" width="18" height="18" fill="white" style={{ flexShrink: 0 }}>
        <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
    </svg>
);

class Register extends Component {
    constructor(props) {
        super(props);
        let cachedSettings = null;
        try {
            const raw = localStorage.getItem('system_settings');
            if (raw) cachedSettings = JSON.parse(raw);
        } catch (_e) {}

        const resolved = resolveOAuthSettings(cachedSettings);
        const enableGoogle = cachedSettings ? resolved.enableGoogle : true;
        const enableFacebook = cachedSettings ? resolved.enableFacebook : true;
        const { enableLinkedIn, enableGitHub } = resolved;

        this.state = {
            email: '',
            password: '',
            passwordRepeat: '',
            isError: false,
            errorMsg: '',
            enableGoogle,
            enableFacebook,
            enableLinkedIn,
            enableGitHub,
            oauthLoading: null,
            oauthError: '', // explanation for a social sign-up that failed and redirected back
            // DIR-048: `alert(msg)` was the fallback when no `throwError` handler was
            // passed in. A native dialog is unthemeable, blocks the thread and is
            // invisible to the automation suite, so the same message now renders in
            // the page using the notice pattern already established for oauthError.
            formError: '',
            isSubmitting: false, // GAP-01: prevent double-submit
            errors: {}, // Validation errors
        };
        this.signUp = this.signUp.bind(this);
        this.signInWithGoogle = this.signInWithGoogle.bind(this);
        this.signInWithFacebook = this.signInWithFacebook.bind(this);
        this.signInWithLinkedIn = this.signInWithLinkedIn.bind(this);
        this.signInWithGitHub = this.signInWithGitHub.bind(this);
        this.handleInputs = this.handleInputs.bind(this);
        this.handleBlur = this.handleBlur.bind(this);
        this._postAuth = this._postAuth.bind(this);
        this._handleRedirect = this._handleRedirect.bind(this);
    }

    componentWillUnmount() {
        this._unmounted = true;
    }

    readOAuthRedirectError() {
        try {
            const search = window.location.search;
            const message = describeOAuthRedirectError(search);
            if (!message) return;
            this.setState({ oauthError: message });
            const cleaned = stripOAuthRedirectError(search);
            window.history.replaceState({}, '', `${window.location.pathname}${cleaned}${window.location.hash}`);
        } catch (_e) {}
    }

    componentDidMount() {
        // Surface a social sign-up that failed and redirected back here.
        this.readOAuthRedirectError();

        import('../../../services/api/platform').then(({ getSystemSettings }) => {
            getSystemSettings().then((settings) => {
                try {
                    localStorage.setItem('system_settings', JSON.stringify(settings));
                } catch (_e) {}

                const configured = resolveOAuthSettings(settings);

                this.setState(configured);

                // Intersect the configured toggles with what the backend can
                // actually serve, so a provider whose route would 404 or 502 is
                // never presented as a working sign-in option.
                fetchOAuthAvailability().then(({ status, auth }) => {
                    if (this._unmounted) return;
                    this.setState(applyOAuthAvailability(configured, auth, status));
                });
            }).catch(() => {});
        }).catch(() => {});
    }

    // ─── Post-OAuth shared logic ───────────────────────────────────────────────
    async _handleRedirect(uid) {
        try {
            const { getPostLoginRedirectPath, clearPostLoginRedirectPath, isSafeInternalPath } = await import('../../../utils/safeInternalPath');
            const targetPath = getPostLoginRedirectPath(window.location.search);
            if (targetPath && isSafeInternalPath(targetPath)) {
                clearPostLoginRedirectPath();
                window.location.href = targetPath;
                return;
            }
            const currentPath = window.location.pathname;
            if (
                currentPath.startsWith('/org') ||
                currentPath.startsWith('/enterprise') ||
                currentPath.startsWith('/dashboard') ||
                currentPath.startsWith('/employer') ||
                currentPath.startsWith('/build') ||
                currentPath.startsWith('/portfolio') ||
                currentPath.startsWith('/admin') ||
                currentPath.startsWith('/adm')
            ) {
                return;
            }
            const { checkIfAdmin } = await import('../../../services/api/platform');
            const isAdmin = await checkIfAdmin(uid);
            if (isAdmin) {
                window.location.href = '/admin/dashboard';
            } else {
                window.location.href = '/dashboard';
            }
        } catch (_err) {
            try {
                const { getPostLoginRedirectPath, clearPostLoginRedirectPath, isSafeInternalPath } = await import('../../../utils/safeInternalPath');
                const targetPath = getPostLoginRedirectPath(window.location.search);
                if (targetPath && isSafeInternalPath(targetPath)) {
                    clearPostLoginRedirectPath();
                    window.location.href = targetPath;
                    return;
                }
            } catch (_) {}
            const currentPath = window.location.pathname;
            if (
                !currentPath.startsWith('/org') &&
                !currentPath.startsWith('/enterprise') &&
                !currentPath.startsWith('/dashboard') &&
                !currentPath.startsWith('/employer') &&
                !currentPath.startsWith('/build') &&
                !currentPath.startsWith('/portfolio') &&
                !currentPath.startsWith('/admin') &&
                !currentPath.startsWith('/adm')
            ) {
                window.location.href = '/dashboard';
            }
        }
    }

    async _postAuth(uid, displayName, email, photoURL, provider) {
        try {
            const nameParts = (displayName || email?.split('@')[0] || 'User').trim().split(' ');
            const firstName = nameParts[0] || 'User';
            const lastName = nameParts.slice(1).join(' ') || '';
            const result = await addUser(uid, firstName, lastName, email, { authProvider: provider, photoURL });
            // New-account mail is part of the server-side profile-create transaction.
            if (!result?.isNewUser) {
                updateUserOnLogin(uid, { photoURL, displayName, authProvider: provider }).catch(() => {});
            }
        } catch (err) {
            console.warn('[Register postAuth notice]:', err.message);
        }
    }

    // ─── Google ─────────────────────────────────────────────────────────────────
    signInWithGoogle() {
        if (this.state.oauthLoading) return;
        this.setState({ oauthLoading: 'google' });
        const self = this;
        fire.auth().signInWithPopup(googleProvider).then(async (result) => {
            const u = result.user;
            await self._postAuth(u.uid, u.displayName, u.email, u.photoURL, 'google');
            self.setState({ oauthLoading: null });
            if (self.props.closeModal) self.props.closeModal();
            self._handleRedirect(u.uid);
        }).catch((error) => {
            self.setState({ oauthLoading: null });
            if (error.code === 'auth/popup-blocked') {
                fire.auth().signInWithRedirect(googleProvider); return;
            }
            if (error.code === 'auth/account-exists-with-different-credential') {
                if (self.props.throwError) self.props.throwError('An account with this email already exists with password authentication. Please sign in with your email and password.');
                return;
            }
            if (['auth/operation-not-allowed', 'auth/unauthorized-domain', 'auth/configuration-not-found'].includes(error.code)) {
                import('../../../utils/googleSdkAuth').then(({ directGoogleAuthFallback }) => {
                    directGoogleAuthFallback(self.props.closeModal, self.props.throwError);
                }).catch(e => { if (self.props.throwError) self.props.throwError(getSafeAuthErrorMessage(e, 'This sign-in method is unavailable right now. Please try email sign-in or contact support.')); });
                return;
            }
            if (error.code !== 'auth/popup-closed-by-user') {
                const msg = getSafeAuthErrorMessage(error);
                if (msg && self.props.throwError) self.props.throwError(msg);
            }
        });
    }

    // ─── Facebook ────────────────────────────────────────────────────────────────
    signInWithFacebook() {
        if (this.state.oauthLoading) return;
        this.setState({ oauthLoading: 'facebook' });
        const self = this;
        fire.auth().signInWithPopup(facebookProvider).then(async (result) => {
            const u = result.user;
            await self._postAuth(u.uid, u.displayName, u.email, u.photoURL, 'facebook');
            self.setState({ oauthLoading: null });
            if (self.props.closeModal) self.props.closeModal();
            self._handleRedirect(u.uid);
        }).catch((error) => {
            self.setState({ oauthLoading: null });
            if (error.code === 'auth/popup-blocked') {
                fire.auth().signInWithRedirect(facebookProvider); return;
            }
            if (error.code === 'auth/account-exists-with-different-credential') {
                if (self.props.throwError) self.props.throwError('An account with this email already exists with password authentication. Please sign in with your email and password.');
                return;
            }
            if (['auth/operation-not-allowed', 'auth/unauthorized-domain', 'auth/configuration-not-found'].includes(error.code)) {
                import('../../../utils/facebookSdkAuth').then(({ directFacebookAuthFallback }) => {
                    directFacebookAuthFallback(self.props.closeModal, self.props.throwError);
                }).catch(e => { if (self.props.throwError) self.props.throwError(getSafeAuthErrorMessage(e, 'This sign-in method is unavailable right now. Please try email sign-in or contact support.')); });
                return;
            }
            if (error.code !== 'auth/popup-closed-by-user') {
                const msg = getSafeAuthErrorMessage(error);
                if (msg && self.props.throwError) self.props.throwError(msg);
            }
        });
    }

    // ─── LinkedIn (server-side redirect) ─────────────────────────────────────────
    signInWithLinkedIn() {
        if (this.state.oauthLoading) return;
        this.setState({ oauthLoading: 'linkedin' });
        window.location.href = '/api/auth/linkedin';
    }

    // ─── GitHub (server-side redirect) ───────────────────────────────────────────
    signInWithGitHub() {
        if (this.state.oauthLoading) return;
        this.setState({ oauthLoading: 'github' });
        window.location.href = '/api/auth/github';
    }

    handleInputs(title, value) {
        switch (title) {
            case "Email": this.setState({ email: value }); break;
            case "Password": this.setState({ password: value }); break;
            case "Repeat Password": this.setState({ passwordRepeat: value }); break;
            default: break;
        }
        // Clear error when user types
        this.setState(prevState => ({
            errors: { ...prevState.errors, [title]: '' }
        }));
    }

    handleBlur(title, value) {
        let errors = { ...this.state.errors };
        if (title === 'Email') {
            if (!value) {
                errors['Email'] = 'Please enter your email address.';
            } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                errors['Email'] = 'Please enter a valid email address.';
            }
        } else if (title === 'Password') {
            if (!value) {
                errors['Password'] = 'Please enter a password.';
            } else if (value.length < 6) {
                errors['Password'] = 'Password must be at least 6 characters.';
            }
        } else if (title === 'Repeat Password') {
            if (value !== this.state.password) {
                errors['Repeat Password'] = 'Passwords do not match.';
            }
        }
        this.setState({ errors });
    }

    async signUp(event) {
        event.preventDefault();
        if (this.state.isSubmitting) return; // GAP-01: prevent double-submit

        const email = (this.state.email || '').trim();
        // GAP-04: email format validation
        if (!email) {
            if (this.props.throwError) this.props.throwError('Please enter your email address.');
            return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            if (this.props.throwError) this.props.throwError('Please enter a valid email address.');
            return;
        }
        if (!this.state.password) {
            if (this.props.throwError) this.props.throwError('Please enter a password.');
            return;
        }
        if (this.state.passwordRepeat !== this.state.password) {
            this.props.throwError("Passwords do not match");
            return;
        }

        this.setState({ isSubmitting: true }); // GAP-01: lock submit
        try {
            const u = await fire.auth().createUserWithEmailAndPassword(email, this.state.password);
            const userName = email.split('@')[0];
            // Uses auth.js addUser for deduplication + metadata tracking
            await addUser(u.user.uid, userName, '', email, { authProvider: 'email' });
            // Welcome mail is durably enqueued by the server-side profile-create transaction.

            // Send branded crypto verification link email if Admin has enabled Email Verification Module
            try {
                const { getSystemSettings } = await import('../../../services/api/platform');
                const settings = await getSystemSettings();
                const emailVerificationEnabled = settings?.modules?.enableEmailVerification === true;
                if (emailVerificationEnabled && u.user && !u.user.emailVerified) {
                    fetch('/api/auth/send-verification-email', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email, userName })
                    }).then(res => res.json()).then(_data => {
                    }).catch(e => console.warn('[Register] Verification email notice:', e.message));
                }
            } catch (verifyErr) {
                console.warn('[Register] Email verification notice:', verifyErr.message);
            }

            // ✅ Show success notification to user
            if (this.props.throwSuccess) this.props.throwSuccess(`Welcome aboard! Your account has been created. Check your inbox for a verification email.`);

            // Delay close so user sees the success toast
            setTimeout(() => {
                if (this.props.closeModal) this.props.closeModal();
                this._handleRedirect(u.user.uid);
            }, 2000);
        } catch (error) {
            this.setState({ isSubmitting: false }); // GAP-01: unlock on error
            const msg = getSafeAuthErrorMessage(error, 'Registration failed. Please try again or contact support.');
            if (error.code === 'auth/email-already-in-use') {
                // Never delete an existing Auth identity based only on an unauthenticated
                // registration attempt. The account owner must sign in or use password reset.
            }
            if (this.props.throwError) this.props.throwError(msg);
            else this.setState({ formError: msg });
            console.error('[Register Error]:', error);
        }
    }

    render() {
        const { t } = this.props;
        const { enableGoogle, enableFacebook, enableLinkedIn, enableGitHub, oauthLoading, oauthError, formError } = this.state;
        const anySocial = enableGoogle || enableFacebook || enableLinkedIn || enableGitHub;

        return (
            <div className="auth">
                <div className="head">
                    <div className="brandBadge">Get Started Free ✨</div>
                    <span>{t("login.register")}</span>
                    <p>Build ATS-friendly resumes & portfolios in minutes</p>
                </div>
                <div className="body">
                    {oauthError && (
                        <div className="oauthNotice" role="alert" data-testid="oauth-error-notice">
                            {oauthError}
                        </div>
                    )}
                    {/* DIR-048: replaces `alert(msg)` for a registration failure when no
                        throwError handler was supplied. Same message, same assertive
                        role, but it lives in the page next to the fields it describes
                        instead of in a blocking OS dialog the suite cannot observe. */}
                    {formError && (
                        <div className="oauthNotice" role="alert" data-testid="register-form-error-notice">
                            {formError}
                        </div>
                    )}

                    <div className="socialAuth" role="group" aria-label="Register with social account">
                        {/* Google — GAP-07: button for keyboard/a11y */}
                        {enableGoogle && (
                            <button type="button" onClick={this.signInWithGoogle} className={`googleAuthItem${oauthLoading === 'google' ? ' is-loading' : ''}`} id="btn-register-google" aria-label="Continue with Google" title="Continue with Google" disabled={!!oauthLoading}>
                                <img src={GoogleImage} alt="" aria-hidden="true" />
                            </button>
                        )}
                        {/* Facebook */}
                        {enableFacebook && (
                            <button type="button" onClick={this.signInWithFacebook} className={`facebookAuthItem${oauthLoading === 'facebook' ? ' is-loading' : ''}`} id="btn-register-facebook" aria-label="Continue with Facebook" title="Continue with Facebook" disabled={!!oauthLoading}>
                                <img src={FacebookImage} alt="" aria-hidden="true" />
                            </button>
                        )}
                        {/* LinkedIn */}
                        {enableLinkedIn && (
                            <button type="button" onClick={this.signInWithLinkedIn} className={`linkedinAuthItem${oauthLoading === 'linkedin' ? ' is-loading' : ''}`} id="btn-register-linkedin" aria-label="Continue with LinkedIn" title="Continue with LinkedIn" disabled={!!oauthLoading}>
                                <LinkedInIcon />
                            </button>
                        )}
                        {/* GitHub */}
                        {enableGitHub && (
                            <button type="button" onClick={this.signInWithGitHub} className={`githubAuthItem${oauthLoading === 'github' ? ' is-loading' : ''}`} id="btn-register-github" aria-label="Continue with GitHub" title="Continue with GitHub" disabled={!!oauthLoading}>
                                <GitHubIcon />
                            </button>
                        )}
                    </div>
                    {/* Divider */}
                    {anySocial && (
                        <div className="devider">
                            <hr />
                            <span>{t("login.or")}</span>
                        </div>
                    )}
                    <form onSubmit={this.signUp} className="registerForm w-full flex flex-col" autoComplete="on" noValidate>
                        <Input 
                            name="Email" 
                            title={t("login.email")} 
                            value={this.state.email} 
                            handleInputs={this.handleInputs} 
                            onBlur={this.handleBlur}
                            errorMessage={this.state.errors['Email']}
                        />
                        <Input 
                            name="Password" 
                            type="Password" 
                            title={t("login.password")} 
                            value={this.state.password} 
                            handleInputs={this.handleInputs} 
                            onBlur={this.handleBlur}
                            errorMessage={this.state.errors['Password']}
                        />
                        <Input 
                            name="Repeat Password" 
                            type="Password" 
                            title={t("login.passwordRepeat")} 
                            value={this.state.passwordRepeat} 
                            handleInputs={this.handleInputs} 
                            onBlur={this.handleBlur}
                            errorMessage={this.state.errors['Repeat Password']}
                        />
                        {/* GAP-01: Loading state on submit button */}
                        <input
                            className="inputSubmit mt-2"
                            value={this.state.isSubmitting ? 'Creating account…' : t('login.register')}
                            type="submit"
                            disabled={this.state.isSubmitting}
                            style={{ opacity: this.state.isSubmitting ? 0.75 : 1, cursor: this.state.isSubmitting ? 'not-allowed' : 'pointer' }}
                        />
                    </form>
                </div>
                {/* Modal Footer */}
                <div className="modalFooter">
                    <span>{t("login.alreadyHaveAccount")} <a onClick={() => this.props.handleNavigationClick()}>{t("login.login")}</a></span>
                </div>
            </div>
        );
    }
}
const MyComponent = withTranslation('common')(Register)
export default MyComponent;