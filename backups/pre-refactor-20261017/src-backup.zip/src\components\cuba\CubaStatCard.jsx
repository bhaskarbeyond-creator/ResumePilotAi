import React from 'react';
import { FiTrendingDown, FiTrendingUp } from 'react-icons/fi';
import CubaCard from './CubaCard';
import CubaSkeleton from './CubaSkeleton';
import './cuba-skeleton.css';

const cx = (...parts) => parts.filter(Boolean).join(' ');

// DIR-047 (Vector 1, token fidelity): the `primary` accent previously reached for
// `border-[#7366ff]`, `bg-[#7366ff]/10` and `text-[#7366ff]`. Those arbitrary
// values bypassed the token layer entirely, so the card could not follow a theme
// change: it painted the LIGHT-theme violet on a dark surface. Every one of them
// has an exactly equivalent published token --
//   #7366ff                 -> --cuba-primary
//   rgba(115,102,255,0.10)  -> --cuba-primary-soft   (byte-identical)
//   rgba(115,102,255,0.20)  -> --cuba-primary-line   (published below for this)
//   #7366ff as TEXT         -> --cuba-primary-ink-strong
// The last one was already being rewritten at runtime by the
// `.text-[#7366ff]` remap in cuba-tokens.css, so naming the token directly is
// behaviour-preserving in light mode and FIXES the dark-mode inversion.
const ACCENT_TOKENS = {
    primary: {
        border: 'border-cuba-primary',
        bg: 'bg-cuba-primary-soft text-cuba-primary-ink-strong',
        badge: 'bg-cuba-primary-soft text-cuba-primary-ink-strong border-cuba-primary-line',
    },
    success: {
        border: 'border-emerald-500',
        bg: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
        badge: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
    },
    info: {
        border: 'border-sky-500',
        bg: 'bg-sky-500/10 text-sky-600 dark:text-sky-400',
        badge: 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/20',
    },
    warning: {
        border: 'border-amber-500',
        bg: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
        badge: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20',
    },
    danger: {
        border: 'border-rose-500',
        bg: 'bg-rose-500/10 text-rose-600 dark:text-rose-400',
        badge: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20',
    },
};

/**
 * CubaStatCard — authentic Cuba Executive widget-1 metric surface.
 *
 * Truthfulness guarantee (§46):
 * `value` is rendered verbatim by the caller. This component never substitutes
 * 0 for a missing metric; `loading` is an explicit prop so "no data yet" is
 * visually distinct from "the value is genuinely zero".
 */
const CubaStatCard = ({
    label,
    value,
    hint,
    icon,
    trend,
    visual = null,
    loading = false,
    accent = 'primary',
    compact = false,
    className = '',
}) => {
    const tokens = ACCENT_TOKENS[accent] || ACCENT_TOKENS.primary;

    return (
        <CubaCard
            className={cx(
                'cuba-stat-card cuba-widget-texture relative overflow-hidden rounded-[15px] border border-cuba-line bg-cuba-card p-5 shadow-cuba-md transition-all duration-300 hover:-translate-y-1 hover:shadow-cuba-lg flex flex-col justify-between',
                className
            )}
        >
            {/* Top row: Icon bubble on left, trend badge on right */}
            <div className={cx('flex items-center justify-between gap-2', compact ? 'mb-1.5 sm:mb-2' : 'mb-3')}>
                {icon && (
                    <div className={cx('relative flex-none rounded-full border border-dashed transition-transform duration-300', compact ? 'p-0.5' : 'p-1', tokens.border)}>
                        <div className={cx('cuba-stat-icon flex items-center justify-center rounded-full shadow-xs transition-transform', compact ? 'h-8 w-8 sm:h-9 sm:w-9' : 'h-11 w-11', tokens.bg)}>
                            {icon}
                        </div>
                    </div>
                )}
                {trend && !loading && (
                    <div className={cx(
                        'flex-none flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold border whitespace-nowrap',
                        trend.tone === 'down'
                            ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20'
                            : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
                    )}>
                        {trend.tone === 'down' ? (
                            <FiTrendingDown className="h-3 w-3" aria-hidden="true" />
                        ) : (
                            <FiTrendingUp className="h-3 w-3" aria-hidden="true" />
                        )}
                        <span>{trend.label}</span>
                    </div>
                )}
            </div>

            {/* Bottom section: Metric value, Category label, and Hint */}
            <div className="space-y-0.5">
                {loading ? (
                    <CubaSkeleton className="mt-1" height="1.75rem" width="4rem" text={`Loading ${label}`} />
                ) : (
                    <p className={cx('font-black tracking-tight text-cuba-ink tabular-nums font-rubik leading-tight', compact ? 'text-xl sm:text-2xl' : 'text-2xl sm:text-3xl')}>
                        {value}
                    </p>
                )}
                {label && (
                    <p className={cx('font-semibold uppercase tracking-wider text-cuba-ink-subtle', compact ? 'text-[10px] sm:text-xs' : 'text-xs')}>
                        {label}
                    </p>
                )}
                {hint && !loading && (
                    <p className={cx('text-[11px] font-medium text-cuba-ink-muted leading-tight pt-0.5', compact && 'hidden sm:block')}>
                        {hint}
                    </p>
                )}
                {/* DIR-077: optional native SVG micro-visual (radial gauge,
                    progress bar, pipeline stepper). Rendered only once the real
                    value has resolved, so a loading card never shows a fake 0. */}
                {visual && !loading && (
                    <div className="pt-2.5">{visual}</div>
                )}
            </div>
        </CubaCard>
    );
};

export default CubaStatCard;
