import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

// Step Components
import HeadingStep from './steps/HeadingStep';
import WorkHistoryStep from './steps/WorkHistoryStep';
import EducationStep from './steps/EducationStep';
import SkillsStep from './steps/SkillsStep';
import LanguagesStep from './steps/LanguagesStep';
import SummaryStep from './steps/SummaryStep';

// CV Templates
import Cv1 from '../../cv-templates/cv1/Cv1';
import Cv2 from '../../cv-templates/cv2/Cv2';
import Cv3 from '../../cv-templates/cv3/Cv3';
import Cv4 from '../../cv-templates/cv4/Cv4';
import Cv5 from '../../cv-templates/cv5/Cv5';
import Cv6 from '../../cv-templates/cv6/Cv6';
import Cv7 from '../../cv-templates/cv7/Cv7';
import Cv8 from '../../cv-templates/cv8/Cv8';
import Cv9 from '../../cv-templates/cv9/Cv9';
import Cv10 from '../../cv-templates/cv10/Cv10';
import Cv11 from '../../cv-templates/cv11/Cv11';
import Cv12 from '../../cv-templates/cv12/Cv12';
import Cv13 from '../../cv-templates/cv13/Cv13';
import Cv14 from '../../cv-templates/cv14/Cv14';
import Cv15 from '../../cv-templates/cv15/Cv15';
import Cv16 from '../../cv-templates/cv16/Cv16';
import Cv17 from '../../cv-templates/cv17/Cv17';
import Cv18 from '../../cv-templates/cv18/Cv18';
import Cv19 from '../../cv-templates/cv19/Cv19';
import Cv20 from '../../cv-templates/cv20/Cv20';
import Cv21 from '../../cv-templates/cv21/Cv21';
import Cv22 from '../../cv-templates/cv22/Cv22';
import Cv23 from '../../cv-templates/cv23/Cv23';
import Cv24 from '../../cv-templates/cv24/Cv24';
import Cv25 from '../../cv-templates/cv25/Cv25';
import Cv26 from '../../cv-templates/cv26/Cv26';
import Cv27 from '../../cv-templates/cv27/Cv27';
import Cv28 from '../../cv-templates/cv28/Cv28';
import Cv29 from '../../cv-templates/cv29/Cv29';
import Cv30 from '../../cv-templates/cv30/Cv30';
import Cv31 from '../../cv-templates/cv31/Cv31';
import Cv32 from '../../cv-templates/cv32/Cv32';
import Cv33 from '../../cv-templates/cv33/Cv33';
import Cv34 from '../../cv-templates/cv34/Cv34';
import Cv35 from '../../cv-templates/cv35/Cv35';
import Cv36 from '../../cv-templates/cv36/Cv36';
import Cv37 from '../../cv-templates/cv37/Cv37';
import Cv38 from '../../cv-templates/cv38/Cv38';
import Cv39 from '../../cv-templates/cv39/Cv39';
import Cv40 from '../../cv-templates/cv40/Cv40';
import Cv41 from '../../cv-templates/cv41/Cv41';
import Cv42 from '../../cv-templates/cv42/Cv42';
import Cv43 from '../../cv-templates/cv43/Cv43';
import Cv44 from '../../cv-templates/cv44/Cv44';
import Cv45 from '../../cv-templates/cv45/Cv45';
import Cv46 from '../../cv-templates/cv46/Cv46';
import Cv47 from '../../cv-templates/cv47/Cv47';
import Cv48 from '../../cv-templates/cv48/Cv48';
import Cv49 from '../../cv-templates/cv49/Cv49';
import Cv50 from '../../cv-templates/cv50/Cv50';
import Cv51 from '../../cv-templates/cv51/Cv51';

// Modal Components
import PreviewModal from './PreviewModal';
import TemplateSelectionModal from './TemplateSelectionModal';
import AtsScoreMeter from './AtsScoreMeter';
import ResumeImportModal from './ResumeImportModal';

// Import necessary modules for PDF export
import axios from 'axios';
import download from 'downloadjs';
import config from '../../conf/configuration';
import { setJsonPb, getJsonById, getResumeById, IncrementDownloads, addOneToNumberOfDocumentsDownloaded, getProfileOfUser, setResumePropertyPerUser, getSystemSettings } from '../../firestore/dbOperations';
import { trackDownload, trackEvent, trackEngagement } from '../../utils/ga4';

// Import logo
import logo from '../../assets/logo/logo.png';

// Import Toasts component for subscription notifications
import Toasts from '../Toasts/Toats';

// Import animation library for toast animations
import { evaluateDownloadAccess, isGlobalSubscriptionDisabled, isUserPremium } from '../../utils/subscriptionUtils';
import { motion, AnimatePresence } from 'framer-motion';

// Import user membership functions
import { getUserMembership } from '../../firestore/paidOperations';
import { getSubscriptionStatus } from '../../firestore/dbOperations';
import fire from '../../conf/fire';

const BuildResume = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { t, i18n } = useTranslation('common');
    const [showPreview, setShowPreview] = useState(false);
    const [showTemplateSelection, setShowTemplateSelection] = useState(false);
    const [showImportModal, setShowImportModal] = useState(false);
    const [isImportEnabled, setIsImportEnabled] = useState(false);
    const [currentTemplate, setCurrentTemplate] = useState('Cv1');
    const [isDownloading, setIsDownloading] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [authChecked, setAuthChecked] = useState(false);
    const [hasLoaded, setHasLoaded] = useState(false);
    const [isManualSaving, setIsManualSaving] = useState(false);
    const [saveSuccessMsg, setSaveSuccessMsg] = useState(false);

    // Mobile responsiveness states
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isMobilePreviewOpen, setIsMobilePreviewOpen] = useState(false);
    const [isFooterCompressed, setIsFooterCompressed] = useState(true);

    // Layout mounting state to handle responsive layout timing
    const [isMounted, setIsMounted] = useState(false);

    // Toast notification states
    const [isSuccessToastVisible, setIsSuccessToastVisible] = useState(false);
    const [isDownloadToastVisible, setIsDownloadToastVisible] = useState(false);
    const [isUpgradeToastVisible, setIsUpgradeToastVisible] = useState(false);

    // User data state (similar to how other components handle it)
    const [userData, setUserData] = useState({
        user: null,
        membership: 'Basic', // Default to Basic
        subscriptionsStatus: null, // This will hold the global subscription status from /data/subscriptions
        membershipEnds: null,
    });

    const [resumeData, setResumeData] = useState({
        // Personal Information
        firstname: '',
        lastname: '',
        email: '',
        phone: '',
        occupation: '',
        country: '',
        city: '',
        address: '',
        postalcode: '',
        photo: null,

        // Work History
        employments: [],

        // Education
        educations: [],

        // Skills
        skills: [],

        // Languages
        languages: [],

        // Summary
        summary: '',

        // Progress tracking
        completedSteps: [],
    });

    // Set mounted state on initial load
    useEffect(() => {
        setIsMounted(true);
    }, []);

    // Load AI module settings & check if import module is enabled (Default OFF)
    useEffect(() => {
        getSystemSettings().then((settings) => {
            const enabled = settings?.modules?.enableImportModule !== undefined
                ? settings.modules.enableImportModule === true
                : settings?.ai?.enableImportModule === true;
            setIsImportEnabled(enabled);
            if (location.search && location.search.includes('import=true') && enabled) {
                setShowImportModal(true);
            }
        }).catch(() => {
            setIsImportEnabled(false);
        });
    }, [location.search]);

    const steps = [
        {
            id: 1,
            name: t('BuildResume.steps.personalInfo'),
            path: 'heading',
            component: HeadingStep,
            icon: (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                </svg>
            ),
        },
        {
            id: 2,
            name: t('BuildResume.steps.workHistory'),
            path: 'work-history',
            component: WorkHistoryStep,
            icon: (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M6 6V5a3 3 0 013-3h2a3 3 0 013 3v1h2a2 2 0 012 2v6.5l1.5 1.5H1.5L3 15.5V8a2 2 0 012-2h1zM8 5v1h4V5a1 1 0 00-1-1h-2a1 1 0 00-1 1z" clipRule="evenodd" />
                </svg>
            ),
        },
        {
            id: 3,
            name: t('BuildResume.steps.education'),
            path: 'education',
            component: EducationStep,
            icon: (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                </svg>
            ),
        },
        {
            id: 4,
            name: t('BuildResume.steps.skills'),
            path: 'skills',
            component: SkillsStep,
            icon: (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path
                        fillRule="evenodd"
                        d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z"
                        clipRule="evenodd"
                    />
                </svg>
            ),
        },
        {
            id: 5,
            name: t('BuildResume.steps.languages', 'Languages'),
            path: 'languages',
            component: LanguagesStep,
            icon: (
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
                </svg>
            ),
        },
        {
            id: 6,
            name: t('BuildResume.steps.summary'),
            path: 'summary',
            component: SummaryStep,
            icon: (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path
                        fillRule="evenodd"
                        d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1z"
                        clipRule="evenodd"
                    />
                </svg>
            ),
        },
    ];

    const getCurrentStepIndex = () => {
        const currentPath = location.pathname.toLowerCase().replace(/\/$/, '');
        const segments = currentPath.split('/').filter(Boolean);
        const lastSegment = segments[segments.length - 1] || 'heading';

        const stepIndex = steps.findIndex((step) => step.path.toLowerCase() === lastSegment);
        return stepIndex >= 0 ? stepIndex : 0;
    };

    const currentStepIndex = getCurrentStepIndex();
    const currentStep = currentStepIndex >= 0 ? steps[currentStepIndex] : steps[0];

    // Automatic background draft saver
    const autoSaveResumeDraft = async (overrideData = null) => {
        try {
            // Don't auto-save if we haven't loaded existing data yet (prevents overwriting)
            if (!hasLoaded) {
                console.log('[AutoSave] Skipped — resume data has not been loaded yet');
                return;
            }

            const userId = userData.user || localStorage.getItem('user');
            if (!userId) return;

            let resumeId = localStorage.getItem('currentResumeId');
            if (!resumeId) {
                resumeId = `resume_${Date.now()}`;
                localStorage.setItem('currentResumeId', resumeId);
            }

            const rawPayload = overrideData || getPreviewData();
            const payload = {
                ...rawPayload,
                template: currentTemplate || rawPayload.template || localStorage.getItem('selectedTemplate') || 'Cv1',
            };

            // Safety check: Don't save completely empty data over existing resumes
            const hasAnyData = (payload.firstname && payload.firstname.trim() !== '') ||
                               (payload.lastname && payload.lastname.trim() !== '') ||
                               (payload.email && payload.email.trim() !== '') ||
                               (payload.employments && payload.employments.length > 0);
            
            if (!hasAnyData) {
                console.log('[AutoSave] Skipped — payload has no meaningful data, refusing to overwrite');
                return;
            }

            localStorage.setItem('currentResumeItem', JSON.stringify(payload));
            if (payload.template) {
                localStorage.setItem('selectedTemplate', payload.template);
            }
            await setJsonPb(resumeId, payload);
            console.log('✔ Auto-saved resume draft to Firestore & localStorage:', resumeId, 'template:', payload.template);
        } catch (err) {
            console.warn('Auto-save background sync warning:', err);
        }
    };

    const handleNext = async () => {
        await autoSaveResumeDraft();
        if (currentStepIndex < steps.length - 1) {
            const nextPath = `/build-resume/${steps[currentStepIndex + 1].path}`;
            console.log('Navigating to:', nextPath, 'Current step index:', currentStepIndex);
            navigate(nextPath);
        }
    };

    const handlePrevious = async () => {
        await autoSaveResumeDraft();
        if (currentStepIndex > 0) {
            const prevPath = `/build-resume/${steps[currentStepIndex - 1].path}`;
            navigate(prevPath);
        }
    };

    const handleStepClick = async (stepPath) => {
        await autoSaveResumeDraft();
        navigate(`/build-resume/${stepPath}`);
    };

    const isStepCompleted = (stepId) => {
        return resumeData.completedSteps.includes(stepId);
    };

    const updateResumeData = (newData) => {
        setResumeData((prev) => {
            const updated = { ...prev, ...newData };
            if (currentStep && !updated.completedSteps.includes(currentStep.id)) {
                updated.completedSteps = [...updated.completedSteps, currentStep.id];
            }
            return updated;
        });

        // Compute the auto-save payload AFTER setting state (deferred auto-save)
        // Use setTimeout(0) to ensure it runs after React has committed the state update
        setTimeout(() => {
            setResumeData((current) => {
                const addressParts = [
                    current.address,
                    current.city,
                    current.postalcode || current.postalCode,
                    current.country
                ].map(item => (item || '').trim()).filter(Boolean);

                const payload = {
                    ...current,
                    fullAddress: addressParts.join(', '),
                    employments: current.employments || [],
                    skills: (current.skills || []).map((skill, index) => ({
                        name: skill.skillName || skill.name || '',
                        rating: skill.rating || 50,
                        date: skill.date || index + 1,
                    })),
                    educations: current.educations || [],
                    languages: current.languages || [],
                };
                autoSaveResumeDraft(payload);
                return current; // Don't change state, just read it
            });
        }, 0);
    };

    // Template component mapping
    const getTemplateComponent = (templateId) => {
        const templateMap = {
            Cv1,
            Cv2,
            Cv3,
            Cv4,
            Cv5,
            Cv6,
            Cv7,
            Cv8,
            Cv9,
            Cv10,
            Cv11,
            Cv12,
            Cv13,
            Cv14,
            Cv15,
            Cv16,
            Cv17,
            Cv18,
            Cv19,
            Cv20,
            Cv21,
            Cv22,
            Cv23,
            Cv24,
            Cv25,
            Cv26,
            Cv27,
            Cv28,
            Cv29,
            Cv30,
            Cv31,
            Cv32,
            Cv33,
            Cv34,
            Cv35,
            Cv36,
            Cv37,
            Cv38,
            Cv39,
            Cv40,
            Cv41,
            Cv42,
            Cv43,
            Cv44,
            Cv45,
            Cv46,
            Cv47,
            Cv48,
            Cv49,
            Cv50,
            Cv51,
        };

        return templateMap[templateId] || Cv1; // Default to Cv1 if template not found
    };

    // Get user-friendly template name
    const getTemplateName = (templateId) => {
        const templateNames = {
            Cv1: t('BuildResume.templates.professionalClassic'),
            Cv2: t('BuildResume.templates.modernCreative'),
            Cv3: t('BuildResume.templates.creativeBold'),
            Cv4: t('BuildResume.templates.executivePro'),
            Cv5: t('BuildResume.templates.techModern'),
            Cv6: t('BuildResume.templates.simpleElegant'),
            Cv7: t('BuildResume.templates.designerSpecial'),
            Cv8: t('BuildResume.templates.cleanSimple'),
            Cv9: t('BuildResume.templates.corporateElite'),
            Cv10: t('BuildResume.templates.startupReady'),
            Cv11: t('BuildResume.templates.creativePro'),
            Cv12: t('BuildResume.templates.minimalPro'),
            Cv13: t('BuildResume.templates.businessClassic'),
            Cv14: t('BuildResume.templates.modernEdge'),
            Cv15: t('BuildResume.templates.artistPortfolio'),
            Cv16: t('BuildResume.templates.techInnovation'),
            Cv17: t('BuildResume.templates.executiveSuite'),
            Cv18: t('BuildResume.templates.creativeShowcase'),
            Cv19: t('BuildResume.templates.cleanProfessional'),
            Cv20: t('BuildResume.templates.futureForward'),
            Cv21: t('BuildResume.templates.professional21'),
            Cv22: t('BuildResume.templates.professional22'),
            Cv23: t('BuildResume.templates.professional23'),
            Cv24: t('BuildResume.templates.professional24'),
            Cv25: t('BuildResume.templates.professional25'),
            Cv26: t('BuildResume.templates.professional26'),
            Cv27: t('BuildResume.templates.professional27'),
            Cv28: t('BuildResume.templates.professional28'),
            Cv29: t('BuildResume.templates.professional29'),
            Cv30: t('BuildResume.templates.professional30'),
            Cv31: t('BuildResume.templates.professional31'),
            Cv32: t('BuildResume.templates.professional32'),
            Cv33: t('BuildResume.templates.professional33'),
            Cv34: t('BuildResume.templates.professional34'),
            Cv35: t('BuildResume.templates.professional35'),
            Cv36: t('BuildResume.templates.professional36'),
            Cv37: t('BuildResume.templates.professional37'),
            Cv38: t('BuildResume.templates.professional38'),
            Cv39: t('BuildResume.templates.professional39'),
            Cv40: t('BuildResume.templates.professional40'),
            Cv41: t('BuildResume.templates.professional41'),
            Cv42: t('BuildResume.templates.professional42'),
            Cv43: t('BuildResume.templates.professional43'),
            Cv44: t('BuildResume.templates.professional44'),
            Cv45: t('BuildResume.templates.professional45'),
            Cv46: t('BuildResume.templates.professional46'),
            Cv47: t('BuildResume.templates.professional47'),
            Cv48: t('BuildResume.templates.professional48'),
            Cv49: t('BuildResume.templates.professional49'),
            Cv50: t('BuildResume.templates.professional50'),
        };

        return templateNames[templateId] || templateId;
    };

    const handleManualSave = async () => {
        setIsManualSaving(true);
        try {
            localStorage.setItem('selectedTemplate', currentTemplate);
            setResumeData(prev => ({ ...prev, template: currentTemplate }));
            
            const payload = {
                ...getPreviewData(),
                template: currentTemplate
            };
            
            try {
                localStorage.setItem('currentResumeItem', JSON.stringify(payload));
            } catch (err) {}

            await autoSaveResumeDraft(payload);

            const userId = userData.user || localStorage.getItem('user');
            const resumeId = localStorage.getItem('currentResumeId');
            if (userId && resumeId) {
                try {
                    await setResumePropertyPerUser(userId, resumeId, 'template', currentTemplate);
                    await setResumePropertyPerUser(userId, resumeId, 'firstname', payload.firstname || '');
                    await setResumePropertyPerUser(userId, resumeId, 'lastname', payload.lastname || '');
                    await setResumePropertyPerUser(userId, resumeId, 'occupation', payload.occupation || '');
                } catch (subErr) {
                    console.warn('[BuildResume] Subcollection template save warning:', subErr);
                }
            }

            setSaveSuccessMsg(true);
            setTimeout(() => {
                setSaveSuccessMsg(false);
            }, 3500);
        } catch (e) {
            console.error('[BuildResume] Failed to save resume state completely:', e);
        } finally {
            setIsManualSaving(false);
        }
    };

    const handleTemplateSelect = (templateId) => {
        setCurrentTemplate(templateId);
        localStorage.setItem('selectedTemplate', templateId);

        const templateColors = getTemplateDefaultColors(templateId);
        let updatedData = { ...resumeData, template: templateId };
        if (templateColors) {
            updatedData.colors = templateColors;
        } else {
            const { colors, ...restData } = updatedData;
            updatedData = restData;
        }
        setResumeData(updatedData);

        const addressParts = [
            updatedData.address,
            updatedData.city,
            updatedData.postalcode || updatedData.postalCode,
            updatedData.country
        ].map(item => (item || '').trim()).filter(Boolean);
        
        const payload = {
            ...updatedData,
            template: templateId,
            fullAddress: addressParts.join(', '),
            employments: updatedData.employments || [],
            skills: (updatedData.skills || []).map((skill, index) => ({
                name: skill.skillName || skill.name || '',
                rating: skill.rating || 50,
                date: skill.date || index + 1,
            })),
            educations: updatedData.educations || [],
            languages: updatedData.languages || [],
            colors: updatedData.colors || templateColors,
        };

        try {
            localStorage.setItem('currentResumeItem', JSON.stringify(payload));
        } catch (err) {}

        autoSaveResumeDraft(payload);

        // Also sync template selection to user subcollection
        const userId = userData.user || localStorage.getItem('user');
        const resumeId = localStorage.getItem('currentResumeId');
        if (userId && resumeId) {
            try {
                setResumePropertyPerUser(userId, resumeId, 'template', templateId);
            } catch (userErr) {
                console.warn('[BuildResume] User subcollection sync warning on template select:', userErr);
            }
        }

        console.log(t('BuildResume.analytics.templateChanged', { templateName: getTemplateName(templateId), templateId }));
    };

    // Load saved template and language on component mount
    React.useEffect(() => {
        // Initialize language from localStorage
        const savedLanguage = localStorage.getItem('preferredLanguage');
        if (savedLanguage && savedLanguage !== i18n.language) {
            i18n.changeLanguage(savedLanguage);
        }

        const savedTemplate = localStorage.getItem('selectedTemplate');
        if (savedTemplate) {
            setCurrentTemplate(savedTemplate);
        }
    }, []);

    // Get default colors for each template based on their actual defaults
    const getTemplateDefaultColors = (templateId) => {
        const templateColors = {
            Cv1: { primary: '#1E40AF', secondary: '#F1F5F9' },
            Cv2: { primary: '#f0c30e', secondary: '#f5f5f5' },
            Cv3: { primary: '#be8a95', secondary: '#000000' },
            Cv4: { primary: '#3d3e42', secondary: '#3d3e42' },
            Cv5: { primary: '#000000', secondary: '#2d3039' },
            Cv6: { primary: '#000000', secondary: '#09043c' },
            Cv7: { primary: '#000000', secondary: '#f5f5f5' },
            Cv8: { primary: '#353f58', secondary: '#3d3e42' },
            Cv9: { primary: '#838383', secondary: '#000000' },
            Cv10: { primary: '#078dff', secondary: '#000000' },
            Cv11: { primary: '#86198f', secondary: '#fdf4ff' },
            Cv12: { primary: '#166534', secondary: '#f0fdf4' },
            Cv13: { primary: '#1e40af', secondary: '#eff6ff' },
            Cv14: { primary: '#b91c1c', secondary: '#fef2f2' },
            Cv15: { primary: '#9333ea', secondary: '#faf5ff' },
            Cv16: { primary: '#0d9488', secondary: '#f0fdfa' },
            Cv17: { primary: '#374151', secondary: '#f9fafb' },
            Cv18: { primary: '#f59e0b', secondary: '#fffbeb' },
            Cv19: { primary: '#3730a3', secondary: '#eef2ff' },
            Cv20: { primary: '#be185d', secondary: '#fdf2f8' },
            // Cv21-Cv50: No color initialization - let them use their hardcoded defaults
            Cv21: null,
            Cv22: null,
            Cv23: null,
            Cv24: null,
            Cv25: null,
            Cv26: null,
            Cv27: null,
            Cv28: null,
            Cv29: null,
            Cv30: null,
            Cv31: null,
            Cv32: null,
            Cv33: null,
            Cv34: null,
            Cv35: null,
            Cv36: null,
            Cv37: null,
            Cv38: null,
            Cv39: null,
            Cv40: null,
            Cv41: null,
            Cv42: null,
            Cv43: null,
            Cv44: null,
            Cv45: null,
            Cv46: null,
            Cv47: null,
            Cv48: null,
            Cv49: null,
            Cv50: null,
            Cv51: null,
        };

        return templateColors[templateId] || templateColors.Cv1;
    };

    // Create preview data ensuring arrays exist to prevent errors
    const getPreviewData = () => {
        const templateColors = getTemplateDefaultColors(currentTemplate);

        const addressParts = [
            resumeData.address,
            resumeData.city,
            resumeData.postalcode || resumeData.postalCode,
            resumeData.country
        ].map(item => (item || '').trim()).filter(Boolean);
        const formattedFullAddress = addressParts.join(', ');

        return {
            ...resumeData,
            template: currentTemplate,
            fullAddress: formattedFullAddress,
            // Ensure arrays exist to prevent component errors
            employments: resumeData.employments || [],
            // Transform skills from new format (skillName) to old format (name) for Cv1 compatibility
            skills: (resumeData.skills || []).map((skill, index) => ({
                name: skill.skillName || skill.name || '',
                rating: skill.rating || 50,
                date: skill.date || index + 1,
            })),
            educations: resumeData.educations || [],
            languages: resumeData.languages || [],
            // Include template-specific default colors
            colors: resumeData.colors || templateColors,
        };
    };

    // Show Toast function similar to BoardFilling.jsx
    const showToast = (type) => {
        if (type === 'Download') {
            setIsDownloadToastVisible(true);
            setTimeout(() => {
                setIsDownloadToastVisible(false);
            }, 8000);
        }
        if (type === 'Success') {
            setIsSuccessToastVisible(true);
            setTimeout(() => {
                setIsSuccessToastVisible(false);
            }, 8000);
        }
        if (type === 'Upgrade') {
            setIsUpgradeToastVisible(true);
            setTimeout(() => {
                setIsUpgradeToastVisible(false);
            }, 8000);
        }
    };

    // Enhanced Download PDF functionality with unified subscription verification
    const handleDownload = async () => {
        if (isDownloading) return;

        console.log('Download initiated. Global subscription status:', userData.subscriptionsStatus);
        console.log('User:', userData.user);
        console.log('User membership:', userData.membership);

        const access = evaluateDownloadAccess({
            user: userData.user,
            membership: userData.membership,
            membershipEnds: userData.membershipEnds,
            subscriptionsStatus: userData.subscriptionsStatus,
            isStatusLoaded: authChecked
        });

        console.log('Evaluated download access decision:', access);

        if (access.allowed) {
            console.log(`Download allowed. Reason: ${access.reason}`);
            showToast('Download');
            await performDownload();
            return;
        }

        if (access.reason === 'LOGIN_REQUIRED') {
            console.log('User not logged in, showing login prompt');
            alert(t('BuildResume.errors.loginRequired', 'Please log in to download your resume. You will be redirected to the login page.'));
            navigate('/');
            return;
        }

        if (access.reason === 'PREMIUM_REQUIRED') {
            console.log('Non-premium user with subscriptions enabled, redirecting to billing');

            try {
                if (!localStorage.getItem('currentResumeId')) {
                    localStorage.setItem('currentResumeId', Math.floor(Math.random() * 20000).toString() + 'xknd');
                }
                await setJsonPb(localStorage.getItem('currentResumeId'), getPreviewData());
                showToast('Success');
            } catch (error) {
                console.error('Error saving resume:', error);
            }

            showToast('Upgrade');
            setTimeout(() => {
                window.location.href = '/billing/plans';
            }, 3000);
        }
    };

    // Separate function for actual download (only called for Premium users)
    const performDownload = async () => {
        setIsDownloading(true);

        try {
            // Generate resume ID if it doesn't exist
            if (!localStorage.getItem('currentResumeId')) {
                localStorage.setItem('currentResumeId', Math.floor(Math.random() * 20000).toString() + 'xknd');
            }

            // Save resume data to database for export
            await setJsonPb(localStorage.getItem('currentResumeId'), getPreviewData());

            // Increment download counter
            await IncrementDownloads();

            // Add to user's download count if user is logged in
            const user = localStorage.getItem('user');
            if (user) {
                await addOneToNumberOfDocumentsDownloaded(user);
            }

            // Make API call to generate PDF
            const response = await axios.post(
                `${config.provider}://${config.backendUrl}/api/export`,
                {
                    language: i18n.language, // Use current language from i18n
                    resumeId: localStorage.getItem('currentResumeId'),
                    resumeName: currentTemplate, // Using selected template
                },
                {
                    responseType: 'blob',
                }
            );

            // Track download analytics
            trackDownload(currentTemplate, 'resume');
            trackEvent('download_document', 'Documents', currentTemplate, 1);
            trackEngagement('document_downloaded', {
                template_name: currentTemplate,
                document_type: 'resume',
                user_id: user,
            });

            // Validate the blob is a real PDF before downloading
            const arrayBuffer = await response.data.arrayBuffer();
            const bytes = new Uint8Array(arrayBuffer).slice(0, 4);
            const isPdf = bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46; // %PDF
            if (!isPdf) {
                // Server returned an error response instead of a PDF
                const errorText = new TextDecoder().decode(arrayBuffer);
                let errorMsg = 'Download failed: Server did not return a valid PDF.';
                try {
                    const parsed = JSON.parse(errorText);
                    if (parsed.error) errorMsg = `Download failed: ${parsed.error}`;
                } catch {}
                throw new Error(errorMsg);
            }
            download(new Blob([arrayBuffer], { type: 'application/pdf' }), 'resume.pdf', 'application/pdf');
        } catch (error) {
            console.error('Download failed:', error);
            // Track download failure
            trackEvent('download_failed', 'Documents', currentTemplate, 0);
            alert(t('BuildResume.errors.downloadFailed'));
        } finally {
            setIsDownloading(false);
        }
    };

    // Complete and save resume handler
    const handleCompleteResume = async () => {
        try {
            const userId = userData.user || localStorage.getItem('user');
            if (!userId) {
                alert('Please sign in to save your resume');
                return;
            }

            let currentResumeId = localStorage.getItem('currentResumeId');
            if (!currentResumeId) {
                currentResumeId = `resume_${Date.now()}`;
                localStorage.setItem('currentResumeId', currentResumeId);
            }

            const completeDataPayload = getPreviewData();

            // setJsonPb takes (resumeId, payload)
            await setJsonPb(currentResumeId, completeDataPayload);

            // Also save resume properties to user subcollection
            try {
                await setResumePropertyPerUser(userId, currentResumeId, 'template', currentTemplate);
                await setResumePropertyPerUser(userId, currentResumeId, 'firstname', completeDataPayload.firstname || '');
                await setResumePropertyPerUser(userId, currentResumeId, 'lastname', completeDataPayload.lastname || '');
                await setResumePropertyPerUser(userId, currentResumeId, 'occupation', completeDataPayload.occupation || '');
            } catch (userErr) {
                console.warn('User subcollection sync warning:', userErr);
            }

            showToast('Success');

            // Track analytics completion event
            trackEvent('resume_completed', 'Documents', currentTemplate, 1);

            // Clean up temporary session flags
            localStorage.removeItem('currentResumeId');
            localStorage.removeItem('currentResumeItem');

            // Navigate back to user dashboard after a brief toast delay
            setTimeout(() => {
                navigate('/dashboard');
            }, 1200);
        } catch (error) {
            console.error('Error completing resume:', error);
            alert('Failed to save resume. Please try again.');
        }
    };

    // Fetch global subscription status on component mount
    React.useEffect(() => {
        // Fetch global subscription status first
        getSubscriptionStatus()
            .then((subscriptionData) => {
                console.log('Global subscription status:', subscriptionData);
                setUserData((prevData) => ({
                    ...prevData,
                    subscriptionsStatus: subscriptionData,
                }));
            })
            .catch((error) => {
                console.error('Error fetching subscription status:', error);
            });
    }, []);

    // Auth listener and user data fetching (similar to Welcome.jsx and DashboardMain.jsx)
    React.useEffect(() => {
        const authListener = fire.auth().onAuthStateChanged((user) => {
            if (user) {
                // User is logged in
                console.log('User logged in:', user.uid);
                setUserData((prevData) => ({
                    ...prevData,
                    user: user.uid,
                }));
                localStorage.setItem('user', user.uid);

                // Fetch user membership information
                getUserMembership(user.uid)
                    .then((value) => {
                        if (value && value.membership) {
                            console.log('User membership data:', value);
                            setUserData((prevData) => ({
                                ...prevData,
                                membership: value.membership,
                                membershipEnds: value.membershipEnds ? value.membershipEnds.toDate() : null,
                            }));
                        } else {
                            console.log('No membership data found, defaulting to Basic');
                            setUserData((prevData) => ({
                                ...prevData,
                                membership: 'Basic',
                            }));
                        }
                        setAuthChecked(true);
                    })
                    .catch((error) => {
                        console.error('Error fetching user membership:', error);
                        setUserData((prevData) => ({
                            ...prevData,
                            membership: 'Basic',
                        }));
                        setAuthChecked(true);
                    });
            } else {
                // User is not logged in
                console.log('User not logged in');
                setUserData({
                    user: null,
                    membership: 'Basic',
                    subscriptionsStatus: null,
                    membershipEnds: null,
                });
                localStorage.removeItem('user');
                setAuthChecked(true);
            }
        });

        // Cleanup function
        return () => authListener();
    }, []); // Empty dependency array to run only on mount

    // Load existing resume or auto pre-fill new resume from Master "My Profile"
    React.useEffect(() => {
        console.log('[BuildResume debug] useEffect triggered. authChecked:', authChecked, 'user:', userData.user, 'hasLoaded:', hasLoaded);
        if (!authChecked || hasLoaded) return;

        const resumeId = localStorage.getItem('currentResumeId');
        console.log('[BuildResume debug] currentResumeId from localStorage:', resumeId);
        if (resumeId) {
            setIsLoading(true);
            
            // Helper to fetch template from subcollection as fallback
            const fetchSubcollectionTemplate = async () => {
                try {
                    const userId = userData.user || localStorage.getItem('user');
                    if (userId) {
                        const db = fire.firestore();
                        const docRef = await db.collection('users').doc(userId).collection('resumes').doc(resumeId).get();
                        if (docRef.exists && docRef.data().template) {
                            return docRef.data().template;
                        }
                    }
                } catch (err) {
                    console.warn('Failed to load template from subcollection:', err);
                }
                return null;
            };

            // Helper: extract resume data from any format (dashboard doc or flat pb object)
            const extractResumeFields = (parsed) => {
                // Handle both { id, item: {...} } format (from dashboard) and flat format (from autoSave/pb)
                const item = parsed.item ? parsed.item : parsed;
                const employments = parsed.employments || item.employments || [];
                const educations = parsed.educations || item.educations || [];
                const rawSkills = parsed.skills || item.skills || [];
                const languages = parsed.languages || item.languages || [];

                // Map skills to ensure compatibility with skillName key
                const skills = rawSkills.map((sk, idx) => ({
                    id: sk.id || `skill_${Date.now()}_${idx}`,
                    skillName: sk.skillName || sk.name || '',
                    rating: sk.rating || 50
                }));

                return { item, employments, educations, skills, languages };
            };

            // Helper: apply extracted data to state
            const applyResumeData = (item, employments, educations, skills, languages, parsed, tId = currentTemplate) => {
                setResumeData({
                    firstname: item.firstname || '',
                    lastname: item.lastname || '',
                    email: item.email || '',
                    phone: item.phone || '',
                    occupation: item.occupation || '',
                    city: item.city || '',
                    country: item.country || '',
                    address: item.address || '',
                    postalcode: item.postalcode || '',
                    photo: item.photo || null,
                    employments: employments,
                    educations: educations,
                    skills: skills,
                    languages: languages,
                    summary: item.summary || '',
                    completedSteps: item.completedSteps || (parsed && parsed.completedSteps) || [],
                    colors: (parsed && parsed.colors) || item.colors || getTemplateDefaultColors(tId) || { primary: '#000000', secondary: '#f5f5f5' },
                });
            };

            // 1. Try to load from localStorage first for instant response
            let loadedFromLocalStorage = false;
            const savedItem = localStorage.getItem('currentResumeItem');
            console.log('[BuildResume debug] currentResumeItem from localStorage:', savedItem ? `${savedItem.substring(0, 200)}...` : 'null');
            if (savedItem && savedItem !== 'null' && savedItem !== 'undefined') {
                try {
                    const parsed = JSON.parse(savedItem);
                    if (parsed && typeof parsed === 'object') {
                        const { item, employments, educations, skills, languages } = extractResumeFields(parsed);
                        
                        console.log('[BuildResume debug] Extracted item keys:', item ? Object.keys(item) : 'null');
                        console.log('[BuildResume debug] Extracted item.firstname:', item?.firstname, 'item.lastname:', item?.lastname);
                        console.log('[BuildResume debug] Extracted lists - employments:', employments.length, 'educations:', educations.length, 'skills:', skills.length, 'languages:', languages.length);
                        
                        // Check if we have ANY meaningful resume data
                        const hasPersonalInfo = item && (
                            (item.firstname && item.firstname.trim() !== '') ||
                            (item.lastname && item.lastname.trim() !== '') ||
                            (item.email && item.email.trim() !== '') ||
                            employments.length > 0
                        );

                        if (hasPersonalInfo) {
                            console.log('[BuildResume debug] ✅ Successfully loaded resume data from localStorage');
                            applyResumeData(item, employments, educations, skills, languages, parsed);
                            loadedFromLocalStorage = true;
                            
                            // Determine template (don't let this block loading)
                            const savedLocalTemp = localStorage.getItem('selectedTemplate');
                            const immediateTemplate = savedLocalTemp || parsed.template || item.template || 'Cv1';
                            setCurrentTemplate(immediateTemplate);
                            localStorage.setItem('selectedTemplate', immediateTemplate);
                            
                            // Also try subcollection template as async enhancement only if no template is saved
                            fetchSubcollectionTemplate().then((subTemp) => {
                                if (subTemp && subTemp !== immediateTemplate && !parsed.template && !savedLocalTemp) {
                                    console.log('[BuildResume debug] Upgrading template from subcollection:', subTemp);
                                    setCurrentTemplate(subTemp);
                                    localStorage.setItem('selectedTemplate', subTemp);
                                }
                            }).catch(() => { /* ignore - we already have a template */ });
                            
                            // Data is loaded - stop loading immediately (don't wait for template fetch)
                            setIsLoading(false);
                            setHasLoaded(true);
                            return; // Skip Firestore fallback
                        } else {
                            console.log('[BuildResume debug] ⚠️ localStorage data exists but has no meaningful personal info, falling through to Firestore');
                        }
                    }
                } catch (e) {
                    console.warn('[BuildResume debug] ❌ Failed to parse currentResumeItem:', e);
                }
            }

            // 2. Fallback to pulling directly from Firestore pb collection
            console.log('[BuildResume debug] Falling back to Firestore getJsonById for resumeId:', resumeId);
            getJsonById(resumeId)
                .then(async (data) => {
                    console.log('[BuildResume debug] Firestore getJsonById resolved data:', data ? 'found' : 'null');
                    
                    // Fallback to loading from subcollections if not found in global pb collection
                    if (!data) {
                        const userId = userData.user || localStorage.getItem('user');
                        if (userId) {
                            console.log('[BuildResume debug] Trying to load from subcollections for userId:', userId, 'resumeId:', resumeId);
                            const subcollectionData = await getResumeById(userId, resumeId);
                            console.log('[BuildResume debug] Reconstructed subcollection data:', subcollectionData ? 'found' : 'null');
                            if (subcollectionData) {
                                data = subcollectionData;
                            }
                        }
                    }

                    if (data) {
                        const { item, employments, educations, skills, languages } = extractResumeFields(data);
                        applyResumeData(item, employments, educations, skills, languages, data);
                        
                        // Also update localStorage so next time loads faster
                        try {
                            localStorage.setItem('currentResumeItem', JSON.stringify(data));
                        } catch (storageErr) {
                            console.warn('Could not cache resume to localStorage:', storageErr);
                        }
                        
                        const savedLocalTemp = localStorage.getItem('selectedTemplate');
                        const templateId = savedLocalTemp || data.template || subTemp || 'Cv1';
                        setCurrentTemplate(templateId);
                        localStorage.setItem('selectedTemplate', templateId);
                        setHasLoaded(true);
                    } else {
                        console.warn('[BuildResume debug] ⚠️ No resume data found in Firestore for resumeId:', resumeId);
                        setHasLoaded(true);
                    }
                })
                .catch((err) => {
                    console.error('Failed to load resume from firestore:', err);
                    setHasLoaded(true);
                })
                .finally(() => {
                    setIsLoading(false);
                });
        } else {
            // New resume - pre-fill from profile if logged in
            if (userData.user) {
                setIsLoading(true);
                getProfileOfUser(userData.user)
                    .then((profile) => {
                        if (profile) {
                            console.log('Auto pre-filling new resume from Master Profile:', profile);
                            setResumeData((prev) => ({
                                ...prev,
                                firstname: prev.firstname || profile.firstname || profile.name?.split(' ')[0] || '',
                                lastname: prev.lastname || profile.lastname || profile.name?.split(' ').slice(1).join(' ') || '',
                                email: prev.email || profile.email || '',
                                phone: prev.phone || profile.phone || '',
                                occupation: prev.occupation || profile.occupation || '',
                                city: prev.city || profile.city || '',
                                country: prev.country || profile.country || '',
                                address: prev.address || profile.address || '',
                                postalcode: prev.postalcode || profile.postalCode || '',
                                photo: prev.photo || profile.selectedImage || profile.photo || null,
                                employments: prev.employments.length > 0 ? prev.employments : (profile.employments || []),
                                educations: prev.educations.length > 0 ? prev.educations : (profile.educations || []),
                                skills: prev.skills.length > 0 ? prev.skills : (profile.skills || []),
                                summary: prev.summary || profile.summary || '',
                            }));
                        }
                        setHasLoaded(true);
                    })
                    .catch((err) => console.error('Error auto-populating master profile:', err))
                    .finally(() => {
                        setIsLoading(false);
                    });
            } else {
                setIsLoading(false);
                setHasLoaded(true);
            }
        }
    }, [authChecked, userData.user, hasLoaded]);

    // Redirect to first step if on base path
    React.useEffect(() => {
        if (
            location.pathname === '/build-resume' ||
            location.pathname === '/build-resume/' ||
            location.pathname === '/create-resume' ||
            location.pathname === '/create-resume/'
        ) {
            navigate('/build-resume/heading');
        }
    }, [location.pathname, navigate]);

    const progressPercentage = Math.round((resumeData.completedSteps.length / steps.length) * 100);

    if (isLoading) {
        return (
            <div className="min-h-screen bg-slate-50 flex items-center justify-center w-full">
                <div className="flex flex-col items-center space-y-4">
                    <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    <p className="text-slate-600 text-sm font-semibold">Loading your resume...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex overflow-hidden">
            {/* Toast Notifications */}
            <AnimatePresence>
                {isSuccessToastVisible && (
                    <motion.div initial={{ opacity: 0, y: -20, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -20, scale: 0.9 }} className="fixed top-6 right-6 z-50">
                        <Toasts type="Success" />
                    </motion.div>
                )}
            </AnimatePresence>

            <AnimatePresence>
                {isDownloadToastVisible && (
                    <motion.div initial={{ opacity: 0, y: -20, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -20, scale: 0.9 }} className="fixed top-6 right-6 z-50">
                        <Toasts type="Download" />
                    </motion.div>
                )}
            </AnimatePresence>

            <AnimatePresence>
                {isUpgradeToastVisible && (
                    <motion.div initial={{ opacity: 0, y: -20, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -20, scale: 0.9 }} className="fixed top-6 right-6 z-50">
                        <Toasts type="Upgrade" />
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Mobile Header - Only visible on mobile */}
            <div className="md:hidden fixed top-0 left-0 right-0 bg-white border-b border-slate-200 px-4 py-3 z-30 flex items-center justify-between">
                {/* Mobile Menu Button */}
                <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg" aria-label="Open navigation menu">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>

                {/* Logo */}
                <Link to={userData.user ? "/dashboard2" : "/"}>
                    <img src={logo} alt="Logo" className="h-8 w-auto object-contain" />
                </Link>

                {/* Mobile Preview Button */}
                <button onClick={() => setIsMobilePreviewOpen(true)} className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg" aria-label="Open resume preview">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                        />
                    </svg>
                </button>
            </div>

            {/* Mobile Navigation Overlay */}
            <AnimatePresence>
                {isMobileMenuOpen && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="md:hidden fixed inset-0 z-50 bg-black bg-opacity-30"
                        onClick={() => setIsMobileMenuOpen(false)}>
                        <motion.div
                            initial={{ x: '-100%' }}
                            animate={{ x: 0 }}
                            exit={{ x: '-100%' }}
                            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                            className="fixed left-0 top-0 bottom-0 w-80 max-w-[85vw] bg-white shadow-xl"
                            onClick={(e) => e.stopPropagation()}>
                            {/* Mobile Navigation Header */}
                            <div className="px-4 py-6 border-b border-slate-100 flex justify-between items-center">
                                <Link to={userData.user ? "/dashboard2" : "/"} onClick={() => setIsMobileMenuOpen(false)}>
                                    <img src={logo} alt="Logo" className="h-8 w-auto object-contain" />
                                </Link>
                                <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 rounded-lg">
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            {/* Mobile Steps Navigation */}
                            <div className="flex-1 px-3 py-4 overflow-y-auto">
                                <nav className="space-y-1">
                                    {steps.map((step, index) => {
                                        const isActive = currentStep.id === step.id;
                                        const isCompleted = isStepCompleted(step.id);
                                        const isPrevious = index < currentStepIndex;

                                        return (
                                            <button
                                                key={step.id}
                                                onClick={() => {
                                                    handleStepClick(step.path);
                                                    setIsMobileMenuOpen(false);
                                                }}
                                                className={`w-full flex items-center text-left p-3 rounded-lg transition-all duration-200 group relative ${
                                                    isActive
                                                        ? 'bg-blue-50 border border-blue-200 text-blue-900 shadow-sm'
                                                        : isCompleted || isPrevious
                                                        ? 'text-slate-700 hover:bg-slate-50 hover:border-slate-200 border border-transparent'
                                                        : 'text-slate-400 hover:text-slate-600 border border-transparent'
                                                }`}
                                                disabled={!isCompleted && !isPrevious && !isActive}
                                                aria-current={isActive ? 'step' : undefined}>
                                                <div className="flex items-center">
                                                    {/* Step Icon/Number */}
                                                    <div
                                                        className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-semibold mr-3 transition-all duration-200 ${
                                                            isActive
                                                                ? 'bg-blue-600 text-white shadow-sm'
                                                                : isCompleted
                                                                ? 'bg-green-500 text-white'
                                                                : isPrevious
                                                                ? 'bg-slate-200 text-slate-600'
                                                                : 'bg-slate-100 text-slate-400'
                                                        }`}>
                                                        {isCompleted ? (
                                                            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                                                <path
                                                                    fillRule="evenodd"
                                                                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                                                    clipRule="evenodd"
                                                                />
                                                            </svg>
                                                        ) : (
                                                            step.icon
                                                        )}
                                                    </div>

                                                    <div className="flex-1 min-w-0">
                                                        <span className="text-sm font-medium block truncate">{step.name}</span>
                                                        {isActive && <span className="text-xs text-blue-600">{t('BuildResume.navigation.current')}</span>}
                                                        {isCompleted && !isActive && <span className="text-xs text-green-600">✓</span>}
                                                    </div>
                                                </div>

                                                {/* Active indicator */}
                                                {isActive && <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-1 h-8 bg-blue-600 rounded-r-full"></div>}
                                            </button>
                                        );
                                    })}
                                </nav>

                                {/* Mobile Progress Section */}
                                <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
                                    <div className="flex items-center justify-between mb-2">
                                        <span className="text-sm font-semibold text-slate-700">{t('BuildResume.progress.progress')}</span>
                                        <span className="text-sm font-bold text-slate-900">{progressPercentage}%</span>
                                    </div>

                                    <div className="w-full bg-slate-200 rounded-full h-2 mb-2 overflow-hidden">
                                        <div
                                            className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-500 ease-out"
                                            style={{ width: `${progressPercentage}%` }}></div>
                                    </div>

                                    <p className="text-xs text-slate-600">
                                        {resumeData.completedSteps.length}/{steps.length} {t('BuildResume.progress.completed')}
                                    </p>
                                </div>
                            </div>

                            {/* Mobile User Status and Actions */}
                            <div className="px-4 py-4 border-t border-slate-200 bg-white">
                                {/* User Status */}
                                {userData.user && (
                                    <div className="mb-4 p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm font-semibold text-slate-800">Plan:</span>
                                            <span
                                                className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                                                    userData.membership === 'Premium' ||
                                                    userData.subscriptionsStatus === false ||
                                                    (userData.subscriptionsStatus && userData.subscriptionsStatus.state === false)
                                                        ? 'bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 border border-green-200/80'
                                                        : 'bg-gradient-to-r from-gray-100 to-slate-100 text-gray-700 border border-gray-200/80'
                                                }`}>
                                                {userData.subscriptionsStatus === false || (userData.subscriptionsStatus && userData.subscriptionsStatus.state === false)
                                                    ? 'Free Access'
                                                    : userData.membership}
                                                {(userData.membership === 'Premium' ||
                                                    userData.subscriptionsStatus === false ||
                                                    (userData.subscriptionsStatus && userData.subscriptionsStatus.state === false)) && <span className="ml-1">✓</span>}
                                            </span>
                                        </div>
                                        {userData.membership === 'Basic' &&
                                            userData.subscriptionsStatus !== false &&
                                            !(userData.subscriptionsStatus && userData.subscriptionsStatus.state === false) && (
                                                <button
                                                    onClick={() => {
                                                        window.location.href = '/billing/plans';
                                                        setIsMobileMenuOpen(false);
                                                    }}
                                                    className="w-full mt-3 text-sm bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2 px-3 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 font-semibold shadow-sm hover:shadow-md">
                                                    Upgrade to Premium
                                                </button>
                                            )}
                                        {(userData.subscriptionsStatus === false || (userData.subscriptionsStatus && userData.subscriptionsStatus.state === false)) && (
                                            <div className="w-full mt-2 text-sm text-center text-green-700 font-semibold">🎉 Free downloads enabled</div>
                                        )}
                                    </div>
                                )}

                                {/* Mobile Action Buttons */}
                                <div className="space-y-3">
                                    <button
                                        onClick={() => {
                                            setShowTemplateSelection(true);
                                            setIsMobileMenuOpen(false);
                                        }}
                                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-4 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-md hover:shadow-lg text-sm flex items-center justify-center space-x-2">
                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                                strokeWidth={2}
                                                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                                            />
                                        </svg>
                                        <span>{t('BuildResume.preview.changeTemplate')}</span>
                                    </button>

                                    <button
                                        onClick={() => {
                                            setShowPreview(true);
                                            setIsMobileMenuOpen(false);
                                        }}
                                        className="w-full border border-slate-300 text-slate-700 py-3 px-4 rounded-lg font-medium hover:bg-slate-50 hover:border-slate-400 transition-all duration-200 text-sm flex items-center justify-center space-x-2">
                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            <path
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                                strokeWidth={2}
                                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                                            />
                                        </svg>
                                        <span>{t('BuildResume.preview.viewFullSize')}</span>
                                    </button>

                                    <button
                                        onClick={() => {
                                            handleDownload();
                                            setIsMobileMenuOpen(false);
                                        }}
                                        disabled={isDownloading}
                                        className={`w-full py-3 px-4 font-medium transition-all duration-200 text-sm rounded-lg flex items-center justify-center space-x-2 ${
                                            isDownloading
                                                ? 'border border-slate-300 text-slate-400 cursor-not-allowed'
                                                : 'border border-emerald-300 text-emerald-700 hover:bg-emerald-50 hover:border-emerald-400'
                                        }`}>
                                        {isDownloading ? (
                                            <>
                                                <div className="w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"></div>
                                                <span className="hidden sm:inline">{t('BuildResume.navigation.downloading')}</span>
                                            </>
                                        ) : (
                                            <>
                                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path
                                                        strokeLinecap="round"
                                                        strokeLinejoin="round"
                                                        strokeWidth={2}
                                                        d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                                    />
                                                </svg>
                                                <span className="hidden sm:inline">{t('BuildResume.navigation.download')}</span>
                                            </>
                                        )}
                                    </button>
                                </div>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Mobile Preview Overlay */}
            <AnimatePresence>
                {isMobilePreviewOpen && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="md:hidden fixed inset-0 z-50 bg-black bg-opacity-30"
                        onClick={() => setIsMobilePreviewOpen(false)}>
                        <motion.div
                            initial={{ x: '100%' }}
                            animate={{ x: 0 }}
                            exit={{ x: '100%' }}
                            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                            className="fixed right-0 top-0 bottom-0 w-80 max-w-[85vw] bg-white shadow-xl"
                            onClick={(e) => e.stopPropagation()}>
                            {/* Mobile Preview Header */}
                            <div className="px-4 py-4 border-b border-slate-100 flex justify-between items-center">
                                <div>
                                    <h3 className="text-sm font-semibold text-slate-900">{t('BuildResume.preview.livePreview')}</h3>
                                    <p className="text-xs text-slate-600 mt-1">{getTemplateName(currentTemplate)}</p>
                                </div>
                                <button onClick={() => setIsMobilePreviewOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 rounded-lg">
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            {/* Mobile Resume Preview */}
                            <div className="flex-1 px-4 py-4 overflow-y-auto">
                                {/* Preview Window */}
                                <div className="bg-white border-2 border-slate-200 rounded-xl shadow-lg overflow-hidden">
                                    {/* Preview Header */}
                                    <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-3 py-2.5 flex items-center justify-between">
                                        <div className="flex items-center space-x-2">
                                            <div className="flex space-x-1">
                                                <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                                                <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                                                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                                            </div>
                                            <div className="text-white text-xs font-medium ml-2">{t('BuildResume.preview.resumePdf')}</div>
                                        </div>
                                    </div>

                                    {/* Resume Content */}
                                    <div className="relative h-80 overflow-hidden bg-gradient-to-br from-slate-50 to-gray-50">
                                        <div
                                            className="cursor-pointer"
                                            onClick={() => {
                                                setShowPreview(true);
                                                setIsMobilePreviewOpen(false);
                                            }}
                                            style={{ transform: 'scale(0.35)', transformOrigin: 'top left', width: '285%', height: '285%' }}>
                                            {(() => {
                                                try {
                                                    const TemplateComponent = getTemplateComponent(currentTemplate);
                                                    return <TemplateComponent values={getPreviewData()} language={i18n.language} />;
                                                } catch (error) {
                                                    console.error('Error rendering template:', error);
                                                    return (
                                                        <div className="flex items-center justify-center h-full bg-gray-100 text-gray-500">
                                                            <div className="text-center">
                                                                <div className="text-sm">{t('BuildResume.errors.templateError')}</div>
                                                                <div className="text-xs mt-1">{t('BuildResume.errors.usingDefault')}</div>
                                                            </div>
                                                        </div>
                                                    );
                                                }
                                            })()}
                                        </div>
                                    </div>

                                    {/* Progress indicator */}
                                    <div className="bg-gradient-to-r from-slate-50 to-blue-50 px-3 py-2 border-t border-slate-200">
                                        <div className="flex items-center justify-between text-xs">
                                            <span className="text-slate-600">{t('BuildResume.progress.completeness')}</span>
                                            <span className="text-blue-600 font-semibold">{progressPercentage}%</span>
                                        </div>
                                        <div className="mt-1 w-full bg-slate-200 rounded-full h-1 overflow-hidden">
                                            <div
                                                className="bg-gradient-to-r from-blue-500 to-purple-500 h-1 rounded-full transition-all duration-500 ease-out"
                                                style={{ width: `${progressPercentage}%` }}></div>
                                        </div>
                                    </div>
                                </div>

                                {/* Mobile Action Buttons */}
                                <div className="mt-4 space-y-2">
                                    <button
                                        onClick={() => {
                                            setShowTemplateSelection(true);
                                            setIsMobilePreviewOpen(false);
                                        }}
                                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2.5 px-4 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-md hover:shadow-lg text-sm flex items-center justify-center space-x-2">
                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                                strokeWidth={2}
                                                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                                            />
                                        </svg>
                                        <span>{t('BuildResume.preview.changeTemplate')}</span>
                                    </button>
                                    <button
                                        onClick={() => {
                                            setShowPreview(true);
                                            setIsMobilePreviewOpen(false);
                                        }}
                                        className="w-full border border-slate-300 text-slate-700 py-2.5 px-4 rounded-lg font-medium hover:bg-slate-50 hover:border-slate-400 transition-all duration-200 text-sm flex items-center justify-center space-x-2">
                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            <path
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                                strokeWidth={2}
                                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                                            />
                                        </svg>
                                        <span>{t('BuildResume.preview.viewFullSize')}</span>
                                    </button>
                                </div>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Left Sidebar - Steps Navigation - Always Visible */}
            <div className="flex flex-col w-56 lg:w-64 bg-white border-r border-slate-200 shadow-sm min-h-screen flex-shrink-0 relative z-20">
                {/* Header */}
                <div className="px-4 py-5 border-b border-slate-100 flex-shrink-0 flex items-center justify-between">
                    <Link to={userData.user ? "/dashboard" : "/"}>
                        <img src={logo} alt="Logo" className="h-7 w-auto object-contain" />
                    </Link>
                    <Link
                        to={userData.user ? "/dashboard" : "/"}
                        className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-indigo-600 bg-slate-100 hover:bg-indigo-50 px-2.5 py-1.5 rounded-lg border border-slate-200/80 transition-all shadow-sm">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                        <span>Dashboard</span>
                    </Link>
                </div>

                {/* Steps Navigation */}
                <div className="flex-1 px-3 py-4 overflow-y-auto">
                    <nav className="space-y-1">
                        {steps.map((step, index) => {
                            const isActive = currentStep.id === step.id;
                            const isCompleted = isStepCompleted(step.id);
                            const isPrevious = index < currentStepIndex;

                            return (
                                <button
                                    key={step.id}
                                    onClick={() => handleStepClick(step.path)}
                                    className={`w-full flex items-center text-left p-2 rounded-lg transition-all duration-200 group relative ${
                                        isActive
                                            ? 'bg-blue-50 border border-blue-200 text-blue-900 shadow-sm'
                                            : isCompleted || isPrevious
                                            ? 'text-slate-700 hover:bg-slate-50 hover:border-slate-200 border border-transparent'
                                            : 'text-slate-400 hover:text-slate-600 border border-transparent'
                                    }`}
                                    disabled={!isCompleted && !isPrevious && !isActive}
                                    aria-current={isActive ? 'step' : undefined}>
                                    <div className="flex items-center">
                                        {/* Step Icon/Number */}
                                        <div
                                            className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-semibold mr-2 transition-all duration-200 ${
                                                isActive
                                                    ? 'bg-blue-600 text-white shadow-sm'
                                                    : isCompleted
                                                    ? 'bg-green-500 text-white'
                                                    : isPrevious
                                                    ? 'bg-slate-200 text-slate-600'
                                                    : 'bg-slate-100 text-slate-400'
                                            }`}>
                                            {isCompleted ? (
                                                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                    <path
                                                        fillRule="evenodd"
                                                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                                        clipRule="evenodd"
                                                    />
                                                </svg>
                                            ) : (
                                                step.icon
                                            )}
                                        </div>

                                        <div className="flex-1 min-w-0">
                                            <span className="text-xs font-medium block truncate">{step.name}</span>
                                            {isActive && <span className="text-xs text-blue-600">{t('BuildResume.navigation.current')}</span>}
                                            {isCompleted && !isActive && <span className="text-xs text-green-600">✓</span>}
                                        </div>
                                    </div>

                                    {/* Active indicator */}
                                    {isActive && <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-1 h-8 bg-blue-600 rounded-r-full"></div>}
                                </button>
                            );
                        })}
                    </nav>

                    {/* Real-Time ATS Score Meter Widget */}
                    <div className="mt-4">
                        <AtsScoreMeter resumeData={resumeData} />
                    </div>

                    {/* Progress Section */}
                    <div className="mt-4 p-3 bg-slate-50 rounded-lg border border-slate-200">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-xs font-semibold text-slate-700">{t('BuildResume.progress.progress')}</span>
                            <span className="text-xs font-bold text-slate-900">{progressPercentage}%</span>
                        </div>

                        <div className="w-full bg-slate-200 rounded-full h-1.5 mb-2 overflow-hidden">
                            <div className="bg-gradient-to-r from-blue-500 to-purple-500 h-1.5 rounded-full transition-all duration-500 ease-out" style={{ width: `${progressPercentage}%` }}></div>
                        </div>

                        <p className="text-xs text-slate-600">
                            {resumeData.completedSteps.length}/{steps.length} {t('BuildResume.progress.completed')}
                        </p>
                    </div>
                </div>

                <div className="px-4 py-3 border-t border-slate-200 bg-white flex-shrink-0 sticky bottom-0 z-20 shadow-md">
                    {/* Expand/Compress Header */}
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-1.5">
                            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Plan:</span>
                            <span
                                className={`text-[11px] font-extrabold px-2 py-0.5 rounded-full ${
                                    userData.membership === 'Premium' || userData.subscriptionsStatus === false || (userData.subscriptionsStatus && userData.subscriptionsStatus.state === false)
                                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                        : 'bg-amber-100 text-amber-800 border border-amber-300'
                                }`}>
                                {userData.subscriptionsStatus === false || (userData.subscriptionsStatus && userData.subscriptionsStatus.state === false)
                                    ? 'Free Access ✓'
                                    : (userData.membership || 'Basic')}
                            </span>
                        </div>
                        <button
                            onClick={() => setIsFooterCompressed(!isFooterCompressed)}
                            className="p-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                            title={isFooterCompressed ? "Expand Footer" : "Compress Footer"}>
                            {isFooterCompressed ? (
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7" />
                                </svg>
                            ) : (
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                                </svg>
                            )}
                        </button>
                    </div>

                    {/* Upgrade to Premium Button - ALWAYS visible even when compressed */}
                    {userData.membership !== 'Premium' && userData.subscriptionsStatus !== false && !(userData.subscriptionsStatus && userData.subscriptionsStatus.state === false) && (
                        <button
                            onClick={() => (window.location.href = '/billing/plans')}
                            className="w-full text-xs bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-700 hover:to-pink-700 text-white py-2 px-3 rounded-lg transition-all duration-200 font-bold shadow-sm hover:shadow-md flex items-center justify-center gap-1.5">
                            <svg className="w-3.5 h-3.5 text-amber-300 fill-current" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                            Upgrade to Premium
                        </button>
                    )}

                    {/* Expanded Details: Help & Support, Privacy Policy, Copyright */}
                    {!isFooterCompressed && (
                        <div className="mt-3 pt-2.5 border-t border-slate-100 space-y-1.5 animate-in fade-in duration-150">
                            <a href="/contact" target="_blank" rel="noopener noreferrer" className="flex items-center text-xs text-slate-600 hover:text-indigo-600 transition-colors font-medium group py-0.5">
                                <svg className="w-3.5 h-3.5 mr-2 text-slate-400 group-hover:text-indigo-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span>Help & Support</span>
                            </a>
                            <a href="/p/privacy-policy" target="_blank" rel="noopener noreferrer" className="flex items-center text-xs text-slate-600 hover:text-indigo-600 transition-colors font-medium group py-0.5">
                                <svg className="w-3.5 h-3.5 mr-2 text-slate-400 group-hover:text-indigo-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                                </svg>
                                <span>Privacy Policy</span>
                            </a>
                            <div className="text-[10px] text-slate-400 pt-2 border-t border-slate-100 font-medium">
                                © {new Date().getFullYear()} {config?.brand?.name || 'Bold Limited'}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Main Content Area - Responsive Center Section */}
            <div className="flex-1 flex flex-col h-full overflow-hidden relative">
                {/* Main Form Content */}
                <div className="flex-1 bg-white flex flex-col h-full overflow-hidden">
                    {/* Scrollable content area */}
                    <div className="flex-1 overflow-y-auto bg-slate-50">
                        <div className="min-h-full pb-6">
                            <Routes>
                                <Route path="heading" element={<HeadingStep resumeData={resumeData} updateResumeData={updateResumeData} />} />
                                <Route path="work-history" element={<WorkHistoryStep resumeData={resumeData} updateResumeData={updateResumeData} />} />
                                <Route path="education" element={<EducationStep resumeData={resumeData} updateResumeData={updateResumeData} />} />
                                <Route path="skills" element={<SkillsStep resumeData={resumeData} updateResumeData={updateResumeData} />} />
                                <Route path="languages" element={<LanguagesStep resumeData={resumeData} updateResumeData={updateResumeData} />} />
                                <Route path="summary" element={<SummaryStep resumeData={resumeData} updateResumeData={updateResumeData} />} />
                                <Route path="" element={<HeadingStep resumeData={resumeData} updateResumeData={updateResumeData} />} />
                            </Routes>
                        </div>
                    </div>

                    {/* Navigation Footer - Sticky at bottom with shadow */}
                    <div className="sticky bottom-0 bg-white border-t border-slate-200 px-4 md:px-6 py-3 md:py-4 flex-shrink-0 z-30 shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
                        <div className="flex justify-between items-center max-w-4xl mx-auto">
                            {/* Left side - Progress indicator - Hidden on mobile */}
                            <div className="hidden md:flex items-center space-x-3">
                                <div className="text-xs text-slate-600">{t('BuildResume.progress.step', { current: currentStepIndex + 1, total: steps.length })}</div>
                                <div className="flex items-center space-x-1">
                                    {steps.map((_, index) => (
                                        <div key={index} className={`w-1.5 h-1.5 rounded-full transition-all duration-200 ${index <= currentStepIndex ? 'bg-blue-500' : 'bg-slate-200'}`} />
                                    ))}
                                </div>
                            </div>

                            {/* Mobile progress indicator */}
                            <div className="md:hidden flex items-center space-x-2">
                                <span className="text-xs font-medium text-slate-600">
                                    {currentStepIndex + 1}/{steps.length}
                                </span>
                                <div className="flex items-center space-x-1">
                                    {steps.map((_, index) => (
                                        <div key={index} className={`w-2 h-2 rounded-full transition-all duration-200 ${index <= currentStepIndex ? 'bg-blue-500' : 'bg-slate-200'}`} />
                                    ))}
                                </div>
                            </div>

                            {/* Right side - Action buttons */}
                            <div className="flex items-center gap-2">
                                {/* Previous Button */}
                                <button
                                    onClick={handlePrevious}
                                    disabled={currentStepIndex === 0}
                                    className="flex items-center px-2 md:px-3 py-2 border border-slate-300 text-slate-700 font-medium hover:bg-slate-50 hover:border-slate-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 text-xs rounded-lg">
                                    <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                                    </svg>
                                    <span className="hidden sm:inline">{t('BuildResume.navigation.previous')}</span>
                                </button>

                                {/* AI Import Resume Button */}
                                {isImportEnabled && (
                                    <button
                                        onClick={() => setShowImportModal(true)}
                                        className="flex items-center px-2.5 md:px-3 py-2 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-300 text-purple-700 font-semibold hover:bg-purple-100 hover:border-purple-400 transition-all duration-200 text-xs rounded-lg shadow-sm">
                                        <svg className="w-3.5 h-3.5 mr-1 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                                        </svg>
                                        Import Resume
                                    </button>
                                )}

                                {/* Mobile Menu and Preview buttons - Only on mobile */}
                                <button
                                    onClick={() => setIsMobileMenuOpen(true)}
                                    className="md:hidden flex items-center px-2 py-2 border border-slate-300 text-slate-700 font-medium hover:bg-slate-50 hover:border-slate-400 transition-all duration-200 text-xs rounded-lg">
                                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                                    </svg>
                                </button>

                                <button
                                    onClick={() => setIsMobilePreviewOpen(true)}
                                    className="md:hidden flex items-center px-2 py-2 border border-slate-300 text-slate-700 font-medium hover:bg-slate-50 hover:border-slate-400 transition-all duration-200 text-xs rounded-lg">
                                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                </button>

                                {/* Desktop Preview Button */}
                                <button
                                    onClick={() => setShowPreview(true)}
                                    className="hidden md:flex items-center px-3 py-2 border border-blue-300 text-blue-700 font-medium hover:bg-blue-50 hover:border-blue-400 transition-all duration-200 text-xs rounded-lg">
                                    <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                            strokeWidth={2}
                                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                                        />
                                    </svg>
                                    {t('BuildResume.navigation.preview')}
                                </button>

                                {/* Download Button */}
                                <button
                                    onClick={handleDownload}
                                    disabled={isDownloading}
                                    className={`flex items-center px-2 md:px-3 py-2 font-medium transition-all duration-200 text-xs rounded-lg ${
                                        isDownloading
                                            ? 'border border-slate-300 text-slate-400 cursor-not-allowed'
                                            : 'border border-emerald-300 text-emerald-700 hover:bg-emerald-50 hover:border-emerald-400'
                                    }`}>
                                    {isDownloading ? (
                                        <>
                                            <div className="w-3 h-3 border-2 border-slate-400 border-t-transparent rounded-full animate-spin mr-1"></div>
                                            <span className="hidden sm:inline">{t('BuildResume.navigation.downloading')}</span>
                                        </>
                                    ) : (
                                        <>
                                            <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                                />
                                            </svg>
                                            <span className="hidden sm:inline">{t('BuildResume.navigation.download')}</span>
                                        </>
                                    )}
                                </button>

                                {/* Next/Complete Button */}
                                {currentStepIndex < steps.length - 1 ? (
                                    <button
                                        onClick={handleNext}
                                        className="flex items-center px-3 md:px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 text-xs shadow-md hover:shadow-lg">
                                        <span className="hidden sm:inline">{t('BuildResume.navigation.nextStep', { stepName: steps[currentStepIndex + 1]?.name })}</span>
                                        <span className="sm:hidden">Next</span>
                                        <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                        </svg>
                                    </button>
                                ) : (
                                    <button
                                        onClick={handleCompleteResume}
                                        className="flex items-center px-3 md:px-4 py-2 bg-gradient-to-r from-emerald-600 to-green-600 text-white rounded-lg font-semibold hover:from-emerald-700 hover:to-green-700 transition-all duration-200 text-xs shadow-md hover:shadow-lg">
                                        <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                        </svg>
                                        <span className="hidden sm:inline">{t('BuildResume.navigation.complete')}</span>
                                        <span className="sm:hidden">Done</span>
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right Sidebar - Resume Preview - Improved Desktop Support */}
            <div className="hidden lg:flex w-80 bg-white border-l border-slate-200 flex-col min-h-screen flex-shrink-0">
                {/* Simplified Header Section */}
                <div className="px-4 py-4 border-b border-slate-100 flex-shrink-0">
                    <div className="flex items-center justify-between">
                        <div>
                            <h3 className="text-sm font-semibold text-slate-900">{t('BuildResume.preview.livePreview')}</h3>
                            <p className="text-xs text-slate-600 mt-1">{getTemplateName(currentTemplate)}</p>
                        </div>
                        <div className="flex items-center space-x-1">
                            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                            <span className="text-xs text-slate-600">{t('BuildResume.preview.autoUpdating')}</span>
                        </div>
                    </div>
                </div>

                {/* Resume Preview - Scrollable */}
                <div className="flex-1 px-4 py-4 overflow-y-auto">
                    {/* Preview Window */}
                    <div className="bg-white border-2 border-slate-200 rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                        {/* Enhanced Preview Header */}
                        <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-3 py-2.5 flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                                <div className="flex space-x-1">
                                    <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                                    <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                                </div>
                                <div className="text-white text-xs font-medium ml-2">{t('BuildResume.preview.resumePdf')}</div>
                            </div>
                        </div>

                        {/* Resume Content with Loading State - A4 Proportion Container */}
                        <div className="relative aspect-[1/1.414] w-full overflow-hidden bg-gradient-to-br from-slate-50 to-gray-50">
                            {/* Loading Overlay for better UX */}
                            <div className="absolute inset-0 bg-white bg-opacity-50 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                                <div onClick={() => setShowPreview(true)} className="cursor-pointer bg-white px-3 py-2 rounded-lg shadow-lg border">
                                    <span className="text-xs text-slate-600">{t('BuildResume.preview.clickToView')}</span>
                                </div>
                            </div>

                            <div
                                className="cursor-pointer transition-transform duration-200 group-hover:scale-105"
                                onClick={() => setShowPreview(true)}
                                style={{ transform: 'scale(0.35)', transformOrigin: 'top left', width: '285%', height: '285%' }}>
                                {(() => {
                                    try {
                                        const TemplateComponent = getTemplateComponent(currentTemplate);
                                        return <TemplateComponent values={getPreviewData()} language={i18n.language} />;
                                    } catch (error) {
                                        console.error('Error rendering template:', error);
                                        return (
                                            <div className="flex items-center justify-center h-full bg-gray-100 text-gray-500">
                                                <div className="text-center">
                                                    <div className="text-sm">{t('BuildResume.errors.templateError')}</div>
                                                    <div className="text-xs mt-1">{t('BuildResume.errors.usingDefault')}</div>
                                                </div>
                                            </div>
                                        );
                                    }
                                })()}
                            </div>
                        </div>

                        {/* Progress indicator */}
                        <div className="bg-gradient-to-r from-slate-50 to-blue-50 px-3 py-2 border-t border-slate-200">
                            <div className="flex items-center justify-between text-xs">
                                <span className="text-slate-600">{t('BuildResume.progress.completeness')}</span>
                                <span className="text-blue-600 font-semibold">{progressPercentage}%</span>
                            </div>
                            <div className="mt-1 w-full bg-slate-200 rounded-full h-1 overflow-hidden">
                                <div className="bg-gradient-to-r from-blue-500 to-purple-500 h-1 rounded-full transition-all duration-500 ease-out" style={{ width: `${progressPercentage}%` }}></div>
                            </div>
                        </div>
                    </div>

                    {/* Enhanced Action Buttons */}
                    <div className="mt-4 space-y-2">
                        <button
                            onClick={() => setShowTemplateSelection(true)}
                            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2.5 px-4 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-md hover:shadow-lg text-sm flex items-center justify-center space-x-2">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                                />
                            </svg>
                            <span>{t('BuildResume.preview.changeTemplate')}</span>
                        </button>
                        <button
                            onClick={() => setShowPreview(true)}
                            className="w-full border border-slate-300 text-slate-700 py-2.5 px-4 rounded-lg font-medium hover:bg-slate-50 hover:border-slate-400 transition-all duration-200 text-sm flex items-center justify-center space-x-2">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                                />
                            </svg>
                            <span>{t('BuildResume.preview.viewFullSize')}</span>
                        </button>
                        <button
                            onClick={handleManualSave}
                            disabled={isManualSaving}
                            className={`w-full py-2.5 px-4 rounded-lg font-semibold transition-all duration-200 shadow-md text-sm flex items-center justify-center space-x-2 ${
                                saveSuccessMsg
                                    ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                                    : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-600 hover:to-teal-700 hover:shadow-lg'
                            }`}>
                            {isManualSaving ? (
                                <>
                                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <span>Saving Resume State...</span>
                                </>
                            ) : saveSuccessMsg ? (
                                <>
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                    </svg>
                                    <span>Resume Saved Completely!</span>
                                </>
                            ) : (
                                <>
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                                    </svg>
                                    <span>Save Resume State</span>
                                </>
                            )}
                        </button>
                        {isImportEnabled && (
                            <button
                                onClick={() => setShowImportModal(true)}
                                className="w-full border border-purple-300 text-purple-700 py-2.5 px-4 rounded-lg font-medium hover:bg-purple-50 hover:border-purple-400 transition-all duration-200 text-sm flex items-center justify-center space-x-2">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                                </svg>
                                <span>{t('BuildResume.preview.importResume')}</span>
                            </button>
                        )}
                    </div>
                </div>

                {/* Enhanced Footer */}
                <div className="px-4 py-4 bg-white border-t border-slate-200 flex-shrink-0">
                    <div className="text-center">
                        <div className="flex items-center justify-center mb-2">
                            <div className="flex items-center space-x-1 bg-amber-50 px-2.5 py-1.5 rounded-full border border-amber-200/80">
                                <div className="flex text-amber-400">
                                    {[...Array(5)].map((_, i) => (
                                        <svg key={i} className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                                        </svg>
                                    ))}
                                </div>
                                <span className="text-sm font-bold text-slate-800 ml-1">4.9/5</span>
                            </div>
                        </div>
                        <p className="text-sm text-slate-700 font-semibold">{t('BuildResume.preview.trustedBy')}</p>
                        <p className="text-xs text-slate-500 mt-1">{t('BuildResume.preview.joinSuccess')}</p>
                    </div>
                </div>
            </div>

            {/* Modal Components */}
            <PreviewModal
                showPreview={showPreview}
                setShowPreview={setShowPreview}
                resumeData={getPreviewData()}
                onDownload={handleDownload}
                isDownloading={isDownloading}
                currentTemplate={currentTemplate}
                getTemplateComponent={getTemplateComponent}
                getTemplateName={getTemplateName}
            />

            <TemplateSelectionModal
                showModal={showTemplateSelection}
                setShowModal={setShowTemplateSelection}
                currentTemplate={currentTemplate}
                onTemplateSelect={handleTemplateSelect}
                resumeData={getPreviewData()}
            />

            <ResumeImportModal
                isOpen={showImportModal}
                onClose={() => setShowImportModal(false)}
                onImportData={(data) => {
                    updateResumeData(data);
                    showToast('Success');
                }}
            />
        </div>
    );
};

export default BuildResume;
