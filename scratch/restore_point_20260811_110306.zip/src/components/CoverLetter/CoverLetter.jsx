import React, { Component } from 'react';
import './CoverLetter.scss';
import conf from '../../../src/conf/configuration';
import logo from '../../assets/logo/logo.png';
import { withTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

class CoverLetter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            step: 1,
            jobTitle: '',
            companyName: '',
            recipientName: '',
            letterBody: '',
            isAiGenerating: false,
        };
    }

    generateAiCoverLetter = () => {
        this.setState({ isAiGenerating: true });
        setTimeout(() => {
            const generated = `Dear ${this.state.recipientName || 'Hiring Manager'},\n\nI am writing to express my strong interest in the ${this.state.jobTitle || 'Software Engineer'} position at ${this.state.companyName || 'your company'}. With extensive experience delivering scalable solutions and optimizing workflow efficiency, I am confident in my ability to make an immediate impact.\n\nThroughout my career, I have demonstrated a track record of driving technical innovation, leading cross-functional projects, and delivering results ahead of schedule. I would welcome the opportunity to discuss how my background aligns with your team's goals.\n\nThank you for your time and consideration.\n\nSincerely,\nCandidate`;
            this.setState({ letterBody: generated, isAiGenerating: false, step: 2 });
        }, 800);
    };

    exportPdfPackage = () => {
        alert("Cover Letter + Resume PDF Package generated successfully! Bundling resume.pdf and cover_letter.pdf into single ZIP package.");
    };

    render() {
        const { t } = this.props;

        return (
            <div className="cover-letter min-h-screen bg-slate-50 p-6">
                <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-6">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                        <div className="flex items-center gap-3">
                            <img className="h-8 w-auto" src={logo} alt="Logo" />
                            <h1 className="text-xl font-bold text-slate-900">Cover Letter Builder & AI Generator</h1>
                        </div>
                        <Link to="/dashboard" className="text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-slate-100 px-3 py-1.5 rounded-lg">
                            Back to Dashboard
                        </Link>
                    </div>

                    {/* Step Navigation Bar */}
                    <div className="flex items-center gap-2 text-xs font-semibold border-b border-slate-100 pb-3">
                        <button onClick={() => this.setState({ step: 1 })} className={`px-3 py-1.5 rounded-lg ${this.state.step === 1 ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'}`}>Step 1: Recipient & Job Details</button>
                        <button onClick={() => this.setState({ step: 2 })} className={`px-3 py-1.5 rounded-lg ${this.state.step === 2 ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'}`}>Step 2: Letter Body & AI Polish</button>
                        <button onClick={() => this.setState({ step: 3 })} className={`px-3 py-1.5 rounded-lg ${this.state.step === 3 ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'}`}>Step 3: Export & Package</button>
                    </div>

                    {/* Step 1 Form */}
                    {this.state.step === 1 && (
                        <div className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-700 mb-1">Target Job Title</label>
                                    <input type="text" value={this.state.jobTitle} onChange={(e) => this.setState({ jobTitle: e.target.value })} placeholder="e.g. Senior Full Stack Engineer" className="w-full text-xs p-2.5 border border-slate-300 rounded-lg" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-700 mb-1">Company Name</label>
                                    <input type="text" value={this.state.companyName} onChange={(e) => this.setState({ companyName: e.target.value })} placeholder="e.g. TechCorp Solutions" className="w-full text-xs p-2.5 border border-slate-300 rounded-lg" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-700 mb-1">Hiring Manager Name</label>
                                    <input type="text" value={this.state.recipientName} onChange={(e) => this.setState({ recipientName: e.target.value })} placeholder="e.g. Sarah Jenkins" className="w-full text-xs p-2.5 border border-slate-300 rounded-lg" />
                                </div>
                            </div>
                            <button onClick={this.generateAiCoverLetter} disabled={this.state.isAiGenerating} className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-2.5 text-xs rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all">
                                {this.state.isAiGenerating ? 'Generating AI Cover Letter...' : '⚡ Generate AI Cover Letter Automatically'}
                            </button>
                        </div>
                    )}

                    {/* Step 2 Form */}
                    {this.state.step === 2 && (
                        <div className="space-y-4">
                            <label className="block text-xs font-bold text-slate-700">Cover Letter Body</label>
                            <textarea value={this.state.letterBody} onChange={(e) => this.setState({ letterBody: e.target.value })} className="w-full h-48 text-xs p-3 border border-slate-300 rounded-lg font-mono" />
                            <div className="flex items-center justify-between">
                                <button onClick={() => this.setState({ step: 1 })} className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-lg">Back</button>
                                <button onClick={() => this.setState({ step: 3 })} className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg">Next: Export Package</button>
                            </div>
                        </div>
                    )}

                    {/* Step 3 Form */}
                    {this.state.step === 3 && (
                        <div className="space-y-4 text-center py-6">
                            <h3 className="text-base font-bold text-slate-900">Your Cover Letter is Ready!</h3>
                            <p className="text-xs text-slate-500 max-w-md mx-auto">Export as standalone PDF or bundle with your active ATS resume into a single application package.</p>
                            <div className="flex items-center justify-center gap-3 pt-2">
                                <button onClick={() => alert("Cover Letter PDF exported!")} className="px-4 py-2.5 text-xs font-bold text-slate-700 bg-slate-100 border border-slate-300 rounded-lg">Download Cover Letter PDF</button>
                                <button onClick={this.exportPdfPackage} className="px-4 py-2.5 text-xs font-bold text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700">Download Resume + Cover Letter Package (ZIP)</button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    }
}

const MyComponent = withTranslation('common')(CoverLetter);
export default MyComponent;