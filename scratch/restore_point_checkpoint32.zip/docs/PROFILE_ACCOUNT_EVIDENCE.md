# Profile and account lifecycle evidence

Audited from the protected Admin baseline `87bac0b` against reachable history through `4a24231`, `d8e016b`, `d04ad53`, and the current native Firebase MFA architecture.

## OLD vs CURRENT

| Area | Previous behavior | Current behavior |
|---|---|---|
| Profile persistence | Profile reads and writes used read-then-unawaited-set operations. Manual save always displayed success; autosave failures only reached console; stale tabs overwrote each other. Save & Next advanced even when saving failed. | Canonical nested `users/{uid}.profile` remains unchanged. Saves are bounded transactional writes with monotonic revisions and `PROFILE_CONFLICT`. UI exposes loading, pending, saving, saved, failed, and conflict states; autosave pauses on conflict; explicit load-latest/overwrite recovery is available; Save & Next advances only after durable success. |
| Profile data | Legacy aliases and rich profile sections were preserved but unbounded and malformed arrays could enter persistence. | Shared normalization preserves Unicode and all legitimate basic, experience, education, skill, language, certification, project, social, summary, and legacy alias fields with generous bounds and Firestore-size checks. It does not synchronize profile edits destructively into customized resumes. |
| Avatar | Any `image/*` file was read and the cropped data was shown optimistically before an unawaited Firestore write. MIME/size/storage failures looked successful. | Input accepts PNG/JPEG/WebP only, rejects files over 5 MB before reading, and persists only bounded raster data URLs or safe HTTPS/site paths. The avatar changes only after transactional revision-aware success; failures/conflicts remain visible and retryable. |
| Verification/MFA truth | The hero always displayed a “Verified User” badge. | Verification badges derive only from Firebase Auth `emailVerified`. MFA state derives only from native Firebase enrolled factors; native TOTP enroll/verify/challenge/remove behavior remains protected and no browser/Firestore MFA secret was introduced. |
| Preferences | No coherent account-scoped language, notification, product-update, or profile-discovery save workflow existed. | Preferences have an explicit save action, field allowlist, revision conflict checks, Firestore rule bounds, account-switch reset, and intentional separation from analytics consent, entitlements, and payment state. Saved language uses the existing i18n runtime. |
| Credential changes | Email changed in Firebase Auth, then Firestore email synchronization failure was swallowed. Password UI accepted eight characters while reset policy requires twelve. | Email reauthentication/native update is followed by forced token refresh and an ownership-bound Firestore email update whose failure is reported. Password UX requires at least 12 characters. Existing provider reauthentication and Firebase password behavior remain intact. |
| Account switching | Component state relied on normal unmount behavior only; the dashboard synthesized `active_user`/`guest_user`, authenticated routes could render without a session, delayed account-A membership/profile work could populate account B, and legacy CacheStorage/recovery records survived logout. | Auth-state identity is observed directly. A UID change clears account browser/session/cache state, remounts account-sensitive route roots, resets dashboard/builder state, invalidates delayed account-A work, and keeps recovery keys UID-scoped while deleting them on logout. Dashboard/Admin/editor/export routes require an authenticated Firebase session in the router; guest resume building remains available on its historical public routes. |
| Data export | “Complete” export omitted Portfolio, CMS, jobs, companies, applications, messaging, recovery-era cover data, Job Tracker, notifications, login history, and nested billing records. | Export is forced to the active Firebase UID and includes browser-readable profile/resume/legacy-cover/cover-letter/Portfolio/CMS/employer/job/application/transaction/Job Tracker/notification/login-history/messaging data. Unavailable sections are listed in `exportWarnings`; provider-held or legally retained records still identify required support/provider channels. |
| Account deletion | User profile was deleted first; related cleanup failures were swallowed; CMS/employer/job/messaging data could remain; UI claimed all personal/subscription data was purged. | Cleanup covers profile tree, resumes/covers, Portfolio/public Portfolio, CMS posts, companies, jobs, applicant-owned applications, employer application, notifications, and Realtime messaging. Deleted-user messages and indexes are removed while the other participant's own messages remain under an anonymized participant marker. Employer deletion preserves applicants' application history/job snapshot instead of deleting another account's record. Partial cleanup is audited and fails closed before self-service identity deletion where possible. Success names retained payment, invoice, transaction, subscription, and security-audit record types. |
| Accessibility | Critical deletion and MFA modals lacked dialog semantics and Escape handling; transient save feedback was not announced. | Save feedback uses live regions; deletion and MFA flows use labelled modal semantics, safe initial focus, Escape handling, and truthful disabled/loading states. |

## Performance and integrity

- Profile save changed from one read plus an unawaited write to one Firestore transaction, preserving the same order of database operations while adding atomic stale protection.
- Autosave remains a 1.5-second idle debounce and does not add polling.
- Durable save updates are skipped by the autosave observer, preventing duplicate revision writes.
- Account load still parallelizes profile and account/security information and now clears prior-account state before either result can render.
- Logout and direct UID transitions remove fixed account keys, UID-scoped resume recovery, session payment/audit context, and legacy service-worker caches while retaining language, consent, and public metadata preferences.
- Legacy board saves now capture the verified Firebase UID and resume ID before delayed work; an A-to-B transition invalidates that work instead of resolving identity from mutable local storage.
- Avatar validation rejects oversized input before FileReader/crop work.

## Security preserved/improved

- Native Firebase Auth, provider reauthentication, TOTP MFA, OAuth, ownership rules, recent-auth deletion, analytics consent, payment authority, and AI boundaries were not replaced.
- Profile and preference writes remain owner-only.
- Email synchronization requires a refreshed Firebase token whose verified email matches the requested Firestore email.
- Avatar validation uses MIME/data signatures and bounded content, never filename extensions.
- Financial and security records are retained explicitly rather than silently deleted or exposed.

## Remaining external validation

- Firebase Identity Platform staging is required for end-to-end TOTP enrollment, sign-in challenge expiry/lost-device behavior, provider popup reauthentication, email-update verification behavior, and a browser-observed A logout → B login journey. Route/storage/listener isolation is statically and deterministically tested here, but requires browser validation for visual/transient-state confirmation.
- Live Storage is not used by the existing avatar design; avatars remain bounded profile data URLs. A future object-storage migration needs signed upload, MIME/dimension scanning, replacement cleanup, and private-object authorization.
- Account deletion cannot atomically combine Firebase Auth, Firestore, and Realtime Database. Partial cleanup and rare identity-delete failure are audited and direct the user to retry/support; staging must validate recovery behavior and messaging redaction at realistic scale.
- Exact legal retention periods for billing/security records require business/legal policy and production lifecycle jobs.
