import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// https://vite.dev/config/
export default defineConfig({
    plugins: [tailwindcss(), react()],
    build: {
        rollupOptions: {
            input: {
                main: 'index.html',
                lab: 'template-lab/index.html',
            },
            output: {
                entryFileNames: 'assets/index-[hash].js',
                chunkFileNames: 'assets/[name]-[hash].js',
                assetFileNames: 'assets/[name]-[hash].[ext]',
            },
        },
    },
    css: {
        preprocessorOptions: {
            scss: {
                // Ensure SASS files are processed correctly
                api: 'modern-compiler',
            },
        },
    },
    resolve: {
        // Add common extensions for better compatibility
        extensions: ['.js', '.jsx', '.ts', '.tsx', '.json', '.scss', '.css'],
    },
    server: {
        host: true,
        allowedHosts: true, // Arena/live-preview hosts are dynamic; this affects the development server only.
        port: 3000,
        strictPort: false,   // Allow fallback to other ports if 5173 is busy
        historyApiFallback: true,
        proxy: {
            '/api': {
                target: process.env.VITE_DEV_BACKEND_URL || 'http://localhost:8080',
                changeOrigin: false,
            },
        },
    },
});
